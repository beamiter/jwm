"""Identify the DRM FD returned by DRI3 on the caller's private X11 display."""
import ctypes as c
import json
import os
import stat
import sys


class Screen(c.Structure):
    _fields_ = [('root', c.c_uint32)]


class ScreenIterator(c.Structure):
    _fields_ = [('data', c.POINTER(Screen)), ('remaining', c.c_int), ('index', c.c_int)]


class OpenCookie(c.Structure):
    _fields_ = [('sequence', c.c_uint)]


class OpenReply(c.Structure):
    _fields_ = [('response_type', c.c_uint8), ('nfd', c.c_uint8)]


def bind(library, name, arguments, result):
    method = getattr(library, name)
    method.argtypes = arguments
    method.restype = result
    return method


def main():
    xcb = c.CDLL('libxcb.so.1')
    dri3 = c.CDLL('libxcb-dri3.so.0')
    libc = c.CDLL('libc.so.6')
    pointer = c.c_void_p
    connect = bind(xcb, 'xcb_connect', [c.c_char_p, c.POINTER(c.c_int)], pointer)
    has_error = bind(xcb, 'xcb_connection_has_error', [pointer], c.c_int)
    get_setup = bind(xcb, 'xcb_get_setup', [pointer], pointer)
    get_roots = bind(xcb, 'xcb_setup_roots_iterator', [pointer], ScreenIterator)
    next_screen = bind(xcb, 'xcb_screen_next', [c.POINTER(ScreenIterator)], None)
    open_device = bind(dri3, 'xcb_dri3_open', [pointer, c.c_uint32, c.c_uint32], OpenCookie)
    get_reply = bind(dri3, 'xcb_dri3_open_reply', [pointer, OpenCookie, c.POINTER(pointer)],
                     c.POINTER(OpenReply))
    reply_fds = bind(dri3, 'xcb_dri3_open_reply_fds', [pointer, c.POINTER(OpenReply)],
                     c.POINTER(c.c_int))
    disconnect = bind(xcb, 'xcb_disconnect', [pointer], None)
    free = bind(libc, 'free', [pointer], None)
    screen = c.c_int()
    conn = connect(sys.argv[1].encode('ascii'), c.byref(screen))
    if not conn:
        raise RuntimeError('cannot allocate private XCB connection')
    try:
        if has_error(conn):
            raise RuntimeError('cannot connect to private X11 display')
        screens = get_roots(get_setup(conn))
        if not 0 <= screen.value < screens.remaining:
            raise RuntimeError('private X11 display supplied no matching root')
        for _ in range(screen.value):
            next_screen(c.byref(screens))
        error = pointer()
        reply = get_reply(conn, open_device(conn, screens.data.contents.root, 0), c.byref(error))
        try:
            if not reply:
                raise RuntimeError('private DRI3 server rejected its default-provider Open')
            count = reply.contents.nfd
            fds = reply_fds(conn, reply)
            received = [fds[index] for index in range(count)] if fds else []
            try:
                if len(received) != 1:
                    raise RuntimeError(f'unexpected private DRI3 descriptor count: {len(received)}')
                fd = received[0]
                info = os.fstat(fd)
                if not stat.S_ISCHR(info.st_mode):
                    raise RuntimeError('private DRI3 FD is not a DRM device')
                print(json.dumps({'path': os.readlink(f'/proc/self/fd/{fd}'),
                                  'major': os.major(info.st_rdev), 'minor': os.minor(info.st_rdev)}))
            finally:
                for fd in received:
                    os.close(fd)
        finally:
            free(reply)
            free(error)
    finally:
        disconnect(conn)


if __name__ == '__main__':
    main()
