#!/usr/bin/env python3
"""Observe native X11 lifetime, resize and source switch on owned displays."""
import argparse
from contextlib import ExitStack
import json
import os
from pathlib import Path
import re
import selectors
import signal
import socket
import struct
import subprocess
import time

from Xlib import X, display, ext, xauth
from pixels import Pixels
from processes import clean_env, get_display, sha256, start_display, stop


FULL = (3840, 2160)
SMALL = (1297, 973)
SECOND = (1920, 1080)
COLORS = (((214, 49, 32), (181, 62, 139), (87, 174, 45), (224, 164, 69)),
          ((34, 159, 92), (47, 118, 201), (67, 153, 174), (75, 191, 211)))
LIBS = '/tmp/jwm-remote-ffmpeg/usr/lib/x86_64-linux-gnu'
PICTURE = 'x11_picture_setup_ms'
SYNC = 'rgb_target_allocation_ms'
PREFETCH = 'x11_prefetch_rgb_allocation_ms'
IMPORT = 'x11_dmabuf_import_ms'


def require(condition, why):
    if not condition:
        raise RuntimeError(why)


def wait_for(label, actors, read, duration=15):
    until = time.monotonic() + duration
    while time.monotonic() < until:
        for actor in actors:
            require(actor.poll() is None, f'{label}: owned actor ended ({actor.returncode})')
        if found := read():
            return found
        time.sleep(.02)
    raise TimeoutError(label)


def rows(path, kind=None):
    parsed = [json.loads(line) for line in path.read_bytes().splitlines(keepends=True)
              if line.startswith(b'{') and line.endswith(b'\n')]
    return [record for record in parsed if kind is None or record.get('type') == kind]


def paint(conn, size, colors):
    root = conn.screen().root
    width, height = size
    gc = root.create_gc()
    for idx, (red, green, blue) in enumerate(colors):
        gc.change(foreground=(red << 16) | (green << 8) | blue)
        root.fill_rectangle(gc, idx % 2 * width // 2, idx // 2 * height // 2, width // 2, height // 2)
    gc.free()
    root.warp_pointer(3839, 2159)
    conn.sync()


def local_authority(ready):
    # Python Xlib only finds an exact family/address match. Copy the owned
    # launcher's one already-authenticated cookie to a private FamilyLocal row.
    launch_auth = Path(ready['xauthority'])
    [(_, _, number, name, cookie)] = xauth.Xauthority(str(launch_auth)).entries
    private_auth = launch_auth.with_name('python-local.authority')
    with os.fdopen(os.open(private_auth, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600), 'wb') as stream:
        stream.write(struct.pack('!H', xauth.FamilyLocal))
        for item in (socket.gethostname().encode(), number, name, cookie):
            stream.write(struct.pack('!H', len(item)) + item)
    return str(private_auth)


def window(conn):
    for candidate in conn.screen().root.query_tree().children:
        title = candidate.get_wm_name()
        if isinstance(title, str) and 'JWM Remote' in title:
            return candidate
    return None


def dimensions(drawable):
    result = drawable.get_geometry()
    return result.width, result.height


def sample(pixels, xid, x, y):
    blue, green, red, _ = pixels.crop(xid, x, y, 1, 1)[0]
    return red, green, blue


def probe(drawable, pixels, target, colors):
    if dimensions(drawable) != target:
        return None
    width, height = target
    extent_width = min(width, height * 16 // 9)
    extent_height = min(height, width * 9 // 16)
    left, top = (width - extent_width) // 2, (height - extent_height) // 2
    rgb = [sample(pixels, drawable.id, left + extent_width * x // 4, top + extent_height * y // 4)
           for x, y in ((1, 1), (3, 1), (1, 3), (3, 3))]
    if any(max(abs(a-b) for a,b in zip(actual, expected)) > 17 for actual, expected in zip(rgb, colors)):
        return None
    black = []
    if top:
        black = [sample(pixels, drawable.id, x, y) for y in (top // 2, height - top // 2 - 1)
                 for x in (width // 8, width // 2, width * 7 // 8)]
        if any(any(pixel) for pixel in black):
            return None
    return {'size': target, 'content': [left, top, extent_width, extent_height], 'rgb': rgb, 'bar_rgb': black}


def stage_count(reports, name):
    return sum(row.get('native_x11_stages', {}).get(name, {}).get('observations', 0) for row in reports)


def run(args):
    directory = args.out
    directory.mkdir(mode=0o700)
    require(sha256(args.binary) == args.binary_sha256, 'release pin differs')
    require(sha256(args.harness) == args.harness_sha256, 'harness pin differs')
    env = clean_env()
    for key in ('XAUTHORITY', 'LD_PRELOAD', 'GBM_BACKEND', 'LIBGL_ALWAYS_SOFTWARE'):
        env.pop(key, None)
    env.update(LD_LIBRARY_PATH=LIBS, XDG_CACHE_HOME=str(directory / 'cache'))
    env['__EGL_VENDOR_LIBRARY_FILENAMES'] = '/usr/share/glvnd/egl_vendor.d/50_mesa.json'
    key = directory / 'private.key'
    host_path, viewer_path, events = directory / 'host.log', directory / 'viewer.log', directory / 'events.jsonl'
    result = {'release_sha256': args.binary_sha256, 'fixture_sha256': args.harness_sha256, 'samples': {}}
    with ExitStack() as closed:
        closed.callback(key.unlink, missing_ok=True)
        def log(path):
            return closed.enter_context(path.open('wb'))
        xwayland = subprocess.Popen(['python3', '-B', Path(__file__).with_name('launch.py'),
                                     '--harness', args.harness, '--harness-sha256', args.harness_sha256,
                                     '--doctor', args.binary, '--doctor-sha256', args.binary_sha256,
                                     '--out', directory / 'display-proof'], env=env, stdin=subprocess.PIPE,
                                     stdout=subprocess.PIPE, stderr=log(directory / 'launcher.log'))
        closed.callback(stop, xwayland, True)
        with selectors.DefaultSelector() as poll:
            poll.register(xwayland.stdout, selectors.EVENT_READ)
            require(poll.select(25), 'owned Intel display readiness timeout')
            ready = json.loads(xwayland.stdout.readline())
        require(ready['size'] == list(FULL), 'wrong initial Xwayland mode')
        viewer_env = env | {'DISPLAY':ready['display'], 'XAUTHORITY':ready['xauthority'],
                            'JWM_REMOTE_GPU_PRESENT':ready['render_node'], 'JWM_REMOTE_X11_LAZY_PICTURE':'1'}
        if args.prefetch:
            viewer_env['JWM_REMOTE_X11_PREFETCH_TARGET'] = '1'
        xvfb = start_display(*FULL, stderr=log(directory / 'source-xvfb.log'))
        closed.callback(stop, xvfb)
        observers = closed.enter_context(ExitStack())
        source_display = get_display(xvfb)
        source = display.Display(source_display)
        observers.callback(source.close)
        os.environ['XAUTHORITY'] = local_authority(ready)
        # This observer uses only core X11. Python Xlib's RANDR extension
        # event registration collides with Xwayland's event table.
        ext.__extensions__ = []
        local = display.Display(ready['display'])
        observers.callback(local.close)
        pixels = Pixels(ready['display'])
        observers.callback(pixels.close)
        paint(source, FULL, COLORS[0])
        subprocess.run([args.binary, 'keygen', '--output', key], check=True, stdout=subprocess.DEVNULL, env=env, timeout=6)
        host = subprocess.Popen([args.binary, 'host', '--once', '--display', source_display, '--listen', '127.0.0.1:0',
                                 '--key-file', key, '--capture-source', 'root', '--share-region', '1920x1080+0+0',
                                 '--fps', '15', '--scaling', 'auto', '--max-width', '0',
                                 '--allow-h264', '--stats-json'], env=env, stdin=subprocess.DEVNULL,
                                stdout=log(host_path), stderr=subprocess.STDOUT)
        closed.callback(stop, host)
        listener = wait_for('owned local host listener', [host], lambda: re.search(r'listening on (127\.0\.0\.1:\d+)', host_path.read_text()))[1]
        viewer = subprocess.Popen([args.binary, 'session', listener, '--display', ready['display'], '--key-file', key,
                                   '--scaling', 'gpu', '--window-size', '3840x2160', '--stats-json'],
                                  env=viewer_env, stdin=subprocess.PIPE, stdout=log(events), stderr=log(viewer_path))
        closed.callback(stop, viewer, True)
        actors = [host, viewer, xwayland]
        drawable = wait_for('real native viewer drawable', actors, lambda: window(local))
        result['samples']['initial'] = wait_for('initial exact native colors', actors, lambda: probe(drawable, pixels, FULL, COLORS[0]))

        def scope(epoch, shape):
            return next((row['catalog'] for row in reversed(rows(events)) if isinstance(row.get('catalog'), dict)
                         and row['catalog']['source_epoch'] == str(epoch)
                         and isinstance(row.get('metrics'), dict)
                         and (row['metrics'].get('last_decoded_frame') or {}).get('encoded_dimensions') == list(shape)
                         and row['metrics']['acked_frames'] > 0), None)

        first = wait_for('first managed scope and drawn ACK', actors, lambda: scope(1, FULL))
        before = wait_for('detailed native stages', actors, lambda: rows(viewer_path, 'jwm_remote_viewer_stats'))
        require(stage_count(before, 'x11_dmabuf_import_ms') > 0 and stage_count(before, PICTURE) == 0,
                'native-size effective lazy-picture route was not observed')
        result['initial_native_import_count'] = stage_count(before, 'x11_dmabuf_import_ms')
        result['initial_picture_setup_count'] = stage_count(before, PICTURE)
        if args.prefetch:
            first_sync, first_prefetch = stage_count(before, SYNC), stage_count(before, PREFETCH)
            require(first_sync > 0 and first_prefetch > 0 and
                    first_sync + first_prefetch == result['initial_native_import_count'],
                    'first 4K allocation was not synchronous, later candidate did not preallocate, or counts diverged')

        os.kill(host.pid, signal.SIGSTOP)
        try:
            wait_for('owned host stopped', actors,
                     lambda: Path(f'/proc/{host.pid}/stat').read_text().rsplit(')', 1)[1].split()[0] == 'T', duration=1)
            host_length = host_path.stat().st_size
            drawable.configure(width=SMALL[0], height=SMALL[1], x=0, y=0)
            local.sync()
            result['samples']['resize_retained'] = wait_for('visible smaller retained scaled frame and black bars', actors,
                                                          lambda: probe(drawable, pixels, SMALL, COLORS[0]), duration=2)
            drawable.configure(width=FULL[0], height=FULL[1], x=0, y=0)
            local.sync()
            result['samples']['restored_retained'] = wait_for('restored retained exact-size frame', actors,
                                                            lambda: probe(drawable, pixels, FULL, COLORS[0]), duration=2)
            require(host_path.stat().st_size == host_length, 'suspended host produced new telemetry')
            result['host_suspended_during_resize'] = True
        finally:
            os.kill(host.pid, signal.SIGCONT)

        [other] = [entry['source_id'] for entry in first['entries'] if entry['source_id'] != first['source_id']]
        paint(source, SECOND, COLORS[1])
        def request(record):
            viewer.stdin.write(json.dumps(record).encode() + b'\n')
            viewer.stdin.flush()
        request({'command':'select_source','request':1,'selection':{'session_id':first['session_id'],
                'source_epoch':first['source_epoch'],'source_id':other}})
        second = wait_for('second authentic source scope and drawn ACK', actors, lambda: scope(2, SECOND))
        require(second['session_id'] == first['session_id'] and second['source_id'] == other, 'scope did not transition on the same session')
        result['samples']['second_source_scaled'] = wait_for('second source scaled to actual 4K drawable', actors,
                                                            lambda: probe(drawable, pixels, FULL, COLORS[1]))
        request({'command':'disconnect','request':2})
        result['viewer_exit'] = viewer.wait(timeout=8)
        result['host_exit'] = host.wait(timeout=8)
        reports = rows(viewer_path, 'jwm_remote_viewer_stats')
        for row in reports:
            require(row['negotiated_codec'] == 'H.264' and row['native_presented'] == row['drawn']
                    and row['stages']['hardware_download_ms']['observations'] == 0, 'non-native frame, codec or download')
        result['picture_setup_count'] = stage_count(reports, PICTURE)
        if args.prefetch:
            for record in reports:
                stages = record.get('native_x11_stages', {})
                measure = lambda name: stages.get(name, {}).get('observations', 0)
                require(measure(SYNC) + measure(PREFETCH) == measure(IMPORT),
                        'an X11 native import does not have precisely one allocation observation')
            result['prefetch_target'] = {'initial_sync': first_sync, 'initial_prefetch': first_prefetch,
                                         'sync': stage_count(reports, SYNC),
                                         'prefetch': stage_count(reports, PREFETCH),
                                         'imports': stage_count(reports, IMPORT)}
        result['native_presented'] = sum(row['native_presented'] for row in reports)
        result['drawn_acks'] = sum(row['acked'] for row in reports)
        result['hardware_downloads'] = 0
        require(result['picture_setup_count'] > 0 and result['native_presented'] > 0
                and result['viewer_exit'] == result['host_exit'] == 0, 'scaled lane or close missing')
        observers.close()
        xwayland.stdin.close()
        require(xwayland.wait(timeout=10) == 0, 'owned private compositor shutdown')
        result['display_launcher_exit'] = xwayland.returncode
        result['source_epochs'] = [first['source_epoch'], second['source_epoch']]
        (directory / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps(result))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binary', type=Path, required=True)
    parser.add_argument('--binary-sha256', required=True)
    parser.add_argument('--harness', type=Path, required=True)
    parser.add_argument('--harness-sha256', required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--prefetch', action='store_true')
    run(parser.parse_args())


if __name__ == '__main__':
    main()
