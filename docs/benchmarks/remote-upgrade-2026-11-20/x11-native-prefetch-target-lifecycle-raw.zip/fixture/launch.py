#!/usr/bin/env python3
"""Keep an owned 4K Intel Xwayland display alive until stdin is closed."""
import argparse
from contextlib import ExitStack
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import selectors
import shutil
import signal
import subprocess
import sys
import tempfile
import time

from previous_probe import MESA_EGL, authority, display_number, drm_parent, stop


HARNESS_FILTER = 'remote::host::wayland_viewer_integration::host_control_integration::cli_process_integration::source_switching::gpu_4k::xwayland::serve_owned_intel_xwayland_output'
FFMPEG_LIB = '/tmp/jwm-remote-ffmpeg/usr/lib/x86_64-linux-gnu'
MODE = [3840, 2160]


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def checked(command, env, log, timeout=10):
    result = subprocess.run(command, env=env, capture_output=True, text=True, timeout=timeout)
    log.write_text(result.stdout + result.stderr)
    result.check_returncode()
    return result.stdout


def ready_when(predicate, processes, label, timeout=14):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        require(all(child.poll() is None for child in processes), f'owned process exited before {label}')
        if found := predicate():
            return found
        time.sleep(.025)
    raise RuntimeError(f'timeout waiting for {label}')


def stop_harness(child):
    if child.stdin and not child.stdin.closed:
        child.stdin.close()
    try:
        child.wait(timeout=5)
    except subprocess.TimeoutExpired:
        stop(child)


def normalized_env(node, device, private):
    scrub = {'DISPLAY', 'WAYLAND_DISPLAY', 'WAYLAND_SOCKET', 'XAUTHORITY', 'LD_PRELOAD',
             'DBUS_SESSION_BUS_ADDRESS', 'GBM_BACKEND', 'LIBGL_ALWAYS_SOFTWARE',
             'MESA_LOADER_DRIVER_OVERRIDE', 'XWAYLAND_NO_GLAMOR', 'WESTON_MODULE_MAP',
             'EGL_PLATFORM', '__EGL_VENDOR_LIBRARY_FILENAMES', '__EGL_VENDOR_LIBRARY_DIRS',
             'DRI_PRIME'}
    env = {key: value for key, value in os.environ.items()
           if key not in scrub and not key.startswith(('JWM_REMOTE_', 'JWM_TEST_'))}
    env.update(XDG_RUNTIME_DIR=str(private), XDG_CACHE_HOME=str(private / 'cache'),
               XDG_CONFIG_HOME=str(private / 'config'), XDG_DATA_HOME=str(private / 'data'),
               DRI_PRIME='pci-' + device.name.replace(':', '_').replace('.', '_'),
               __EGL_VENDOR_LIBRARY_FILENAMES=str(MESA_EGL),
               JWM_TEST_XWAYLAND_SOCKET=str(private / 'weston-free.sock'),
               JWM_TEST_XWAYLAND_REPORT=str(private / 'compositor.json'),
               JWM_TEST_XWAYLAND_RENDER_NODE=str(node))
    if Path(FFMPEG_LIB).is_dir():
        env['LD_LIBRARY_PATH'] = ':'.join(filter(None, (FFMPEG_LIB, env.get('LD_LIBRARY_PATH'))))
    return env


def launch(args, out):
    node = args.node.resolve(strict=True)
    device = drm_parent(node)
    require(node.name.startswith('renderD') and os.access(node, os.R_OK | os.W_OK), 'an accessible DRM render node is required')
    require((device / 'vendor').read_text().strip() == '0x8086', 'render node must be Intel')
    require(MESA_EGL.is_file(), 'Mesa EGL manifest is missing')
    xwayland = shutil.which('Xwayland')
    require(xwayland, 'Xwayland is required')
    harness, doctor = args.harness.resolve(strict=True), args.doctor.resolve(strict=True)
    binaries = {'harness': digest(harness), 'doctor': digest(doctor), 'xwayland': digest(Path(xwayland))}
    require(not args.harness_sha256 or binaries['harness'] == args.harness_sha256, 'harness pin differs')
    require(not args.doctor_sha256 or binaries['doctor'] == args.doctor_sha256, 'doctor pin differs')
    with tempfile.TemporaryDirectory(prefix='jwm-xwayland-runtime.', dir='/tmp') as runtime, ExitStack() as cleanup:
        private = Path(runtime)
        for name in ('cache', 'config', 'data'):
            (private / name).mkdir(mode=0o700)
        env = normalized_env(node, device, private)
        smithay_log = out / 'smithay.log'
        compositor = subprocess.Popen([harness, args.harness_filter, '--exact', '--ignored', '--nocapture', '--test-threads=1'],
                                      env=env, stdin=subprocess.PIPE, stdout=cleanup.enter_context(smithay_log.open('wb')),
                                      stderr=subprocess.STDOUT, start_new_session=True)
        cleanup.callback(stop_harness, compositor)
        socket = Path(env['JWM_TEST_XWAYLAND_SOCKET'])
        ready_when(socket.is_socket, (compositor,), 'owned Smithay socket')
        cookie = secrets.token_bytes(16)
        server_auth, client_auth = private / 'server.authority', private / 'client.authority'
        authority(server_auth, b'', cookie)
        env['WAYLAND_DISPLAY'] = socket.name
        xwayland_log = out / 'xwayland.log'
        display_server = subprocess.Popen([xwayland, '-displayfd', '1', '-nolisten', 'tcp', '-noreset',
                                          '-geometry', f'{MODE[0]}x{MODE[1]}', '-fullscreen', '-auth', server_auth],
                                         env=env, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                         stderr=cleanup.enter_context(xwayland_log.open('wb')), start_new_session=True)
        cleanup.callback(stop, display_server)
        number = display_number(display_server, xwayland_log)
        authority(client_auth, number, cookie)
        x11 = ':' + number.decode('ascii')
        env.update(DISPLAY=x11, XAUTHORITY=str(client_auth))
        screen = checked(['xdpyinfo', '-display', x11], env, out / 'xdpyinfo.log')
        for required in (r'dimensions:\s+3840x2160 pixels', r'depth of root window:\s+24 planes', r'^\s+DRI3\s*$', r'^\s+DAMAGE\s*$'):
            require(re.search(required, screen, re.MULTILINE), f'private X11 screen lacks prerequisite: {required}')
        dri3 = json.loads(checked([sys.executable, '-I', '-B', Path(__file__).with_name('dri3-node.py'), x11],
                                  env, out / 'dri3.log'))
        dri3_parent = (Path('/sys/dev/char') / f"{dri3['major']}:{dri3['minor']}" / 'device').resolve(strict=True)
        require(dri3_parent == device, f"DRI3 opened another DRM node: {dri3['path']}")
        renderer = re.search(r'JWM_NATIVE_WAYLAND_RENDERER=(.*)', smithay_log.read_text())
        require(renderer and 'intel' in renderer[1].lower(), 'owned Smithay did not initialize hardware Intel GL')
        key = private / 'doctor.key'
        checked([doctor, 'keygen', '--output', key], env, out / 'keygen.log')
        probe = checked([doctor, 'doctor', '--display', x11, '--key-file', key, '--probe-gpu-present', node],
                        env, out / 'doctor.log', timeout=18)
        require(re.search(rf'GPU present: VA-API NV12 rendered with GLES to an X11 DRI3 pixmap on {re.escape(str(node))}', probe),
                'production doctor did not prove VA-API, GLES and DRI3 pixels')
        # Exercise one committed and GPU-composed rootful frame before readiness.
        root_check = subprocess.Popen(['xmessage', '-display', x11, '-geometry', '360x240+0+0',
                                       'Owned 4K Xwayland prerequisite'], env=env, stdin=subprocess.DEVNULL,
                                      stdout=cleanup.enter_context((out / 'root-check.log').open('wb')),
                                      stderr=subprocess.STDOUT, start_new_session=True)
        cleanup.callback(stop, root_check)
        report = Path(env['JWM_TEST_XWAYLAND_REPORT'])
        rendered = ready_when(lambda: json.loads(report.read_text()) if report.exists() else None,
                              (compositor, display_server, root_check), 'actual owned output draw')
        require(rendered['render_node_device'] == node.stat().st_rdev and rendered['size'] == MODE
                and rendered['dmabuf_draws'] > 0, 'owned output did not draw an exact-size same-device DMA-BUF')
        stop(root_check)
        result = {'status': 'ready', 'screen_size': MODE, 'screen_depth': 24, 'render_node': str(node),
                  'pci_device': device.name, 'dri3': dri3, 'smithay_renderer': renderer[1],
                  'owned_output_first_draw': rendered, 'production_doctor_passed': True, 'binary_sha256': binaries}
        (out / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps({'display': x11, 'xauthority': str(client_auth), 'render_node': str(node),
                          'size': MODE, 'runtime_directory': str(private), 'evidence': str(out / 'result.json')}), flush=True)
        if not args.preflight_only:
            with selectors.DefaultSelector() as poll:
                poll.register(sys.stdin, selectors.EVENT_READ)
                while True:
                    require(compositor.poll() is None and display_server.poll() is None, 'owned display exited during use')
                    if poll.select(.1) and not os.read(sys.stdin.fileno(), 1):
                        break
        stop(display_server)
        stop_harness(compositor)
        require(compositor.returncode == 0, 'owned Smithay did not stop cleanly')
        result['owned_output_final'] = json.loads(report.read_text())
        result['compositor_exit'] = compositor.returncode
        (out / 'result.json').write_text(json.dumps(result, indent=2) + '\n')


def interrupted(_signum, _frame):
    raise KeyboardInterrupt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--harness', type=Path, required=True)
    parser.add_argument('--doctor', type=Path, required=True)
    parser.add_argument('--node', type=Path, default=Path('/dev/dri/renderD128'))
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--harness-sha256')
    parser.add_argument('--doctor-sha256')
    parser.add_argument('--harness-filter', default=HARNESS_FILTER)
    parser.add_argument('--preflight-only', action='store_true')
    args = parser.parse_args()
    out = args.out.resolve()
    out.mkdir(mode=0o700)
    signal.signal(signal.SIGTERM, interrupted)
    launch(args, out)


if __name__ == '__main__':
    main()
