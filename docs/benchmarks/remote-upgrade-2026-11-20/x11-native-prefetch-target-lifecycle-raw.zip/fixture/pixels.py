"""XGetImage RGB readback from the existing private terminal fixture."""
import ctypes as C


class Image(C.Structure):
    _fields_ = [(name, C.c_int) for name in ('width', 'height', 'xoffset', 'format')]
    _fields_ += [('data', C.c_void_p)]
    _fields_ += [(name, C.c_int) for name in (
        'byte_order', 'bitmap_unit', 'bitmap_bit_order', 'bitmap_pad', 'depth',
        'bytes_per_line', 'bits_per_pixel')]
    _fields_ += [(name, C.c_ulong) for name in ('red_mask', 'green_mask', 'blue_mask')]


class Pixels:
    def __init__(self, display):
        self.xlib = C.CDLL('libX11.so.6')
        for name, inputs, result in (
            ('XOpenDisplay', [C.c_char_p], C.c_void_p),
            ('XCloseDisplay', [C.c_void_p], C.c_int),
            ('XDefaultRootWindow', [C.c_void_p], C.c_ulong),
            ('XGetImage', [C.c_void_p, C.c_ulong, C.c_int, C.c_int, C.c_uint,
                           C.c_uint, C.c_ulong, C.c_int], C.POINTER(Image)),
            ('XDestroyImage', [C.POINTER(Image)], C.c_int),
        ):
            fn = getattr(self.xlib, name)
            fn.argtypes, fn.restype = inputs, result
        self.display = self.xlib.XOpenDisplay(display.encode())
        if not self.display:
            raise RuntimeError(f'could not open owned X display {display}')
        self.root = self.xlib.XDefaultRootWindow(self.display)

    def close(self):
        self.xlib.XCloseDisplay(self.display)

    def crop(self, xid, x, y, width, height):
        ptr = self.xlib.XGetImage(self.display, xid, x, y, width, height, C.c_ulong(-1), 2)
        if not ptr:
            raise RuntimeError('owned drawable did not return pixels')
        try:
            info = ptr.contents
            layout = (info.width, info.height, info.byte_order, info.bits_per_pixel,
                      info.red_mask, info.green_mask, info.blue_mask)
            if layout != (width, height, 0, 32, 0xff0000, 0xff00, 0xff):
                raise RuntimeError(f'unexpected owned Xvfb pixel format {layout}')
            packed = C.string_at(info.data, info.bytes_per_line * height)
            return tuple(packed[y:y + width * 4]
                         for y in range(0, len(packed), info.bytes_per_line))
        finally:
            self.xlib.XDestroyImage(ptr)


def write_capture(path, rows):
    with path.open('wb') as image:
        image.write(f'P6\n{len(rows[0]) // 4} {len(rows)}\n255\n'.encode())
        for row in rows:
            rgb = bytearray(len(row) // 4 * 3)
            rgb[0::3], rgb[1::3], rgb[2::3] = row[2::4], row[1::4], row[0::4]
            image.write(rgb)


