#!/usr/bin/env python3
"""Probe native DRI3 presentation only on a private headless compositor."""
import argparse
from contextlib import ExitStack, contextmanager
import json
import os
from pathlib import Path
import re
import secrets
import selectors
import shutil
import signal
import stat
import struct
import subprocess
import sys
import tempfile
import time


WESTON_ROOT = Path('/tmp/jwm-aether-weston.xBLhos')
MESA_EGL = Path('/usr/share/glvnd/egl_vendor.d/50_mesa.json')


def drm_parent(node):
    info = node.stat()
    if not stat.S_ISCHR(info.st_mode):
        raise RuntimeError(f'not a DRM character device: {node}')
    device = Path('/sys/dev/char') / f'{os.major(info.st_rdev)}:{os.minor(info.st_rdev)}'
    return (device / 'device').resolve(strict=True)


def authority(path, number, cookie):
    # Xauthority entries are network-order short lengths. FamilyWild scopes
    # the private cookie to the separately owned server/display number.
    with open(path, 'xb', opener=lambda name, flags: os.open(name, flags, 0o600)) as stream:
        stream.write(struct.pack('!H', 65535))
        for field in (b'', number, b'MIT-MAGIC-COOKIE-1', cookie):
            stream.write(struct.pack('!H', len(field)) + field)


def stop(proc):
    if proc.poll() is not None:
        return
    try:
        os.killpg(proc.pid, signal.SIGTERM)
        proc.wait(timeout=4)
    except ProcessLookupError:
        proc.wait(timeout=4)
    except subprocess.TimeoutExpired:
        os.killpg(proc.pid, signal.SIGKILL)
        proc.wait(timeout=4)


def read_log(path):
    return path.read_text(encoding='utf-8', errors='replace')


def wait_socket(proc, path, log):
    deadline = time.monotonic() + 12
    while time.monotonic() < deadline:
        if proc.poll() is not None:
            break
        if path.is_socket():
            return
        time.sleep(.025)
    raise RuntimeError(f'private Weston socket did not become ready; see {log}')


def display_number(proc, log):
    end = time.monotonic() + 12
    line = bytearray()
    with selectors.DefaultSelector() as selector:
        selector.register(proc.stdout, selectors.EVENT_READ)
        while time.monotonic() < end and selector.select(max(0, end - time.monotonic())):
            chunk = os.read(proc.stdout.fileno(), 32)
            if not chunk:
                break
            line.extend(chunk)
            if b'\n' in line or len(line) >= 32:
                if re.fullmatch(rb'[0-9]+\n', line) and proc.poll() is None:
                    return bytes(line).strip()
                break
    raise RuntimeError(f'private Xwayland did not announce a display; see {log}')


@contextmanager
def private_xwayland(out, weston_root, node, width=3840, height=2160):
    libraries = weston_root / 'usr/lib/x86_64-linux-gnu'
    weston = weston_root / 'usr/bin/weston'
    modules = {'headless-backend.so': libraries / 'libweston-13/headless-backend.so',
               'gl-renderer.so': libraries / 'libweston-13/gl-renderer.so',
               'kiosk-shell.so': libraries / 'weston/kiosk-shell.so'}
    xwayland = shutil.which('Xwayland')
    if not (weston.is_file() and os.access(weston, os.X_OK) and xwayland
            and all(path.is_file() for path in modules.values())):
        raise RuntimeError(f'missing staged Weston GL modules or Xwayland under {weston_root}')
    if not os.access(node, os.R_OK | os.W_OK):
        raise RuntimeError(f'render node is not readable/writable: {node}')
    if not MESA_EGL.is_file() or json.loads(MESA_EGL.read_text())['ICD']['library_path'] != 'libEGL_mesa.so.0':
        raise RuntimeError(f'Mesa EGL vendor manifest not found: {MESA_EGL}')
    device = drm_parent(node)
    if (device / 'vendor').read_text().strip() != '0x8086':
        raise RuntimeError(f'requested render node is not Intel: {node}')
    if not re.fullmatch(r'[0-9a-f]{4}:[0-9a-f]{2}:[0-9a-f]{2}\.[0-7]', device.name):
        raise RuntimeError(f'render node has no PCI address: {node}')
    prime = 'pci-' + device.name.replace(':', '_').replace('.', '_')

    scrub = {'DISPLAY', 'WAYLAND_DISPLAY', 'WAYLAND_SOCKET', 'XAUTHORITY', 'LD_PRELOAD',
             'DBUS_SESSION_BUS_ADDRESS',
             'GBM_BACKEND', 'LIBGL_ALWAYS_SOFTWARE', 'MESA_LOADER_DRIVER_OVERRIDE',
             'XWAYLAND_NO_GLAMOR', 'WESTON_MODULE_MAP', 'EGL_PLATFORM',
             '__EGL_VENDOR_LIBRARY_FILENAMES', '__EGL_VENDOR_LIBRARY_DIRS'}
    env = {key: value for key, value in os.environ.items()
           if key not in scrub and not key.startswith('JWM_REMOTE_')}
    with tempfile.TemporaryDirectory(prefix='jwm-private-dri3.') as scratch, ExitStack() as cleanup:
        private = Path(scratch)
        for name in ('cache', 'config', 'data'):
            (private / name).mkdir(mode=0o700)
        env.update(XDG_RUNTIME_DIR=scratch, XDG_CACHE_HOME=str(private / 'cache'),
                   XDG_CONFIG_HOME=str(private / 'config'), XDG_DATA_HOME=str(private / 'data'),
                   DRI_PRIME=prime, __EGL_VENDOR_LIBRARY_FILENAMES=str(MESA_EGL))
        weston_env = env | {
            'WESTON_MODULE_MAP': ';'.join(f'{name}={path}' for name, path in modules.items()),
            'LD_LIBRARY_PATH': ':'.join(filter(None, (
                str(libraries), str(libraries / 'weston'), env.get('LD_LIBRARY_PATH')))),
        }
        wayland = 'jwm-private-4k'
        weston_log = out / 'weston.log'
        compositor = subprocess.Popen(
            [weston, '--backend=headless', '--renderer=gl', '--shell=kiosk',
             f'--width={width}', f'--height={height}', '--scale=1', f'--socket={wayland}',
             '--no-config', '--idle-time=0'],
            env=weston_env, stdin=subprocess.DEVNULL,
            stdout=cleanup.enter_context(weston_log.open('wb')), stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        cleanup.callback(stop, compositor)
        wait_socket(compositor, private / wayland, weston_log)
        cookie = secrets.token_bytes(16)
        server_auth, client_auth = private / 'server.authority', private / 'client.authority'
        authority(server_auth, b'', cookie)
        env.update(WAYLAND_DISPLAY=wayland)
        xwayland_log = out / 'xwayland.log'
        display_server = subprocess.Popen(
            [xwayland, '-displayfd', '1', '-nolisten', 'tcp', '-noreset',
             '-geometry', f'{width}x{height}', '-fullscreen', '-auth', server_auth],
            env=env, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
            stderr=cleanup.enter_context(xwayland_log.open('wb')), start_new_session=True,
        )
        cleanup.callback(stop, display_server)
        number = display_number(display_server, xwayland_log)
        authority(client_auth, number, cookie)
        x11 = ':' + number.decode('ascii')
        env.update(DISPLAY=x11, XAUTHORITY=str(client_auth))
        yield x11, env, device, compositor, display_server


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('binary', type=Path)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--weston-root', type=Path, default=WESTON_ROOT)
    parser.add_argument('--node', type=Path, default=Path('/dev/dri/renderD128'))
    args = parser.parse_args()
    out = args.out.resolve()
    out.mkdir(mode=0o700)
    binary, node = args.binary.resolve(strict=True), args.node.resolve(strict=True)
    with private_xwayland(out, args.weston_root, node) as (x11, env, device, compositor, server):
        screen = subprocess.run(['xdpyinfo', '-display', x11], env=env, capture_output=True,
                                text=True, timeout=8)
        (out / 'xdpyinfo.txt').write_text(screen.stdout + screen.stderr)
        screen.check_returncode()
        for requirement in (r'dimensions:\s+3840x2160 pixels', r'depth of root window:\s+24 planes',
                            r'^\s+DRI3\s*$'):
            if not re.search(requirement, screen.stdout, re.MULTILINE):
                raise RuntimeError(f'private X11 screen lacks prerequisite {requirement}')
        opened = subprocess.run(
            [sys.executable, '-B', Path(__file__).with_name('dri3-node.py'), x11], env=env,
            capture_output=True, text=True, timeout=8,
        )
        (out / 'dri3-node.log').write_text(opened.stdout + opened.stderr)
        opened.check_returncode()
        dri3 = json.loads(opened.stdout)
        dri3_parent = (Path('/sys/dev/char') / f"{dri3['major']}:{dri3['minor']}" / 'device').resolve(strict=True)
        weston_log = read_log(out / 'weston.log')
        renderer = re.search(r'GL renderer:\s*(.*)', weston_log)
        if not renderer or 'intel' not in renderer[1].lower():
            raise RuntimeError('Weston did not advertise its real Intel GLES renderer')
        render_node = re.search(r'Using rendering device:\s*(/dev/dri/\S+)', weston_log)
        if render_node and drm_parent(Path(render_node[1])) != device:
            raise RuntimeError('Weston initialized a different DRM device')
        if dri3_parent != device:
            raise RuntimeError(f"Xwayland opened a different DRM device: {dri3['path']} ({dri3_parent})")
        key = Path(env['XDG_RUNTIME_DIR']) / 'doctor.key'
        subprocess.run([binary, 'keygen', '--output', key], env=env, check=True,
                       stdout=subprocess.DEVNULL, timeout=5)
        probe = subprocess.run(
            [binary, 'doctor', '--display', x11, '--key-file', key, '--probe-gpu-present', node],
            env=env, capture_output=True, text=True, timeout=15,
        )
        (out / 'doctor.txt').write_text(probe.stdout + probe.stderr)
        probe.check_returncode()
        if not re.search(
            rf'GPU present: VA-API NV12 rendered with GLES to an X11 DRI3 pixmap on {re.escape(str(node))}',
            probe.stdout,
        ):
            raise RuntimeError('doctor did not verify the private same-device VA-API/EGL/DRI3 path')
        if compositor.poll() is not None or server.poll() is not None:
            raise RuntimeError('owned display exited during the probe')
        result = {'private_x11_display': x11, 'root_dimensions': [3840, 2160], 'root_depth': 24,
                  'weston_renderer': renderer[1], 'requested_render_node': str(node),
                  'pci_device': device.name, 'driver_checked_by_doctor': True,
                  'dri3_fd': dri3, 'egl_vendor_manifest': str(MESA_EGL),
                  'marker_observer_extensions': {
                      name: bool(re.search(rf'^\s+{name}\s*$', screen.stdout, re.MULTILINE))
                      for name in ('DAMAGE', 'MIT-SHM')
                  },
                  'scope': '251x247 hardware pixel probe on exact 4K private X11 screen'}
        (out / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps(result))


if __name__ == '__main__':
    main()
