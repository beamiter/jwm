/// Keep the retained X11 shell on this thread while the existing socket
/// deadlines cover the authenticated setup work on a scoped worker.
fn run_recovery_io<T: Send, S: Send>(
    viewer: Option<&mut Viewer>,
    connection: S,
    socket: impl FnOnce(&S) -> &TcpStream,
    operation: impl FnOnce(S) -> RemoteResult<T> + Send,
) -> RemoteResult<Option<T>> {
    let Some(viewer) = viewer else {
        return operation(connection).map(Some);
    };
    let cancel = socket(&connection).try_clone()?;
    let (wake, completion) = wake_pair()?;
    thread::scope(|scope| {
        let worker = thread::Builder::new()
            .name("jwm-remote-recovery-io".into())
            .spawn_scoped(scope, move || {
                let result = operation(connection);
                // Closing this end wakes the main poll even if setup failed.
                drop(completion);
                result
            })?;
        let ready: RemoteResult<bool> = (|| {
            loop {
                if !viewer.poll_disconnected_window()? {
                    return Ok(false);
                }
                if worker.is_finished() {
                    return Ok(true);
                }
                viewer.prepare_wait()?;
                if viewer.has_pending_events()? {
                    continue;
                }
                if wait_for_activity(
                    viewer.connection_fd(),
                    wake.as_fd(),
                    Instant::now() + Duration::from_millis(25),
                )? == WaitOutcome::ViewerHangup
                {
                    return Err(io::Error::new(
                        io::ErrorKind::UnexpectedEof,
                        "X11 viewer connection closed during recovery",
                    )
                    .into());
                }
            }
        })();
        if !matches!(ready, Ok(true)) {
            let _ = cancel.shutdown(Shutdown::Both);
        }
        let result = worker
            .join()
            .map_err(|_| io::Error::other("viewer recovery I/O worker panicked"))?;
        if ready? {
            result.map(Some)
        } else {
            Ok(None)
        }
    })
}

