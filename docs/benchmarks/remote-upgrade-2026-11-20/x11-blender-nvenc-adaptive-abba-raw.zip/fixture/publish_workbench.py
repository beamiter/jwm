"""Archive the complete scored Workbench record and verify a fresh extraction."""

import argparse
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile

from replay_workbench import canonical, run_report, sha

STEM = 'x11-blender-nvenc-adaptive-abba'


def keep(path):
    return (path.name in ('manifest.json','outcomes.json')
            or path.parts[0] == 'fixture' and path.suffix in ('.py','.c','.so')
            or path.parts[0].startswith('trial-') and len(path.parts) == 2
            and path.suffix in ('.json','.jsonl','.log','.png'))


def publish(root, output):
    scored = canonical(run_report(root))
    assert scored['manifest']['pilot'] is False, 'pilot results belong in their own record'
    output.mkdir(mode=0o700)
    members = {relative: sha(item)
               for item in root.rglob('*') if item.is_file()
               if keep(relative := item.relative_to(root))}
    bundle = output/f'{STEM}-raw.zip'
    with ZipFile(bundle, 'x', compression=ZIP_DEFLATED, compresslevel=6) as archive:
        for relative in sorted(members):
            archive.write(root/relative, str(relative))
    scored['archive'] = {'sha256': sha(bundle), 'members': {str(key): value for key,value in members.items()}}
    summary = output/f'{STEM}.json'
    summary.write_text(json.dumps(scored, indent=2, allow_nan=False) + '\n')
    replay(summary, bundle)


def replay(summary, bundle):
    archived = json.loads(summary.read_text())
    pins = archived.pop('archive')
    assert sha(bundle) == pins['sha256'], 'archive identity differs'
    with TemporaryDirectory(prefix='jwm-blender-adaptive-replay.') as tmp:
        directory = Path(tmp)
        with ZipFile(bundle) as archive:
            assert archive.testzip() is None and sorted(archive.namelist()) == sorted(pins['members'])
            for member in archive.namelist():
                part = Path(member)
                assert not part.is_absolute() and '..' not in part.parts and keep(part)
                archive.extract(member, directory)
        assert all(sha(directory/name) == digest for name,digest in pins['members'].items())
        assert canonical(run_report(directory)) == archived, 'fresh archive replay differs'
    print('Matched Workbench pixels, gaps, telemetry, recovery and all attempt outcomes reproduced.')


if __name__ == '__main__':
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('action', choices=('publish','replay'))
    cli.add_argument('first', type=Path)
    cli.add_argument('second', type=Path)
    args = cli.parse_args()
    {'publish':publish,'replay':replay}[args.action](args.first, args.second)
