#!/usr/bin/env python3
"""Owned 4K X11 native fresh-target prefetch A/B with a separate RGB control."""

import argparse
from contextlib import ExitStack
import fcntl
import json
import os
from pathlib import Path
import re
import selectors
import shlex
import shutil
import socket
import stat
from statistics import median
import subprocess
import sys
import tempfile
import threading
import time
import traceback

from evidence import (InvalidTrial, NATIVE_LOG, NativeRouteUnavailable, analyze, records,
                      require, write_json, write_rows)
from processes import clean_env, get_display, sha256, start_display, stop, wait_for


HERE = Path(__file__).resolve().parent
LOCK = Path('/tmp/jwm-p08-p09-release/benchmark.lock')
PEER = 'ubuntu@192.168.0.78'
DEFAULT_SOURCE = '/tmp/jwm-p09-candidate.rtF7yQja'
HOST = '/tmp/jwm-p09-resolution-candidate/jwm-remote'
OBSERVER = Path('/tmp/jwm-p09-workload/p09-workload')
OBSERVER_PIN = 'b79b433f17f1e061d30dc9fc4d5bb7cf867535c8ed4ca002987cc30640a21706'
REMOTE_PINS = {
    'host': '59572059a51aae67c91eff3013012352b932850806647cb81ccda2756522b47b',
    'source.py': '8517136f81dafdd22185590d3e7b546276b189389e26671a28b16f0907530b6f',
    'processes.py': 'b1628dc5f7ec4ae82b98f1c18fc9415a5435d7f6d1fc3a7083a6421a3c78b494',
    'p09-workload': '717de249d87d7d824356890b1b7d2a1407c0832ca9e28347f03f736c8ea50136',
}
SSH_OPTIONS = ['-4', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
               '-o', 'ControlMaster=no', '-o', 'ControlPath=none', '-o', 'ServerAliveInterval=5',
               '-o', 'Compression=no', '-o', 'ProxyJump=none', '-o', 'ProxyCommand=none',
               '-o', 'ForwardAgent=no', '-o', 'ForwardX11=no', '-o', 'StrictHostKeyChecking=yes']
WIDTH, HEIGHT = 3840, 2160
SIZE = f'{WIDTH}x{HEIGHT}'
CANDIDATE = 'JWM_REMOTE_X11_PREFETCH_TARGET'
LAZY_PICTURE = 'JWM_REMOTE_X11_LAZY_PICTURE'
STUDIES = {
    'preflight': ('off',),
    'pilot': ('off', 'on'),
    'pair': ('off', 'on'),
    'abba': ('off', 'on', 'on', 'off') * 2,
    'rgb-comparator': ('cpu',),
}


def options():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--viewer-bin', required=True, type=Path)
    cli.add_argument('--viewer-sha256', required=True)
    cli.add_argument('--out', required=True, type=Path)
    cli.add_argument('--tag', required=True)
    cli.add_argument('--study', choices=STUDIES, default='preflight')
    cli.add_argument('--run-id-base', type=int, default=170)
    cli.add_argument('--remote-dir', default=DEFAULT_SOURCE)
    cli.add_argument('--display-launcher', type=Path)
    cli.add_argument('--launcher-sha256')
    cli.add_argument('--launcher-arg', action='append', default=[],
                     help='Repeat for launcher arguments. Substitutions: {out}, {width}, {height}, {node}, {viewer}, {viewer_sha256}.')
    cli.add_argument('--render-node', type=Path, default=Path('/dev/dri/renderD128'))
    cli.add_argument('--ffmpeg-lib', type=Path,
                     default=Path('/tmp/jwm-remote-ffmpeg/usr/lib/x86_64-linux-gnu'))
    args = cli.parse_args()
    if not re.fullmatch(r'[a-z0-9]{1,14}', args.tag):
        cli.error('tag must be a unique lowercase alphanumeric campaign ID, up to 14 letters')
    if not re.fullmatch(r'[0-9a-f]{64}', args.viewer_sha256):
        cli.error('declare the exact viewer binary SHA-256 before either arm')
    if args.study != 'rgb-comparator' and (
        args.display_launcher is None or not re.fullmatch(r'[0-9a-f]{64}', args.launcher_sha256 or '')
    ):
        cli.error('native runs require an explicit executable private display launcher and its SHA-256')
    if not re.fullmatch(r'/tmp/jwm-p09-candidate\.[A-Za-z0-9]+', args.remote_dir):
        cli.error('expected the preexisting private parallel-YUV P09 source fixture')
    if not 1 <= args.run_id_base <= 256 - len(STUDIES[args.study]):
        cli.error('P09 run IDs must remain within 1..255')
    if args.out.exists() or not args.out.parent.is_dir():
        cli.error('output must be a new directory under an existing parent')
    return args


def trial_schedule(args):
    mode = args.study
    pilot = mode == 'pilot'
    for index, arm in enumerate(STUDIES[mode]):
        yield {
            'slot': index + 1, 'block': index // 4 + 1 if mode == 'abba' else None,
            'name': f'x11-prefetch-{mode}-{args.tag}-{index+1:02}-{arm}',
            'run_id': args.run_id_base + index, 'mode': arm,
            'formal': mode in ('pair', 'abba'), 'warmup_seconds': 6 if pilot else 30,
            'score_seconds': 18 if pilot else 60, 'observer_seconds': 35 if pilot else 105,
        }


def viewer_env(args):
    env = clean_env()
    for key in ('XAUTHORITY', 'LD_PRELOAD', 'P09_SEND_BUFFER', 'P09_PROXY_RCVBUF'):
        env.pop(key, None)
    if args.study != 'rgb-comparator':
        for key in ('GBM_BACKEND', 'LIBGL_ALWAYS_SOFTWARE', 'MESA_LOADER_DRIVER_OVERRIDE',
                    'EGL_PLATFORM', '__EGL_VENDOR_LIBRARY_DIRS'):
            env.pop(key, None)
        env['__EGL_VENDOR_LIBRARY_FILENAMES'] = '/usr/share/glvnd/egl_vendor.d/50_mesa.json'
        pci = render_pin(args)['render_pci_device']
        env['DRI_PRIME'] = 'pci-' + pci.replace(':', '_').replace('.', '_')
    if args.ffmpeg_lib.is_dir():
        inherited = env.get('LD_LIBRARY_PATH')
        env['LD_LIBRARY_PATH'] = str(args.ffmpeg_lib) + (':' + inherited if inherited else '')
    return env


def private_copy(source, target, expected):
    with source.open('rb') as read, target.open('xb') as output:
        shutil.copyfileobj(read, output)
    target.chmod(0o500)
    require(sha256(target) == expected, f'copied {target.name} does not match the declared SHA-256')
    return target


def pin_remote(args):
    paths = {name: HOST if name == 'host' else f'{args.remote_dir}/{name}' for name in REMOTE_PINS}
    output = subprocess.check_output(['ssh', *SSH_OPTIONS, '-n', PEER,
                                      shlex.join(['sha256sum', '--', *paths.values()])],
                                     text=True, timeout=15)
    matches = {path: digest for digest, path in (line.split(maxsplit=1) for line in output.splitlines())}
    actual = {name: matches.get(path) for name, path in paths.items()}
    require(actual == REMOTE_PINS, 'source host, controller, process helpers or painter differ from pinned ABBA')
    return actual


def render_pin(args):
    node = args.render_node.resolve(strict=True)
    sysnode = Path('/sys/class/drm') / node.name / 'device'
    require(re.fullmatch(r'renderD\d+', node.name) and (sysnode / 'vendor').read_text().strip() == '0x8086',
            'expected the pinned Intel DRM render node')
    return {'render_node': str(node), 'render_node_rdev': node.stat().st_rdev,
            'render_pci_device': sysnode.resolve().name}


def announce_display(child, args, launcher_dir):
    announcement = bytearray()
    deadline = time.monotonic() + 60
    with selectors.DefaultSelector() as selector:
        selector.register(child.stdout, selectors.EVENT_READ)
        while b'\n' not in announcement and len(announcement) < 4096:
            if not selector.select(max(0, deadline - time.monotonic())):
                raise NativeRouteUnavailable('private native display readiness timed out')
            part = os.read(child.stdout.fileno(), 4096 - len(announcement))
            if not part:
                raise NativeRouteUnavailable(f'private native display launcher ended ({child.poll()})')
            announcement.extend(part)
    require(b'\n' in announcement, 'private display announcement exceeded its fixed size')
    ready = json.loads(announcement.split(b'\n', 1)[0])
    display = ready.get('display')
    require(isinstance(display, str) and re.fullmatch(r':\d+', display),
            'launcher did not announce one private X11 display')
    require(ready.get('size') == [WIDTH, HEIGHT] and ready.get('render_node') == str(args.render_node),
            'private display announced a different size or render device')
    result = (launcher_dir / 'result.json').resolve(strict=True)
    require(Path(ready['evidence']).resolve(strict=True) == result,
            'launcher evidence must be in the private display output')
    report = json.loads(result.read_text())
    require(report.get('status') == 'ready' and report.get('production_doctor_passed') is True
            and report['binary_sha256']['doctor'] == args.viewer_sha256
            and report['owned_output_first_draw']['dmabuf_draws'] > 0,
            'launcher did not prove the selected viewer on its owned accelerated output')
    runtime = Path(ready['runtime_directory']).resolve(strict=True)
    require(runtime.parent == Path('/tmp') and runtime.name.startswith('jwm-xwayland-runtime.')
            and runtime.is_dir() and runtime.stat().st_uid == os.getuid()
            and stat.S_IMODE(runtime.stat().st_mode) == 0o700,
            'launcher authorization is outside the owned private runtime')
    authority = Path(ready['xauthority']).resolve(strict=True)
    require(authority == runtime / 'client.authority' and authority.is_file()
            and authority.stat().st_uid == os.getuid()
            and stat.S_IMODE(authority.stat().st_mode) == 0o600,
            'launcher authorization must be a private managed file')
    return display, authority


def close_display(child, run):
    if child.stdin is not None and not child.stdin.closed:
        child.stdin.close()
    require(child.wait(timeout=15) == 0, 'private display cleanup did not exit cleanly')
    report = json.loads((run / 'display' / 'result.json').read_text())
    require(report.get('compositor_exit') == 0 and report.get('owned_output_final'),
            'private renderer did not report its clean close')


def start_x11(args, run, stack, log, env, mode):
    if mode == 'cpu':
        child = start_display(WIDTH, HEIGHT, log('xvfb.log'))
        stack.callback(stop, child)
        display = get_display(child)
    else:
        require(sha256(args.display_launcher) == args.launcher_sha256,
                'private display launcher changed before use')
        launcher_dir = run / 'display'
        launcher_args = [value.format(out=launcher_dir, width=WIDTH, height=HEIGHT, node=args.render_node,
                                       viewer=args.viewer_bin, viewer_sha256=args.viewer_sha256)
                         for value in args.launcher_arg]
        launcher = ([sys.executable, '-B', args.display_launcher] if args.display_launcher.suffix == '.py'
                    else [args.display_launcher])
        child = subprocess.Popen([*launcher, *launcher_args], env=env,
                                 stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=log('launcher.log'))
        stack.callback(stop, child, natural=True)
        display, authority = announce_display(child, args, launcher_dir)
        if authority:
            env['XAUTHORITY'] = str(authority)
    env['DISPLAY'] = display
    requirement = subprocess.run(['xwininfo', '-display', display, '-root'], env=env, text=True,
                                 capture_output=True, check=True, timeout=7)
    width, = re.findall(r'^\s+Width:\s+(\d+)$', requirement.stdout, re.M)
    height, = re.findall(r'^\s+Height:\s+(\d+)$', requirement.stdout, re.M)
    require((int(width), int(height)) == (WIDTH, HEIGHT), 'private X11 root differs from exact 4K')
    (run / 'root-window.txt').write_text(requirement.stdout)
    return display, child


def prove_gpu(args, run, key, log, env, display):
    path = run / 'doctor.log'
    check = subprocess.run([args.viewer_bin, 'doctor', '--key-file', key, '--display',
                            display, '--probe-gpu-present', args.render_node],
                           env=env, stdin=subprocess.DEVNULL, stdout=log(path.name),
                           stderr=subprocess.STDOUT, timeout=15)
    if check.returncode or 'VA-API NV12 rendered with GLES to an X11 DRI3 pixmap' not in path.read_text():
        raise NativeRouteUnavailable('same-device X11 DRI3 pixel probe failed before source startup')


def find_viewer(display, port, env):
    tree = subprocess.check_output(['xwininfo', '-display', display, '-root', '-tree'],
                                   env=env, text=True, timeout=5)
    title = re.escape(f'127.0.0.1:{port} - JWM Remote')
    geometry = re.escape(SIZE + '+0+0')
    matches = re.findall(rf'^ +(0x[\da-f]+) "{title}(?: - [^"]*)?": .* {geometry}(?= |$)', tree, re.M)
    require(len(matches) <= 1, 'more than one 4K viewer drawable on the private root')
    return matches[0] if matches else None


def source_command(args, trial):
    source = ['python3', '-u', f'{args.remote_dir}/source.py', trial['name'], '--arm', 'treatment',
              '--width', str(WIDTH), '--height', str(HEIGHT), '--fps', '30', '--paint-fps', '60',
              '--seconds', str(trial['observer_seconds']), '--run-id', str(trial['run_id']),
              '--cap', '0', '--send-buffer', '0', '--recv-buffer', '0', '--capture-scaling', 'auto',
              '--feature-flag', 'JWM_REMOTE_PARALLEL_YUV420', '--enable-at', 'host']
    return ['ssh', *SSH_OPTIONS, PEER, shlex.join(source)]


def rcv_port(path, child):
    def get():
        ready = records(path)
        if not ready:
            return None
        port = ready[0]['upstream_port']
        require(type(port) is int and 0 < port < 65536, 'invalid private remote loopback port')
        return port
    return wait_for(child, get, 20)


def connect(args, trial, run, key, stack, log, env, display, source):
    port = rcv_port(run / 'remote-ready.log', source)
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as socket_chooser:
        socket_chooser.bind(('127.0.0.1', 0))
        local_port = socket_chooser.getsockname()[1]
    tunnel_log = run / 'tunnel.log'
    tunnel = subprocess.Popen(['ssh', *SSH_OPTIONS, '-vN', '-o', 'ExitOnForwardFailure=yes',
                               '-L', f'127.0.0.1:{local_port}:127.0.0.1:{port}', PEER],
                              env=env, stdin=subprocess.DEVNULL, stdout=log(tunnel_log.name),
                              stderr=subprocess.STDOUT)
    stack.callback(stop, tunnel)
    wait_for(tunnel, lambda: re.search(r'Local forwarding listening on 127\.0\.0\.1 port',
                                       tunnel_log.read_text()), 12)

    cpu = trial['mode'] == 'cpu'
    viewer_args = [args.viewer_bin, 'connect', f'127.0.0.1:{local_port}', '--view-only', '--toggle',
                   '--stats-json', '--key-file', key, '--display', display, '--window-size', SIZE,
                   '--window-position', '0,0', '--scaling', 'cpu' if cpu else 'gpu']
    viewer_environment = env.copy()
    if not cpu:
        viewer_environment['JWM_REMOTE_GPU_PRESENT'] = str(args.render_node)
    if trial['mode'] == 'on':
        viewer_environment[CANDIDATE] = '1'
    write_json(run / 'viewer-control.json', {
        'mode': trial['mode'], 'x11_display_backend': 'Xvfb' if cpu else 'private accelerated X11',
        'viewer_sha256': args.viewer_sha256, 'scaling': 'cpu' if cpu else 'gpu',
        'gpu_render_node': viewer_environment.get('JWM_REMOTE_GPU_PRESENT'),
        'prefetch_env': viewer_environment.get(CANDIDATE),
        'lazy_picture_env': viewer_environment.get(LAZY_PICTURE),
    })
    view_log, clock_log = log('viewer.log'), log('viewer-clock.jsonl')
    view = subprocess.Popen(viewer_args, env=viewer_environment, stdin=subprocess.DEVNULL,
                            stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    stack.callback(stop, view)
    relay_errors = []

    def relay():
        try:
            for line in iter(view.stderr.readline, b''):
                arrived = time.monotonic_ns()
                view_log.write(line)
                view_log.flush()
                if line.startswith(b'{') and line.rstrip().endswith(b'}'):
                    entry = json.loads(line)
                    if (entry.get('type') == 'jwm_remote_viewer_stats' and not entry.get('final')
                            and entry.get('window_seconds', 0) >= 4.9):
                        clock_log.write(json.dumps({'end_ns': arrived}).encode() + b'\n')
                        clock_log.flush()
        except (OSError, ValueError) as error:
            relay_errors.append(str(error))

    thread = threading.Thread(target=relay, daemon=True)
    thread.start()

    def initialized():
        if not cpu:
            diagnostics = (run / 'viewer.log').read_text(errors='replace')
            if re.search(r'^jwm-remote: native x11 video (?:unavailable|disabled)', diagnostics,
                         re.M | re.I):
                raise NativeRouteUnavailable('viewer attempted RGB fallback during native readiness')
            if NATIVE_LOG not in diagnostics:
                return None
        return find_viewer(display, local_port, env)

    drawable = wait_for(view, initialized, 20)
    observer = subprocess.Popen([args.observer_bin, 'observe', '--display', display, '--window', drawable,
                                 '--width', str(WIDTH), '--height', str(HEIGHT),
                                 '--seconds', str(trial['observer_seconds']), '--run-id', str(trial['run_id'])],
                                env=env, stdin=subprocess.DEVNULL, stdout=log('observed.jsonl'),
                                stderr=log('observer-stderr.log'))
    stack.callback(stop, observer)
    require(observer.wait(timeout=trial['observer_seconds'] + 10) == 0, 'presentation observer failed')
    require(view.poll() is None, 'viewer exited before the last observed marker')
    subprocess.run(viewer_args, env=viewer_environment, stdin=subprocess.DEVNULL,
                   stdout=subprocess.DEVNULL, stderr=log('disconnect.log'), timeout=8, check=True)
    require(view.wait(timeout=10) == 0, 'viewer did not close normally')
    thread.join(timeout=5)
    require(not thread.is_alive() and not relay_errors, 'viewer telemetry drain did not finish')
    require(source.wait(timeout=15) == 0, 'pinned source did not close normally')


def attempt(args, trial):
    run = args.out / trial['name']
    run.mkdir(mode=0o700)
    source_started = False
    problem = None
    try:
        if args.study != 'preflight':
            write_json(run / 'source-pins-before.json', pin_remote(args))
        with ExitStack() as stack:
            log = lambda name: stack.enter_context((run / name).open('xb'))
            env = viewer_env(args)
            env['XDG_RUNTIME_DIR'] = stack.enter_context(
                tempfile.TemporaryDirectory(prefix='runtime.', dir=run))
            key = run / 'key'
            stack.callback(key.unlink, missing_ok=True)
            subprocess.run([args.viewer_bin, 'keygen', '--output', key], env=env, timeout=8,
                           stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                           stderr=log('keygen.log'), check=True)
            display, launcher = start_x11(args, run, stack, log, env, trial['mode'])
            if trial['mode'] != 'cpu':
                prove_gpu(args, run, key, log, env, display)
            if args.study == 'preflight':
                close_display(launcher, run)
                return trial | {'status': 'preflight_passed', 'score': None}
            source = subprocess.Popen(source_command(args, trial), stdin=subprocess.PIPE,
                                      stdout=log('remote-ready.log'), stderr=log('remote-stderr.log'))
            source_started = True
            stack.callback(stop, source, natural=True)
            source.stdin.write(key.read_bytes())
            source.stdin.flush()
            connect(args, trial, run, key, stack, log, env, display, source)
            if trial['mode'] != 'cpu':
                close_display(launcher, run)
    except Exception:
        problem = sys.exc_info()[1]
        raise
    finally:
        if source_started:
            try:
                subprocess.run(['scp', *SSH_OPTIONS, '-qr', f'{PEER}:{args.remote_dir}/{trial["name"]}',
                                run / 'remote'],
                               timeout=25, check=True, stderr=subprocess.PIPE)
                write_json(run / 'source-pins-after.json', pin_remote(args))
            except (OSError, subprocess.SubprocessError, RuntimeError):
                if not problem:
                    raise
                (run / 'remote-harvest-error.log').write_text(traceback.format_exc())
    result, host, viewer, markers = analyze(run, trial)
    for lane, rows in (('host', host), ('viewer', viewer), ('markers', markers)):
        write_rows(run / f'retained-{lane}.jsonl', rows)
    return result | {'status': 'valid'}


def summarize(study, rows):
    completed = all(row['status'] in ('valid', 'preflight_passed') for row in rows)
    arms = {}
    for mode in ('off', 'on', 'cpu'):
        scored = [row for row in rows if row['mode'] == mode and row['status'] == 'valid']
        if not scored:
            continue
        marks = [row['marker'] for row in scored]
        arms[mode] = {
            'valid_trials': len(scored),
            'median_visible_fps': median(row['visible_fps'] for row in marks),
            'median_trial_gap_p95_ms': median(row['gap_p95_ms'] for row in marks),
            'longest_observed_gap_ms': max(row['longest_gap_ms'] for row in marks),
        }
    paired = []
    if study in ('pilot', 'pair', 'abba'):
        for first, second in zip(rows[::2], rows[1::2]):
            expected = {first['mode']: first, second['mode']: second}
            off, on = expected['off'], expected['on']
            valid = off['status'] == on['status'] == 'valid'
            paired.append({
                'slots': [first['slot'], second['slot']], 'valid': valid,
                'on_minus_off_fps': on['marker']['visible_fps'] - off['marker']['visible_fps']
                if valid else None,
                'on_minus_off_longest_gap_ms': on['marker']['longest_gap_ms'] - off['marker']['longest_gap_ms']
                if valid else None,
            })
    return {
        'study': study, 'status': 'complete' if completed else 'incomplete',
        'attempts': rows, 'arms': arms, 'adjacent_pairs': paired,
        'balanced_abba_candidate_gate': (
            completed and all(row['meets_27_fps_gate'] is True for row in rows if row['mode'] == 'on')
            if study == 'abba' else None),
    }

def run(args):
    args.out.mkdir(mode=0o700)
    args.out = args.out.resolve(strict=True)
    schedule = list(trial_schedule(args))
    if args.study != 'rgb-comparator':
        args.render_node = args.render_node.resolve(strict=True)
    protocol = {
        'schema': 1, 'study': args.study, 'dimensions': [WIDTH, HEIGHT], 'host_requested_fps': 30,
        'source_requested_fps': 60, 'host_route': 'Auto MIT-SHM, H.264 NVENC, parallel YUV420',
        'transport': 'uncapped IPv4 SSH forward', 'candidate_flag': CANDIDATE,
        'lazy_picture_env': None,
        'phase_accounting': {
            'worker_allocation': 'Time on the fresh target worker, measured only when its output is consumed',
            'synchronous_allocation': 'Target allocation on the viewer thread after a miss',
            'miss_ratio': 'Synchronous allocations divided by observed native DRI3 imports',
        },
        'renderer': render_pin(args) if args.study != 'rgb-comparator' else None,
        'remote_pins': REMOTE_PINS, 'observer_sha256': OBSERVER_PIN, 'viewer_sha256': args.viewer_sha256,
        'launcher_sha256': args.launcher_sha256, 'schedule': schedule,
        'fixture_sha256': {name: sha256(HERE / name) for name in (
            'run.py', 'evidence.py', 'processes.py', 'p09-workload.c',
            'pinned-source.py', 'pinned-source-processes.py')},
    }
    write_json(args.out / 'protocol.json', protocol)
    args.viewer_bin = private_copy(args.viewer_bin, args.out / 'viewer', args.viewer_sha256)
    args.observer_bin = private_copy(OBSERVER, args.out / 'observer', OBSERVER_PIN)
    if args.display_launcher:
        args.display_launcher = args.display_launcher.resolve(strict=True)
    rows = []
    with LOCK.open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        for trial in schedule:
            print(f'started {trial["name"]}', flush=True)
            try:
                row = attempt(args, trial)
            except (OSError, RuntimeError, subprocess.SubprocessError, ValueError, KeyError) as error:
                run_dir = args.out / trial['name']
                (run_dir / 'error.log').write_text(traceback.format_exc())
                status = 'native_unavailable' if isinstance(error, NativeRouteUnavailable) else 'invalid'
                row = trial | {'status': status, 'scope': None, 'marker': None, 'meets_27_fps_gate': None,
                               'failure': str(error)}
            write_json(args.out / trial['name'] / 'result.json', row)
            rows.append(row)
            print(json.dumps(row, allow_nan=False), flush=True)
    summary = summarize(args.study, rows)
    write_json(args.out / 'summary.json', summary)
    return 0 if summary['status'] == 'complete' else 1


def main():
    args = options()
    result = 1
    try:
        result = run(args)
    except (KeyboardInterrupt, OSError, RuntimeError, ValueError):
        traceback.print_exc()
    if args.out.is_dir():
        with (args.out / 'live.exit').open('x') as output:
            print(result, file=output)
    return result


if __name__ == '__main__':
    raise SystemExit(main())
