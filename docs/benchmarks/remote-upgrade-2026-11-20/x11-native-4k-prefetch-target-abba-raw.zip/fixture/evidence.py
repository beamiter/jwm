"""Offline evidence validator for an owned-display 4K X11 comparison."""

import json
import math
import re
from statistics import median


HOST_STATS = 'jwm_remote_host_stats'
VIEWER_STATS = 'jwm_remote_viewer_stats'
NATIVE_PATH = 'x11-vaapi-dmabuf-dri3'
NATIVE_LOG = 'jwm-remote: native H.264 VA-API/EGL/DRI3 video rendering active'
PARALLEL_HOST = 'parallel 4:2:0 conversion active (RGB24 -> YUV420P, 3840x2160, 4 bands)'
SIZE = [3840, 2160]


class InvalidTrial(RuntimeError):
    pass


class NativeRouteUnavailable(InvalidTrial):
    pass


def require(condition, detail):
    if not condition:
        raise InvalidTrial(detail)


def records(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.startswith('{')]


def stats(path, kind):
    return [row for row in records(path) if row.get('type') == kind]


def write_json(path, value):
    with path.open('x') as output:
        json.dump(value, output, indent=2, allow_nan=False)
        output.write('\n')


def write_rows(path, rows):
    with path.open('x') as output:
        for row in rows:
            output.write(json.dumps(row, allow_nan=False) + '\n')


def nearest_rank(samples, percentile):
    return sorted(samples)[math.ceil(len(samples) * percentile) - 1]


def mark_score(trial, path, source_path):
    observer = records(path)
    start, = [row for row in observer if row['type'] == 'p09_start']
    end, = [row for row in observer if row['type'] == 'p09_end']
    painter, = [row for row in records(source_path) if row['type'] == 'p09_end']
    require(start['run_id'] == end['run_id'] == painter['run_id'] == trial['run_id'],
            'source and observer identities differ')
    require(not any(end[field] for field in ('target_lost', 'interrupted', 'wrong_run', 'reordered')),
            'observer lost the exact drawable or saw the wrong/reordered source')
    require(painter['last_submit_ns'] > painter['first_submit_ns'], 'source did not advance')
    source_fps = ((painter['submitted'] - 1) * 1e9
                  / (painter['last_submit_ns'] - painter['first_submit_ns']))
    require(source_fps >= 30, 'source was below requested video rate')
    start_ns = start['monotonic_ns'] + trial['warmup_seconds'] * 10**9
    end_ns = start_ns + trial['score_seconds'] * 10**9
    require(end['monotonic_ns'] >= end_ns, 'observer ended before the exact score boundary')
    marks = [row for row in observer if row['type'] == 'p09_frame']
    require(all(row['run_id'] == trial['run_id'] for row in marks), 'observer saw another run ID')
    require(all(a['monotonic_ns'] < b['monotonic_ns'] and a['source_frame'] < b['source_frame']
                for a, b in zip(marks, marks[1:])), 'observer marks are not strictly increasing')
    retained = [row for row in marks if start_ns <= row['monotonic_ns'] < end_ns]
    require(retained, 'the observer saw no valid scored pixels')
    points = [start_ns, *(row['monotonic_ns'] for row in retained), end_ns]
    gap_ms = [(b - a) / 1e6 for a, b in zip(points, points[1:])]
    result = {
        'score_start_ns': start_ns, 'score_end_ns': end_ns,
        'distinct_markers': len(retained),
        'visible_fps': len(retained) / trial['score_seconds'],
        'gap_median_ms': median(gap_ms), 'gap_p95_ms': nearest_rank(gap_ms, .95),
        'longest_gap_ms': max(gap_ms), 'source_fps': source_fps,
        'observer_raw_summary': end,
    }
    return result, retained


def scoped_windows(trial, score, viewer_rows, clocks, host_rows):
    complete = [row for row in viewer_rows if not row.get('final') and row['window_seconds'] >= 4.9]
    require(len(complete) == len(clocks), 'viewer telemetry and receipt clocks do not match')
    viewer = []
    for row, stamp in zip(complete, clocks):
        end = stamp['end_ns']
        start = end - round(row['window_seconds'] * 10**9)
        if start >= score['score_start_ns'] and end <= score['score_end_ns']:
            viewer.append(row | {'start_ns': start, 'end_ns': end})
    minimum = int(trial['score_seconds'] / 5) - 1
    require(len(viewer) >= minimum and bool(viewer), 'insufficient whole viewport telemetry windows')
    host = []
    skipped = selected = 0.
    for row in host_rows:
        if row.get('final') or row['window_seconds'] < 4.9:
            continue
        if skipped < trial['warmup_seconds']:
            skipped += row['window_seconds']
        elif selected < trial['score_seconds']:
            selected += row['window_seconds']
            host.append(row)
    require(len(host) >= minimum and bool(host), 'insufficient host-clock steady windows')
    return host, viewer


def observed(row, group, name):
    return row.get(group, {}).get(name, {}).get('observations', 0)


def prove_host(host_rows, host_log):
    require('hardware H.264 encoding active (NVENC)' in host_log, 'host did not activate NVENC')
    require(PARALLEL_HOST in host_log, 'host did not activate the pinned 4-way YUV420 conversion')
    require(sum(row['h264_frames'] for row in host_rows) > 0, 'host sent no H.264 frames')
    require(sum(row['drawn_acks'] for row in host_rows) > 0, 'host saw no drawn acknowledgement')
    require(not any(row['jpeg_atlases'] or row['hevc444_frames'] for row in host_rows),
            'host changed its fixed H.264 path')
    for row in host_rows:
        capture = row.get('x11_capture', {})
        require(not observed(capture, 'stages', 'cpu_resize_ms')
                and not observed(capture, 'stages', 'core_readback_ms'),
                'host took a core readback or resized the native-size stream')
        if row['captured']:
            require(observed(capture, 'stages', 'shm_readback_ms') > 0,
                    'active host capture did not use MIT-SHM')


def prove_route(viewer_rows, viewer_log, mode):
    native = mode != 'cpu'
    active = [row for row in viewer_rows if row['drawn']]
    require(active, 'no consumed viewer frames')
    require(all(row['negotiated_codec'] == 'H.264' for row in viewer_rows),
            'viewer changed negotiated codec')
    if native:
        reasons = re.findall(r'^jwm-remote: native x11 video (?:unavailable|disabled).*$',
                             viewer_log, re.M | re.I)
        downloads = sum(observed(row, 'stages', 'hardware_download_ms') for row in viewer_rows)
        if (reasons or NATIVE_LOG not in viewer_log or downloads
                or any(row['native_presented'] != row['drawn']
                       or row['last_presentation_path'] != NATIVE_PATH for row in active)):
            raise NativeRouteUnavailable(
                f'native path not sustained (download observations {downloads}, '
                f'fallback diagnostics {len(reasons)})')
    else:
        require(not any(row['native_presented'] for row in viewer_rows)
                and all(row['last_presentation_path'] == 'rgb' for row in active),
                'separate CPU comparator did not use RGB presentation')
        require(sum(observed(row, 'stages', 'hardware_download_ms') for row in viewer_rows) > 0,
                'separate CPU comparator did not exercise the hardware download route')


def phase_stats(rows, group):
    stages = sorted({name for row in rows for name in row.get(group, {})})
    summary = {}
    for name in stages:
        values = [row[group][name] for row in rows if name in row.get(group, {})]
        means = [value['mean'] for value in values if value.get('mean') is not None]
        if not means:
            continue
        counts = [value for value in values if value.get('observations', 0) > 0]
        total = sum(value['observations'] for value in counts)
        p50 = [value['quantiles']['p50_ms'] for value in values
               if value.get('quantiles', {}).get('p50_ms') is not None]
        p95 = [value['quantiles']['p95_ms'] for value in values
               if value.get('quantiles', {}).get('p95_ms') is not None]
        summary[name] = {
            'windows': len(means),
            'observations': total if counts else None,
            'weighted_mean_ms': (sum(value['mean'] * value['observations'] for value in counts) / total
                                 if total else None),
            'median_window_mean_ms': median(means),
            'median_window_p50_ms': median(p50) if p50 else None,
            'median_window_p95_ms': median(p95) if p95 else None,
            'max_recent_window_p95_ms': max(p95) if p95 else None,
        }
    return summary


def verify_prefetch(viewer, full_viewer, mode):
    group = 'native_x11_stages'
    native_frame_stages = (
        'va_surface_wait_ms', 'va_frame_export_ms',
        'egl_prepare_and_submit_ms', 'egl_fence_wait_ms', 'x11_dmabuf_import_ms',
        'x11_picture_setup_ms', 'x11_backing_populate_ms', 'x11_window_submit_ms',
    )
    synchronous = 'rgb_target_allocation_ms'
    prefetch = 'x11_prefetch_rgb_allocation_ms'
    totals = {}
    for scope, windows in (('steady', viewer), ('whole_run', full_viewer)):
        stages = (*native_frame_stages, synchronous, prefetch)
        counts = dict.fromkeys(stages, 0)
        for index, row in enumerate(windows, start=1):
            samples = {name: observed(row, group, name) for name in stages}
            require(all(type(value) is int and value >= 0 for value in samples.values()),
                    f'invalid native stage observations in {scope} window {index}')
            imports = samples['x11_dmabuf_import_ms']
            require(all(samples[name] == imports for name in native_frame_stages),
                    f'native submission and eager picture counts differ in {scope} window {index}')
            require(samples[synchronous] + samples[prefetch] == imports,
                    f'prefetch and synchronous allocations do not partition imports in {scope} window {index}')
            if mode == 'off':
                require(samples[prefetch] == 0, f'unexpected prefetch in the off arm {scope} window {index}')
            for name, amount in samples.items():
                counts[name] += amount
        imports = counts['x11_dmabuf_import_ms']
        require(imports > 0, f'no observed native DRI3 imports in {scope}')
        if mode == 'on':
            require(counts[prefetch] > 0, f'no prefetched fresh target was used in the on arm {scope}')
        totals[scope] = {
            'native_stage_observations': counts,
            'native_imports': imports,
            'synchronous_allocations': counts[synchronous],
            'prefetch_uses': counts[prefetch],
            'miss_ratio': counts[synchronous] / imports,
        }
    return totals


def analyze(run, trial):
    host_path = run / 'remote' / 'host.log'
    viewer_path = run / 'viewer.log'
    host_all, viewer_all = stats(host_path, HOST_STATS), stats(viewer_path, VIEWER_STATS)
    host_log, viewer_log = host_path.read_text(), viewer_path.read_text()
    prove_host(host_all, host_log)
    prove_route(viewer_all, viewer_log, trial['mode'])
    sessions = {row['session_id'] for row in host_all + viewer_all}
    require(None not in sessions and len(sessions) == 1, 'endpoints did not use the same authenticated session')
    scopes = {tuple(row['last_frame'][field] for field in ('source_epoch', 'geometry_epoch'))
              for row in viewer_all if row.get('last_frame') and row['drawn']}
    require(len(scopes) == 1, 'viewer scope changed during a fixed 4K run')
    frames = [row['last_frame'] for row in viewer_all if row.get('last_frame')]
    frames += [row['last_sent_frame'] for row in host_all if row.get('last_sent_frame')]
    require(frames and all(frame['source_dimensions'] == frame['encoded_dimensions'] == SIZE
                           and frame['codec'] == 'H.264' for frame in frames),
            'the video left its exact source geometry or codec')
    score, marks = mark_score(trial, run / 'observed.jsonl', run / 'remote' / 'paint.jsonl')
    host, viewer = scoped_windows(trial, score, viewer_all, records(run / 'viewer-clock.jsonl'), host_all)
    mode = trial['mode']
    native = mode != 'cpu'
    result = trial | {
        'route': 'validated X11 VA-API/EGL/DRI3' if native else 'Xvfb RGB diagnostic comparator',
        'scope': {'session_id': sessions.pop(), 'source_epoch': next(iter(scopes))[0],
                  'geometry_epoch': next(iter(scopes))[1]},
        'source_and_encoded_pixels': SIZE,
        'marker': score,
        'meets_27_fps_gate': score['visible_fps'] >= 27 if native and trial['formal'] else None,
        'viewer_receipt_clock_windows': len(viewer),
        'host_local_clock_windows': len(host),
        'host_window_duration_seconds': sum(row['window_seconds'] for row in host),
        'viewer_window_duration_seconds': sum(row['window_seconds'] for row in viewer),
        'host_sent_h264': sum(row['h264_frames'] for row in host),
        'host_acknowledged': sum(row['drawn_acks'] for row in host),
        'viewer_native_presented': sum(row['native_presented'] for row in viewer),
        'viewer_drawn': sum(row['drawn'] for row in viewer),
        'zero_host_frame_windows': sum(row['h264_frames'] == 0 for row in host),
        'zero_viewer_draw_windows': sum(row['drawn'] == 0 for row in viewer),
        'host_stages': phase_stats(host, 'stages'),
        'host_encoder_stages': phase_stats(host, 'hardware_encode_stages'),
        'viewer_stages': phase_stats(viewer, 'stages'),
    }
    if native:
        result['native_x11_prefetch'] = verify_prefetch(viewer, viewer_all, mode)
        result['native_x11_phases'] = phase_stats(viewer, 'native_x11_stages')
    return result, host, viewer, marks
