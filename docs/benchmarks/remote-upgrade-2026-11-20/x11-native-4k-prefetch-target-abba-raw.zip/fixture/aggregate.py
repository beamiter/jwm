"""Compute scoped native prefetch aggregates from validated trial reports."""

import argparse
import json
from pathlib import Path
from statistics import median


def group_summary(rows, group):
    names = sorted({name for row in rows for name in row[group]})
    result = {}
    for name in names:
        stages = [row[group][name] for row in rows if name in row[group]]
        counts = sum(stage['observations'] or 0 for stage in stages)
        result[name] = {
            'weighted_mean_ms': (
                sum(stage['weighted_mean_ms'] * stage['observations'] for stage in stages
                    if stage.get('observations') and stage.get('weighted_mean_ms') is not None) / counts
                if counts else None),
            'median_trial_window_mean_ms': median(stage['median_window_mean_ms'] for stage in stages),
            'median_trial_window_p95_ms': (median(value) if (
                value := [stage['median_window_p95_ms'] for stage in stages
                          if stage['median_window_p95_ms'] is not None]) else None),
            'observations': counts if counts else None,
        }
    return result


def aggregate(summary):
    rows = summary['attempts']
    pairs = []
    for first, second in zip(rows[::2], rows[1::2]):
        scoped = {row['mode']: row for row in (first, second)}
        if scoped.keys() != {'off', 'on'}:
            continue
        off, on = scoped['off'], scoped['on']
        if not (off['status'] == on['status'] == 'valid'):
            continue
        pairs.append({
            'slots': [first['slot'], second['slot']],
            'on_minus_off_fps': on['marker']['visible_fps'] - off['marker']['visible_fps'],
            'on_minus_off_gap_p95_ms': on['marker']['gap_p95_ms'] - off['marker']['gap_p95_ms'],
            'on_minus_off_longest_gap_ms': on['marker']['longest_gap_ms'] - off['marker']['longest_gap_ms'],
        })
    arms = {}
    for mode in ('off', 'on'):
        valid = [row for row in rows if row['mode'] == mode and row['status'] == 'valid']
        if not valid:
            continue
        totals = {}
        for scope in ('steady', 'whole_run'):
            fields = ('native_imports', 'synchronous_allocations', 'prefetch_uses')
            observed = {name: sum(row['native_x11_prefetch'][scope][name] for row in valid)
                        for name in fields}
            totals[scope] = observed | {
                'miss_ratio': observed['synchronous_allocations'] / observed['native_imports'],
            }
        arms[mode] = {
            'retained_viewer_windows': sum(row['viewer_receipt_clock_windows'] for row in valid),
            'retained_host_windows': sum(row['host_local_clock_windows'] for row in valid),
            'score_fps': [row['marker']['visible_fps'] for row in valid],
            'score_p95_gap_ms': [row['marker']['gap_p95_ms'] for row in valid],
            'score_max_gap_ms': [row['marker']['longest_gap_ms'] for row in valid],
            'whole_observer_invalid_markers': [row['marker']['observer_raw_summary']['invalid']
                                               for row in valid],
            'imports': totals,
            'native_x11_phases': group_summary(valid, 'native_x11_phases'),
            'host_stages': group_summary(valid, 'host_stages'),
            'viewer_stages': group_summary(valid, 'viewer_stages'),
        }
    return {'arms': arms, 'pairs': pairs}


if __name__ == '__main__':
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('summary', type=Path)
    args = cli.parse_args()
    print(json.dumps(aggregate(json.loads(args.summary.read_text())), indent=2))
