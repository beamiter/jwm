"""Replay P07 ReleaseAll using typed X11 edges and issuer timestamps."""

SAMPLES = 100
SESSIONS = 3
SOFTWARE_LIMIT_NS = 50_000_000
NS = 1_000_000_000
METRICS = {"loopback": "same_clock_host_edge", "dual": "viewer_receive_upper_bound"}
CLOCKS = {
    "loopback": "one system CLOCK_MONOTONIC",
    "dual": "separate CLOCK_MONOTONIC clocks, viewer issue through independent SSH observer receipt only",
}
KEY_PRESS, KEY_RELEASE, BUTTON_PRESS, BUTTON_RELEASE, MOTION = 2, 3, 4, 5, 6
INLINE_TRANSPORT = "in_key_up_observer_reply_after_source_xquerykeymap"
PROBE_KEYS = ("F8", "F9", "Control_L", "Super_L", "F12")
SAMPLE_STATES = {"passed", "timeout", "failed", "not_issued"}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def timestamp(value):
    return type(value) is int and value > 0


def interval(ns):
    return ns / 1_000_000


def nearest(values, percentile=95):
    return sorted(values)[(len(values) * percentile + 99) // 100 - 1] if values else None


def nondecreasing(values):
    return all(before <= after for before, after in zip(values, values[1:]))


def source_witness(sample, profile, keys, inline=False):
    seq = sample["seq"]
    key = sample["held_keycode"]
    issue = sample["viewer_issue_ns"]
    edge_t = sample["host_edge_ns"]
    receipt = sample["viewer_receipt_ns"]
    cleanup = sample["viewer_local_key_up_ns"]
    require(all(timestamp(t) for t in (issue, edge_t, receipt, cleanup)), "sample lacks release or cleanup timestamp")
    require(key == keys[PROBE_KEYS[(seq - 1) % 2]], "held keycode does not match the alternating X11 probe key")
    ctrl, sup, trigger = (keys[name] for name in ("Control_L", "Super_L", "F12"))
    require(sample["grab_before"] == [1, 1] and sample["grab_after"] == [0, 0], "viewer grab ownership did not cross release")
    require(sample["host_held_before"] == sample["viewer_held_before"] == [key] and
            sample["host_held_after"] == sample["viewer_held_after_cleanup"] == [] and
            set(sample["viewer_held_before_cleanup"]) == {key, ctrl, sup, trigger},
            "endpoint key state did not prove held-key release")
    edges = sample["source_edges"]
    indices = [edge["index"] for edge in edges]
    require(indices == list(range(1, len(indices) + 1)), "missing, duplicate or reordered source edge index")
    require(all(edge["seq"] == seq and timestamp(edge["host_ns"]) and timestamp(edge["viewer_receipt_ns"])
                for edge in edges) and nondecreasing([edge["host_ns"] for edge in edges]) and
            nondecreasing([edge["viewer_receipt_ns"] for edge in edges]),
            "source edge identity or monotonic order changed")
    edges_raw = [(edge["type"], edge["detail"]) for edge in edges]
    forwarded = [code for kind, code in edges_raw[3:] if kind == KEY_PRESS]
    require(forwarded == [code for code in (ctrl, sup) if code in forwarded], "unexpected forwarded chord key-down")
    expected = ([(BUTTON_PRESS, 1), (BUTTON_RELEASE, 1), (KEY_PRESS, key)] +
                [(KEY_PRESS, code) for code in forwarded] +
                [(KEY_RELEASE, code) for code in reversed(forwarded)] + [(KEY_RELEASE, key)])
    require(expected == edges_raw, "source edges do not preserve reacquisition and reverse modifier unwind")
    require(edges[-1]["host_ns"] == edge_t and edges[-1]["viewer_receipt_ns"] == receipt,
            "raw held-key release and reply differ from the sampled endpoints")
    if inline:
        checked = edges[-1]["host_keymap_checked_ns"]
        require(edges[-1]["host_held_at_release"] == sample["host_held_after"] == [] and
                timestamp(checked) and checked >= edge_t and sample["host_keymap_checked_ns"] == checked,
                "matched X11 key-up has no valid inline source XQueryKeymap proof")
    actions = sample["viewer_actions"]
    expected_actions = [
        ("focus_pointer", MOTION, 0), ("reacquire_button_down", BUTTON_PRESS, 1),
        ("reacquire_button_up", BUTTON_RELEASE, 1), ("held_key_down", KEY_PRESS, key),
        ("shortcut_modifier_down", KEY_PRESS, ctrl), ("shortcut_modifier_down", KEY_PRESS, sup),
        ("shortcut_trigger_down", KEY_PRESS, trigger), ("shortcut_cleanup_up", KEY_RELEASE, trigger),
        ("shortcut_cleanup_up", KEY_RELEASE, sup), ("shortcut_cleanup_up", KEY_RELEASE, ctrl),
        ("held_key_local_up", KEY_RELEASE, key),
    ]
    require([(row["event"], row["type"], row["detail"]) for row in actions] == expected_actions and
            all(timestamp(row["at_ns"]) for row in actions) and nondecreasing([row["at_ns"] for row in actions]) and
            actions[6]["at_ns"] == issue and actions[-1]["at_ns"] == cleanup,
            "viewer XTEST action trace differs from the issued ReleaseAll and local cleanup")
    require(edges[1]["viewer_receipt_ns"] <= actions[3]["at_ns"] <= edges[2]["viewer_receipt_ns"] <=
            issue <= receipt <= actions[7]["at_ns"] <= cleanup,
            "viewer action and source reply order crossed the ReleaseAll boundary")
    if sample.get("pipelined_setup"):
        require(actions[1]["at_ns"] <= actions[2]["at_ns"] <= edges[0]["viewer_receipt_ns"] <=
                edges[1]["viewer_receipt_ns"], "pipelined click did not preserve both local actions and host replies")
        press = edges[2]
        before = sample["host_press_keymap_checked_ns"]
        require(press["host_held_at_press"] == [key] and timestamp(before)
                and press["host_ns"] <= before <= edges[-1]["host_ns"]
                and before == press["host_press_keymap_checked_ns"],
                "pipelined setup lost source XQueryKeymap proof at the actual key-down")
        if sample.get("event_armed_setup"):
            click = edges[0]
            checked = click["host_start_keymap_checked_ns"]
            require("arm_exchange" not in sample and click["host_held_at_start"] == [] and
                    timestamp(checked) and click["host_ns"] <= checked <= before and
                    sample["started_ns"] <= actions[0]["at_ns"],
                    "actual source click did not establish clean auto-arm evidence")
        else:
            arm = sample["arm_exchange"]
            require(arm["op"] == "arm" and arm["seq"] == seq and arm["held_keycode"] == key and
                    timestamp(arm["request_id"]) and timestamp(arm["host_command_read_ns"]) and
                    timestamp(arm["host_reply_ns"]) and arm["host_command_read_ns"] <= arm["host_reply_ns"] and
                    sample["started_ns"] <= arm["viewer_request_ns"] <= arm["viewer_receipt_ns"] <= actions[0]["at_ns"],
                    "pipelined arm command or clock witness is incomplete")
    else:
        require(actions[1]["at_ns"] <= edges[0]["viewer_receipt_ns"] <= actions[2]["at_ns"] <=
                edges[1]["viewer_receipt_ns"], "serial setup did not observe both click edges in order")
    if profile == "loopback":
        require(edges[2]["host_ns"] <= issue <= edge_t <= receipt, "same-clock release sequence is out of order")
        return edge_t - issue

    # Host CLOCK_MONOTONIC has a separate epoch. Only the viewer's issue and
    # receipt timestamps participate in this bounded software interval.
    return receipt - issue


def unsuccessful_observation(sample, profile):
    result = {
        "slot": sample["slot"], "seq": sample.get("seq"), "status": sample["status"], "latency_ns": None,
        "stage": sample.get("stage"), "error_class": sample.get("error_class"),
        "shortcut_issued": timestamp(sample.get("viewer_issue_ns")),
    }
    issue = sample.get("viewer_issue_ns")
    edge_ns = sample.get("host_edge_ns")
    receipt = sample.get("viewer_receipt_ns")
    if not (timestamp(issue) and timestamp(edge_ns) and timestamp(receipt) and issue <= receipt):
        return result
    raw_edges = [edge for edge in sample["source_edges"]
                 if edge["seq"] == sample.get("seq") and edge["type"] == KEY_RELEASE and
                 edge["detail"] == sample.get("held_keycode") and edge["host_ns"] == edge_ns and
                 edge["viewer_receipt_ns"] == receipt]
    observed = edge_ns - issue if profile == "loopback" else receipt - issue
    if len(raw_edges) == 1 and 0 <= observed == sample.get("latency_ns"):
        result["unqualified_edge_witness"] = {
            "duration_ns": observed,
            "metric": METRICS[profile],
            "source_edge_index": raw_edges[0]["index"],
            "proof_fields_missing": [field for field in (
                "host_held_after", "grab_after", "viewer_local_key_up_ns", "viewer_held_after_cleanup",
            ) if field not in sample or sample[field] is None],
        }
    return result


def observation(sample, profile, deadline_ns, keys, inline=False):
    status = sample["status"]
    require(status in SAMPLE_STATES, "unexpected sample outcome")
    seq = sample.get("seq")
    if status != "passed":
        return unsuccessful_observation(sample, profile)
    duration = source_witness(sample, profile, keys, inline)
    require(duration == sample["latency_ns"] and 0 <= duration <= deadline_ns,
            "recorded latency differs from raw evidence or exceeds its deadline")
    result = {"slot": sample["slot"], "seq": seq, "status": "passed", "latency_ns": duration}
    if inline:
        result["source_keymap_proof_ns_after_key_up"] = sample["host_keymap_checked_ns"] - sample["host_edge_ns"]
    return result


def distribution(observations, planned=SAMPLES):
    response = [sample["latency_ns"] for sample in observations if sample["status"] == "passed"]
    rank = (planned * 95 + 99) // 100
    p95_upper = sorted(response)[rank - 1] if len(response) >= rank else None
    return {
        "planned_observations": planned,
        "replayed_slot_records": len(observations),
        "verified_responses": len(response),
        "timeouts": sum(item["status"] == "timeout" for item in observations),
        "failed_or_invalid_attempts": sum(item["status"] in {"failed", "invalid_evidence"} for item in observations),
        "not_issued_slots": sum(item["status"] == "not_issued" for item in observations),
        "absent_slot_records": planned - len(observations),
        "nearest_rank_p95_rank": rank,
        "p95_ms_over_planned_rank": interval(p95_upper) if p95_upper is not None else None,
        "p95_planned_rank_unbounded": p95_upper is None,
        "observed_only_ms": {
            "minimum": interval(min(response)) if response else None,
            "p50": interval(nearest(response, 50)) if response else None,
            "p95": interval(nearest(response)) if response else None,
            "maximum": interval(max(response)) if response else None,
        },
        "planned_rank_at_most_50_ms": p95_upper is not None and p95_upper <= SOFTWARE_LIMIT_NS,
    }


def verify_phase_slots(rows, phase, start, end, planned):
    require(type(rows) is list and len(rows) <= planned, "unexpected count of phase slot records")
    for index, sample in enumerate(rows, 1):
        slot_ns = start + ((end - start) * (index - 1) // planned)
        next_slot_ns = start + ((end - start) * index // planned)
        require(sample["phase"] == phase and sample["slot"] == index and sample["planned_slot_ns"] == slot_ns,
                "fixed scheduled phase or sample slot differs")
        if sample["status"] == "passed":
            require(slot_ns <= sample["started_ns"] < min(next_slot_ns, sample["viewer_issue_ns"]) and
                    sample["viewer_issue_ns"] <= sample["viewer_receipt_ns"] < end and
                    sample["viewer_local_key_up_ns"] <= sample["observations_finished_locally_ns"],
                    "completed sample crossed its observation phase or began outside its planned slot")


def threshold(profile, complete_trace, stats):
    if not complete_trace or stats["p95_planned_rank_unbounded"]:
        return "not_evaluable"
    if stats["planned_rank_at_most_50_ms"]:
        return "met" if profile == "loopback" else "met_by_measured_upper_bound"
    if profile == "dual":
        return "upper_bound_above_50_ms_exact_one_way_inconclusive"
    return "not_met" if stats["verified_responses"] == stats["planned_observations"] else "unverified_samples"


def endpoint_checks(endpoint, profile):
    scope = (endpoint.get("authenticated_scope_equal") is True and endpoint.get("host_auth_starts") == 1 and
             endpoint.get("viewer_auth_starts") == 1 and endpoint.get("final_viewer_stats") is True and
             len(endpoint.get("host_session_aliases", [])) == 1 and
             endpoint["host_session_aliases"] == endpoint.get("viewer_session_aliases"))
    exits = (endpoint.get("host_exit") == endpoint.get("viewer_exit") == endpoint.get("observer_exit") == 0
             and endpoint.get("host_held_when_finished") == [])
    frames = endpoint.get("observed_route", [])
    interfaces = [endpoint.get("host_interface"), endpoint.get("viewer_interface")]
    route = (endpoint.get("viewer_dimensions") == [1920, 1080] and bool(frames) and
             all(frame.get("codec") == "JPEG" and frame.get("encoded_dimensions") == [1920, 1080]
                 for frame in frames) and
             (interfaces == ["lo", "lo"] if profile == "loopback" else all(kind and kind != "lo" for kind in interfaces)))
    has_grant_witness = any(name in endpoint for name in (
        "viewer_keyboard_and_pointer_granted", "host_keyboard_and_pointer_granted",
    ))
    if has_grant_witness:
        scope = (scope and endpoint.get("viewer_keyboard_and_pointer_granted") is True and
                 endpoint.get("host_keyboard_and_pointer_granted") is True and
                 endpoint.get("host_keymap_diagnostic_lines") == 0)
    if "viewer_dimensions_at_close" in endpoint:
        route = route and endpoint["viewer_dimensions_at_close"] == endpoint["viewer_dimensions"]
    alignment = endpoint.get("keymap_alignment")
    if alignment is not None:
        before, after = alignment.get("before") or {}, alignment.get("after") or {}
        scope = (scope and alignment.get("authority_matches") is True and
                 type(before.get("compatible")) is bool and
                 alignment.get("viewer_map_loaded") is (not before["compatible"]) and
                 after.get("compatible") is True and after.get("modifiers_equal") is True and
                 after.get("differing_keycodes") == [] and type(after.get("common_bound")) is int and
                 after["common_bound"] >= 32 and has_grant_witness and
                 all(frame.get("source_dimensions") == [1920, 1080] for frame in frames))
    return scope, exits, route


def reconcile_ledger(frozen, joined):
    require(len(frozen) == len(joined), "append-only and joined sample counts differ")
    observed_after_deadline = {}
    for old, new in zip(frozen, joined):
        if old == new:
            continue
        same_action = {key: value for key, value in old.items() if key != "source_edges"} == {
            key: value for key, value in new.items() if key != "source_edges"
        }
        require(old["status"] in {"failed", "timeout"} and same_action,
                "append-only action changed in joined result")
        observed = old["source_edges"]
        updated = new["source_edges"]
        require(len(updated) > len(observed) and updated[:len(observed)] == observed,
                "joined result omitted or rewrote an observed edge")
        late = updated[len(observed):]
        ended = old["observations_finished_locally_ns"]
        require(all(edge["seq"] == old["seq"] and edge["index"] == index and
                    timestamp(edge["host_ns"]) and timestamp(edge["viewer_receipt_ns"]) and
                    edge["viewer_receipt_ns"] > ended
                    for index, edge in enumerate(late, len(observed) + 1)) and
                nondecreasing([edge["host_ns"] for edge in updated]) and
                nondecreasing([edge["viewer_receipt_ns"] for edge in updated]),
                "late source edge is not a post-deadline extension of the same attempt")
        observed_after_deadline[(old["phase"], old["slot"])] = [
            edge | {"received_after_observation_ns": edge["viewer_receipt_ns"] - ended} for edge in late
        ]
    return observed_after_deadline


def trial_replay(session, profile, timings, expected_index, ledger, inline=False):
    require(session["session_index"] == expected_index and session["requested"] == SAMPLES,
            "session slot or sample budget changed")
    samples, warmup = session["samples"], session["warmup_samples"]
    require(type(samples) is list and type(warmup) is list and len(samples) <= SAMPLES,
            "attempted or retained sample count exceeds planned slots")
    late_source = reconcile_ledger(ledger, warmup + samples)
    if inline:
        require(not late_source, "terminal-lane edge leaked into the measured inline sample ledger")
    attempted = sum("seq" in sample for sample in samples)
    require(session["attempted"] == attempted and session["not_attempted"] == SAMPLES - attempted and
            session["shortcut_issued"] == sum("viewer_issue_ns" in sample for sample in samples),
            "attempted, missing and issued sample counts differ")
    sequence = [sample["seq"] for sample in ledger if "seq" in sample]
    require(sequence == list(range(1, len(sequence) + 1)), "missing or duplicated viewer action sequence")
    keys = session.get("probe_keycodes", {})
    if samples or warmup:
        require(set(keys) == set(PROBE_KEYS) and all(type(code) is int and 8 <= code <= 255 for code in keys.values())
                and len(set(keys.values())) == len(PROBE_KEYS), "missing or invalid probe X11 keycodes")
        start, score, end = (session[field] for field in ("warmup_start_ns", "score_start_ns", "score_end_ns"))
        require(all(timestamp(t) for t in (start, score, end)) and
                score - start == timings["warmup_seconds"] * NS and end - score == timings["score_seconds"] * NS,
                "warmup or scoring duration differs from formal scope")
        verify_phase_slots(warmup, "warmup", start, score, timings["warmup_samples"])
        verify_phase_slots(samples, "scored", score, end, SAMPLES)
    observations = []
    warmup_failures = []
    for sample in ledger:
        try:
            verified = observation(sample, profile, timings["deadline_ms"] * 1_000_000, keys, inline)
        except (KeyError, ValueError, TypeError) as error:
            verified = {"slot": sample["slot"], "seq": sample.get("seq"), "status": "invalid_evidence",
                        "latency_ns": None, "error": str(error) if type(error) is ValueError else type(error).__name__}
        late_edges = late_source.get((sample["phase"], sample["slot"]))
        if late_edges:
            verified["late_source_edges_after_observation"] = late_edges
        if sample["phase"] == "scored":
            observations.append(verified)
        elif verified["status"] != "passed":
            warmup_failures.append(verified | {"stage": sample.get("stage")})
    issued = [sample["viewer_issue_ns"] for sample in ledger if timestamp(sample.get("viewer_issue_ns"))]
    require(all(before < after for before, after in zip(issued, issued[1:])),
            "viewer issue timestamps are repeated or reordered across samples")
    stages = distribution(observations)
    endpoint = session.get("endpoint_witness") or {}
    scope, exits, route = endpoint_checks(endpoint, profile)
    complete_trace = (len(samples) == SAMPLES and len(warmup) == timings["warmup_samples"] and
                      not warmup_failures and not any(item["status"] == "invalid_evidence" for item in observations)
                      and scope and exits and route and session.get("setup_status") == "passed")
    all_responded = stages["verified_responses"] == SAMPLES
    teardown = verify_failed_teardown(endpoint, ledger) if inline else None
    if inline and session.get("status") == "passed":
        require(teardown is None and "terminal_error" not in endpoint and exits and scope and route,
                "completed inline trial missed clean authenticated endpoint closure")
    result = {
        "session_index": expected_index, "fixture_setup_status": session.get("setup_status"),
        "fixture_session_status": session.get("status"),
        "fixture_session_error_class": session.get("error_class"),
        "fixture_session_failure_code": session.get("failure_code"),
        "missing_terminal_evidence": [name for name in (
            "host_exit", "viewer_exit", "observer_exit", "authenticated_scope_equal", "final_viewer_stats",
        ) if name not in endpoint],
        "complete_trace": complete_trace,
        "authenticated_scope_verified": scope, "endpoint_exits_clean": exits, "jpeg_x11_route_verified": route,
        "endpoint_routing": {
            key: endpoint[key] for key in ("host_interface", "viewer_interface", "keymap_alignment",
                                          "viewer_keyboard_and_pointer_granted", "host_keyboard_and_pointer_granted",
                                          "host_keymap_diagnostic_lines") if key in endpoint
        },
        "attempted": attempted, "not_attempted": SAMPLES - attempted,
        "warmup_records": len(warmup), "warmup_failures": warmup_failures,
        "samples": observations, "distribution": stages,
        "all_attempts_responded": all_responded,
        "threshold_evaluation": threshold(profile, complete_trace, stages),
        "replayed_software_p95_meets_50_ms": complete_trace and all_responded and stages["planned_rank_at_most_50_ms"],
    }
    if inline:
        result["release_proof_transport"] = INLINE_TRANSPORT
        result["failed_measurement_teardown"] = teardown
        result["failure_closed_with_full_endpoint_witness"] = bool(
            teardown and teardown["status"] == "observer_terminal_reply_received" and scope and exits and route
        )
        result["terminal_error"] = endpoint.get("terminal_error")
        delays = [sample["source_keymap_proof_ns_after_key_up"] for sample in observations
                  if sample["status"] == "passed"]
        result["inline_source_keymap_check"] = {
            "scored_key_up_edges_verified": len(delays),
            "edge_to_keymap_check_p95_ms": interval(nearest(delays)) if delays else None,
            "edge_to_keymap_check_max_ms": interval(max(delays)) if delays else None,
        }
    return result


def verify_failed_teardown(endpoint, samples):
    lane = endpoint.get("failed_measurement_teardown")
    if lane is None:
        return None
    finish = lane.get("finish_command") or {}
    pending = lane.get("pending_control")
    replies = lane.get("late_replies") or []
    finish_receipt = lane.get("finished_receipt_ns")
    result = {
        "status": "observer_terminal_reply_received" if finish_receipt is not None else "unfinished_teardown",
        "terminal_only_late_replies": len(replies),
        "finished_receipt_ns": finish_receipt,
        "pending_control": pending,
        "finish_command": finish or None,
        "late_replies": replies,
    }
    # Preserve an unfinished terminal lane even if malformed or truncated.
    # A claimed terminal reply, however, must have internally coherent IDs.
    if finish_receipt is None:
        return result
    require(finish.get("op") == "finish" and type(finish.get("seq")) is int and finish["seq"] >= 0 and
            type(finish.get("request_id")) is int and finish["request_id"] > 0 and len(replies) < 32,
            "invalid finished inline teardown command identity")
    actual = {finish["seq"]}
    if pending is not None:
        require(pending["op"] in {"arm", "snapshot"} and 0 < pending["request_id"] < finish["request_id"] and
                timestamp(pending["viewer_request_ns"]), "invalid abandoned inline control request")
        if pending["op"] == "arm":
            require(finish.get("abandoned_arm_seq") == pending["seq"] == finish["seq"] + 1,
                    "abandoned inline arm and finish identities differ")
            actual.add(pending["seq"])
        else:
            require("abandoned_arm_seq" not in finish and pending["seq"] == finish["seq"],
                    "abandoned inline snapshot and finish identities differ")
    else:
        require("abandoned_arm_seq" not in finish, "inline finish named an unrecorded abandoned arm")
    if "abandoned_event_seq" in finish:
        require(pending is None and samples and finish["abandoned_event_seq"] == finish["seq"] > 0
                and samples[-1].get("event_armed_setup") is True and samples[-1].get("seq") == finish["seq"]
                and not samples[-1].get("source_edges"),
                "inline finish named an unrecorded abandoned source click")
        actual.add(finish["seq"] - 1)
    if samples and samples[-1].get("event_armed_setup") is True:
        source_seq = lane.get("finished_source_seq")
        require(type(source_seq) is int and source_seq in actual,
                "finished source did not match the event-armed terminal sequence")
        result["finished_source_seq"] = source_seq
    times = [reply["viewer_receipt_ns"] for reply in replies] + [finish_receipt]
    require(all(timestamp(t) for t in times) and nondecreasing(times), "terminal inline reply timestamps regressed")
    if samples:
        require(finish_receipt >= samples[-1]["observations_finished_locally_ns"],
                "finished teardown reply preceded the frozen measurement")
    saw_control = False
    for reply in replies:
        name = reply["event"]
        require(reply["seq"] in actual, "teardown reply is outside the abandoned sample identity")
        if name == "edge":
            require(timestamp(reply["host_ns"]) and reply["index"] > 0,
                    "invalid late X11 edge in failed teardown")
            continue
        require(pending is not None and not saw_control and reply["request_id"] == pending["request_id"] and
                reply["request_seq"] == reply["seq"] == pending["seq"] and
                reply["viewer_receipt_ns"] >= pending["viewer_request_ns"] and
                timestamp(reply["host_command_read_ns"]) and timestamp(reply["host_reply_ns"]) and
                reply["host_reply_ns"] >= reply["host_command_read_ns"],
                "late inline control reply does not match the abandoned request")
        require((name == "snapshot" and pending["op"] == "snapshot" and reply["token"] == pending["token"]) or
                (name == "armed" and pending["op"] == "arm"), "unexpected inline teardown control kind")
        saw_control = True
        result["abandoned_control_request_to_reply_ns"] = reply["viewer_receipt_ns"] - pending["viewer_request_ns"]
    result["matched_abandoned_control_reply"] = saw_control
    return result
