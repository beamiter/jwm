#!/usr/bin/env bash
# Only used by the isolated phase diagnostic. The Rust test still owns the viewer PID.
set -euo pipefail
lab=$(cd "$(dirname "$0")" && pwd)
[[ ${1-} == session && -x ${JWM_PHASE_REAL_VIEWER:?} && -d ${JWM_PHASE_EVIDENCE:?} ]]
exec "$JWM_PHASE_REAL_VIEWER" "$@" --stats-json \
    2> >(python3 -B "$lab/tee_stderr.py" "$JWM_PHASE_EVIDENCE" >&2)
