"""Timestamp whole viewer JSON records and preserve the test's original stderr pipe."""
import json
from pathlib import Path
import sys
import time


def relay(incoming, forwarded, complete, windows, clock=time.monotonic_ns):
    for line in incoming:
        arrived = clock()
        complete.write(line)
        complete.flush()
        if line.startswith(b'{') and b'jwm_remote_viewer_stats' in line:
            record = json.loads(line)
            if record.get('type') == 'jwm_remote_viewer_stats':
                print(json.dumps({'arrival_monotonic_ns': arrived, 'record': record},
                                 separators=(',', ':')), file=windows, flush=True)
        if forwarded is not None:
            try:
                forwarded.write(line)
                forwarded.flush()
            except BrokenPipeError:
                forwarded = None


def main(evidence):
    with (evidence / 'viewer-complete-stderr.log').open('xb') as complete, \
            (evidence / 'viewer-stage-windows.jsonl').open('x') as windows:
        relay(sys.stdin.buffer, sys.stdout.buffer, complete, windows)
    (evidence / 'viewer-stderr-relay-complete').touch(exist_ok=False)


if __name__ == '__main__':
    main(Path(sys.argv[1]))
