#define _GNU_SOURCE
#include <dlfcn.h>
#include <errno.h>
#include <pthread.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

struct SwsContext;
typedef int (*scale_fn)(struct SwsContext *, const uint8_t *const [], const int [],
                       int, int, uint8_t *const [], const int *);
static pthread_once_t initialized = PTHREAD_ONCE_INIT;
static scale_fn actual_scale;

static void resolve_scale(void)
{
    actual_scale = (scale_fn)dlsym(RTLD_NEXT, "sws_scale");
    if (!actual_scale)
        _exit(125);
}

int sws_scale(struct SwsContext *context, const uint8_t *const source[],
              const int source_stride[], int first, int height,
              uint8_t *const dest[], const int dest_stride[])
{
    int saved_errno = errno;
    pthread_once(&initialized, resolve_scale);
    const char *gate = getenv("JWM_WORKBENCH_DELAY");
    if (gate && first == 0 && height > 0 && height <= 640 && access(gate, F_OK) == 0) {
        // Both arms have the same area-proportional RGB conversion burden.
        struct timespec left = {
            .tv_sec = 0,
            .tv_nsec = 33000000LL * height * height / (640 * 640),
        };
        while (nanosleep(&left, &left) == -1 && errno == EINTR) {}
    }
    errno = saved_errno;
    return actual_scale(context, source, source_stride, first, height, dest, dest_stride);
}
