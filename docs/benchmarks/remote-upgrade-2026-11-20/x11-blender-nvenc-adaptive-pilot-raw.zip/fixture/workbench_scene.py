"""Deterministic interactive Workbench scene, executed only inside Blender."""
import json
import math
import os
from pathlib import Path
import time

import bpy
import gpu
from mathutils import Vector

SCENE_VERSION = 'jwm-workbench-cube-v2'
REPORT = Path(os.environ['JWM_WORKBENCH_REPORT'])
START = Path(os.environ['JWM_WORKBENCH_START'])
STOP = Path(os.environ['JWM_WORKBENCH_STOP'])
RECOVERY_FRAME = 151

bpy.context.preferences.view.show_splash = False
bpy.context.preferences.inputs.use_mouse_emulate_3_button = True
bpy.context.preferences.inputs.use_mouse_continuous = False
bpy.context.preferences.edit.keyframe_new_interpolation_type = 'LINEAR'
scene = bpy.context.scene
scene.render.engine = 'BLENDER_WORKBENCH'
scene.render.resolution_x = 960
scene.render.resolution_y = 640
scene.render.resolution_percentage = 100
scene.render.fps = 60
scene.render.fps_base = 1
scene.sync_mode = 'FRAME_DROP'
scene.frame_start = 1
scene.frame_end = 7200
scene.view_settings.view_transform = 'Standard'

cube = scene.objects['Cube']
cube.animation_data_clear()
cube.rotation_mode = 'XYZ'
material = bpy.data.materials.new('JWM measured cube red')
material.diffuse_color = (0.95, 0.024, 0.012, 1.0)
cube.data.materials.clear()
cube.data.materials.append(material)
for index in range(121):
    frame = 1 + 60 * index
    cube.location = (-3.3 if index % 2 == 0 else 3.3, 0.0, 0.0)
    cube.rotation_euler = (math.radians(16), math.radians(13), math.radians(68) * index)
    cube.keyframe_insert(data_path='location', frame=frame, group='Cube travel')
    cube.keyframe_insert(data_path='rotation_euler', frame=frame, group='Cube turn')
scene.frame_set(scene.frame_start)
for obj in scene.objects:
    obj.select_set(False)

camera = scene.objects['Camera']
camera.location = (0.0, -14.0, 3.0)
camera.rotation_euler = (Vector((0.0, 0.0, 0.0)) - camera.location).to_track_quat('-Z', 'Y').to_euler()
camera.data.type = 'ORTHO'
camera.data.sensor_fit = 'HORIZONTAL'
camera.data.ortho_scale = 12.0
scene.camera = camera

configured = None
requested = False
stopped = False
last_report = 0.0
last_state = None


def control_and_report():
    global configured, requested, stopped, last_report, last_state
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type != 'VIEW_3D':
                continue
            region = next((item for item in area.regions if item.type == 'WINDOW'), None)
            if region is None or region.width < 150 or region.height < 150:
                continue
            space = area.spaces.active
            if configured != area.as_pointer():
                space.overlay.show_overlays = False
                space.show_gizmo = False
                space.shading.type = 'SOLID'
                space.shading.light = 'STUDIO'
                space.shading.color_type = 'MATERIAL'
                space.shading.background_type = 'VIEWPORT'
                space.shading.background_color = (0.035, 0.035, 0.035)
                space.region_3d.view_perspective = 'CAMERA'
                space.region_3d.view_camera_zoom = 0.0
                space.region_3d.view_camera_offset = (0.0, 0.0)
                configured = area.as_pointer()
                area.tag_redraw()
            if not requested and START.is_file():
                with bpy.context.temp_override(window=window, area=area, region=region):
                    if bpy.ops.screen.animation_play.poll():
                        requested = 'FINISHED' in bpy.ops.screen.animation_play()
            if requested and not stopped and STOP.is_file():
                with bpy.context.temp_override(window=window, area=area, region=region):
                    if window.screen.is_animation_playing and not bpy.ops.screen.animation_cancel.poll():
                        return 0.05
                    if window.screen.is_animation_playing:
                        bpy.ops.screen.animation_cancel(restore_frame=False)
                    scene.frame_set(RECOVERY_FRAME)
                    area.tag_redraw()
                    stopped = True
            playing = window.screen.is_animation_playing
            viewport = [region.x, window.height - region.y - region.height, region.width, region.height]
            state = (viewport, requested, stopped, playing)
            now = time.monotonic()
            if state != last_state or now - last_report >= 1.0:
                payload = {'scene': SCENE_VERSION, 'application_version': bpy.app.version_string,
                           'build_hash': bpy.app.build_hash.decode('ascii', 'replace'),
                           'renderer': gpu.platform.renderer_get(), 'render_engine': scene.render.engine,
                           'shading': space.shading.type, 'camera': space.region_3d.view_perspective,
                           'viewport': viewport, 'window_size': [window.width, window.height],
                           'timeline_fps': scene.render.fps, 'frame': scene.frame_current,
                           'playing': playing, 'playback_requested': requested, 'playback_stopped': stopped}
                staged = REPORT.with_suffix('.pending')
                staged.write_text(json.dumps(payload) + '\n')
                staged.replace(REPORT)
                last_state, last_report = state, now
            return 0.05
    return 0.05


bpy.app.timers.register(control_and_report, first_interval=0.0)
