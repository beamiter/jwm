#!/usr/bin/env python3
"""Measure fixed and adaptive H.264 with an actual Blender Workbench scene."""
import argparse
from contextlib import ExitStack
import fcntl
import hashlib
import json
import math
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import time
import traceback
from statistics import median
from capture_quality import compare_images, image_from_rows, save_pair, endpoint_resources

from processes import clean_env, get_display, start_display, stop, wait_for
from x11_session import (Pixels, monitor_stderr, stop_group,
                         wait_for_window, write_capture)

HERE = Path(__file__).resolve().parent
BLENDER = '/tmp/jwm-blender-acceptance.VR4FQlr0/blender-4.5.16-linux-x64/blender'
RELEASE = '/tmp/jwm-adaptive-resolution-recovery.Mru1IqY2/jwm-remote'
MEDIA_LIBS = '/tmp/jwm-remote-ffmpeg/usr/lib/x86_64-linux-gnu'
MODE_ORDER = ('fixed', 'adaptive', 'adaptive', 'fixed') * 2
UI_RECT = (800, 31, 150, 107)
RECOVERY_FRAME = 151
FULL = [960, 640]
SCENE = HERE / 'workbench_scene.py'
WIDTH, HEIGHT = 960, 640
SECOND = 1_000_000_000
REQUESTED_FPS = 30
POLL_HZ = 90


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def red_span(row):
    """Longest connected saturated-red mesh run in this row."""
    start = None
    best = None
    for x, (b, g, r) in enumerate(zip(row[0::4], row[1::4], row[2::4])):
        if r >= 75 and r - g >= 34 and r - b >= 42:
            if start is None:
                start = x
            if best is None or x - start > best[1] - best[0]:
                best = start, x
        else:
            start = None
    return best if best and best[1] - best[0] + 1 >= 14 else None


def locate_cube_row(rows, viewport):
    x, y, width, height = viewport
    # The startup scene keeps the cube centered vertically. The center of its
    # actual painted red components, not a hard-coded screen y, defines the ROI.
    run = []
    best = []
    for row in range(y + height // 4, y + 3 * height // 4, 3):
        if red_span(rows[row][x * 4:(x + width) * 4]) is not None:
            run.append(row)
            if len(run) > len(best):
                best = run.copy()
        else:
            run = []
    return best[len(best) // 2] if len(best) >= 8 else None


def read_cube(pixels, xid, viewport, scan_row):
    x, _, width, _ = viewport
    rows = pixels.crop(xid, x, scan_row - 1, width, 3)
    spans = sorted((span for row in rows if (span := red_span(row)) is not None),
                   key=lambda edges: sum(edges))
    if len(spans) < 2:
        return None
    left, right = spans[len(spans) // 2]
    return {'center_x': x + (left + right) // 2, 'left': x + left, 'right': x + right}


def score_pixels(rows, start, end):
    bins = [0] * ((end - start) // SECOND)
    previous = None
    invalid = samples = max_read = 0
    stamps = []
    for row in rows:
        stamp = row['end_monotonic_ns']
        if stamp >= end:
            break
        active = stamp >= start
        span = row['cube_span']
        if active:
            samples += 1
            max_read = max(max_read, stamp - row['start_monotonic_ns'])
            invalid += span is None
        if span is None:
            continue
        current = span['center_x']
        if previous is None:
            previous = current
        elif abs(current - previous) >= 2:
            previous = current
            if active:
                bins[(stamp - start) // SECOND] += 1
                stamps.append(stamp)
    points = [start, *stamps, end]
    gaps = sorted((b - a) / 1e6 for a, b in zip(points, points[1:]))
    return {'distinct_mesh_positions': len(stamps), 'unique_content_fps': len(stamps) / len(bins),
            'one_second_unique_bins': bins, 'zero_unique_bins': bins.count(0),
            'reads': samples, 'invalid_mesh_reads': invalid, 'observer_max_read_ms': max_read / 1e6,
            'gap_ms': {'p95': gaps[math.ceil(.95 * len(gaps)) - 1], 'max': gaps[-1]},
            'accepted_monotonic_ns': stamps}


def capture_rect(lanes, rect):
    return tuple(image_from_rows(pixels.crop(xid, *rect)) for pixels, xid in lanes.values())


def observed_telemetry(path):
    return [json.loads(line) for line in path.read_text().splitlines(keepends=True)
            if line.endswith('\n')]


def score_telemetry(directory, phase, role):
    start, end = (phase[f'score_{bound}_monotonic_ns'] for bound in ('start', 'end'))
    clocked = observed_telemetry(directory/f'{role}-clocked-telemetry.jsonl')
    included = [row for row in clocked
                if start <= row['end_monotonic_ns'] - round(row['record']['window_seconds'] * SECOND)
                and row['end_monotonic_ns'] <= end]
    rows = [row['record'] for row in included]
    scope_field = 'last_sent_frame' if role == 'host' else 'last_frame'
    frames = [row[scope_field] for row in rows if row.get(scope_field)]
    codecs = sorted({frame['codec'] for frame in frames})
    shapes = sorted({tuple(frame['encoded_dimensions']) for frame in frames})
    stages = {
        'host': ('capture_ms', 'atlas_pack_and_codec_ms', 'credit_wait_ms', 'socket_write_ms', 'capture_start_to_ack_ms'),
        'viewer': ('decode_ms', 'presentation_queue_ms', 'presentation_completion_ms'),
    }
    summary = {
        'whole_windows': len(rows),
        'window_seconds': sum(row['window_seconds'] for row in rows),
        'frame_scopes': len(frames),
        'codecs': codecs,
        'encoded_rasters': shapes,
        'source_rasters': sorted({tuple(frame['source_dimensions']) for frame in frames}),
        'sessions': sorted({row['session_id'] for row in rows}),
        'paths': sorted({path for row in rows if (path := row.get('mode' if role == 'host' else 'last_presentation_path'))}),
    }
    if role == 'host' and summary['window_seconds']:
        summary['video_payload_mbit_per_second'] = sum(row['bytes'] for row in rows) * 8 / (1e6 * summary['window_seconds'])
        summary['peak_outstanding'] = max(row['max_outstanding'] for row in rows)
    tails = {}
    for stage in stages[role]:
        values = []
        for row in rows:
            stat = row.get('stages', {}).get(stage)
            if stat:
                percentile = stat.get('quantiles', {}).get('p95_ms', stat.get('p95_ms'))
                if percentile is not None:
                    values.append(percentile)
        if values:
            tails[stage] = {'median_window_p95_ms': median(values), 'max_window_p95_ms': max(values), 'windows': len(values)}
    summary['stage_tails'] = tails
    return summary


def collect_phase(directory, name, lanes, report, viewport, scan_row, processes, warm, seconds):
    begin = time.monotonic_ns()
    start = begin + warm * SECOND
    end = start + seconds * SECOND
    phase = {'phase': name, 'phase_start_monotonic_ns': begin, 'score_start_monotonic_ns': start,
             'score_end_monotonic_ns': end, 'warmup_seconds': warm, 'scored_seconds': seconds}
    scope_path = directory/f'{name}-scope.json'
    write_json(scope_path, phase)
    positions = {side: [] for side in lanes}
    snapshots = []
    offsets = (seconds // 4, seconds // 2, 3 * seconds // 4)
    slot = last_health_check = 0
    with (directory/f'{name}-pixels.jsonl').open('w') as stream:
        while (now := time.monotonic_ns()) < end:
            if now - last_health_check >= SECOND:
                state = json.loads(report.read_text())
                if (any(proc.poll() is not None for proc in processes) or state['viewport'] != list(viewport)
                        or state['playing'] != (name != 'static')):
                    raise RuntimeError(f'{name} lost its owned process, viewport or playback state: {state}')
                last_health_check = now
            for side, (pixels, xid) in lanes.items():
                before = time.monotonic_ns()
                span = read_cube(pixels, xid, viewport, scan_row)
                observation = {'side': side, 'start_monotonic_ns': before,
                               'end_monotonic_ns': time.monotonic_ns(), 'cube_span': span}
                positions[side].append(observation)
                print(json.dumps(observation, separators=(',', ':')), file=stream)
            if len(snapshots) < len(offsets) and now >= start + offsets[len(snapshots)] * SECOND:
                stamp = time.monotonic_ns()
                images = capture_rect(lanes, UI_RECT)
                counters = {role: endpoint_resources(proc) for role, proc in zip(('host', 'viewer'), processes[1:], strict=True)}
                snapshots.append((stamp, images, counters))
            slot = max(slot + 1, (time.monotonic_ns() - begin) * POLL_HZ // SECOND + 1)
            due = min(end, begin + slot * SECOND // POLL_HZ)
            time.sleep(max(0, (due - time.monotonic_ns()) / SECOND))
    if len(snapshots) != len(offsets):
        raise RuntimeError(f'{name} missed a quality or resource snapshot')
    phase['samples'] = {side: score_pixels(rows, start, end) for side, rows in positions.items()}
    phase['quality'] = [{
        'label': f'{name}-ui-{index}',
        'offset_seconds': (stamp - start) / SECOND,
        'metrics': save_pair(directory, f'{name}-ui-{index}', pair),
        'resources': counters,
    } for index, (stamp, pair, counters) in enumerate(snapshots, 1)]
    phase['source_ui_stability'] = [compare_images(snapshots[0][1][0], pair[0])['rgb_mae']
                                    for _, pair, _ in snapshots]
    write_json(scope_path, phase)
    return phase


def measure_recovery(directory, lanes, report, viewport, scan_row, processes, stop, delay, static):
    requested = time.monotonic_ns()
    stop.touch(exist_ok=False)
    delay.unlink()

    def stopped():
        state = json.loads(report.read_text())
        return state if state.get('playback_stopped') and not state['playing'] and state['frame'] == RECOVERY_FRAME else None

    state = wait_for(processes[0], stopped, 8)
    write_json(directory/'recovery-blender-state.json', state)
    time.sleep(.25)
    source_at, source_id = lanes['source']
    viewer_at, viewer_id = lanes['viewer']
    target = read_cube(source_at, source_id, viewport, scan_row)
    if target is None:
        raise RuntimeError('stopped Blender pose did not expose its red cube')
    source_ui = image_from_rows(source_at.crop(source_id, *UI_RECT))
    max_mae = max(1., median(item['metrics']['rgb_mae'] for item in static['quality']) + 1.)
    first = None
    confirmed = None
    good = []
    trace = directory/'recovery-pixels.jsonl'
    with trace.open('w') as stream:
        while time.monotonic_ns() < requested + 78 * SECOND:
            if any(proc.poll() is not None for proc in processes):
                raise RuntimeError('actor exited before visual recovery')
            now = time.monotonic_ns()
            sample = read_cube(viewer_at, viewer_id, viewport, scan_row)
            viewer_ui = image_from_rows(viewer_at.crop(viewer_id, *UI_RECT))
            quality = compare_images(source_ui, viewer_ui)
            telemetry = observed_telemetry(directory/'viewer-clocked-telemetry.jsonl')
            recent = next((row for row in reversed(telemetry)
                           if row['end_monotonic_ns'] > requested and row['record'].get('last_frame')
                           and row['record']['acked'] > 0), None)
            scope = recent['record']['last_frame'] if recent else None
            matches = sample is not None and all(abs(sample[name] - target[name]) <= 3 for name in ('left','right','center_x'))
            eligible = bool(matches and scope and scope['encoded_dimensions'] == FULL and quality['rgb_mae'] <= max_mae)
            row = {'offset_ms': (now - requested) / 1e6, 'viewer_cube': sample, 'source_target_cube': target,
                   'ui_quality': quality, 'eligible': eligible,
                   'last_viewer_report': {'offset_ms': (recent['end_monotonic_ns'] - requested) / 1e6,
                                          'scope': scope} if recent else None}
            print(json.dumps(row, separators=(',', ':')), file=stream)
            if eligible:
                good.append(row)
                if len(good) == 3:
                    first, confirmed = good[0], good[-1]
                    save_pair(directory, 'recovery-ui-confirmed', (source_ui, viewer_ui))
                    save_pair(directory, 'recovery-viewport-confirmed', capture_rect(lanes, viewport))
                    break
            else:
                good.clear()
            time.sleep(.25)
    return {'stop_and_unload_requested_monotonic_ns': requested, 'blender_stop_frame': RECOVERY_FRAME,
            'baseline_derived_ui_mae_threshold': max_mae, 'first_sustained_observation': first,
            'confirmed_observation': confirmed, 'poll_interval_ms': 250,
            'viewer_scope_resolution_ms': 5000}


def run(args, directory, mode):
    directory.mkdir(mode=0o700)
    print(f'Workbench trial {mode}: {directory}', flush=True)
    runtime, config = directory / 'runtime', directory / 'blender-config'
    runtime.mkdir(mode=0o700)
    config.mkdir(mode=0o700)
    report = directory / 'workbench-view.json'
    start_playback, stop_playback, delay = (
        directory / name for name in ('start-playback', 'stop-playback', 'conversion-burden')
    )
    env = clean_env()
    for key in ('LD_PRELOAD', 'LD_LIBRARY_PATH', 'XAUTHORITY', 'JWM_WORKBENCH_DELAY'):
        env.pop(key, None)
    env.update(XDG_RUNTIME_DIR=str(runtime), XDG_SESSION_TYPE='x11')
    media_env = env | {'LD_LIBRARY_PATH': MEDIA_LIBS}
    host_env = media_env | ({'JWM_REMOTE_ADAPT_VIDEO': 'motion', 'JWM_REMOTE_ADAPT_RESOLUTION': '1'}
                            if mode == 'adaptive' else {})
    viewer_env = media_env | {'LD_PRELOAD': str(HERE/'proportional-rgb-delay.so'),
                              'JWM_REMOTE_ADAPT_FEEDBACK': '1', 'JWM_WORKBENCH_DELAY': str(delay)}
    size = f'{WIDTH}x{HEIGHT}'
    with ExitStack() as stack:
        def log(name):
            return stack.enter_context((directory / name).open('wb'))

        displays = []
        for side in ('source', 'viewer'):
            server = start_display(WIDTH, HEIGHT, log(f'{side}-xvfb.log'))
            stack.callback(stop, server)
            displays.append(get_display(server))
        source_display, viewer_display = displays
        blender_env = dict(env, DISPLAY=source_display, GDK_BACKEND='x11', LIBGL_ALWAYS_SOFTWARE='1',
                           BLENDER_USER_RESOURCES=str(config), BLENDER_USER_CONFIG=str(config),
                           JWM_WORKBENCH_REPORT=str(report), JWM_WORKBENCH_START=str(start_playback),
                           JWM_WORKBENCH_STOP=str(stop_playback))
        blender_env.pop('EGL_PLATFORM', None)
        app = subprocess.Popen(['dbus-run-session', '--', args.blender, '--factory-startup',
                                '--disable-autoexec', '--window-geometry', '0', '0', str(WIDTH), str(HEIGHT),
                                '--python', str(SCENE)], env=blender_env, stdout=log('blender-stdout.log'),
                               stderr=log('blender-stderr.log'), start_new_session=True)
        stack.callback(stop_group, app)
        source = wait_for_window(app, source_display, 'Blender', env, directory / 'blender-window.log', 30)
        subprocess.run(['xdotool', 'windowmove', str(source), '0', '0', 'windowsize', str(source),
                        str(WIDTH), str(HEIGHT)], env=dict(env, DISPLAY=source_display), check=True, timeout=5)
        native = wait_for_window(app, source_display, 'Blender', env, directory / 'blender-positioned.log', 10,
                                 (WIDTH, HEIGHT))
        if native != source:
            raise RuntimeError('Blender recreated its X11 window during setup')

        def ready_state():
            if not report.is_file():
                return None
            state = json.loads(report.read_text())
            if state.get('window_size') != [WIDTH, HEIGHT]:
                return None
            if (not state['application_version'].startswith('4.5.16') or state['build_hash'] != '3f6797307da5'
                    or state['scene'] != 'jwm-workbench-cube-v2' or state['render_engine'] != 'BLENDER_WORKBENCH'
                    or state['shading'] != 'SOLID' or state['camera'] != 'CAMERA' or state['playing']
                    or state['timeline_fps'] != 60
                    or not any(driver in state['renderer'].lower() for driver in ('llvmpipe', 'softpipe'))):
                raise RuntimeError(f'wrong Blender, scene or camera state: {state}')
            return state

        state = wait_for(app, ready_state, 15)
        viewport = tuple(state['viewport'])
        x, y, width, height = viewport
        if min(x, y) < 0 or width < 200 or height < 200 or x + width > WIDTH or y + height > HEIGHT:
            raise RuntimeError(f'unusable measured Blender viewport: {viewport}')
        write_json(directory / 'workbench-static-state.json', state)
        source_pixels = Pixels(source_display)
        stack.callback(source_pixels.close)
        last_pixels = ()

        def find_scan_row():
            nonlocal last_pixels
            last_pixels = source_pixels.crop(source_pixels.root, 0, 0, WIDTH, HEIGHT)
            return locate_cube_row(last_pixels, viewport)

        try:
            scan_row = wait_for(app, find_scan_row, 10)
        finally:
            if last_pixels:
                write_capture(directory / 'source-static.ppm', last_pixels)
        initial = read_cube(source_pixels, source_pixels.root, viewport, scan_row)
        if initial is None:
            raise RuntimeError('could not read the center of the actual startup cube')
        write_json(directory / 'workbench-initial-oracle.json', {'scan_row': scan_row, 'source_span': initial})
        key = directory / 'key'
        stack.callback(key.unlink, missing_ok=True)
        subprocess.run([args.release, 'keygen', '--output', str(key)], env=media_env, stdout=subprocess.DEVNULL,
                       check=True, timeout=8)
        host = subprocess.Popen([args.release, 'host', '--display', source_display, '--capture-source', 'root',
                                 '--scaling', 'auto', '--once', '--listen', '127.0.0.1:0', '--key-file', str(key),
                                 '--stats-json', '--fps', str(REQUESTED_FPS), '--max-width', str(WIDTH), '--allow-h264'],
                                env=host_env, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        stack.callback(stop, host)
        host_monitor, host_errors = monitor_stderr(host, 'host', directory)
        host_log = directory / 'host.log'

        def address():
            if not host_log.exists():
                return None
            match = re.search(r'listening on (127\.0\.0\.1:[0-9]+)', host_log.read_text())
            return match.group(1) if match else None

        remote = wait_for(host, address)
        viewer_args = [args.release, 'connect', remote, '--display', viewer_display, '--window-size', size,
                       '--window-position', '0,0', '--scaling', 'auto', '--view-only', '--toggle',
                       '--stats-json', '--key-file', str(key)]
        viewer = subprocess.Popen(viewer_args, env=viewer_env, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        stack.callback(stop, viewer)
        viewer_monitor, viewer_errors = monitor_stderr(viewer, 'viewer', directory)
        viewer_id = wait_for_window(viewer, viewer_display, f'{remote} - JWM Remote', env,
                                    directory / 'viewer-window.log', 15, (WIDTH, HEIGHT))
        for display in (source_display, viewer_display):
            subprocess.run(['xdotool', 'mousemove', '959', '639'], env=env | {'DISPLAY': display},
                           check=True, timeout=5)
        viewer_pixels = Pixels(viewer_display)
        stack.callback(viewer_pixels.close)

        def initial_viewer():
            seen = read_cube(viewer_pixels, viewer_id, viewport, scan_row)
            return seen if seen and abs(seen['center_x'] - initial['center_x']) <= 4 else None

        try:
            visible = wait_for(viewer, initial_viewer, 10)
        finally:
            write_capture(directory / 'viewer-static.ppm', viewer_pixels.crop(viewer_id, 0, 0, WIDTH, HEIGHT))
        write_json(directory / 'workbench-initial-oracle.json',
                   {'scan_row': scan_row, 'source_span': initial, 'viewer_span': visible})
        lanes = {'source': (source_pixels, source_pixels.root), 'viewer': (viewer_pixels, viewer_id)}
        processes = app, host, viewer
        phases = [collect_phase(directory, 'static', lanes, report, viewport, scan_row, processes,
                                5 if args.pilot else 30, 8 if args.pilot else 60)]
        save_pair(directory, 'static-viewport', capture_rect(lanes, viewport))
        start_playback.touch(exist_ok=False)

        def first_motion():
            active = json.loads(report.read_text()).get('playing')
            seen = read_cube(source_pixels, source_pixels.root, viewport, scan_row)
            return seen if active and seen and abs(seen['center_x'] - initial['center_x']) >= 8 else None

        wait_for(app, first_motion, 10)
        phases.append(collect_phase(directory, 'ordinary-motion', lanes, report, viewport, scan_row, processes,
                                    5 if args.pilot else 30, 8 if args.pilot else 60))
        delay.touch(exist_ok=False)
        phases.append(collect_phase(directory, 'pressured-motion', lanes, report, viewport, scan_row, processes,
                                    45, 10 if args.pilot else 60))
        recovery = measure_recovery(directory, lanes, report, viewport, scan_row, processes, stop_playback, delay, phases[0])
        write_json(directory/'recovery.json', recovery)
        subprocess.run(viewer_args, env=media_env, stdout=subprocess.DEVNULL, stderr=log('disconnect.log'),
                       check=True, timeout=8)
        statuses = viewer.wait(timeout=10), host.wait(timeout=10)
        for monitor in (viewer_monitor, host_monitor):
            monitor.join(timeout=3)
        if any(statuses) or viewer_errors or host_errors or viewer_monitor.is_alive() or host_monitor.is_alive():
            raise RuntimeError(f'host or viewer failed closure/telemetry: {statuses}, {host_errors}, {viewer_errors}')
        evidence = (directory/'host.log').read_text()
        if 'hardware H.264 encoding active (NVENC)' not in evidence or 'encoding failed, switching to JPEG' in evidence:
            raise RuntimeError('actual owned NVENC H.264 route was not retained')
        reduced = re.findall(r'hardware resolution target (75|50)%', evidence)
        if (mode == 'adaptive') != bool(reduced):
            raise RuntimeError(f'resolution policy did not distinguish matched modes: {mode}, tiers={reduced}')
        for phase in phases:
            phase['telemetry'] = {side: score_telemetry(directory, phase, side) for side in ('host', 'viewer')}
        result = {'mode': mode, 'pilot': args.pilot, 'resolution': FULL, 'ui_rect_xywh': UI_RECT,
                  'requested_fps': REQUESTED_FPS, 'codec': 'H.264 NVENC YUV420', 'static_state': state,
                  'scan_row': scan_row, 'phases': phases, 'stop_to_clarity': recovery,
                  'host_tier_events': re.findall(r'hardware resolution target (\d+)% \((\w+)\)', evidence),
                  'host_rate_events': re.findall(r'hardware rate target (\d+) fps, (\d+)% nominal bitrate \((\w+)\)', evidence),
                  'host_exit': statuses[1], 'viewer_exit': statuses[0]}
        write_json(directory/'result.json', result)
        for phase in phases:
            print(json.dumps({'mode': mode, 'phase': phase['phase'], 'trial': str(directory),
                  'source_fps': phase['samples']['source']['unique_content_fps'],
                  'viewer_fps': phase['samples']['viewer']['unique_content_fps'],
                  'viewer_p95_gap_ms': phase['samples']['viewer']['gap_ms']['p95'],
                  'host_rasters': phase['telemetry']['host']['encoded_rasters'],
                  'ui_mae': [row['metrics']['rgb_mae'] for row in phase['quality']]}), flush=True)
        if not recovery['confirmed_observation']:
            print(f'{mode} hit the 78-second clarity recovery limit', flush=True)
        return result


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def command(*args):
    return subprocess.check_output(args, text=True, timeout=12).strip()


if __name__ == '__main__':
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--blender', default=BLENDER)
    cli.add_argument('--release', default=RELEASE)
    cli.add_argument('--pilot', action='store_true')
    cli.add_argument('--out', type=Path, required=True)
    args = cli.parse_args()
    args.blender = str(Path(args.blender).resolve(strict=True))
    args.release = str(Path(args.release).resolve(strict=True))
    order = ('adaptive','fixed') if args.pilot else MODE_ORDER
    if sha(args.release) != 'b1a21b01f937331ede0df7a42eee0e923de21d8e3333fc9b040e8da8757b987b':
        raise SystemExit('release helper differs from the archived adaptive-resolution benchmark')
    if sha(args.blender) != 'c752cdc50bc29b5968e23b6e5588936bb05046e29dbc119e26aab79a9de2b55b':
        raise SystemExit('Blender executable differs from the declared configuration')
    with open('/tmp/jwm-p08-p09-release/benchmark.lock', 'a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        directory = args.out.resolve()
        directory.mkdir(mode=0o700)
        fixtures = directory/'fixture'
        fixtures.mkdir(mode=0o700)
        fixture_files = ('run_workbench.py','workbench_scene.py','capture_quality.py','processes.py',
                         'x11_session.py','proportional-rgb-delay.c','proportional-rgb-delay.so')
        for name in fixture_files:
            shutil.copyfile(HERE/name, fixtures/name)
        manifest = {
            'scene': SCENE.name, 'scene_sha256': sha(SCENE),
            'blender': args.blender, 'blender_sha256': sha(args.blender),
            'release': args.release, 'release_sha256_both_arms': sha(args.release),
            'mode_order': order, 'pilot': args.pilot,
            'scope': 'same machine, private Xvfb source and viewer, XRender Auto and authenticated IPv4 loopback',
            'host_and_viewer_cpu': next(line.split(':',1)[1].strip() for line in command('lscpu').splitlines() if line.startswith('Model name:')),
            'gpu': command('nvidia-smi','--query-gpu=name,driver_version','--format=csv,noheader'),
            'kernel': command('uname','-r'), 'xvfb': command('dpkg-query','-W','xvfb'),
            'viewer_pressure': 'on measured pressured-motion phase, proportional RGB conversion delay of 33 ms at 640 scanlines',
            'warmup_and_score_seconds': {'static': [30,60], 'ordinary-motion': [30,60], 'pressured-motion': [45,60]},
            'source_and_viewer_raster': FULL, 'requested_fps': REQUESTED_FPS, 'raw_ui_crop_xywh': UI_RECT,
            'fixture_sha256': {name: sha(HERE/name) for name in fixture_files},
        }
        write_json(directory/'manifest.json', manifest)
        outcomes = []
        for index, mode in enumerate(order,1):
            trial = directory/f'trial-{index:02}-{mode}'
            try:
                result = run(args, trial, mode)
                outcomes.append({'slot': index, 'mode': mode, 'status': 'completed',
                                 'motion_fps': result['phases'][1]['samples']['viewer']['unique_content_fps'],
                                 'pressured_fps': result['phases'][2]['samples']['viewer']['unique_content_fps'],
                                 'recovery_observed': bool(result['stop_to_clarity']['confirmed_observation'])})
            except (OSError, ValueError, RuntimeError, subprocess.SubprocessError):
                trial.mkdir(mode=0o700, exist_ok=True)
                (trial/'failure.log').write_text(traceback.format_exc())
                outcomes.append({'slot': index, 'mode': mode, 'status': 'failed',
                                 'error': (trial/'failure.log').read_text().strip().splitlines()[-1]})
                print(outcomes[-1], flush=True)
            write_json(directory/'outcomes.json', outcomes)
        if any(row['status'] != 'completed' for row in outcomes):
            raise SystemExit(1)
