"""Compare calibrated X11 RGB snapshots and sample owned endpoint processes."""
from math import log10
from pathlib import Path

from PIL import Image, ImageChops


def image_from_rows(rows):
    return Image.frombytes('RGB', (len(rows[0]) // 4, len(rows)), b''.join(rows), 'raw', 'BGRX')


def mean(histogram):
    count = sum(histogram)
    return sum(level * n for level, n in enumerate(histogram)) / count if count else None


def horizontal_edges(image):
    gray = image.convert('L')
    return ImageChops.difference(gray.crop((0, 0, gray.width - 1, gray.height)),
                                 gray.crop((1, 0, gray.width, gray.height)))


def compare_images(source, viewer):
    delta = ImageChops.difference(source, viewer)
    per_channel = [delta.getchannel(channel).histogram() for channel in 'RGB']
    per_channel_mse = [sum(level * level * n for level, n in enumerate(hist)) / sum(hist)
                       for hist in per_channel]
    mse = sum(per_channel_mse) / len(per_channel_mse)
    edge_source, edge_viewer = map(horizontal_edges, (source, viewer))
    mask = edge_source.point([255 if value >= 24 else 0 for value in range(256)])
    ref = mean(edge_source.histogram(mask))
    actual = mean(edge_viewer.histogram(mask))
    return {
        'rgb_mae': sum(map(mean, per_channel)) / len(per_channel),
        'rgb_psnr_db': 10 * log10(255 * 255 / mse) if mse else None,
        'source_edge_pixels': mask.histogram()[255],
        'source_horizontal_luma_gradient': ref,
        'viewer_horizontal_luma_gradient_at_source_edges': actual,
        'relative_edge_contrast': actual / ref if ref else None,
    }


def save_pair(directory, label, pair):
    for side, image in zip(('source', 'viewer'), pair, strict=True):
        image.save(directory / f'{label}-{side}.png')
    return compare_images(*pair)


def endpoint_resources(process):
    if process.poll() is not None:
        raise RuntimeError('lost an owned process before sampling resource counters')
    proc = Path('/proc') / str(process.pid)
    names = ('VmRSS', 'RssAnon', 'RssShmem', 'Threads')
    fields = {}
    for line in (proc/'status').read_text().splitlines():
        key, _, value = line.partition(':')
        if key in names:
            fields[key] = int(value.split()[0])
    if set(fields) != set(names):
        raise RuntimeError('incomplete owned process resource counters')
    fields['fds'] = sum(1 for fd in (proc/'fd').iterdir() if fd.name.isdecimal())
    if process.poll() is not None:
        raise RuntimeError('lost an owned process during resource sampling')
    return fields
