# P09 X11 motion fixture

Build independently on each Linux machine with the X11, XDamage, and Xext
development packages installed.

```sh
cc -std=c11 -O3 -Wall -Wextra -Werror -o p09-workload p09-workload.c \
  $(pkg-config --cflags --libs x11 xdamage xext)
```

The source opens a borderless window at the top-left of the selected private X11
screen. Its 1920×1080 default scene changes a broad colored texture and moves an
object across it at 60 scheduled updates per second. The left stripe retains a
static color reference except for a marker. A marker holds an 8-bit trial ID, a
16-bit scheduled source frame number, a checksum, and a second copy with
inverted polarity. The ID occupies a 96×96 region at (16,16).

```sh
./p09-workload paint --display :42 --run-id 1 --seed 1 --fps 60 --seconds 110
```

Capture the fixture at 1920×1080 and target the viewer's unoccluded X11 client
drawable at 1:1 scaling. Use its window ID from the matching viewer, then keep
the window size and viewport fixed.

```sh
./p09-workload observe --display :43 --window 0x400004 --run-id 1 --seconds 100
```

The observer samples the marker crop on XDamage notifications using MIT-SHM.
Set `--poll-hz 120` to run a separate polling measurement when the drawable's
presentation path does not emit usable damage. Keep the observation mode fixed
throughout a comparison. The observation timestamp follows completion of the
crop read and uses the observer's local monotonic clock. It measures visible
X11 drawable contents in software. Keep stream output drained during trials.

Each process emits JSONL. `p09_start` includes its role, local time, trial ID,
dimensions, window ID, and requested settings. The source start line appears
after the first paint. The source end line reports submitted frames, missed
scheduled slots, and the longest render and server synchronization interval.
Exact source marker values can skip when the producer falls behind.

The observer emits `p09_frame` for each new validated and increasing source
frame ID. It emits `p09_end` with distinct, duplicate, unreadable, wrong-trial,
and reordered counts plus the longest crop turnaround. Count observer frames
over a fixed 60-second interval and include leading and trailing gaps when
reporting the longest wait. Retain the raw diagnostics and archive interruption
or window-loss results. Source and observer clocks live on separate machines.

For local fixture validation, run `python3 smoke.py`. The smoke opens an owned
1920×1080 Xvfb screen and checks both observer modes and rejection of a foreign
trial ID.
