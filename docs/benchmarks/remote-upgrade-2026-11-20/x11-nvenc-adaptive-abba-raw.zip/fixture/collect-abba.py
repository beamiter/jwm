#!/usr/bin/env python3
"""Re-score finished attempts and retain the first valid observation for each slot."""
import argparse
import contextlib
import hashlib
import io
import json
import re
import statistics
import zipfile
from pathlib import Path

import benchmark

ARMS = ("fixed", "adaptive", "adaptive", "fixed") * 2
COPIED_FIELDS = (
    "window_seconds", "h264_frames", "bytes", "drawn_acks", "last_sent_frame",
    "captured", "backpressure_skipped", "replaced", "outstanding",
)


def complete_lines(path):
    try:
        return [line.rstrip("\n") for line in path.read_text().splitlines(keepends=True)
                if line.endswith("\n")]
    except FileNotFoundError:
        return []


def finished_attempts(path):
    attempts = {}
    name = None
    for line in complete_lines(path):
        if line.startswith("started "):
            name = line.removeprefix("started ")
            attempts[name] = {"state": "running"}
        elif line.startswith("failed "):
            attempt, _, error = line.removeprefix("failed ").partition(": ")
            attempts[attempt] = {"state": "failed", "error": error}
        elif name and line.startswith("{"):
            result = json.loads(line)
            if "observer_unique_source_frames" in result:
                attempts[name] = {"state": "scored"}
    return attempts


def repro_args(profile, remote_dir, arm):
    arguments = ["--remote-dir", remote_dir, "--label", f"abba-{profile}-1080p"]
    if profile == "write":
        arguments += ["--cap", "400000", "--send-buffer", "4096", "--recv-buffer", "4096"]
    opts = benchmark.parser().parse_args(arguments)
    opts.arm = arm
    return opts


def verify_codec_scope(host, viewer):
    # The first visible scope for this view-only run is already established.
    sent = [row["last_sent_frame"] for row in host if row["last_sent_frame"]]
    drawn = [row["last_frame"] for row in viewer if row["last_frame"]]
    scope = {(frame["source_epoch"], frame["geometry_epoch"], frame["codec"])
             for frame in sent + drawn}
    if len(scope) != 1 or next(iter(scope))[2] != "H.264":
        raise ValueError("captured host and viewer scopes changed during measurement")
    for endpoint, frames in (("host", sent), ("viewer", drawn)):
        seq = [frame["sequence"] for frame in frames]
        if any(new <= old for old, new in zip(seq, seq[1:])):
            raise ValueError(f"{endpoint} presented a non-increasing frame sequence")
    source_epoch, geometry_epoch, codec = scope.pop()
    return {"source_epoch": source_epoch, "geometry_epoch": geometry_epoch, "codec": codec}


def collect_attempt(lab, name, record, opts, slot):
    trial = lab / name
    if record["state"] == "running":
        return {"state": "running", "label": name}
    can_rescore = record["state"] == "scored"
    if not can_rescore:
        failure = "\n".join(complete_lines(lab/f"{name}-error.log"))
        # Only a failure thrown inside scoring establishes that the fixture
        # passed its explicit observer / viewer / host shutdown checks.
        can_rescore = 'in analyze' in failure and "run_trial" in failure
    try:
        if not can_rescore:
            raise ValueError(record.get("error", "recorded process failure"))
        with contextlib.redirect_stdout(io.StringIO()):
            benchmark.analyze(trial, opts, slot)
        host = benchmark.read_jsonl(trial/"retained-host.jsonl")
        viewer = benchmark.read_jsonl(trial/"retained-viewer.jsonl")
        marks = benchmark.read_jsonl(trial/"retained-markers.jsonl")
        result = json.loads((trial/"result.json").read_text())
        if result["observer_window_seconds"] != 60 or len(marks) != result["observer_unique_source_frames"]:
            raise ValueError("the observer score is not the fixed 60-second gate")
        scope = verify_codec_scope(host, viewer)
    except (ValueError, OSError, RuntimeError, KeyError) as error:
        return {"state": "failed", "label": name, "error": str(error), "runner_event": record}
    attempt = {
        "state": "scored", "label": name, "result": result, "scope": scope,
        "host_windows": [
            {**{key: row[key] for key in COPIED_FIELDS},
             "socket_write_ms": row["stages"]["socket_write_ms"],
             "credit_wait_ms": row["stages"]["credit_wait_ms"],
             "capture_ms": row["stages"]["capture_ms"],
             "h264_ms": row["stages"]["h264_ms"],
             "send_to_ack_ms": row["stages"]["send_to_ack_ms"]}
            for row in host],
        "viewer_windows": [
            {key: row[key] for key in ("window_seconds", "drawn", "acked", "start_ns", "end_ns", "last_frame",
                                       "last_presentation_path", "stages")}
            for row in viewer],
        "unique_frames": marks,
    }
    if record["state"] == "failed":
        attempt["initial_scoring_diagnostic"] = record["error"]
    return attempt


def describe(values):
    return {"min": min(values), "median": statistics.median(values), "max": max(values)}


def summarize(trials):
    arms = {}
    for arm in ("fixed", "adaptive"):
        rows = [trial["result"] for trial in trials if trial["result"]["arm"] == arm]
        if not rows:
            continue
        arms[arm] = {
            "count": len(rows),
            "observed_frames_per_second": describe([row["observer_unique_frames_per_second"] for row in rows]),
            "median_gap_ms": describe([row["observer_gap_ms"]["median"] for row in rows]),
            "p95_gap_ms": describe([row["observer_gap_ms"]["p95"] for row in rows]),
            "longest_gap_ms": describe([row["observer_gap_ms"]["max"] for row in rows]),
            "payload_mbps": describe([row["host_payload_mbps"] for row in rows]),
            "zero_frame_host_windows": sum(row["host_zero_frame_windows"] for row in rows),
            "incidents_over_one_second": sum(row["observer_gap_ms"]["max"] > 1000 for row in rows),
            "uncapped_27_fps_passes": sum(row["uncapped_unique_fps_gate_met"] is True for row in rows),
            "verified_live_bitrate_adaptations": sum(row["adaptive_bitrate_step_applied"] for row in rows),
            "verified_live_fps_adaptations": sum(row["adaptive_fps_step_applied"] for row in rows),
        }
    return arms


def collect(profile, lab, remote_dir, console, ended):
    events = finished_attempts(console)
    trials, failed, supplemental, pending = [], [], [], []
    for slot, arm in enumerate(ARMS, 1):
        label = f"abba-{profile}-1080p-{slot:02d}-{arm}"
        opts = repro_args(profile, remote_dir, arm)
        picked = False
        for attempt in (label, label + "-retry"):
            event = events.get(attempt)
            if not event:
                continue
            result = collect_attempt(lab, attempt, event, opts, slot)
            if result["state"] == "scored":
                if picked:
                    supplemental.append(result)
                else:
                    trials.append(result)
                    picked = True
            elif result["state"] == "failed":
                failed.append(result)
            elif result["state"] == "running" and ended:
                failed.append({"label": attempt, "state": "failed", "error": "runner ended before reporting this attempt"})
        if not picked:
            pending.append(label)
    status = "in progress"
    if ended:
        status = "completed" if not pending else "ended with missing or failed slots"
    return {
        "status": status,
        "summary": summarize(trials),
        "scored_trials": trials,
        "supplementary_attempts": supplemental,
        "failed_attempts": failed,
        "pending_or_unscored_slots": pending,
        "network_rtt_observations": {
            end: complete_lines(lab/f"abba-{profile}-1080p-link-{end}.txt")
            for end in ("before", "after")},
    }


TRIAL_LOGS = (
    "viewer.log", "viewer-clock.jsonl", "observed.jsonl", "observer-stderr.log",
    "remote-stderr.log", "remote-copy-error.log", "disconnect.log", "result.json",
    "retained-host.jsonl", "retained-viewer.jsonl", "retained-markers.jsonl",
    "remote/host.log", "remote/paint.jsonl", "remote/paint-stderr.log", "remote/proxy.log",
)
FIXTURE_FILES = (
    "benchmark.py", "collect-abba.py", "source.py", "processes.py",
    "proxy-compat.py", "remote-fault-proxy.py", "accept-buffers.c",
)


def archive_raw(path, conditions, lab):
    # Keep a narrow allowlist: never package either private key or SSH
    # debugging output. The logs are from owned displays with synthetic data.
    pending = path.with_suffix(".zip.tmp")
    manifest = {}
    with zipfile.ZipFile(pending, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=4) as archive:
        def write_file(source, name):
            if not source.is_file():
                return False
            data = source.read_bytes()
            archive.writestr(name, data)
            manifest[name] = {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
            return True

        for profile, condition in conditions.items():
            for attempt in condition["scored_trials"] + condition["supplementary_attempts"] + condition["failed_attempts"]:
                label = attempt["label"]
                if not re.fullmatch(rf"abba-{profile}-1080p-0[1-8]-(fixed|adaptive)(-retry)?", label):
                    raise ValueError(f"invalid raw trial archive label: {label}")
                written = {file for file in TRIAL_LOGS
                           if write_file(lab/label/file, f"{profile}/{label}/{file}")}
                mandatory = {"viewer.log", "remote/host.log", "remote/paint.jsonl", "observed.jsonl",
                             "retained-host.jsonl", "retained-viewer.jsonl", "retained-markers.jsonl"}
                if attempt["state"] == "scored" and not mandatory <= written:
                    raise ValueError(f"scored trial {label} has missing raw evidence")
                write_file(lab/f"{label}-error.log", f"{profile}/{label}/initial-scoring-or-run-error.log")
            write_file(Path(f"/tmp/jwm-p09-abba-{profile}-1080p.log"), f"{profile}/controller.log")
            for phase in ("before", "after"):
                write_file(lab/f"abba-{profile}-1080p-link-{phase}.txt", f"{profile}/link-{phase}.txt")
        for file in FIXTURE_FILES:
            write_file(lab/file, f"fixture/{file}")
        write_file(Path("/tmp/jwm-p09-workload/p09-workload.c"), "fixture/p09-workload.c")
        write_file(Path("/tmp/jwm-p09-workload/README.md"), "fixture/workload-README.md")
        archive.writestr("member-manifest.json", json.dumps(manifest, indent=2)+"\n")
    with zipfile.ZipFile(pending) as archive:
        bad = archive.testzip()
        if bad or set(archive.namelist()) != {"member-manifest.json", *manifest}:
            raise ValueError(f"invalid raw archive member: {bad}")
    pending.replace(path)
    return {"file": path.name, "members": len(manifest)+1,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def reduce_details(conditions):
    for profile, condition in conditions.items():
        for attempt in condition["scored_trials"] + condition["supplementary_attempts"]:
            attempt["raw_path"] = f"{profile}/{attempt['label']}/"
            for field in ("host_windows", "viewer_windows", "unique_frames"):
                attempt.pop(field)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--existing-record", type=Path, required=True)
    parser.add_argument("--raw-archive", type=Path)
    parser.add_argument("--write-ended", action="store_true")
    parser.add_argument("--clear-ended", action="store_true")
    args = parser.parse_args()
    lab = Path(__file__).parent
    remote_dir = (lab/"remote-dir").read_text().strip()
    evidence = json.loads(args.existing_record.read_text())
    if "trials" in evidence:
        evidence.pop("trials")
    evidence["results_by_condition"] = {
        profile: collect(profile, lab, remote_dir, Path(f"/tmp/jwm-p09-abba-{profile}-1080p.log"), ended)
        for profile, ended in (("write", args.write_ended), ("clear", args.clear_ended))
    }
    outcomes = {entry["status"] for entry in evidence["results_by_condition"].values()}
    evidence["status"] = ("in progress" if "in progress" in outcomes else
                          "completed" if outcomes == {"completed"} else "ended with missing or failed slots")
    if args.raw_archive:
        evidence["raw_archive"] = archive_raw(args.raw_archive, evidence["results_by_condition"], lab)
        reduce_details(evidence["results_by_condition"])
    else:
        evidence.pop("raw_archive", None)
    # Atomic publication because the record may be read while a case is pending.
    temporary = args.output.with_suffix(".tmp")
    temporary.write_text(json.dumps(evidence, indent=2)+"\n")
    temporary.replace(args.output)
    print(json.dumps({
        profile: {"state": part["status"], "scored": len(part["scored_trials"]),
                  "failed": len(part["failed_attempts"]), "supplemental": len(part["supplementary_attempts"])}
        for profile,part in evidence["results_by_condition"].items()
    }))

if __name__ == "__main__":
    main()
