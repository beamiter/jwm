#!/usr/bin/env python3
"""Native Aether WebKitGTK/XEmbed clipboard consent with two owned Xvfb servers."""
import argparse
from collections import deque
from contextlib import ExitStack
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import tempfile
import time


ROOT = Path(__file__).resolve().parent


def require(value, message):
    if not value:
        raise RuntimeError(message)


def sha256(path):
    with path.open('rb') as data:
        return hashlib.file_digest(data, 'sha256').hexdigest()


def wait(check, label, timeout=16):
    end = time.monotonic() + timeout
    while time.monotonic() < end:
        if result := check():
            return result
        time.sleep(.08)
    raise RuntimeError(f'Timed out waiting for {label}')


def stop(child):
    if child.poll() is None:
        child.terminate()
        try:
            child.wait(timeout=4)
        except subprocess.TimeoutExpired:
            child.kill()
            child.wait(timeout=4)


def exercise(args, root, report):
    with ExitStack() as owned:
        env = os.environ.copy()
        for name in list(env):
            if name.startswith('JWM_REMOTE_') or name in ('DISPLAY', 'WAYLAND_DISPLAY', 'WAYLAND_SOCKET', 'XAUTHORITY',
                                                           'AT_SPI_BUS_ADDRESS', 'NO_AT_BRIDGE'):
                env.pop(name, None)
        for field in ('CONFIG', 'CACHE', 'RUNTIME', 'DATA', 'STATE'):
            path = root / field.lower()
            path.mkdir(mode=0o700)
            env['XDG_RUNTIME_DIR' if field == 'RUNTIME' else f'XDG_{field}_HOME'] = str(path)

        trace = root / 'helper-clipboard.jsonl'
        env.update(GDK_BACKEND='x11', LIBGL_ALWAYS_SOFTWARE='1', GTK_A11Y='always', ACCESSIBILITY_ENABLED='1',
                   GSETTINGS_BACKEND='memory', GIO_USE_VFS='local', GTK_USE_PORTAL='0',
                   AETHER_CLIPBOARD_SMOKE_HELPER=str(args.helper),
                   AETHER_CLIPBOARD_SMOKE_TRACE=str(trace))
        env['PATH'] = str(ROOT / 'bin') + ':' + env['PATH']
        if args.lib:
            env['LD_LIBRARY_PATH'] = args.lib

        def launch(argv, name, stdin=subprocess.DEVNULL, pass_fds=()):
            output = owned.enter_context((root / name).open('wb'))
            proc = subprocess.Popen(argv, env=env, stdin=stdin, stdout=output, stderr=subprocess.STDOUT, pass_fds=pass_fds)
            owned.callback(stop, proc)
            return proc

        def display(name):
            path = root / f'{name}-display'
            number = owned.enter_context(path.open('wb'))
            proc = launch(['Xvfb', '-displayfd', str(number.fileno()), '-screen', '0', '1440x1080x24',
                           '-nolisten', 'tcp', '-ac', '-noreset'], f'{name}-xvfb.log', pass_fds=(number.fileno(),))
            picked = wait(lambda: path.read_text().strip(), f'{name} owned Xvfb display')
            require(picked.isascii() and picked.isdigit() and proc.poll() is None, 'invalid owned Xvfb display')
            return ':' + picked, proc

        source, source_x = display('source')
        target, viewer_x = display('viewer')
        env['DISPLAY'] = target
        os.environ.pop('AT_SPI_BUS_ADDRESS', None)
        os.environ.pop('NO_AT_BRIDGE', None)
        os.environ.update({name: env[name] for name in ('DISPLAY', 'GTK_A11Y', 'GDK_BACKEND')})
        import pyatspi as ax
        desktop = ax.Registry.getDesktop(0)

        def cmd(*argv, check=True):
            return subprocess.run(argv, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                  text=True, check=check, timeout=5).stdout

        def xt(*argv):
            return cmd('xdotool', *map(str, argv))

        key = root / 'config' / 'jwm' / 'remote.key'
        key.parent.mkdir(mode=0o700)
        owned.callback(key.unlink, missing_ok=True)
        cmd(args.helper, 'keygen', '--output', key)
        cmd('xsetroot', '-display', source, '-solid', '#ba2441')
        launch(['metacity', '--sm-disable'], 'metacity.log')
        wait(lambda: '_NET_SUPPORTING_WM_CHECK(WINDOW)' in cmd('xprop', '-root', '_NET_SUPPORTING_WM_CHECK'), 'owned WM')
        aether = launch([args.aether], 'aether.log')

        def visible_window(selector, value):
            found = cmd('xdotool', 'search', '--onlyvisible', selector, str(value), check=False).split()
            return int(found[-1]) if found else None

        app = wait(lambda: visible_window('--pid', aether.pid), 'native Aether window')
        xt('windowactivate', '--sync', app)
        xt('windowsize', app, 960, 820)

        def accessibles():
            pending = deque(item for item in desktop if item)
            result = []
            while pending and len(result) < 1024:
                item = pending.popleft()
                if item:
                    result.append(item)
                    pending.extend(item)
            return result

        def by_name(name, role=None):
            for item in accessibles():
                if ((item.name or '').strip() == name and (role is None or item.getRoleName() == role)
                        and item.getState().contains(ax.STATE_SHOWING)):
                    return item
            return None

        def visible_text(text):
            for item in accessibles():
                if not item.getState().contains(ax.STATE_SHOWING):
                    continue
                if (item.name or '').strip() == text:
                    return True
                try:
                    if (item.queryText().getText(0, -1) or '').strip() == text:
                        return True
                except NotImplementedError:
                    pass
            return False

        def click_accessible(item):
            rect = item.queryComponent().getExtents(ax.DESKTOP_COORDS)
            require(rect.width > 0 and rect.height > 0, 'Aether control outside owned window')
            xt('mousemove', rect.x + rect.width // 2, rect.y + rect.height // 2, 'click', 1)

        def screenshot(name):
            cmd('import', '-window', hex(app), root / f'{name}.png')

        def select_control(name, role, fallback):
            item = by_name(name, role)
            if item is not None:
                click_accessible(item)
            else:
                xt('mousemove', '--window', app, *fallback, 'click', 1)
            return item is not None

        time.sleep(1.3)
        (root / 'accessibility-tree.json').write_text(json.dumps([
            {'name': item.name, 'role': item.getRoleName()} for item in accessibles()], indent=2) + '\n')
        screenshot('native-initial')
        select_control('Remote Desktop', 'push button', (183, 35))
        time.sleep(.55)
        screenshot('remote-settings')

        def trace_rows():
            if not trace.exists():
                return []
            return [json.loads(row) for row in trace.read_text().splitlines(keepends=True) if row.endswith('\n')]

        def own_clip(display_name, text, name):
            owner = launch(['xclip', '-display', display_name, '-selection', 'clipboard', '-t', 'UTF8_STRING', '-i', '-quiet'],
                           name, stdin=subprocess.PIPE)
            owner.stdin.write(text.encode())
            owner.stdin.close()
            return owner

        def paste(display_name):
            return cmd('xclip', '-display', display_name, '-selection', 'clipboard', '-t', 'UTF8_STRING', '-o', check=False)

        def assert_xembed(xid):
            tree = cmd('xwininfo', '-id', hex(xid), '-tree')
            parent = int(re.search(r'Parent window id: (0x[0-9a-f]+)', tree)[1], 16)
            require(hex(parent) in cmd('xwininfo', '-id', hex(app), '-tree'), 'viewer not under the Aether native pane')
            top_levels = cmd('xprop', '-root', '_NET_CLIENT_LIST')
            require(hex(app) in top_levels and hex(xid) not in top_levels, 'viewer is a separate top-level window')
            info = cmd('xprop', '-id', hex(xid), '-f', '_XEMBED_INFO', '32c', '_XEMBED_INFO')
            require('_XEMBED_INFO(_XEMBED_INFO) = 0, 1' in info, 'XEmbed plug handshake missing')

        def connect_case(name, allow_clipboard):
            begin = len(trace_rows())
            host_flags = [args.helper, 'host', '--listen', '127.0.0.1:0', '--once', '--key-file', key,
                          '--capture-source', 'root', '--display', source, '--region', '640x480+0+0', '--stats-json']
            if allow_clipboard:
                host_flags += ['--allow-clipboard', '--clipboard-mode', 'text', '--clipboard-direction', 'both',
                               '--clipboard-file-limit', '0']
            host = launch(host_flags, f'{name}-host.log')
            log = root / f'{name}-host.log'
            address = wait(lambda: (match[1] if (match := re.search(r'listening on (127\.0\.0\.1:\d+)', log.read_text())) else None),
                           'private host TCP listener')
            clipboard = by_name('Share clipboard', 'check box')
            if clipboard is not None:
                require(not clipboard.getState().contains(ax.STATE_CHECKED), 'clipboard enabled before explicit consent')
            select_control('Share clipboard', 'check box', (32, 303))
            time.sleep(.25)
            screenshot(f'{name}-consent')
            if clipboard is not None:
                wait(lambda: by_name('Share clipboard', 'check box').getState().contains(ax.STATE_CHECKED), 'checked opt-in')
            select_control('Host', None, (220, 160))
            xt('key', 'ctrl+a', 'BackSpace')
            xt('type', '--clearmodifiers', address)
            xt('key', 'Return')
            viewer = wait(lambda: visible_window('--class', 'JwmRemote'), 'actual embedded video')
            assert_xembed(viewer)
            snapshots = lambda: trace_rows()[begin:]
            expected_argv = {'event': 'argv', 'clipboard': True, 'x11_parent': True, '--clipboard-mode': 'text',
                             '--clipboard-direction': 'from-host', '--clipboard-file-limit': '0'}
            wait(lambda: expected_argv in snapshots(), 'real selected helper arguments')
            expected_mode, expected_direction = ('text', 'from-host') if allow_clipboard else (None, None)
            effective = {'mode': expected_mode, 'direction': expected_direction, 'file_limit_bytes': '0', 'transfer': None}
            wait(lambda: any(row['event'] == 'snapshot' and row.get('state') == 'viewing' and row.get('clipboard') == effective
                             for row in snapshots()), 'actual effective clipboard snapshot')
            ui_copy = 'Clipboard · Text · From host' if allow_clipboard else 'Clipboard off'
            time.sleep(.35)  # allow the status polling loop to apply the observed snapshot
            effective_ui = visible_text(ui_copy)
            screenshot(f'{name}-effective')
            return host, viewer, snapshots, effective, effective_ui

        def disconnect_case(host, snapshots):
            xt('windowsize', app, 1180, 820)
            time.sleep(.3)
            select_control('Disconnect', 'push button', (1035, 159))
            require(host.wait(timeout=12) == 0, 'host did not exit cleanly')
            wait(lambda: not visible_window('--class', 'JwmRemote'), 'retired XEmbed viewer')
            wait(lambda: {'event': 'exit', 'code': 0} in snapshots(), 'real managed helper exit')
            xt('windowsize', app, 960, 820)
            time.sleep(.4)

        a = 'aether-synthetic-host-consent-not-granted'
        b = 'aether-synthetic-local-clipboard-retained'
        own_clip(source, a, 'denied-source-owner.log')
        own_clip(target, b, 'denied-viewer-owner.log')
        wait(lambda: paste(source) == a and paste(target) == b, 'seeded private selections')
        host, _, snapshots, denied, denied_ui = connect_case('denied', False)
        fresh_denied = 'aether-synthetic-fresh-copy-without-host-consent'
        own_clip(source, fresh_denied, 'denied-source-fresh.log')
        wait(lambda: paste(source) == fresh_denied, 'fresh ungranted source copy')
        time.sleep(.85)
        require(paste(target) == b and paste(source) == fresh_denied, 'clipboard moved despite missing host permission')
        disconnect_case(host, snapshots)
        report['without_host_grant'] = {'effective': denied, 'viewer_local_selection_preserved': True, 'xembed': True,
                                          'effective_status_accessible': denied_ui}

        c = 'aether-synthetic-receive-only-host-value'
        d = 'aether-synthetic-ungranted-return-value'
        host, _, snapshots, effective, effective_ui = connect_case('from-host', True)
        require(paste(target) == b, 'host selection captured before the connection unexpectedly propagated')
        own_clip(source, c, 'allowed-source-owner.log')
        wait(lambda: paste(source) == c, 'fresh source copy after negotiated permission')
        wait(lambda: paste(target) == c, 'actual host-to-viewer clipboard text')
        own_clip(target, d, 'allowed-viewer-owner.log')
        wait(lambda: paste(target) == d, 'actual local changed selection')
        until = time.monotonic() + 1.2
        while time.monotonic() < until:
            require(paste(source) == c, 'forbidden viewer-to-host clipboard changed host selection')
            time.sleep(.075)
        disconnect_case(host, snapshots)
        report['receive_only'] = {'effective': effective, 'exact_synthetic_paste': True, 'opposite_direction_rejected': True,
                                  'xembed': True, 'effective_status_accessible': effective_ui}
        cmd('wmctrl', '-i', '-c', hex(app))
        require(aether.wait(timeout=10) == 0, 'native app exit failed')
        report['native_app_exit'] = 0
    report['owned_xvfb_exits'] = [source_x.returncode, viewer_x.returncode]
    require(None not in report['owned_xvfb_exits'], 'owned display leaked')


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--aether', type=Path, required=True)
    cli.add_argument('--helper', type=Path, required=True)
    cli.add_argument('--aether-sha256', required=True)
    cli.add_argument('--helper-sha256', required=True)
    cli.add_argument('--lib', default='/tmp/jwm-remote-ffmpeg/usr/lib/x86_64-linux-gnu')
    args = cli.parse_args()
    require(os.environ.get('DBUS_SESSION_BUS_ADDRESS'), 'run under an owned dbus-run-session')
    require(sha256(args.aether) == args.aether_sha256 and sha256(args.helper) == args.helper_sha256, 'pinned binaries changed')
    root = Path(tempfile.mkdtemp(prefix='jwm-aether-clipboard-live.'))
    print(root, flush=True)
    report = {'status': 'failed', 'aether_sha256': args.aether_sha256, 'jwm_remote_sha256': args.helper_sha256}
    signal.signal(signal.SIGTERM, lambda signum, _frame: signal.default_int_handler(signum, _frame))
    try:
        exercise(args, root, report)
        report['status'] = 'passed'
    except BaseException as error:
        report['failure'] = f'{type(error).__name__}: {error}'
        raise
    finally:
        (root / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report), flush=True)


if __name__ == '__main__':
    main()
