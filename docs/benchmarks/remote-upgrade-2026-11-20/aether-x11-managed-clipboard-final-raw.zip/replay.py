#!/usr/bin/env python3
"""Replay the sanitized Aether XEmbed and managed clipboard witness offline."""
import hashlib
import json
from pathlib import Path
import struct


ROOT = Path(__file__).resolve().parent
HELPER = '653d8f4d4624c4349152416b2685eefe7e5ef29d063bf6a80f3ec186467a655c'
AETHER = '9b70adc816a1815e79abfde7248bfd17c9e4817ecfa8ca0109964acdc561f00b'
ADAPTER = '8a8087b939f4018bd5d96fc2f744a750b4084160256285d39aac1425338f1ccd'


def require(condition, detail):
    if not condition:
        raise ValueError(detail)


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def parse_sessions(records):
    sessions = []
    allowed_states = {'connecting', 'waiting_for_presentation', 'viewing', 'closing', 'closed'}
    for record in records:
        if record['event'] == 'argv':
            require(not sessions or sessions[-1][-1] == {'event': 'exit', 'code': 0},
                    'new helper before old clean termination')
            require(record == {'event': 'argv', 'clipboard': True, 'x11_parent': True,
                '--clipboard-mode': 'text', '--clipboard-direction': 'from-host', '--clipboard-file-limit': '0'},
                'helper did not receive narrow opt-in and native parent')
            sessions.append([record])
        elif record['event'] == 'snapshot':
            require(sessions and set(record) == {'event', 'state', 'clipboard'} and record['state'] in allowed_states,
                    'unexpected snapshot fields or state')
            require(sessions[-1][-1]['event'] != 'exit', 'snapshot after helper exit')
            sessions[-1].append(record)
        elif record == {'event': 'exit', 'code': 0}:
            require(sessions and sessions[-1][-1]['event'] != 'exit', 'unexpected helper exit')
            sessions[-1].append(record)
        else:
            raise ValueError('unexpected record in clipboard-only trace')
    require(len(sessions) == 2 and all(group[-1] == {'event': 'exit', 'code': 0} for group in sessions),
            'exactly two close-completed scenarios expected')
    return sessions


def inspect(root):
    original = json.loads((root / 'native-result.json').read_text())
    manifest = json.loads((root / 'provenance.json').read_text())
    require(manifest['aether_binary_sha256'] == original['aether_sha256'] == AETHER
            and manifest['jwm_remote_binary_sha256'] == original['jwm_remote_sha256'] == HELPER,
            'final native binary identities changed')
    require(manifest['canonical_and_vendored_adapter_sha256'] == ADAPTER
            == manifest['aether_source_sha256']['src-tauri/vendor/jwm-remote/client.rs'], 'vendor identity changed')
    require(manifest['statuses'] == {'aether_build': 0, 'jwm_helper_build': 0, 'native_controller': 0}
            and original['status'] == 'passed' and original['native_app_exit'] == 0
            and original['owned_xvfb_exits'] == [0, 0], 'terminal witness missing')
    sessions = parse_sessions(rows(root / 'helper-clipboard.jsonl'))
    evidence = []
    for index, name in enumerate(('without_host_grant', 'receive_only')):
        witness = original[name]
        active = {'mode': None if index == 0 else 'text', 'direction': None if index == 0 else 'from-host',
                  'file_limit_bytes': '0', 'transfer': None}
        require(witness['effective'] == active and witness['xembed'] and witness['effective_status_accessible'],
                'missing actual native permission, embed or status witness')
        if index == 0:
            require(witness['viewer_local_selection_preserved'], 'unapproved fresh source copied')
        else:
            require(witness['exact_synthetic_paste'] and witness['opposite_direction_rejected'], 'direction proof failed')
        session_events = sessions[index][1:-1]
        shown = [entry['clipboard'] for entry in session_events if entry['state'] == 'viewing']
        require(bool(shown) and all(policy == active for policy in shown), 'effective helper gesture changed')
        require(session_events[0]['state'] == 'connecting'
                and session_events[-2:] == [{'event': 'snapshot', 'state': 'closing', 'clipboard': None},
                                            {'event': 'snapshot', 'state': 'closed', 'clipboard': None}],
                'missing closure or stale clipboard status')
        evidence.append({'scenario': name, 'effective_policy': active, 'viewing_records': len(shown),
                         'xembed_native_status_and_helper_agree': True, 'helper_exit': 0})
    images = {}
    for name in ('denied-effective.png', 'from-host-effective.png'):
        data = (root / name).read_bytes()
        require(data.startswith(b'\x89PNG\r\n\x1a\n') and data[12:16] == b'IHDR', 'missing actual PNG witness')
        width, height = struct.unpack('>II', data[16:24])
        require((width, height) == (960, 820), 'unexpected screenshot target size')
        images[name] = {'dimensions': [width, height], 'sha256': hashlib.sha256(data).hexdigest()}
    return {'passed_scenarios': evidence, 'actual_synthetic_receive_and_reverse_rejection': True,
            'both_hosts_helpers_app_and_displays_closed': True, 'images': images}


def main():
    members = json.loads((ROOT / 'member-sha256.json').read_text())
    for name, digest in members.items():
        require(hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, f'member digest changed: {name}')
    result = inspect(ROOT)
    expected = json.loads((ROOT / 'replay-result.json').read_text())
    require(result == expected, 'replay does not match the recorded final evidence')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
