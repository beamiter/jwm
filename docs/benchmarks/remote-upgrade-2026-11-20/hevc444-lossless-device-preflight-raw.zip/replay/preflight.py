#!/usr/bin/env python3
"""Private NVENC HEVC 4:4:4 lossless capability and AU-budget preflight."""
import argparse
from collections import Counter
from contextlib import contextmanager
import hashlib
import json
from pathlib import Path
import re
import subprocess
from threading import Timer
from zipfile import ZipFile

FPS = 30
GOP = 60
FORCED_IDR = 77
FRAMES = 81
AU_LIMIT = 1024 * 1024
FILE_LIMIT = (FRAMES + 1) * AU_LIMIT
DEADLINE = 60
PPM_SIZE = (1920, 1080)
PPM_HEADER = b'P6\n1920 1080\n255\n'
SOURCE_MEMBERS = tuple('trial-01/host/' + name for name in
                       ('source-static.ppm', 'source-motion-end.ppm', 'source-static-end.ppm'))
DEFAULT_ARCHIVE = Path('/home/yj/projects/jwm/docs/benchmarks/remote-upgrade-2026-11-20/x11-terminal-scroll-hevc444-pilot-raw.zip')
START_CODE = re.compile(rb'\x00\x00(?:\x00)?\x01')
PLANES = ('Y', 'U', 'V')


def need(predicate, message):
    if not predicate:
        raise RuntimeError(message)


def checksum(data):
    return hashlib.sha256(data).hexdigest()


def file_checksum(path):
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def save(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')


def metadata(ffmpeg, ffprobe, *, require_probe=True):
    result = {}
    for path, required in ((ffmpeg, True), (ffprobe, require_probe)):
        try:
            binary = Path(path).resolve(strict=True)
        except FileNotFoundError:
            if required:
                raise
            result['ffprobe'] = {'available': False}
            continue
        info = subprocess.check_output([str(binary), '-version'], text=True, timeout=8)
        result[binary.name] = {'version': info.splitlines()[0],
                               'linked_versions': [line for line in info.splitlines() if line.startswith('lib')],
                               'binary_sha256': file_checksum(binary)}
    result['compiled_hwaccels'] = subprocess.check_output(
        [ffmpeg, '-hide_banner', '-hwaccels'], text=True, timeout=8).splitlines()[1:]
    return result


def crop(raw, rectangle):
    input_width, input_height = PPM_SIZE
    x, y, width, height = rectangle
    need(x >= 0 and y >= 0 and x + width <= input_width and y + height <= input_height,
         'crop outside the recorded XTerm surface')
    return b''.join(raw[(row*input_width + x)*3:(row*input_width + x + width)*3]
                    for row in range(y, y+height))


def read_xterm(archive):
    result = []
    manifest = []
    with ZipFile(archive) as bundle:
        for name in SOURCE_MEMBERS:
            need(bundle.getinfo(name).file_size == len(PPM_HEADER) + 1920*1080*3, 'unexpected archived PPM length')
            image = bundle.read(name)
            need(image.startswith(PPM_HEADER), 'recorded XTerm PPM has a different raster header')
            result.append(image[len(PPM_HEADER):])
            manifest.append({'member': name, 'sha256': checksum(image)})
    return result, manifest


@contextmanager
def codec_process(argv, stderr_path, *, stdin_pipe=False, stdout_pipe=False):
    # prlimit constrains regular-file output inside the child, including logs.
    # The decoder pipe is bounded separately by its expected number of bytes.
    limited = ['prlimit', f'--fsize={FILE_LIMIT}:{FILE_LIMIT}', '--', *argv]
    timeout = []
    with stderr_path.open('xb') as stderr, subprocess.Popen(
        limited, stdin=subprocess.PIPE if stdin_pipe else subprocess.DEVNULL,
        stdout=subprocess.PIPE if stdout_pipe else subprocess.DEVNULL, stderr=stderr,
    ) as process:
        def expire():
            timeout.append(True)
            process.kill()

        watchdog = Timer(DEADLINE, expire)
        watchdog.start()
        try:
            yield process
            status = process.wait(timeout=DEADLINE)
            need(not timeout, f'codec process exceeded {DEADLINE} seconds')
            need(status == 0, f'codec process exited {status}; see {stderr_path.name}')
        finally:
            watchdog.cancel()
            if process.poll() is None:
                process.kill()
            watchdog.join()


def canonical(ffmpeg, rgb, width, height):
    # The equality oracle starts after this deliberate one-time conversion.
    # The encoder never receives RGB or a subsampled chroma input.
    data = subprocess.check_output(
        [ffmpeg, '-hide_banner', '-loglevel', 'error', '-f', 'rawvideo', '-pixel_format', 'rgb24',
         '-video_size', f'{width}x{height}', '-i', 'pipe:0', '-frames:v', '1',
         '-vf', 'scale=in_range=pc:out_range=tv:out_color_matrix=bt709,format=yuv444p',
         '-pix_fmt', 'yuv444p', '-f', 'rawvideo', 'pipe:1'],
        input=rgb, timeout=15)
    need(len(data) == width*height*3, 'canonical planar YUV444 frame has the wrong byte size')
    return data


def chroma_witness(width, height, variant):
    values = ((16, 58, 131, 235), (24, 78, 174, 232), (220, 163, 75, 34))
    return b''.join(bytes(plane[(x//step + y//(step+3) + variant) % 4]
                         for y in range(height) for x in range(width))
                    for plane,step in zip(values, (7, 3, 5), strict=True))


def source_index(n):
    return 0 if n < 20 else 1 if n < 46 or n >= 70 else 2


def planes(data, width, height):
    n = width*height
    return (data[:n], data[n:2*n], data[2*n:3*n])


def hashes(data, width, height):
    return {name: checksum(plane) for name,plane in zip(PLANES, planes(data, width, height), strict=True)}


def nvenc_command(ffmpeg, width, height, stream, gpu):
    return [ffmpeg, '-hide_banner', '-nostdin', '-loglevel', 'info', '-nostats',
            '-f', 'rawvideo', '-pixel_format', 'yuv444p', '-video_size', f'{width}x{height}',
            '-framerate', str(FPS), '-i', 'pipe:0', '-frames:v', str(FRAMES),
            '-an', '-c:v', 'hevc_nvenc', '-gpu', str(gpu),
            '-preset', 'p3', '-tune', 'lossless', '-profile:v', 'rext', '-rc', 'constqp', '-qp', '0',
            '-pix_fmt', 'yuv444p', '-bf', '0', '-g', str(GOP), '-rc-lookahead', '0',
            '-zerolatency', '1', '-forced-idr', '1', '-force_key_frames', f'expr:eq(n,{FORCED_IDR})',
            '-color_range', 'tv', '-colorspace', 'bt709', '-color_primaries', 'bt709', '-color_trc', 'bt709',
            '-f', 'hevc', '-n', str(stream)]


def encode(ffmpeg, refs, width, height, stream, log, gpu):
    argv = nvenc_command(ffmpeg, width, height, stream, gpu)
    with codec_process(argv, log, stdin_pipe=True) as process:
        # A closed pipe means the device rejected the configuration or did not
        # consume the complete input. The captured encoder diagnostic remains.
        for index in range(FRAMES):
            process.stdin.write(refs[source_index(index)])
        process.stdin.close()
    need(0 < stream.stat().st_size <= FILE_LIMIT, 'encoded file exceeded preflight file limit')
    return argv


def nal_summary(au):
    starts = list(START_CODE.finditer(au))
    need(starts and starts[0].start() == 0, 'AU is not Annex B')
    types = set()
    first = 0
    for index, prefix in enumerate(starts):
        tail = starts[index+1].start() if index+1 < len(starts) else len(au)
        available = tail - prefix.end()
        need(available >= 2, 'truncated HEVC NAL header')
        major, minor = au[prefix.end():prefix.end()+2]
        need(major & 0x81 == 0 and 0 < minor <= 7, 'invalid or layered HEVC NAL header')
        kind = (major >> 1) & 63
        types.add(kind)
        if kind < 32:
            need(available >= 3, 'truncated VCL NAL')
            first += bool(au[prefix.end()+2] & 0x80)
    need(first == 1, 'ffprobe packet does not contain exactly one HEVC picture start')
    return sorted(types), bool(types & {19, 20})


def packet_oracle(ffprobe, stream, width, height):
    cmd = [ffprobe, '-v', 'error', '-f', 'hevc', '-select_streams', 'v:0',
           '-show_packets', '-show_streams',
           '-show_entries', 'stream=codec_name,profile,width,height,pix_fmt,color_range,has_b_frames:packet=pos,size,flags',
           '-of', 'json', str(stream)]
    result = json.loads(subprocess.check_output(cmd, timeout=DEADLINE))
    video, = result['streams']
    need((video['codec_name'], video['profile'], video['pix_fmt'], video['width'], video['height'],
          video['has_b_frames']) == ('hevc', 'Rext', 'yuv444p', width, height, 0),
         'unexpected visible HEVC profile, format, or reorder depth')
    packets = result['packets']
    need(len(packets) == FRAMES, 'ffprobe did not return one packet per submitted picture')
    units = []
    with stream.open('rb') as handle:
        offset = 0
        for ordinal, item in enumerate(packets):
            length = int(item['size'])
            need(int(item['pos']) == offset and length > 0, 'ffprobe packet spans are not contiguous')
            au = handle.read(length)
            need(len(au) == length, 'ffprobe packet exceeds stream size')
            types, idr = nal_summary(au)
            units.append({'index': ordinal, 'offset': offset, 'bytes': length, 'nal_types': types,
                          'idr': idr, 'probe_key_flag': 'K' in item['flags']})
            offset += length
        need(handle.read(1) == b'', 'ffprobe packets did not cover the complete encoded file')
    idrs = {packet['index'] for packet in units if packet['idr']}
    return {'stream': video, 'access_units': units,
            'idrs': sorted(idrs), 'required_idrs': [0, GOP, FORCED_IDR],
            'initial_scheduled_and_forced_idr_verified': {0, GOP, FORCED_IDR} <= idrs,
            'largest_au_bytes': max(packet['bytes'] for packet in units),
            'oversized_au_indices': [packet['index'] for packet in units if packet['bytes'] > AU_LIMIT]}


def decode_command(ffmpeg, stream, hardware):
    hw = ['-hwaccel', 'cuda', '-hwaccel_output_format', 'cuda'] if hardware else ['-hwaccel', 'none']
    return [ffmpeg, '-hide_banner', '-nostdin', '-loglevel', 'info', '-nostats', '-xerror', *hw,
            '-c:v', 'hevc', '-f', 'hevc', '-i', str(stream), '-map', '0:v:0',
            *(['-vf', 'hwdownload,format=yuv444p'] if hardware else []),
            '-vsync', '0', '-pix_fmt', '+yuv444p', '-f', 'rawvideo', 'pipe:1']


def decode(ffmpeg, stream, log, width, height, expected, originals=None, hardware=False):
    argv = decode_command(ffmpeg, stream, hardware)
    bad = Counter()
    first_bad = None
    with codec_process(argv, log, stdout_pipe=True) as process:
        for index, wanted in enumerate(expected):
            data = process.stdout.read(width*height*3)
            need(len(data) == width*height*3, f'decoder ended before frame {index}; see {log.name}')
            actual = hashes(data, width, height)
            reference = planes(originals[source_index(index)], width, height) if originals is not None else None
            for name, plane, at in zip(PLANES, planes(data, width, height), range(3), strict=True):
                mismatch = actual[name] != wanted[name]
                if reference is not None:
                    mismatch |= plane != reference[at]
                if mismatch:
                    bad[name] += 1
                    if first_bad is None:
                        first_bad = {'frame_index': index, 'plane': name}
        need(process.stdout.read(1) == b'', 'decoder produced extra frame data')
    return {'argv': argv, 'backend': 'CUDA with mandatory YUV444 hardware download' if hardware else 'software HEVC',
            'checked_frames': len(expected), 'exact': not bad, 'mismatched_frames_by_plane': dict(bad),
            'first_mismatch': first_bad,
            'comparison': 'Byte equality plus SHA-256 of each visible plane' if originals is not None
                          else 'SHA-256 equality of each visible plane against the Mint source manifest'}


def mint(args):
    status = {'scope': 'Owned HEVC444 lossless preflight; immutable captured and synthetic cases.',
              'tools': metadata(args.ffmpeg,args.ffprobe),
              'archive_sha256': file_checksum(args.archive), 'au_limit_bytes': AU_LIMIT,
              'per_file_cap_bytes': FILE_LIMIT, 'frame_rate': FPS, 'gop': GOP, 'frames_per_case': FRAMES}
    ffmpeg, ffprobe = args.ffmpeg, args.ffprobe
    rasters, source = read_xterm(args.archive)
    status['recorded_xterm_members'] = source
    status['cases'] = []
    for name, rect in (('xterm-crop', (0,20,1200,240)),('xterm-full', (0,0,1920,1080)),
                       ('chroma-witness', (0,0,256,256))):
        w,h = rect[2:]
        item = {'name': name, 'width': w, 'height': h,
                'recorded_crop_xywh': list(rect) if name.startswith('xterm-') else None}
        status['cases'].append(item)
        try:
            refs = ([canonical(ffmpeg,crop(rgb,rect),w,h) for rgb in rasters] if name.startswith('xterm-')
                    else [chroma_witness(w,h,i) for i in range(3)])
            item['reference_plane_sha256'] = [hashes(frame,w,h) for frame in refs]
            item['reference_index_per_frame'] = [source_index(i) for i in range(FRAMES)]
            item['additional_non_neutral_chroma_exercised'] = any(
                len(set(plane)) > 1 for rgb in refs for plane in planes(rgb,w,h)[1:])
            stream = args.out / f'{name}.hevc'
            item['stream_file'] = stream.name
            item['encoder'] = encode(ffmpeg, refs,w,h,stream,args.out/f'{name}-encode.log',args.gpu)
            item['stream_sha256'] = file_checksum(stream)
            item['stream_bytes'] = stream.stat().st_size
            item['packets'] = packet_oracle(ffprobe,stream,w,h)
            expected = [item['reference_plane_sha256'][i] for i in item['reference_index_per_frame']]
            item['software_decode'] = decode(ffmpeg,stream,args.out/f'{name}-software.log',w,h,expected,refs)
            item['qualified'] = (item['software_decode']['exact']
                                 and item['packets']['initial_scheduled_and_forced_idr_verified']
                                 and not item['packets']['oversized_au_indices'])
        except (OSError, RuntimeError, ValueError, KeyError, subprocess.SubprocessError) as error:
            item.update(qualified=False, failure=f'{type(error).__name__}: {error}')
        save(args.out/'mint-result.json', status)
    return all(item['qualified'] for item in status['cases'])


def peer(args):
    origin = json.loads((args.from_mint/'mint-result.json').read_text())
    out = {'scope': 'Ubuntu hardware and software decode only; no encode or profile substitution.',
           'tools': metadata(args.ffmpeg,args.ffprobe,require_probe=False), 'cases': []}
    need(sorted(source['name'] for source in origin['cases']) ==
         ['chroma-witness', 'xterm-crop', 'xterm-full'], 'unexpected peer case set')
    for source in origin['cases']:
        item = {'name': source['name']}
        out['cases'].append(item)
        try:
            need(source.get('qualified') is True, 'Mint case did not establish the input oracle/AU budget')
            name = source['stream_file']
            need(name == source['name'] + '.hevc' and name == Path(name).name, 'unsafe stream name')
            stream = args.from_mint/name
            need(0 < stream.stat().st_size == source['stream_bytes'] <= FILE_LIMIT
                 and file_checksum(stream) == source['stream_sha256'], 'peer stream differs from Mint evidence')
            w,h = source['width'],source['height']
            need((w,h) in ((1200,240),(1920,1080),(256,256)), 'unexpected peer raster size')
            refs = source['reference_plane_sha256']
            seq = source['reference_index_per_frame']
            need(len(refs) == 3 and seq == [source_index(i) for i in range(FRAMES)], 'unexpected peer reference fixture')
            expected = [refs[index] for index in seq]
            for role, gpu in (('software',False),('cuda',True)):
                try:
                    item[role] = decode(args.ffmpeg,stream,args.out/f'{item["name"]}-{role}.log',w,h,expected,hardware=gpu)
                except (OSError, RuntimeError, ValueError, subprocess.SubprocessError) as error:
                    item[role] = {'exact': False, 'failure': f'{type(error).__name__}: {error}'}
            item['qualified'] = item['software']['exact'] and item['cuda']['exact']
        except (OSError, RuntimeError, ValueError, KeyError, subprocess.SubprocessError) as error:
            item.update(qualified=False, failure=f'{type(error).__name__}: {error}')
        save(args.out/'peer-result.json',out)
    return bool(out['cases']) and all(item['qualified'] for item in out['cases'])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--ffmpeg', default='/usr/bin/ffmpeg')
    parser.add_argument('--ffprobe', default='/usr/bin/ffprobe')
    subparsers = parser.add_subparsers(dest='mode', required=True)
    subparsers.add_parser('metadata')
    host = subparsers.add_parser('mint')
    host.add_argument('--archive', type=Path, default=DEFAULT_ARCHIVE)
    host.add_argument('--gpu', type=int, default=0)
    host.add_argument('--out', type=Path, required=True)
    decoder = subparsers.add_parser('peer')
    decoder.add_argument('--from-mint', type=Path, required=True)
    decoder.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    if args.mode == 'metadata':
        print(json.dumps(metadata(args.ffmpeg,args.ffprobe),indent=2))
        return
    args.out.mkdir(mode=0o700)
    raise SystemExit(0 if (mint(args) if args.mode == 'mint' else peer(args)) else 1)


if __name__ == '__main__':
    main()
