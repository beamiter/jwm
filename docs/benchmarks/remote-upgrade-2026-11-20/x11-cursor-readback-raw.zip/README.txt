Compile x11-fixture.c with cc -std=c11 -O2 -Wall -Wextra -Werror -o x11-fixture x11-fixture.c -lX11.
Set LD_LIBRARY_PATH as needed for the release binary. Adjust CLI in check.py and the lock path for the installed test build.
Run python3 check.py from this extracted directory. It creates its own displays, loopback listeners and temporary key.
Run python3 -m unittest -q test_gate.py for the protocol gate check.
