"""Exercise a blocked host GetImage with live authenticated host/viewer helpers."""
import asyncio
from contextlib import ExitStack
import fcntl
import json
from pathlib import Path
import re
import subprocess
import tempfile
import time

from processes import clean_env, get_display, start_display, stop
from x11_delay import CaptureGate

ROOT = Path(__file__).parent
CLI = "/tmp/jwm-p08-p09-release/jwm-remote"
FIXTURE = str(ROOT/"x11-fixture")
SIZE = (640, 480)
BACKGROUND = 0x204060
NEXT_BACKGROUND = 0x9a3d50
OLD = (120, 160)
POINTS = ((280, 190), (425, 250))


def rgb_close(actual, want, margin=7):
    return all(abs((actual >> shift & 255) - (want >> shift & 255)) <= margin
               for shift in (0,8,16))


async def wait_for(predicate, seconds=4):
    end = time.monotonic()+seconds
    while time.monotonic() < end:
        if result := predicate():
            return result
        await asyncio.sleep(.02)
    raise RuntimeError("required runtime witness did not arrive")


async def command(source, text):
    source.stdin.write(text.encode('ascii')+b'\n')
    await source.stdin.drain()
    result = await asyncio.wait_for(source.stdout.readline(),3)
    if result != b'ok\n':
        raise RuntimeError(f"owned Xvfb source didn't execute {text!r}")


def window_at(display,port):
    out=subprocess.check_output(["xwininfo","-display",display,"-root","-tree"],text=True,timeout=2)
    target=re.escape(f"127.0.0.1:{port} - JWM Remote")
    areas=re.findall(rf'^ +(0x[\da-f]+) "{target}(?: - [^"]*)?": .* 640x480\+0\+0(?= |$)',out,re.M)
    if len(areas)>1:
        raise RuntimeError("too many viewer drawables on isolated Xvfb")
    return areas[0] if areas else None


async def trial(env, key, tag, worker):
    directory=ROOT/tag
    directory.mkdir(mode=0o700)
    pixels=[]
    with ExitStack() as scope:
        xvfb_log=scope.enter_context((directory/"xvfb.log").open("wb"))
        source_display=start_display(*SIZE,xvfb_log)
        scope.callback(stop,source_display)
        source_name=get_display(source_display)
        viewer_display=start_display(*SIZE,xvfb_log)
        scope.callback(stop,viewer_display)
        viewer_name=get_display(viewer_display)
        source=await asyncio.create_subprocess_exec(
            FIXTURE,"source",source_name,stdin=asyncio.subprocess.PIPE,stdout=asyncio.subprocess.PIPE,env=env)
        proxy=CaptureGate(source_name)
        display=await proxy.start()
        try:
            assert await asyncio.wait_for(source.stdout.readline(),4) == b"ready\n"
            await command(source, f"paint {BACKGROUND:x}")
            await command(source, f"move {OLD[0]} {OLD[1]}")
            path=directory/"host.log"
            host_log=scope.enter_context(path.open("wb"))
            host_env=dict(env)
            if worker:
                host_env["JWM_REMOTE_CURSOR_WORKER"]="1"
            host=subprocess.Popen(
                [CLI,"host","--display",display,"--capture-source","root","--scaling","cpu",
                 "--listen","127.0.0.1:0","--once","--key-file",str(key),"--stats-json","--fps","30",
                 "--jpeg-quality","85","--fixed-jpeg-quality"],
                stdin=subprocess.DEVNULL,stdout=host_log,stderr=host_log,env=host_env)
            scope.callback(stop,host)
            port=(await wait_for(lambda:re.search(r"listening on 127\.0\.0\.1:(\d+)",path.read_text()))).group(1)
            view_log=scope.enter_context((directory/"viewer.log").open("wb"))
            viewer_args=[CLI,"connect",f"127.0.0.1:{port}","--display",viewer_name,"--view-only",
                         "--toggle","--stats-json","--jpeg","--key-file",str(key),"--window-size","640x480",
                         "--window-position","0,0","--scaling","cpu"]
            viewer=subprocess.Popen(viewer_args,env=env,stdout=view_log,stderr=view_log,stdin=subprocess.DEVNULL)
            scope.callback(stop,viewer)
            window=await wait_for(lambda:window_at(viewer_name,port),8)

            def sample(point):
                value=subprocess.check_output([FIXTURE,"sample",viewer_name,window,
                                               str(point[0]),str(point[1])],env=env,text=True,timeout=2)
                return int(value.strip(),16)

            markers=lambda x: rgb_close(sample(x),0xffffff,2)
            color=lambda want: rgb_close(sample((30,30)),want)
            await wait_for(lambda: color(BACKGROUND) and markers(OLD),6)
            observed_ns=time.monotonic_ns()
            proxy.arm()
            await command(source, f"paint {NEXT_BACKGROUND:x}")
            await asyncio.wait_for(proxy.ready.wait(),3)
            event,=proxy.delays
            assert (event["width"],event["height"]) == SIZE
            last=OLD
            for x,y in POINTS:
                await command(source,f"move {x} {y}")
                if worker:
                    await wait_for(lambda: markers((x,y)),.6)
                    assert not markers(last), "previous composited cursor was not erased"
                    last=(x,y)
                else:
                    await asyncio.sleep(.24)
                    assert not markers((x,y)), "capture-loop cursor changed during pending core readback"
                    assert markers(OLD), "capture-loop cursor did not retain its old position"
                assert color(BACKGROUND), "the new captured frame reached the viewer before gate release"
                pixels.append({
                    "checked_ns":time.monotonic_ns(), "target_xy":[x,y],
                    "target_rgb_hex":f"{sample((x,y)):06x}",
                    "last_cursor_xy":last,"frame_rgb_hex":f"{sample((30,30)):06x}",
                })
            proxy.release.set()
            await wait_for(lambda: color(NEXT_BACKGROUND) and markers(POINTS[-1]),5)
            subprocess.run(viewer_args,env=env,stdout=subprocess.DEVNULL,stderr=view_log,
                           timeout=5,check=True)
            assert await asyncio.to_thread(viewer.wait,5)==0
            assert await asyncio.to_thread(host.wait,5)==0
            host_text=path.read_text()
            assert ("independent X11 cursor sampler active" in host_text) == worker
            assert "core GetImage" in host_text or "core-getimage" in host_text
            assert all(event["start_ns"] < check["checked_ns"] < event["release_ns"] for check in pixels)
            result={"arm":tag,"baseline_observed_ns":observed_ns,"core_readback":event,
                    "source_and_viewer_dimensions":SIZE,"during_readback":pixels,
                    "post_release_rgb_hex":f"{NEXT_BACKGROUND:06x}",
                    "source_cursor_reached_final_position":True,"graceful_host_and_viewer_exit":True}
            (directory/"result.json").write_text(json.dumps(result,indent=2)+"\n")
            print(json.dumps(result),flush=True)
        finally:
            await proxy.close()
            if source.stdin:
                source.stdin.close()
            if source.returncode is None:
                try:
                    await asyncio.wait_for(source.wait(),2)
                except asyncio.TimeoutError:
                    source.terminate()
                    await asyncio.wait_for(source.wait(),2)


async def both():
    env=clean_env()
    with tempfile.TemporaryDirectory(prefix="jwm-p05-runtime.") as runtime:
        env["XDG_RUNTIME_DIR"]=runtime
        key=Path(runtime)/"key"
        subprocess.run([CLI,"keygen","--output",str(key)],env=env,stdout=subprocess.DEVNULL,timeout=3,check=True)
        await trial(env,key,"capture-loop",False)
        await trial(env,key,"independent",True)


if __name__=="__main__":
    lock_path="/tmp/jwm-p08-p09-release/benchmark.lock"
    with open(lock_path,"a") as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        asyncio.run(both())
