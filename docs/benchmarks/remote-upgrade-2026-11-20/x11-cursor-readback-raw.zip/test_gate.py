import asyncio
from pathlib import Path
import struct
import tempfile
import unittest

from x11_delay import CaptureGate


class GateTest(unittest.IsolatedAsyncioTestCase):
    async def test_readback_block_keeps_other_connection_moving(self):
        with tempfile.TemporaryDirectory(prefix="jwm-p05-gate-test-") as directory:
            path=Path(directory)/"test.sock"
            forwarded=asyncio.Queue()

            async def server(reader, writer):
                try:
                    setup=await reader.readexactly(12)
                    if setup[0] == ord("l"):
                        writer.write(b"ready")
                        await writer.drain()
                    while data:=await reader.readexactly(4):
                        size=int.from_bytes(data[2:4],"little")*4
                        await forwarded.put(data+await reader.readexactly(size-4))
                        writer.write(b"ok")
                        await writer.drain()
                except asyncio.IncompleteReadError:
                    pass
                finally:
                    writer.close()
                    await writer.wait_closed()

            upstream=await asyncio.start_unix_server(server,path)
            proxy=CaptureGate(":99")
            proxy.path=path
            display=await proxy.start()
            port=int(display.split(":")[1])+6000
            setup=struct.pack("<BBHHHHH",ord("l"),0,11,0,0,0,0)
            async def open_client():
                reader,writer=await asyncio.open_connection("127.0.0.1",port)
                writer.write(setup)
                await writer.drain()
                self.assertEqual(await asyncio.wait_for(reader.readexactly(5),1),b"ready")
                return reader,writer

            capture,write_capture=await open_client()
            cursor,write_cursor=await open_client()
            try:
                proxy.arm()
                request=struct.pack("<BBHIhhHHI",73,2,5,1,0,0,640,480,0xffffffff)
                write_capture.write(request)
                await write_capture.drain()
                await asyncio.wait_for(proxy.ready.wait(),1)
                self.assertTrue(forwarded.empty())
                self.assertEqual((proxy.delays[0]["width"],proxy.delays[0]["height"]),(640,480))
                pointer=struct.pack("<BBHI",38,0,2,1)
                write_cursor.write(pointer)
                await write_cursor.drain()
                self.assertEqual(await asyncio.wait_for(forwarded.get(),1),pointer)
                self.assertEqual(await asyncio.wait_for(cursor.readexactly(2),1), b"ok")
                self.assertTrue(forwarded.empty())
                proxy.release.set()
                self.assertEqual(await asyncio.wait_for(forwarded.get(),1),request)
                self.assertEqual(await asyncio.wait_for(capture.readexactly(2),1),b"ok")
                self.assertGreater(proxy.delays[0]["release_ns"],proxy.delays[0]["start_ns"])
            finally:
                write_capture.close()
                write_cursor.close()
                await proxy.close()
                upstream.close()
                await upstream.wait_closed()
