#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int source(Display *display) {
    Window root = DefaultRootWindow(display);
    char bits[32];
    memset(bits, 255, sizeof(bits));
    Pixmap white = XCreateBitmapFromData(display, root, bits, 16, 16);
    if (white == None) return 3;
    XColor fg = {.red=65535, .green=65535, .blue=65535};
    XColor bg = {0};
    Cursor cursor = XCreatePixmapCursor(display, white, white, &fg, &bg, 8, 8);
    if (cursor == None) return 3;
    XDefineCursor(display, root, cursor);
    printf("ready\n");
    fflush(stdout);
    char line[120];
    while (fgets(line, sizeof(line), stdin)) {
        int x, y;
        unsigned color;
        if (sscanf(line, "paint %x", &color) == 1 && color <= 0xffffff) {
            XSetWindowBackground(display, root, color);
            XClearWindow(display, root);
        } else if (sscanf(line, "move %d %d", &x, &y) == 2) {
            XWarpPointer(display, None, root, 0, 0, 0, 0, x, y);
        } else {
            return 4;
        }
        XSync(display, False);
        printf("ok\n");
        fflush(stdout);
    }
    XUndefineCursor(display, root);
    XFreeCursor(display, cursor);
    XFreePixmap(display, white);
    return 0;
}

static int sample(Display *display, int argc, char **argv) {
    if (argc < 6 || (argc - 4) % 2 != 0) return 2;
    Window window = strtoul(argv[3], NULL, 0);
    for (int i = 4; i < argc; i += 2) {
        XImage *image = XGetImage(display, window, atoi(argv[i]), atoi(argv[i+1]),
                                  1, 1, AllPlanes, ZPixmap);
        if (!image) return 5;
        printf("%06lx\n", XGetPixel(image,0,0) & 0xffffff);
        XDestroyImage(image);
    }
    return 0;
}

int main(int argc, char **argv) {
    if (argc < 3) return 2;
    Display *display = XOpenDisplay(argv[2]);
    if (!display) return 3;
    int result;
    if (!strcmp(argv[1], "source")) result = source(display);
    else if (!strcmp(argv[1], "sample")) result = sample(display, argc, argv);
    else result = 2;
    XCloseDisplay(display);
    return result;
}
