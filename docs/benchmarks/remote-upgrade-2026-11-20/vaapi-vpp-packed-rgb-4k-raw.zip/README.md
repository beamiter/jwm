# Intel VA-API 4K packed RGB compatibility

Extract the archive and run `python3 -B verify_pair.py` for offline replay. The
archive retains independent attempts using `bgr0` and `bgra` with the stock
FFmpeg VA-API decode and `scale_vaapi` path. Each reruns the same two pinned
single-IDR source pictures and its own VA-API NV12 and CPU RGB references.
Original run scripts, comparison sources, status files, commands, logs, packet
pins and active-byte outputs are included. This archive uses no hardware for
replay.

The first attempt recorded an explicit hardware output format rejection for
`bgr0` and empty output for both inputs. Its original parser reported a generic
candidate run failure. The paired replay detects the driver's exact text and
preserves the original reports. The BGRA attempt has its own terminal status.
If its packed download succeeds, RGB metrics use the little-endian order
B,G,R,alpha. Alpha is retained in the raw packed frames and independently
reported as an exact histogram and digests for the full frame and crop.

The RGB source cases use SMPTE 170M limited range and BT.709 full range. The
filter output requests full-range RGB. Successful RGB comparisons report
complete-frame and offline 3839×2159 crop channel deltas and guarded 8×8 solid
swatches. The swatch check allows at most four integer levels per channel for
small conversion rounding differences. The statistics contain all active pixel
locations, including chroma transitions where chroma interpolation can differ.
This is a compatibility check. Surface padding, timing, visible X11 cadence
and product integration are outside its scope.
