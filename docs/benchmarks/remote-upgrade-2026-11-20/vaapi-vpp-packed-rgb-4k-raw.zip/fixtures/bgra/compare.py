#!/usr/bin/env python3
"""Verify the exact 4K Intel VPP compatibility fixture without using hardware."""

import argparse
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import re
import sys
from zlib import adler32

SIZE = (3840, 2160)
PATTERNS = {
    'testsrc2': {
        'packet': '05f987caf29cdc4ecb07e09472628eb10ada85528c1cdf8908420604217be36e',
        'matrix': 'smpte170m', 'range': 'tv', 'nv12_adler': ('8848632d', 'a6efb58e'),
    },
    'smptehdbars': {
        'packet': '69702756f0f14d433626899cb869e3656a791a261e8546c2c2f347e6a2168c15',
        'matrix': 'bt709', 'range': 'pc', 'nv12_adler': ('e8aa1721', '5406062a'),
    },
}
SOLID_PATCH_SIZE = 8
SOLID_GUARD_HALF_WIDTH = 12
SOLID_ERROR_BUDGET = 4  # Smoke only. Allow small implementation rounding differences.


def file_sha(path, block_size=1024 * 1024):
    digest = sha256()
    with path.open('rb') as stream:
        while chunk := stream.read(block_size):
            digest.update(chunk)
    return digest.hexdigest()


def require(ok, message):
    if not ok:
        raise ValueError(message)


def log_frame(log, lane, pixel_format, size):
    lines = [line.split('] ', 1)[-1] for line in log.splitlines() if f'[showinfo@{lane} @ ' in line]
    frame, = [line for line in lines if re.search(r'\bn:\s*0\s', line)]
    properties = dict(re.findall(r'\b(fmt|s|iskey|type):\s*(\S+)', frame))
    color, = [line for line in lines if 'color_range:' in line]
    properties.update(dict(re.findall(r'\b(color_\w+):\s*(\S+)', color)))
    require(properties.get('fmt') == pixel_format and properties.get('s') == f'{size[0]}x{size[1]}',
            f'FFmpeg did not report {pixel_format} at expected size for {lane}')
    return properties


def command_record(directory, label):
    retained = {ext: directory / f'{label}.{ext}' for ext in ('argv', 'stdout', 'stderr', 'exit')}
    return {'exit_code': int(retained['exit'].read_text()),
            'artifacts_sha256': {ext: file_sha(path) for ext, path in retained.items()}}


def packed_bgr_to_rgb24(raw):
    require(len(raw) % 4 == 0, 'candidate output is not packed in 4-byte pixels')
    rgb = bytearray(len(raw) // 4 * 3)
    rgb[0::3], rgb[1::3], rgb[2::3] = raw[2::4], raw[1::4], raw[0::4]
    return rgb


def read_exact(path, length):
    require(path.stat().st_size == length, f'{path.name} did not contain exactly one active frame')
    return path.read_bytes()


def metric(histogram, left_hash, right_hash, channel_count):
    require(sum(histogram.values()) == channel_count, 'inconsistent active channel count')
    def quantile(numerator):
        running = 0
        for value in range(256):
            running += histogram[value]
            if running * 100 >= channel_count * numerator:
                return value
        raise AssertionError('empty metric')
    return {
        'active_rgb_bytes_per_path': channel_count,
        'reference_rgb_sha256': left_hash.hexdigest(),
        'vpp_rgb_sha256': right_hash.hexdigest(),
        'equal_channels': histogram[0],
        'mean_absolute_channel_delta': sum(value * frequency for value, frequency in histogram.items()) / channel_count,
        'p95_absolute_channel_delta': quantile(95),
        'p99_absolute_channel_delta': quantile(99),
        'maximum_absolute_channel_delta': max(histogram),
    }


def update_histogram(histogram, left, right):
    if left == right:
        histogram[0] += len(left)
    else:
        histogram.update(abs(a - b) for a, b in zip(left, right))


def compare_pixels(reference, candidate, width, height):
    full_ref, full_vpp = sha256(reference), sha256(candidate)
    crop_ref, crop_vpp = sha256(), sha256()
    interior, border = Counter(), Counter()
    row_bytes, crop_row_bytes = width * 3, (width - 1) * 3
    for y in range(height - 1):
        start = y * row_bytes
        stop = start + crop_row_bytes
        left, right = reference[start:stop], candidate[start:stop]
        crop_ref.update(left)
        crop_vpp.update(right)
        update_histogram(interior, left, right)
        update_histogram(border, reference[stop:stop + 3], candidate[stop:stop + 3])
    last_row = (height - 1) * row_bytes
    update_histogram(border, reference[last_row:], candidate[last_row:])
    return {
        'full': metric(interior + border, full_ref, full_vpp, width * height * 3),
        'odd_top_left_crop': metric(interior, crop_ref, crop_vpp, (width - 1) * (height - 1) * 3),
        'odd_top_left_crop_size': [width - 1, height - 1],
    }


def solid_samples(reference, candidate, width, height, step=40):
    # Select from the reference only, then evaluate VPP at those fixed locations.
    # The 24x24 uniform guard excludes chroma resampling at ordinary edges.
    samples = {}
    guard, half = SOLID_GUARD_HALF_WIDTH, SOLID_PATCH_SIZE // 2
    for y in range(guard, height - guard, step):
        for x in range(guard, width - guard, step):
            def offset(px, py):
                return (py * width + px) * 3
            color = tuple(reference[offset(x, y):offset(x, y) + 3])
            if color in samples:
                continue
            expected = bytes(color) * (2 * guard)
            if not all(reference[offset(x - guard, row):offset(x + guard, row)] == expected
                       for row in range(y - guard, y + guard)):
                continue
            pixels = [tuple(candidate[offset(px, py):offset(px, py) + 3])
                      for py in range(y - half, y + half) for px in range(x - half, x + half)]
            samples[color] = {
                'center': [x, y], 'reference_rgb': list(color),
                'vpp_rgb_mean': [sum(pixel[channel] for pixel in pixels) / len(pixels) for channel in range(3)],
                'vpp_rgb_min': [min(pixel[channel] for pixel in pixels) for channel in range(3)],
                'vpp_rgb_max': [max(pixel[channel] for pixel in pixels) for channel in range(3)],
                'max_channel_delta': max(abs(pixel[channel] - color[channel]) for pixel in pixels for channel in range(3)),
            }
    return list(samples.values())


def explicit_format_rejection(log, pixel_format):
    return [line for line in log.splitlines()
            if re.search(rf'\b{pixel_format}\b', line, re.I)
            and re.search(r'unsupported|not supported|does not support|invalid output format|not available', line, re.I)]


def alpha_summary(alpha, width, height):
    crop = sha256()
    for y in range(height - 1):
        crop.update(alpha[y * width:(y + 1) * width - 1])
    histogram = Counter(alpha)
    return {'bytes': len(alpha), 'sha256': sha256(alpha).hexdigest(),
            'odd_top_left_crop_sha256': crop.hexdigest(),
            'minimum': min(histogram), 'maximum': max(histogram),
            'fully_opaque': histogram[255], 'fully_transparent': histogram[0],
            'histogram': {str(value): count for value, count in sorted(histogram.items())}}


def run_case(directory, pattern, pin, size, pixel_format):
    path = directory / f'{pattern}.h264'
    candidate_lane = 'bgrx' if pixel_format == 'bgr0' else 'bgra'
    candidate_path = directory / f'{pattern}.{pixel_format}'
    result = {'pattern': pattern, 'packet_sha256': file_sha(path), 'packet_bytes': path.stat().st_size,
              'commands': {name: command_record(directory, f'{pattern}-{name}') for name in ('stream', 'reference', candidate_lane)},
              'decoded_observations': {}, 'candidate_format': pixel_format,
              'candidate_file_bytes': candidate_path.stat().st_size if candidate_path.exists() else None}
    try:
        require(result['packet_sha256'] == pin['packet'], 'packet SHA does not match golden fixture')
        stream, = json.loads((directory / f'{pattern}-stream.stdout').read_text())['streams']
        result['stream_metadata'] = stream
        require(result['commands']['stream']['exit_code'] == 0 and stream['codec_name'] == 'h264'
                and (stream['width'], stream['height']) == (stream['coded_width'], stream['coded_height']) == size
                and (stream['color_space'], stream['color_range']) == (pin['matrix'], pin['range']),
                'stream metadata failed the fixed source and color scope')
        reference_log = (directory / f'{pattern}-reference.stderr').read_text()
        candidate_log = (directory / f'{pattern}-{candidate_lane}.stderr').read_text()
        result['explicit_candidate_format_rejection'] = explicit_format_rejection(candidate_log, pixel_format)
        for arm, lane, fmt, log in [('reference', 'decode', 'vaapi', reference_log),
                                   ('reference', 'nv12_download', 'nv12', reference_log),
                                   ('reference', 'cpu_rgb', 'rgb24', reference_log),
                                   (candidate_lane, 'decode', 'vaapi', candidate_log),
                                   (candidate_lane, 'vpp', 'vaapi', candidate_log),
                                   (candidate_lane, f'{candidate_lane}_download', pixel_format, candidate_log)]:
            try:
                result['decoded_observations'][f'{arm}.{lane}'] = log_frame(log, lane, fmt, size)
            except (KeyError, ValueError):
                continue  # Keep partial stage proof if one operand failed.
        require(result['commands']['reference']['exit_code'] == 0, 'reference VA-API decode/download failed')
        width, height = size
        pixel_count = width * height
        nv12 = read_exact(directory / f'{pattern}.nv12', pixel_count * 3 // 2)
        reference = read_exact(directory / f'{pattern}.rgb24', pixel_count * 3)
        y, uv = memoryview(nv12)[:pixel_count], memoryview(nv12)[pixel_count:]
        y_adler, uv_adler = f'{adler32(y):08x}', f'{adler32(uv):08x}'
        result['reference_active_nv12'] = {'y_bytes': len(y), 'uv_bytes': len(uv),
                                          'y_adler32': y_adler, 'uv_adler32': uv_adler,
                                          'sha256': sha256(nv12).hexdigest(),
                                          'matches_earlier_standalone_probe': (y_adler, uv_adler) == pin['nv12_adler']}
        require((y_adler, uv_adler) == pin['nv12_adler'], 'NV12 identity differs from earlier standalone decode')
        for name in ('reference.decode', 'reference.nv12_download'):
            observation = result['decoded_observations'][name]
            require((observation.get('color_space'), observation.get('color_range')) == (pin['matrix'], pin['range']),
                    f'{name} does not report declared matrix and range')
        require(result['decoded_observations']['reference.cpu_rgb'].get('color_range') == 'pc',
                'reference CPU RGB does not report full output range')
        if result['commands'][candidate_lane]['exit_code'] != 0:
            result['status'] = ('explicit_format_rejection' if result['explicit_candidate_format_rejection'] else 'candidate_run_failed')
            return result
        decode = result['decoded_observations'][f'{candidate_lane}.decode']
        require((decode.get('color_space'), decode.get('color_range')) == (pin['matrix'], pin['range']),
                'candidate decode does not report declared matrix and range')
        download = f'{candidate_lane}.{candidate_lane}_download'
        for name in (f'{candidate_lane}.vpp', download):
            observation = result['decoded_observations'][name]
            require(observation.get('color_range') == 'pc', f'{name} does not report full output range')
        require(result['decoded_observations'][download].get('color_space') == 'gbr',
                'native RGB download does not report RGB matrix')
        packed = read_exact(candidate_path, pixel_count * 4)
        result['candidate_active_packed_rgb'] = {'format': pixel_format, 'bytes': len(packed),
                                                'sha256': sha256(packed).hexdigest()}
        if pixel_format == 'bgra':
            result['candidate_active_packed_rgb']['alpha'] = alpha_summary(packed[3::4], width, height)
        else:
            result['candidate_active_packed_rgb']['unused_fourth_byte_ignored'] = True
        candidate = packed_bgr_to_rgb24(packed)
        result['pixel_deltas'] = compare_pixels(reference, candidate, width, height)
        samples = solid_samples(reference, candidate, width, height)
        result['interior_solid_patches'] = {'sample_size': [SOLID_PATCH_SIZE] * 2, 'guard_size': [SOLID_GUARD_HALF_WIDTH * 2] * 2,
                                            'per_channel_rounding_budget': SOLID_ERROR_BUDGET, 'samples': samples}
        require(len(samples) >= 3 and any(max(patch['reference_rgb']) - min(patch['reference_rgb']) >= 48 for patch in samples),
                'sampled reference did not supply several materially different interior solid colors')
        require(all(patch['max_channel_delta'] <= SOLID_ERROR_BUDGET for patch in samples), 'interior solid colors exceeded smoke rounding budget')
        result['status'] = 'download_and_solid_colors_verified'
    except (OSError, KeyError, ValueError) as error:
        result.update(status='verification_failure', reason=str(error))
    return result


def evaluate(directory, pixel_format):
    cases = [run_case(directory, name, pin, SIZE, pixel_format) for name, pin in PATTERNS.items()]
    report = {
        'schema_version': 1, 'scope': 'Stock FFmpeg VA-API SDR H.264 decode / VPP packed RGB download compatibility on Intel i915',
        'candidate_format': pixel_format,
        'status': 'complete' if all(case['status'] == 'download_and_solid_colors_verified' for case in cases) else 'unqualified',
        'exact_decoded_size': list(SIZE), 'performance_measured': False, 'cases': cases,
        'device': dict(line.split(maxsplit=1) for line in (directory / 'device.txt').read_text().splitlines()),
        'ffmpeg_artifacts_sha256': {name: file_sha(directory / name) for name in ('ffmpeg-tools.sha256', 'ffmpeg-version.stdout', 'vaapi-filter.stdout', 'fixture.sha256', 'packet.sha256')},
        'limitations': [
            'Separate FFmpeg executions independently decode the same pinned packet. Only single-IDR compatibility is tested.',
            'The top-left 3839x2159 crop is computed offline from that same downloaded 3840x2160 output. The filter itself performs no scaling or odd-sized allocation.',
            'Raw files contain active samples only. Surface padding, GPU/CPU timing, X11 presentation, and product support are outside this fixture.',
            'BGRA alpha is reported separately from RGB. A later XRGB display must independently check depth, byte order and composition semantics.',
            'Color range/matrix reflect stream and actual frame logs. Chroma interpolation and numerical rounding may differ between VPP and libswscale.',
        ],
    }
    return report


def self_test():
    width, height = (80, 32)
    reference = bytes([224, 65, 11]) * width * height
    candidate = bytearray(reference)
    candidate[-1] = 255
    delta = compare_pixels(reference, candidate, width, height)
    assert delta['full']['maximum_absolute_channel_delta'] == 244
    assert delta['odd_top_left_crop']['maximum_absolute_channel_delta'] == 0
    samples = solid_samples(reference, candidate, width, height)
    assert len(samples) == 1 and samples[0]['max_channel_delta'] == 0
    assert not explicit_format_rejection('driver error in bgr0 candidate', 'bgr0')
    assert explicit_format_rejection('[hwdownload] Invalid output format bgra for hwframe download.', 'bgra')
    assert explicit_format_rejection('[Parsed_scale_vaapi_1] Hardware does not support output format bgr0.', 'bgr0')
    assert alpha_summary(bytes([0, 255, 188, 255]), 2, 2)['histogram'] == {'0': 1, '188': 1, '255': 2}
    assert packed_bgr_to_rgb24(bytes([3, 2, 1, 255, 6, 5, 4, 0])) == bytes([1, 2, 3, 4, 5, 6])
    sample = ('[showinfo@decode @ 0xabc] n:   0 pts:0 fmt:vaapi s:3840x2160 iskey:1 type:I\n'
              '[showinfo@decode @ 0xabc] color_range:tv color_space:smpte170m color_primaries:unknown color_trc:unknown\n')
    assert log_frame(sample, 'decode', 'vaapi', SIZE)['color_range'] == 'tv'
    print('Offline byte-order, crop, solid-patch, log and format-rejection self-check passed.')
    return 0


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('run', type=Path, nargs='?')
    parser.add_argument('--self-test', action='store_true')
    parser.add_argument('--format', choices=('bgra', 'bgr0'), default='bgra')
    args = parser.parse_args()
    if args.self_test and args.run is None:
        sys.exit(self_test())
    if args.run is None or args.self_test:
        parser.error('select either a completed run directory or --self-test')
    report = evaluate(args.run, args.format)
    print(json.dumps(report, indent=2, sort_keys=True))
    sys.exit(0 if report['status'] == 'complete' else 3)
