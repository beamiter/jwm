#!/usr/bin/env bash
set -euo pipefail
umask 077
base=$(cd "$(dirname "$0")" && pwd)
node=${1:-/dev/dri/renderD128}
[[ $# -le 1 && "$node" =~ ^/dev/dri/renderD[0-9]+$ ]] || { printf '%s\n' 'Usage: bash run.sh [/dev/dri/renderD<N>]' >&2; exit 2; }
lock=${JWM_VAAPI_PROBE_LOCK:-/tmp/jwm-p08-p09-release/benchmark.lock}
run=$(mktemp -d "$base/run.XXXXXXXX")
printf '%s\n' "$run"
cd "$run"
exec 9>>"$lock"
flock -x -w 600 9
trap 'printf "%s\n" "$?" > controller.exit' EXIT

capture() {
    local label=$1
    shift
    printf '%q ' "$@" > "$label.argv"
    printf '\n' >> "$label.argv"
    local code=0
    "$@" > "$label.stdout" 2> "$label.stderr" || code=$?
    printf '%s\n' "$code" > "$label.exit"
}

unset DISPLAY WAYLAND_DISPLAY WAYLAND_SOCKET LD_LIBRARY_PATH LD_PRELOAD
cp -- "$base/testsrc2.h264" "$base/smptehdbars.h264" "$base/packet.sha256" .
sha256sum --check packet.sha256
(cd "$base" && sha256sum run.sh compare.py) > fixture.sha256
sha256sum /usr/bin/ffmpeg /usr/bin/ffprobe > ffmpeg-tools.sha256
capture ffmpeg-version /usr/bin/ffmpeg -hide_banner -version
capture vaapi-filter /usr/bin/ffmpeg -hide_banner -h filter=scale_vaapi
device="/sys/class/drm/${node##*/}/device"
{
    printf 'vendor %s\n' "$(cat "$device/vendor")"
    printf 'device %s\n' "$(cat "$device/device")"
    printf 'revision %s\n' "$(cat "$device/revision")"
    printf 'driver %s\n' "$(basename "$(readlink "$device/driver")")"
} > device.txt
if [[ ! -c "$node" ]] || ! [[ $(sed -n '1p' device.txt) == 'vendor 0x8086' && $(sed -n '2p' device.txt) == 'device 0x7d67' && $(sed -n '4p' device.txt) == 'driver i915' ]]; then
    printf '%s\n' 'The requested Intel 8086:7d67 i915 render node is unavailable.' >&2
    exit 11
fi

for pattern in testsrc2 smptehdbars; do
    if [[ $pattern == testsrc2 ]]; then
        matrix=smpte170m
        range=limited
    else
        matrix=bt709
        range=full
    fi
    capture "${pattern}-stream" timeout --kill-after=2s 8s /usr/bin/ffprobe \
        -v error -select_streams v:0 \
        -show_entries stream=codec_name,profile,width,height,coded_width,coded_height,pix_fmt,color_range,color_space,color_transfer,color_primaries,chroma_location \
        -of json "${pattern}.h264"
    common=(timeout --kill-after=2s 20s /usr/bin/ffmpeg -nostdin -hide_banner -loglevel verbose \
        -n -noauto_conversion_filters -filter_complex_threads 1 -hwaccel vaapi \
        -hwaccel_device "$node" -hwaccel_output_format vaapi -threads 1 -c:v h264 -i "${pattern}.h264")
    reference="[0:v]showinfo@decode=checksum=0,hwdownload,format=nv12,showinfo@nv12_download=checksum=0,split=2[nvbytes][cpu];[cpu]scale=w=iw:h=ih:flags=bilinear:in_color_matrix=${matrix}:in_range=${range}:out_range=full,format=rgb24,showinfo@cpu_rgb=checksum=0[rgb]"
    candidate='[0:v]showinfo@decode=checksum=0,scale_vaapi=w=iw:h=ih:format=bgr0:out_color_matrix=gbr:out_range=full,showinfo@vpp=checksum=0,hwdownload,format=bgr0,showinfo@bgrx_download=checksum=0[bgrx]'
    capture "${pattern}-reference" "${common[@]}" -filter_complex "$reference" \
        -map '[nvbytes]' -frames:v 1 -c:v rawvideo -threads:v 1 -pix_fmt +nv12 -f rawvideo "${pattern}.nv12" \
        -map '[rgb]' -frames:v 1 -c:v rawvideo -threads:v 1 -pix_fmt +rgb24 -f rawvideo "${pattern}.rgb24"
    capture "${pattern}-bgrx" "${common[@]}" -filter_complex "$candidate" \
        -map '[bgrx]' -frames:v 1 -c:v rawvideo -threads:v 1 -pix_fmt +bgr0 -f rawvideo "${pattern}.bgr0"
done
# Device use has finished. Raw validation can run independently of the lab lock.
flock -u 9
exec 9>&-
python3 -B "$base/compare.py" . > report.json
cat report.json
