#!/usr/bin/env python3
"""Verify the BGR0 rejection and independent terminal BGRA follow-up offline."""

import argparse
import json
from pathlib import Path
import subprocess
import sys

from fixtures.bgra.compare import evaluate, file_sha, require


def verify_attempt(root, kind):
    run = root / 'runs' / kind
    source = root / 'fixtures' / kind
    expected = dict((name, digest) for digest, name in
                    (line.split(maxsplit=1) for line in (run / 'fixture.sha256').read_text().splitlines()))
    require(set(expected) == {'run.sh', 'compare.py'}, f'{kind} fixture pin scope differs')
    require(all(file_sha(source / name) == digest for name, digest in expected.items()), f'{kind} source pin differs')
    require(all(file_sha(source / name) == file_sha(run / name)
                for name in ('testsrc2.h264', 'smptehdbars.h264', 'packet.sha256')), f'{kind} archived packet pins differ')
    controller = int((run / 'controller.exit').read_text())
    require(controller in (0, 3), f'{kind} controller is not at a replayable terminal outcome')
    original_bytes = (run / 'report.json').read_bytes()
    original = json.loads(original_bytes)
    require(controller == (0 if original['status'] == 'complete' else 3),
            f'{kind} controller status differs from its report')
    options = ['--format', kind] if kind == 'bgra' else []
    recorded = subprocess.run([sys.executable, '-B', str(source / 'compare.py'), str(run), *options],
                              capture_output=True)
    require(recorded.returncode == controller and recorded.stdout == original_bytes,
            f'{kind} original parser and captured result differ in offline replay')
    current = evaluate(run, 'bgr0') if kind == 'bgr0' else original
    if kind == 'bgr0':
        require(controller == 3 and all(c['status'] == 'explicit_format_rejection'
                and c['commands']['reference']['exit_code'] == 0
                and c['commands']['bgrx']['exit_code'] == 234 and c['candidate_file_bytes'] == 0
                and c['reference_active_nv12']['matches_earlier_standalone_probe']
                and any('Hardware does not support output format bgr0' in line
                        for line in c['explicit_candidate_format_rejection']) for c in current['cases']),
                'the initial BGR0 rejection does not match the recorded hardware evidence')
    return {'controller_exit': controller, 'original_report_sha256': file_sha(run / 'report.json'),
            'original_parser_case_statuses': [case['status'] for case in original['cases']],
            'verified': current}


def neutral_swatch_observations(report):
    samples = []
    for case in report['cases']:
        if case.get('stream_metadata', {}).get('color_range') != 'pc':
            continue
        for patch in case.get('interior_solid_patches', {}).get('samples', []):
            color = patch['reference_rgb']
            if not color[0] == color[1] == color[2]:
                continue
            target = color[0]
            expanded = max(0, min(255, ((target - 16) * 255 + 109) // 219))
            observed = patch['vpp_rgb_mean']
            samples.append({'center': patch['center'], 'reference_rgb': color,
                            'observed_vpp_rgb_mean': observed,
                            'predicted_if_nominal_limited_range_expansion': expanded,
                            'maximum_difference_from_prediction': max(abs(value - expanded) for value in observed)})
    return samples


def verify(root):
    initial = verify_attempt(root, 'bgr0')
    follow_up = verify_attempt(root, 'bgra')
    require(initial['verified']['device'] == follow_up['verified']['device'],
            'the BGRA follow-up used a different recorded device')
    cross_run = {}
    for first, second in zip(initial['verified']['cases'], follow_up['verified']['cases']):
        pattern = first['pattern']
        require(pattern == second['pattern'] and first['packet_sha256'] == second['packet_sha256'],
                'independent attempts used different source input')
        a = root / 'runs' / 'bgr0'
        b = root / 'runs' / 'bgra'
        cross_run[pattern] = {ext: {'bgr0_run_sha256': file_sha(a / f'{pattern}.{ext}'),
                                    'bgra_run_sha256': file_sha(b / f'{pattern}.{ext}') if (b / f'{pattern}.{ext}').exists() else None}
                              for ext in ('nv12', 'rgb24')}
        for formats in cross_run[pattern].values():
            formats['equal'] = formats['bgr0_run_sha256'] == formats['bgra_run_sha256']
    return {'schema_version': 1, 'performance_measured': False,
            'scope': 'Independent stock FFmpeg VA-API VPP packed RGB compatibility attempts on Intel i915',
            'initial_bgr0': initial, 'followup_bgra': follow_up, 'references_across_attempts': cross_run,
            'full_range_neutral_swatch_observations': neutral_swatch_observations(follow_up['verified']),
            'notes': [
                'The initial parser missed the driver phrase “does not support output format”. The original report and parser are preserved and replayed; the paired verifier classifies the exact retained stderr.',
                'The neutral swatch comparison applies a nominal limited-to-full luma mapping to the CPU reference. It is evidence of compatible behavior and does not identify the cause or explain the full color differences.',
                'Each attempt uses independently decoded inputs. A BGR0 rejection and any BGRA result apply to the tested FFmpeg and Intel runtime. No surface padding, timing, X11 present result or product route is established.',
            ]}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', nargs='?', type=Path, default=Path(__file__).resolve().parent)
    arguments = parser.parse_args()
    print(json.dumps(verify(arguments.root.resolve()), sort_keys=True, indent=2))
