"""Delay one exact core GetImage target from an owned test Xvfb client."""
import asyncio
from pathlib import Path
import time


def padded(length):
    return (length + 3) & ~3


def get_image_target(header, payload, endian):
    if len(header) != 4 or header[:2] != bytes((73, 2)) or len(payload) != 16:
        return None
    if int.from_bytes(payload[12:16], endian) != 0xffffffff:
        return None
    return (int.from_bytes(payload[:4], endian),
            int.from_bytes(payload[4:6], endian, signed=True),
            int.from_bytes(payload[6:8], endian, signed=True),
            int.from_bytes(payload[8:10], endian),
            int.from_bytes(payload[10:12], endian))


class CaptureGate:
    def __init__(self, display, target):
        self.server = None
        self.path = Path("/tmp/.X11-unix") / f"X{int(display.removeprefix(':'))}"
        self.sessions = set()
        self.target = target
        self.readbacks = []
        self.connections_opened = 0
        self.ready = asyncio.Event()
        self.release = asyncio.Event()
        self.delays = []
        self.armed = False

    async def start(self):
        self.server = await asyncio.start_server(self.session, "127.0.0.1", 0)
        port = self.server.sockets[0].getsockname()[1]
        if port <= 6000:
            raise RuntimeError("X11 test proxy requires TCP port above 6000")
        return f"127.0.0.1:{port-6000}"

    def arm(self):
        if self.delays or self.ready.is_set():
            raise RuntimeError("the GetImage gate has already been used")
        self.armed = True

    async def session(self, downstream, downstream_writer):
        owner = asyncio.current_task()
        self.sessions.add(owner)
        self.connections_opened += 1
        connection = self.connections_opened
        upstream_writer = None
        copies = []
        try:
            upstream, upstream_writer = await asyncio.open_unix_connection(self.path)

            async def requests():
                setup = await downstream.readexactly(12)
                if setup[0] not in (ord("l"), ord("B")):
                    raise ValueError("invalid X11 byte order")
                endian = "little" if setup[0] == ord("l") else "big"
                def integer(data):
                    return int.from_bytes(data, endian)
                auth = padded(integer(setup[6:8])) + padded(integer(setup[8:10]))
                if auth > 4096:
                    raise ValueError("X11 test auth is too large")
                upstream_writer.write(setup + await downstream.readexactly(auth))
                await upstream_writer.drain()
                while True:
                    header = await downstream.readexactly(4)
                    size = integer(header[2:4])
                    extended = size == 0
                    extra = await downstream.readexactly(4) if extended else b""
                    length = (integer(extra) if extended else size)*4 - len(header) - len(extra)
                    if not 0 <= length <= 4*1024*1024:
                        raise ValueError("unexpected X11 test request length")
                    payload = await downstream.readexactly(length)
                    target = get_image_target(header, payload, endian)
                    if target is not None:
                        if len(self.readbacks) >= 2048:
                            raise RuntimeError("owned GetImage trace exceeded its bound")
                        event = {"opcode": 73, "format": "ZPixmap", "all_planes": True,
                                 "target": list(target), "connection": connection,
                                 "observed_ns": time.monotonic_ns()}
                        self.readbacks.append(event)
                        if self.armed and target == self.target:
                            self.armed = False
                            self.delays.append(event)
                            self.ready.set()
                            await asyncio.wait_for(self.release.wait(), 5)
                            event["release_ns"] = time.monotonic_ns()
                    upstream_writer.write(header + extra + payload)
                    await upstream_writer.drain()

            async def replies():
                while chunk := await upstream.read(65536):
                    downstream_writer.write(chunk)
                    await downstream_writer.drain()

            copies = [asyncio.create_task(requests()), asyncio.create_task(replies())]
            done, _ = await asyncio.wait(copies, return_when=asyncio.FIRST_COMPLETED)
            for task in done:
                task.result()
        except (asyncio.IncompleteReadError, OSError):
            pass
        finally:
            for task in copies:
                task.cancel()
            await asyncio.gather(*copies, return_exceptions=True)
            downstream_writer.close()
            if upstream_writer:
                upstream_writer.close()
            self.sessions.discard(owner)

    async def close(self):
        self.release.set()
        if self.server:
            self.server.close()
            await self.server.wait_closed()
        sessions = list(self.sessions)
        for task in sessions:
            task.cancel()
        await asyncio.gather(*sessions, return_exceptions=True)
