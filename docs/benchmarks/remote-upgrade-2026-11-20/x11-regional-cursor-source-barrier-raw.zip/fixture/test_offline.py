"""Fake request bytes and proof records only. No X11 connection or child processes."""
from copy import deepcopy
import struct
import unittest

from run import (A_ORIGIN, B_ORIGIN, COLORS, HOLD_NS, POINTS, SIZE,
                 gated_colors, region, verify)
from x11_delay import get_image_target


def rgb(label, white=None):
    return {key: 0xffffff if key == white else COLORS[label] for key in POINTS}


def evidence():
    def row(key, time, color, white=None, switching=False):
        label = 'switching to' if switching else 'source'
        return {'rgb': rgb(color, white), 'sample_ns': time,
                'title': f'Test - JWM Remote | {label} {region(A_ORIGIN if key == "A" else B_ORIGIN)}'}
    root, start = 449, 10_000_000_000
    end = start + HOLD_NS
    a = {'target': [root, *A_ORIGIN, *SIZE], 'connection': 7, 'observed_ns': start - 3}
    gate = {'opcode': 73, 'format': 'ZPixmap', 'all_planes': True, 'target': [root, *B_ORIGIN, *SIZE],
            'connection': 7, 'observed_ns': start, 'release_ns': end}
    held = []
    for index, label in enumerate(['A_motion'] * 3 + ['B_initial'] * 3, 1):
        held.append(row('B', start + index * 10, 'A', 'A_old', switching=True)
                    | {'move_witness_ns': start + index, 'move_label': label})
    return {'source_root': root, 'gate': gate, 'readbacks': [a, gate],
            'toggle_return_ns': start + 1, 'toggle_start_ns': start - 1, 'toggle_exit_status': 0,
            'view_window_before': 305, 'view_window_after': 305, 'viewer_exit_status': 0, 'host_exit_status': 0,
            'pre': row('A', start - 4, 'A', 'A_old'), 'A_follow': row('A', start - 12, 'A', 'A_motion'),
            'held_B': held, 'B_first': row('B', end + 1, 'B', 'B_initial'),
            'B_follow': row('B', end + 2, 'B', 'B_motion'),
            'scopes': [{'session_id': 'fake-actual-session', 'source_epoch': 1, 'geometry_epoch': 4},
                       {'session_id': 'fake-actual-session', 'source_epoch': 2, 'geometry_epoch': 5}]}


class Tests(unittest.TestCase):
    def test_precise_getimage_parses_both_byte_orders_and_signed_origins(self):
        for order, encoding in (('little', '<'), ('big', '>')):
            request = struct.pack(encoding + 'IhhHHI', 449, -432, 104, 320, 320, 0xffffffff)
            self.assertEqual(get_image_target(b'I\x02\x05\x00', request, order), (449, -432, 104, 320, 320))
            self.assertIsNone(get_image_target(b'I\x01\x05\x00', request, order))
            self.assertIsNone(get_image_target(b'I\x02\x05\x00', request[:-1], order))

    def test_gated_old_sprite_is_observed_and_new_cursors_are_excluded(self):
        self.assertTrue(gated_colors(rgb('A', 'A_old')))
        self.assertTrue(gated_colors(rgb('A')))
        self.assertFalse(gated_colors(rgb('A', 'A_motion')))
        self.assertFalse(gated_colors(rgb('A', 'B_initial')))
        self.assertFalse(gated_colors(rgb('B', 'B_initial')))

    def test_same_session_and_actual_barrier_proof_replay(self):
        source = evidence()
        self.assertEqual(verify(source)['gate_hold_ms'], 1500)
        mutations = [
            lambda p: p['scopes'][1].update(session_id='another-session'),
            lambda p: p['scopes'][1].update(geometry_epoch=4),
            lambda p: p['held_B'][1]['rgb'].update(A_motion=0xffffff),
            lambda p: p['B_first']['rgb'].update(A_old=0xffffff),
            lambda p: p['readbacks'].insert(1, p['gate'] | {'observed_ns': p['gate']['observed_ns'] - 1, 'release_ns': None}),
            lambda p: p.update(view_window_after=77),
            lambda p: p.update(toggle_return_ns=p['gate']['release_ns'] + 1),
        ]
        for change in mutations:
            wrong = deepcopy(source)
            change(wrong)
            with self.assertRaises(RuntimeError):
                verify(wrong)


if __name__ == '__main__':
    unittest.main()
