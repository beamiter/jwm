"""Revalidate saved regional source switch evidence without opening X11."""
import json
from pathlib import Path
import sys

from run import logged_scope, require, verify


def replay(folder):
    evidence = json.loads((folder / 'evidence.json').read_text())
    result = json.loads((folder / 'result.json').read_text())
    require(verify(evidence) == result, 'raster and GetImage evidence differs from summary')
    host = (folder / 'host.log').read_text()
    require(host.count('authenticated session started') == 1
            and 'independent X11 cursor sampler active' in host, 'host cursor mode or session count differs')
    for scope in evidence['scopes']:
        for filename, role, frame_field, ack in (
            ('host.log', 'host', 'last_sent_frame', 'drawn_acks'),
            ('viewer.log', 'viewer', 'last_frame', 'acked'),
        ):
            rows = logged_scope(folder / filename, role, scope['source_epoch'])
            require(any(row['session_id'] == scope['session_id'] and row[frame_field] == scope[f'{role}_scope']
                        and row[ack] == scope['host_drawn_acks_in_window' if role == 'host'
                                             else 'viewer_acks_in_window'] for row in rows),
                    'frame/ACK scope absent from product telemetry')
    return result


if __name__ == '__main__':
    print(json.dumps(replay(Path(sys.argv[1])), indent=2))
