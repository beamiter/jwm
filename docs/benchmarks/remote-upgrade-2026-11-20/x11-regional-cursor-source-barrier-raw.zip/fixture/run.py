#!/usr/bin/env python3
"""Proof of observed X11 frame/cursor behavior across one authenticated region switch."""
import asyncio
from contextlib import ExitStack
import fcntl
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tempfile
import time
import traceback

from Xlib import X, display

from check import CLI, FIXTURE, command, rgb_close
from processes import clean_env, get_display, start_display, stop
from x11_delay import CaptureGate


HERE = Path(__file__).resolve().parent
LOCK = Path('/tmp/jwm-p08-p09-release/benchmark.lock')
PINS = {CLI: '5e1951ed8bbc23f41db5b5918931d91a37baa1e9fa213c8ef9067a214a1511e5',
        FIXTURE: 'afe56ec71d6b7f47d61b3533686642baaa4e588d7a333513869f716af1ebe652'}
SOURCE_SIZE = (800, 560)
SIZE = (320, 320)
A_ORIGIN, B_ORIGIN = (24, 64), (432, 104)
COLORS = {'A': 0x204060, 'B': 0x9a3d50}
POINTS = {'background': (35, 35), 'A_old': (70, 86), 'A_motion': (139, 147),
          'B_initial': (186, 203), 'B_motion': (251, 226)}
HOLD_NS = 1_500_000_000
TOLERANCE_NS = 75_000_000


def require(test, error):
    if not test:
        raise RuntimeError(error)


def put_json(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')


def region(origin):
    return f'{SIZE[0]}x{SIZE[1]}{origin[0]:+}{origin[1]:+}'


def titled(window, kind, label):
    title = window.get_wm_name() or ''
    return f' | {kind} {label}' in title


def viewer_window(connection, port):
    candidates = [(child, child.get_wm_name() or '') for child in connection.screen().root.query_tree().children]
    matching = [child for child, name in candidates if name.startswith(f'127.0.0.1:{port} - JWM Remote')]
    require(len(matching) <= 1, 'more than one viewer belongs to the same loopback endpoint')
    if matching:
        child, = matching
        geometry = child.get_geometry()
        if (geometry.width, geometry.height, geometry.x, geometry.y) == (*SIZE, 0, 0):
            return child
    return None


def paint_regions(connection):
    screen = connection.screen()
    windows = []
    for name, (x, y) in (('A', A_ORIGIN), ('B', B_ORIGIN)):
        window = screen.root.create_window(x, y, *SIZE, 0, screen.root_depth, X.InputOutput,
                                           X.CopyFromParent, background_pixel=COLORS[name])
        window.map()
        windows.append(window)
    connection.sync()
    return windows


def logged_scope(path, role, epoch):
    result = []
    field = 'last_sent_frame' if role == 'host' else 'last_frame'
    for line in path.read_text(errors='replace').splitlines():
        if not line.startswith('{'):
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        if row.get('type') != f'jwm_remote_{role}_stats':
            continue
        frame = row.get(field)
        if (frame and frame['source_epoch'] == epoch and row.get('session_id')
                and row.get('drawn_acks' if role == 'host' else 'acked', 0) > 0):
            result.append(row)
    return result


def scope_pair(host, viewer, epoch):
    left, right = logged_scope(host, 'host', epoch), logged_scope(viewer, 'viewer', epoch)
    if not left or not right:
        return None
    h, v = left[-1], right[-1]
    require(h['session_id'] == v['session_id'], 'endpoint source scope observed on different authenticated sessions')
    frames = h['last_sent_frame'], v['last_frame']
    require(all(frame['codec'] == 'JPEG' and frame['source_dimensions'] == list(SIZE)
                and frame['encoded_dimensions'] == list(SIZE) and frame['source_epoch'] == epoch for frame in frames),
            'root dimensions, scaling or codec changed in a granted region')
    require(frames[0]['geometry_epoch'] == frames[1]['geometry_epoch'], 'endpoints disagree on geometry epoch')
    require('core-getimage' in h['mode'] and v['viewer_backend'] == 'x11'
            and v['last_presentation_path'] == 'rgb', 'wrong actual capture/viewer path')
    return {'session_id': h['session_id'], 'source_epoch': epoch,
            'geometry_epoch': frames[0]['geometry_epoch'], 'host_scope': frames[0], 'viewer_scope': frames[1],
            'host_drawn_acks_in_window': h['drawn_acks'], 'viewer_acks_in_window': v['acked']}


def clean_colors(rgb, background, white_at=()):
    return all(rgb_close(value, 0xffffff if tag in white_at else background, 2 if tag in white_at else 7)
               for tag, value in rgb.items())


def gated_colors(rgb):
    if set(rgb) != set(POINTS):
        return False
    stable = dict(rgb)
    old = stable.pop('A_old')
    return clean_colors(stable, COLORS['A']) and (
        rgb_close(old, COLORS['A']) or rgb_close(old, 0xffffff, 2))


def verify(data):
    gate = data['gate']
    root = data['source_root']
    target_a, target_b = [root, *A_ORIGIN, *SIZE], [root, *B_ORIGIN, *SIZE]
    require(gate['target'] == target_b and gate['format'] == 'ZPixmap' and gate['all_planes'],
            'gate did not block exact B source core read')
    readbacks = data['readbacks']
    first_b, = [row for row in readbacks if row.get('release_ns')]
    require(first_b == gate and next(row for row in readbacks if row['target'] == target_b) == gate,
            'first core B read was not held')
    require(any(row['target'] == target_a and row['connection'] == gate['connection']
                and row['observed_ns'] < gate['observed_ns'] for row in readbacks),
            'capture did not preserve its actual X11 connection across the source switch')
    require(all(row['target'] == (target_a if row['observed_ns'] < gate['observed_ns'] else target_b)
                for row in readbacks), 'capture used a region outside the current grant')
    require(all(row['connection'] == gate['connection'] for row in readbacks),
            'core capture switched to a second X11 connection')
    start, end = gate['observed_ns'], gate['release_ns']
    require(abs(end - start - HOLD_NS) <= TOLERANCE_NS, 'B gate missed its scheduled fixture duration')
    require(data['toggle_start_ns'] <= start and data['toggle_return_ns'] <= end
            and data['toggle_exit_status'] == 0, 'owned toggle did not control this gate')
    require(data['pre']['title'].endswith(f' | source {region(A_ORIGIN)}')
            and data['B_first']['title'].endswith(f' | source {region(B_ORIGIN)}')
            and data['B_follow']['title'].endswith(f' | source {region(B_ORIGIN)}'),
            'wrong source title on visible frame')
    require(data['A_follow']['sample_ns'] < data['pre']['sample_ns'] <= data['toggle_start_ns'],
            'A raster was not observed before requesting B')
    require(all(set(data[key]['rgb']) == set(POINTS) for key in ('pre', 'A_follow', 'B_first', 'B_follow')),
            'missing actual raster points')
    require(clean_colors(data['pre']['rgb'], COLORS['A'], ('A_old',))
            and clean_colors(data['A_follow']['rgb'], COLORS['A'], ('A_motion',)), 'A cursor preflight failed')
    gated = data['held_B']
    require(len(gated) == 6 and [row['move_label'] for row in gated] == ['A_motion'] * 3 + ['B_initial'] * 3,
            'missing gated A/B pointer motion samples')
    for row in gated:
        require(start < row['move_witness_ns'] <= row['sample_ns'] < end
                and row['title'].endswith(f' | switching to {region(B_ORIGIN)}') and gated_colors(row['rgb']),
                'old-frame content or gated cursor isolation changed')
    require(end < data['B_first']['sample_ns'] < data['B_follow']['sample_ns']
            and clean_colors(data['B_first']['rgb'], COLORS['B'], ('B_initial',))
            and clean_colors(data['B_follow']['rgb'], COLORS['B'], ('B_motion',)),
            'actual B frame and cursor did not arrive at the expected locations')
    scopes = data['scopes']
    require([scope['source_epoch'] for scope in scopes] == [1, 2]
            and scopes[0]['session_id'] == scopes[1]['session_id']
            and scopes[1]['geometry_epoch'] == scopes[0]['geometry_epoch'] + 1, 'wrong session or source boundary')
    require(data['view_window_before'] == data['view_window_after']
            and data['viewer_exit_status'] == data['host_exit_status'] == 0, 'viewer rebuilt or shutdown failed')
    return {'session_id': scopes[0]['session_id'], 'gate_hold_ms': (end - start) / 1e6,
            'cursor_on_last_A_raster_while_gated': [
                'frozen_sprite' if rgb_close(row['rgb']['A_old'], 0xffffff, 2) else 'background' for row in gated],
            'source_epochs': [1, 2], 'geometry_epochs': [scope['geometry_epoch'] for scope in scopes],
            'B_visible_after_gate_ms': (data['B_first']['sample_ns'] - end) / 1e6}


async def until(label, predicate, *children, seconds=6):
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        for child in children:
            require(child.poll() is None, f'{label}: owned child exited at status {child.returncode}')
        value = predicate()
        if value:
            return value
        await asyncio.sleep(.020)
    raise RuntimeError(f'timed out waiting for {label}')


async def main(batch, environment, key):
    data = {'binary_sha256': {Path(path).name: sha for path, sha in PINS.items()}}
    with ExitStack() as cleanup:
        xvfb_log = cleanup.enter_context((batch / 'xvfb.log').open('wb'))
        source_xvfb = start_display(*SOURCE_SIZE, xvfb_log)
        cleanup.callback(stop, source_xvfb)
        viewer_xvfb = start_display(*SOURCE_SIZE, xvfb_log)
        cleanup.callback(stop, viewer_xvfb)
        source_display, viewer_display = get_display(source_xvfb), get_display(viewer_xvfb)
        require(source_display != viewer_display, 'two independent owned Xvfb endpoints required')
        source_x, viewer_x = display.Display(source_display), display.Display(viewer_display)
        cleanup.callback(source_x.close)
        cleanup.callback(viewer_x.close)
        record = cleanup.enter_context((batch / 'events.jsonl').open('w', encoding='utf-8'))

        def save(name, observation):
            print(json.dumps({'event': name, 'logged_ns': time.monotonic_ns(), **observation}), file=record, flush=True)
            return observation

        save('owned_endpoints', {'source_xvfb_pid': source_xvfb.pid, 'viewer_xvfb_pid': viewer_xvfb.pid})
        source_root = source_x.screen().root
        data['source_root'] = source_root.id
        data['source_region_window_ids'] = [window.id for window in paint_regions(source_x)]
        source = await asyncio.create_subprocess_exec(
            FIXTURE, 'source', source_display, env=environment, stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE, stderr=cleanup.enter_context((batch / 'source.log').open('wb')))
        gate = CaptureGate(source_display, (source_root.id, *B_ORIGIN, *SIZE))
        timer = None

        async def release_at(stamp):
            await asyncio.sleep(max(0, (stamp - time.monotonic_ns()) / 1e9))
            save('gate_release_requested', {'due_ns': stamp})
            gate.release.set()

        try:
            require(await asyncio.wait_for(source.stdout.readline(), 4) == b'ready\n', 'X11 source cursor unavailable')

            async def move(origin, label):
                (left, top), (x, y) = origin, POINTS[label]
                root_xy = (left + x, top + y)
                await command(source, f'move {root_xy[0]} {root_xy[1]}')
                pointer = source_root.query_pointer()
                require((pointer.root_x, pointer.root_y) == root_xy, 'owned source X11 cursor did not move')
                return time.monotonic_ns()

            await move(A_ORIGIN, 'A_old')
            proxy = await gate.start()
            host_path, view_path = batch / 'host.log', batch / 'viewer.log'

            def start(args, path, env):
                log = cleanup.enter_context(path.open('ab'))
                child = subprocess.Popen(args, env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=log)
                cleanup.callback(stop, child)
                return child

            host = start([CLI, 'host', '--display', proxy, '--capture-source', 'root', '--scaling', 'cpu',
                          '--region', region(A_ORIGIN), '--share-region', region(B_ORIGIN), '--max-width', '0',
                          '--listen', '127.0.0.1:0', '--once', '--stats-json', '--fps', '30',
                          '--jpeg-quality', '85', '--fixed-jpeg-quality', '--key-file', str(key)],
                         host_path, environment | {'JWM_REMOTE_CURSOR_WORKER': '1'})
            port = (await until('private host listener',
                                lambda: re.search(r'listening on 127\.0\.0\.1:(\d+)', host_path.read_text()),
                                host)).group(1)
            args = [CLI, 'connect', f'127.0.0.1:{port}', '--display', viewer_display, '--view-only',
                    '--toggle', '--stats-json', '--jpeg', '--key-file', str(key), '--window-size', '320x320',
                    '--window-position', '0,0', '--scaling', 'cpu']
            viewer = start(args, view_path, environment)
            children = host, viewer
            window = await until('exact production viewer drawable', lambda: viewer_window(viewer_x, port), *children)
            data['view_window_before'] = window.id
            pixel_args = [FIXTURE, 'sample', viewer_display, hex(window.id),
                          *(str(axis) for point in POINTS.values() for axis in point)]

            async def sample():
                output = await asyncio.to_thread(subprocess.check_output, pixel_args, env=environment, text=True, timeout=1)
                rgb = {label: int(value, 16) for label, value in zip(POINTS, output.splitlines(), strict=True)}
                return {'sample_ns': time.monotonic_ns(), 'rgb': rgb, 'title': window.get_wm_name() or ''}

            async def sample_until(source_label, white):
                deadline = time.monotonic() + 7
                origin = A_ORIGIN if source_label == 'A' else B_ORIGIN
                while time.monotonic() < deadline:
                    row = await sample()
                    if row['title'].endswith(f' | source {region(origin)}') and clean_colors(
                        row['rgb'], COLORS[source_label], (white,)
                    ):
                        return row
                    require(all(child.poll() is None for child in children), 'owned endpoint exited during pixel probe')
                    await asyncio.sleep(.025)
                raise RuntimeError(f'missing source {source_label} and {white} on actual viewer pixels')

            async def toggle(extra, output):
                with (batch / output).open('wb') as log:
                    return await asyncio.to_thread(
                        subprocess.run, [*args, *extra], env=environment, stdout=log, stderr=log,
                        stdin=subprocess.DEVNULL, timeout=5, check=False)

            await sample_until('A', 'A_old')
            await move(A_ORIGIN, 'A_motion')
            data['A_follow'] = save('A_follow', await sample_until('A', 'A_motion'))
            await move(A_ORIGIN, 'A_old')
            data['pre'] = save('A_baseline', await sample_until('A', 'A_old'))
            a_scope = await until('matching authenticated source epoch A',
                                  lambda: scope_pair(host_path, view_path, 1), *children, seconds=12)
            save('source_A_scope', a_scope)
            gate.arm()
            data['toggle_start_ns'] = time.monotonic_ns()
            async def request_switch():
                switched = await toggle(['--next-source'], 'toggle-switch.log')
                data['toggle_exit_status'] = switched.returncode
                data['toggle_return_ns'] = time.monotonic_ns()
                save('switch_helper_returned', {'exit_status': switched.returncode})

            switch = asyncio.create_task(request_switch())
            try:
                await asyncio.wait_for(gate.ready.wait(), 5)
                data['gate'], = gate.delays
                start_ns = data['gate']['observed_ns']
                timer = asyncio.create_task(release_at(start_ns + HOLD_NS))
                save('first_B_read_held', data['gate'])
                await until('stable switching title over blocked B read',
                            lambda: titled(window, 'switching to', region(B_ORIGIN)), *children)
                data['held_B'] = []
                for origin, label in ((A_ORIGIN, 'A_motion'), (B_ORIGIN, 'B_initial')):
                    moved = await move(origin, label)
                    for _ in range(3):
                        await asyncio.sleep(.050)
                        row = await sample() | {'move_witness_ns': moved, 'move_label': label}
                        data['held_B'].append(save('gated_cursor_probe', row))
                        require(not gate.release.is_set() and gated_colors(row['rgb']),
                                'gated source B or unsanctioned cursor movement reached the raster')
            finally:
                if timer is not None:
                    await timer
                await switch
            await until('first B read actually forwarded', lambda: data['gate'].get('release_ns'), *children)
            data['B_first'] = save('source_B_visible', await sample_until('B', 'B_initial'))
            same_window = viewer_window(viewer_x, port)
            require(same_window is not None, 'active viewer window changed identity')
            data['view_window_after'] = same_window.id
            await move(B_ORIGIN, 'B_motion')
            data['B_follow'] = save('source_B_cursor_follow', await sample_until('B', 'B_motion'))
            b_scope = await until('matching authenticated source epoch B',
                                  lambda: scope_pair(host_path, view_path, 2), *children, seconds=12)
            data['scopes'] = [a_scope, save('source_B_scope', b_scope)]
            close = await toggle([], 'toggle-close.log')
            require(close.returncode == 0, 'owned viewer close toggle failed')
            data['viewer_exit_status'], data['host_exit_status'] = await asyncio.gather(
                asyncio.to_thread(viewer.wait, 7), asyncio.to_thread(host.wait, 7))
            require('independent X11 cursor sampler active' in host_path.read_text()
                    and host_path.read_text().count('authenticated session started') == 1,
                    'host did not keep the requested cursor worker and one authenticated session')
            data['readbacks'] = gate.readbacks
            result = verify(data)
            put_json(batch / 'result.json', result)
            print(json.dumps(result), flush=True)
        except Exception:
            (batch / 'failure.log').write_text(traceback.format_exc(), encoding='utf-8')
            raise
        finally:
            data['readbacks'] = gate.readbacks
            put_json(batch / 'evidence.json', data)
            await gate.close()
            source.stdin.close()
            try:
                await asyncio.wait_for(source.wait(), 3)
            except asyncio.TimeoutError:
                source.kill()
                await asyncio.wait_for(source.wait(), 3)


def run():
    for raw_path, expected in PINS.items():
        with Path(raw_path).open('rb') as file:
            require(hashlib.file_digest(file, 'sha256').hexdigest() == expected, 'fixture or release pin mismatch')
    env = clean_env()
    env.pop('XAUTHORITY', None)
    env.pop('LD_PRELOAD', None)
    batch = Path(tempfile.mkdtemp(prefix='regional-switch.', dir=HERE))
    print(batch, flush=True)
    with tempfile.TemporaryDirectory(prefix='jwmp05src.') as runtime:
        env.update(XDG_RUNTIME_DIR=runtime, XDG_CONFIG_HOME=runtime, XDG_STATE_HOME=runtime)
        key = Path(runtime) / 'key'
        subprocess.run([CLI, 'keygen', '--output', str(key)], env=env, stdin=subprocess.DEVNULL,
                       stdout=subprocess.DEVNULL, timeout=4, check=True)
        asyncio.run(main(batch, env, key))


if __name__ == '__main__':
    with LOCK.open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        run()
