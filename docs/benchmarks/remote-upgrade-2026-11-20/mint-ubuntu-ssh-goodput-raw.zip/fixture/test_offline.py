"""Offline parser and counter tests. Does not launch commands or open sockets."""
import json
from pathlib import Path
import struct
import tempfile
import unittest
from unittest.mock import MagicMock, patch

import characterize
import net_probe


class PingSamples(unittest.TestCase):
    def test_reordered_duplicate_loss_and_upper_bound(self):
        data = """
PING redacted.peer (192.0.2.1) 56(84) bytes of data.
[1790000000.100001] 64 bytes from 192.0.2.1: icmp_seq=2 ttl=64 time=4.00 ms
[1790000000.200001] 64 bytes from 192.0.2.1: icmp_seq=1 ttl=64 time=2.00 ms
[1790000000.300001] 64 bytes from 192.0.2.1: icmp_seq=2 ttl=64 time=5.00 ms (DUP!)
[1790000000.400001] 64 bytes from 192.0.2.1: icmp_seq=4 ttl=64 time<1.00 ms
[1790000000.500001] 64 bytes from 192.0.2.1: icmp_seq=5 ttl=64 time=8.00 ms
5 packets transmitted, 4 received, +1 duplicates, 20% packet loss, time 804ms
"""
        result = net_probe.parse_ping(data, 5)
        self.assertEqual(result['echo_loss_fraction'], .2)
        self.assertEqual(result['unanswered_sequences'], [3])
        self.assertEqual(result['duplicate_replies'], 1)
        self.assertEqual(result['rtt_exact_count'], 3)
        self.assertEqual(result['rtt_upper_bound_count'], 1)
        self.assertEqual(result['rtt_ms']['p50_nearest_rank'], 4)
        self.assertEqual(result['rtt_ms']['p95_nearest_rank'], 8)
        self.assertEqual(result['consecutive_exact_success_pairs'], 1)
        self.assertEqual(result['absolute_consecutive_rtt_difference_ms']['max'], 2)
        self.assertEqual(result['raw_numeric_echoes'][0]['arrival_realtime_ns'], 1790000000100001000)
        self.assertNotIn('192.0.2.1', json.dumps(result))
        self.assertNotIn('redacted.peer', json.dumps(result))

    def test_complete_absence_and_bad_clip(self):
        result = net_probe.parse_ping('2 packets transmitted, 0 received, 100% packet loss', 2)
        self.assertEqual(result['unanswered_sequences'], [1, 2])
        self.assertIsNone(result['rtt_ms'])
        self.assertIsNone(result['absolute_consecutive_rtt_difference_ms'])
        with self.assertRaisesRegex(ValueError, 'transmission count'):
            net_probe.parse_ping('1 packets transmitted, 0 received, 100% packet loss', 2)
        with self.assertRaisesRegex(ValueError, 'replies disagree'):
            net_probe.parse_ping('2 packets transmitted, 1 received, 50% packet loss', 2)


class TransferSamples(unittest.TestCase):
    def test_receiver_rate_is_independent_of_sender_clock(self):
        sender = dict(bytes=1_000_000, start_monotonic_ns=23_000_000_000,
                      end_monotonic_ns=24_000_000_000, stop_condition='duration',
                      receipt_bytes=1_000_000, receipt_monotonic_ns=25_000_000_000)
        receiver = dict(bytes=1_000_000, start_monotonic_ns=2_000_000_000,
                        last_byte_monotonic_ns=3_000_000_000, end_marker_monotonic_ns=3_500_000_000,
                        sender_reported_bytes=1_000_000, receipt_sent_monotonic_ns=3_501_000_000)
        summary = characterize.throughput_report('ubuntu_to_mint', sender, receiver)
        self.assertEqual(summary['receiver_observed_goodput_mbps'], 8)
        self.assertEqual(summary['receiver_observed_duration_seconds'], 1)
        with self.assertRaisesRegex(ValueError, 'byte counts'):
            characterize.throughput_report('ubuntu_to_mint', sender, receiver | {'bytes': 500})
        with self.assertRaisesRegex(ValueError, 'byte counts'):
            characterize.throughput_report('ubuntu_to_mint', sender | {'receipt_bytes': 4}, receiver)

    def test_exact_cap_roundtrip_with_short_reads_and_writes_without_half_close(self):
        sender_socket = MemoryStream(struct.pack('!Q', 7))
        sender_trace = net_probe.Trace(lambda row: None)
        receiver_trace = net_probe.Trace(lambda row: None)
        with patch.multiple(net_probe, TCP_BYTE_CAP=7, BLOCK_BYTES=3):
            reported = net_probe.send_bytes(sender_socket, sender_trace)
            receiver = MemoryStream(sender_socket.written)
            receipt = net_probe.receive_bytes(receiver, receiver_trace)
            summary = characterize.throughput_report('mint_to_ubuntu', reported, receipt)
        self.assertEqual(reported['bytes'], 7)
        self.assertEqual(reported['stop_condition'], 'byte_cap')
        self.assertEqual(receiver.written, struct.pack('!Q', 7))
        self.assertEqual(summary['receiver']['bytes'], 7)
        self.assertEqual(sender_trace.phase, 'wait_receiver_receipt')
        self.assertEqual(receiver_trace.phase, 'send_receiver_receipt')

    def test_receiver_rejects_byte_overrun(self):
        fake = MemoryStream(struct.pack('!I', 5))
        trace = net_probe.Trace(lambda row: None)
        with patch.object(net_probe, 'TCP_BYTE_CAP', 4):
            with self.assertRaisesRegex(RuntimeError, 'byte cap'):
                net_probe.receive_bytes(fake, trace)

    def test_partial_payload_and_wait_phase_survive_failure(self):
        raw = []
        trace = net_probe.Trace(raw.append)
        partial = MemoryStream(struct.pack('!I', 5) + b'ab', exhausted=TimeoutError)
        with self.assertRaises(TimeoutError):
            net_probe.receive_bytes(partial, trace)
        self.assertEqual(trace.phase, 'read_chunk_payload')
        self.assertEqual(trace.bytes, 2)
        self.assertEqual(raw[-1]['payload_bytes'], 2)

        sender = MemoryStream(b'', exhausted=TimeoutError)
        trace = net_probe.Trace(raw.append)
        with patch.multiple(net_probe, TCP_BYTE_CAP=1, BLOCK_BYTES=1):
            with self.assertRaises(TimeoutError):
                net_probe.send_bytes(sender, trace)
        self.assertEqual(trace.phase, 'wait_receiver_receipt')
        self.assertEqual(trace.bytes, 1)

    def test_graceful_close_without_counted_marker_is_incomplete(self):
        fake = MemoryStream(struct.pack('!I', 3) + b'abc')
        trace = net_probe.Trace(lambda row: None)
        with self.assertRaises(EOFError):
            net_probe.receive_bytes(fake, trace)
        self.assertEqual(trace.bytes, 3)
        self.assertEqual(trace.phase, 'read_chunk_header_or_end')
        self.assertEqual(fake.written, b'')


class MemoryStream:
    """In-memory short I/O. There is intentionally no shutdown method."""

    def __init__(self, incoming, exhausted=None):
        self.incoming = bytearray(incoming)
        self.written = bytearray()
        self.exhausted = exhausted

    def settimeout(self, seconds):
        if not 0 < seconds <= net_probe.IO_IDLE_SECONDS:
            raise AssertionError('timeout is not bounded')

    def send(self, data):
        chunk = data[:2]
        self.written.extend(chunk)
        return len(chunk)

    def recv_into(self, target):
        length = min(len(self.incoming), len(target), 2)
        if not length and self.exhausted is not None:
            raise self.exhausted('offline scripted I/O failure')
        target[:length] = self.incoming[:length]
        del self.incoming[:length]
        return length


class DirectionIsolation(unittest.TestCase):
    def test_control_attempts_reverse_after_direction_raises(self):
        with tempfile.TemporaryDirectory() as directory, \
                patch.object(net_probe, 'route', return_value=('192.0.2.1', {'classification': 'ethernet'})), \
                patch.object(characterize, 'inspect_peer', return_value={
                    'route': {'classification': 'wifi'}, 'iperf3_available': False,
                }), \
                patch.object(characterize, 'wait_master'), \
                patch.object(characterize.subprocess, 'Popen'), \
                patch.object(characterize, 'characterize_direction', side_effect=[
                    TimeoutError(), {'direction': 'ubuntu_to_mint', 'status': 'completed'},
                ]) as directions:
            run = Path(directory)
            self.assertEqual(characterize.collect(run), 'partial')
            summary = json.loads((run / 'result.json').read_text())
        self.assertEqual([call.args[-1] for call in directions.call_args_list],
                         ['mint_to_ubuntu', 'ubuntu_to_mint'])
        first, reverse = summary['tcp']['directions']
        self.assertEqual(first['error_category'], 'TimeoutError')
        self.assertEqual(reverse['status'], 'completed')
        self.assertFalse(summary['icmp_repeated'])

    def test_partial_peer_trace_can_be_read_without_accepting_it_as_final(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'events'
            path.write_bytes(b'{"payload_bytes":65536}\n{"phase":')
            self.assertEqual(characterize.trace_records(path, allow_partial=True), [{'payload_bytes': 65536}])
            with self.assertRaisesRegex(ValueError, 'partial record'):
                characterize.trace_records(path)


class SelectedRoute(unittest.TestCase):
    def test_rejects_wrong_device_and_ignores_ip_identifiers_in_classification(self):
        fake = MagicMock(returncode=0)
        fake.stdout = json.dumps([{'dev': 'wrong', 'prefsrc': '192.0.2.2'}])
        with patch.object(net_probe, 'run_numeric', return_value=fake):
            with self.assertRaisesRegex(RuntimeError, 'expected lab interface'):
                net_probe.route('192.0.2.1', 'eno1')

    def test_rejects_mismatched_ssh_peer(self):
        with patch.dict(net_probe.os.environ, {'SSH_CONNECTION': '192.0.2.3 1 192.0.2.2 22'}):
            with self.assertRaisesRegex(RuntimeError, 'socket addresses differ'):
                net_probe.checked_ssh_addresses('192.0.2.1', '192.0.2.2', 'wlp3s0')


if __name__ == '__main__':
    unittest.main()
