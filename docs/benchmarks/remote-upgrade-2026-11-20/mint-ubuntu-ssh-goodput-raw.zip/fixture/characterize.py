#!/usr/bin/env python3
"""Characterize the existing authorized Mint/Ubuntu lab route without network changes."""
import argparse
from contextlib import ExitStack, suppress
import fcntl
import json
import os
from pathlib import Path
import secrets
import shlex
import shutil
import socket
import subprocess
import tempfile
import time

import net_probe as probe


HERE = Path(__file__).resolve().parent
LOCK = '/tmp/jwm-p08-p09-release/benchmark.lock'
PEER_IPV4 = '192.168.0.78'
DESTINATION = 'ubuntu@' + PEER_IPV4
MINT_DEVICE = 'eno1'
UBUNTU_DEVICE = 'wlp3s0'
SSH = ['ssh', '-4', '-T', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
       '-o', 'ConnectionAttempts=1', '-o', 'StrictHostKeyChecking=yes',
       '-o', 'ForwardX11=no', '-o', 'ForwardAgent=no', '-o', 'ProxyCommand=none',
       '-o', 'ProxyJump=none', '-o', 'ExitOnForwardFailure=yes',
       '-o', 'ServerAliveInterval=8', '-o', 'ServerAliveCountMax=2',
       '-o', 'Compression=no']

TRACE_LIMIT = 64 * 1024
DIR_ERRORS = (OSError, EOFError, ValueError, RuntimeError, KeyError, TypeError, subprocess.SubprocessError)


def close_process(process):
    if process.stdin is not None and not process.stdin.closed:
        process.stdin.close()
    if process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=3)
    if process.stdout is not None:
        process.stdout.close()


def write_private(path, record):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(record, indent=2, ensure_ascii=False) + '\n')
    temporary.chmod(0o600)
    temporary.replace(path)


def ssh(control, local, *options):
    return SSH + ['-b', local, '-S', str(control), *options]


def command(control, local, source, action, *options):
    args = ['python3', '-B', '-u', '-c', source, action, local, PEER_IPV4,
            UBUNTU_DEVICE, *options]
    return ssh(control, local, '--', DESTINATION, shlex.join(args))


def control_operation(control, local, *options):
    return subprocess.run(ssh(control, local, '-O', *options, '--', DESTINATION),
                          stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                          stderr=subprocess.DEVNULL, timeout=6).returncode


def forget_forward(control, local, forward):
    with suppress(OSError, subprocess.SubprocessError):
        control_operation(control, local, 'cancel', '-L', forward)


def wait_master(master, control, local):
    deadline = time.monotonic() + 10
    while master.poll() is None and time.monotonic() < deadline:
        if control_operation(control, local, 'check') == 0:
            return
        time.sleep(.05)
    raise RuntimeError('private SSH master did not become ready')


def worker_json(raw, status=0):
    result = json.loads(raw)
    if not isinstance(result, dict) or status or 'worker_error' in result:
        raise RuntimeError('peer worker did not complete the selected measurement')
    return result


def inspect_peer(control, local, source):
    result = subprocess.run(command(control, local, source, 'inspect'),
                            stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                            stderr=subprocess.DEVNULL, timeout=12)
    return worker_json(result.stdout, result.returncode)


def trace_records(path, *, allow_partial=False):
    with path.open('rb') as stream:
        raw = stream.read(TRACE_LIMIT + 1)
    if len(raw) > TRACE_LIMIT:
        raise ValueError('peer trace exceeded its byte limit')
    if raw and not raw.endswith(b'\n'):
        if not allow_partial:
            raise ValueError('peer trace ended with a partial record')
        end = raw.rfind(b'\n')
        raw = raw[:end + 1]
    records = [json.loads(line) for line in raw.splitlines()]
    if any(not isinstance(row, dict) for row in records):
        raise ValueError('peer trace contained an invalid record')
    return records


def wait_peer_listener(worker, path):
    deadline = time.monotonic() + 8
    while time.monotonic() < deadline:
        for row in trace_records(path, allow_partial=True):
            if row.get('phase') == 'accept_peer_loopback_stream' and row.get('event') == 'enter':
                port = row.get('loopback_port')
                if type(port) is not int or not 1 <= port <= 65535:
                    raise ValueError('peer loopback listener reported an invalid port')
                return port
        if worker.poll() is not None:
            raise RuntimeError('peer worker ended before listening')
        time.sleep(.05)
    raise TimeoutError('peer loopback listener readiness deadline expired')


def throughput_report(direction, sender, receiver):
    count = receiver['bytes']
    if (type(count) is not int or not 0 < count <= probe.TCP_BYTE_CAP
            or sender['bytes'] != count or sender['receipt_bytes'] != count
            or receiver['sender_reported_bytes'] != count):
        raise ValueError('sender and receiver byte counts do not match')
    if not (receiver['start_monotonic_ns'] < receiver['last_byte_monotonic_ns']
            <= receiver['end_marker_monotonic_ns'] <= receiver['receipt_sent_monotonic_ns']):
        raise ValueError('receiver reports an invalid transfer span')
    if not sender['start_monotonic_ns'] < sender['end_monotonic_ns'] <= sender['receipt_monotonic_ns']:
        raise ValueError('sender clock did not advance')
    if sender['stop_condition'] != ('byte_cap' if count == probe.TCP_BYTE_CAP else 'duration'):
        raise ValueError('invalid transfer stop condition')
    elapsed = receiver['last_byte_monotonic_ns'] - receiver['start_monotonic_ns']
    return {'direction': direction, 'receiver_observed_goodput_mbps': 8000 * count / elapsed,
            'receiver_observed_duration_seconds': elapsed / 10**9,
            'sender': sender, 'receiver': receiver}


def local_loopback_port():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as selector:
        selector.bind(('127.0.0.1', 0))
        return selector.getsockname()[1]


def characterize_direction(control, local, source, run, direction):
    mint_log = run / (direction + '.mint.jsonl')
    ubuntu_log = run / (direction + '.ubuntu.jsonl')
    capability = secrets.token_hex(32).encode()
    with mint_log.open('x', buffering=1) as local_file, ubuntu_log.open('xb') as peer_file:
        mint_log.chmod(0o600)
        ubuntu_log.chmod(0o600)
        trace = probe.Trace(lambda row: local_file.write(json.dumps(row, separators=(',', ':')) + '\n'))
        result = {'direction': direction, 'mint_trace': mint_log.name, 'ubuntu_trace': ubuntu_log.name}
        worker = None
        with ExitStack() as cleanup:
            try:
                trace.enter('start_peer_worker')
                worker = subprocess.Popen(command(control, local, source, 'transfer', direction),
                                          stdin=subprocess.PIPE, stdout=peer_file,
                                          stderr=subprocess.DEVNULL, bufsize=0)
                cleanup.callback(close_process, worker)
                trace.enter('write_worker_capability')
                if worker.stdin.write(capability + b'\n') != len(capability) + 1:
                    raise RuntimeError('incomplete peer control capability write')
                worker.stdin.close()
                trace.enter('wait_peer_listener')
                port = wait_peer_listener(worker, ubuntu_log)
                trace.enter('select_local_loopback_port')
                local_port = local_loopback_port()
                forward = f'127.0.0.1:{local_port}:127.0.0.1:{port}'
                trace.enter('install_ipv4_loopback_forward')
                status = control_operation(control, local, 'forward', '-L', forward)
                if status != 0:
                    trace.event('forward_rejected', returncode=status)
                    raise RuntimeError('private IPv4 loopback forward could not be established')
                cleanup.callback(forget_forward, control, local, forward)
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as connection:
                    connection.settimeout(probe.HANDSHAKE_SECONDS)
                    trace.enter('connect_ipv4_loopback_forward')
                    connection.connect(('127.0.0.1', local_port))
                    trace.enter('send_forwarded_capability')
                    connection.sendall(capability)
                    trace.enter('wait_forwarded_capability_confirmation')
                    ack = bytearray(1)
                    deadline = time.monotonic_ns() + probe.HANDSHAKE_SECONDS * 10**9
                    probe.transfer_read(connection, ack, deadline, trace)
                    if ack != b'\x01':
                        raise RuntimeError('peer did not confirm the private stream')
                    local_transfer = (probe.receive_bytes(connection, trace) if direction == 'ubuntu_to_mint'
                                      else probe.send_bytes(connection, trace))
                trace.enter('wait_peer_exit', transfer=local_transfer)
                status = worker.wait(timeout=6)
                trace.enter('read_peer_result', returncode=status)
                records = trace_records(ubuntu_log)
                completed = [row['transfer'] for row in records if row.get('event') == 'complete']
                if status or len(completed) != 1:
                    raise RuntimeError('peer worker did not complete the transfer')
                peer = completed[0]
                sender, receiver = (peer, local_transfer) if direction == 'ubuntu_to_mint' else (local_transfer, peer)
                trace.enter('validate_sender_receiver_counts')
                result.update(throughput_report(direction, sender, receiver), status='completed')
                trace.event('complete')
            except DIR_ERRORS as error:
                trace.event('failed', error_category=type(error).__name__)
                result.update(status='failed', failed_stage=trace.phase, error_category=type(error).__name__,
                              mint_payload_bytes=trace.bytes, mint_last_payload_monotonic_ns=trace.last_payload_ns)
                if worker is not None and worker.poll() is None:
                    # The stream scope has closed. Give the peer a brief bounded
                    # opportunity to flush its matching error or partial count.
                    with suppress(subprocess.TimeoutExpired):
                        worker.wait(timeout=1)
        if result['status'] == 'failed':
            with suppress(OSError, ValueError):
                records = trace_records(ubuntu_log, allow_partial=True)
                if records:
                    last = records[-1]
                    result['peer_last_record'] = {key: last.get(key) for key in (
                        'phase', 'event', 'error_category', 'payload_bytes', 'last_payload_monotonic_ns')}
        return result


def collect(run):
    source = (HERE / 'net_probe.py').read_text()
    artifact = run / 'result.json'
    report = {
        'status': 'started',
        'scope': 'Bounded SSH payload goodput retry on the existing IPv4 Wi-Fi/Ethernet lab route.',
        'icmp_repeated': False,
        'tcp': {'configuration': {'sender_target_seconds': probe.TCP_SECONDS,
                                   'sender_maximum_bytes': probe.TCP_BYTE_CAP,
                                   'data_idle_timeout_seconds': probe.IO_IDLE_SECONDS,
                                   'receiver_absolute_timeout_seconds': probe.RECEIVE_SECONDS,
                                   'transport': 'IPv4 loopback OpenSSH forward with compression disabled',
                                   'completion': 'counted application end marker and receiver receipt',
                                   'rate_scope': 'receiver payload goodput through SSH including endpoint/cipher effects'},
                'directions': []},
    }
    write_private(artifact, report)
    stage = 'selected_local_route'
    try:
        local, mint = probe.route(PEER_IPV4, MINT_DEVICE)
        if mint['classification'] != 'ethernet':
            raise RuntimeError('Mint route did not verify as Ethernet')
        report['mint'] = {'route_before': mint, 'iperf3_available': shutil.which('iperf3') is not None}
        stage = 'private_ssh_master'
        # The short control path avoids sockaddr_un length limits and remains private.
        with ExitStack() as cleanup:
            runtime = Path(cleanup.enter_context(tempfile.TemporaryDirectory(prefix='jwnet.')))
            control = runtime / 'control'
            master = subprocess.Popen(ssh(control, local, '-N', '-M', '-o', 'ControlPersist=no',
                                           '-o', 'ClearAllForwardings=yes', '--', DESTINATION),
                                      stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                      stderr=subprocess.DEVNULL)
            cleanup.callback(close_process, master)
            wait_master(master, control, local)
            stage = 'selected_peer_route'
            peer = inspect_peer(control, local, source)
            if peer['route']['classification'] != 'wifi':
                raise RuntimeError('Ubuntu route did not verify as Wi-Fi')
            report['ubuntu'] = {'route_before': peer['route'], 'iperf3_available': peer['iperf3_available']}

            for direction in ('mint_to_ubuntu', 'ubuntu_to_mint'):
                stage = direction + '_ssh_goodput'
                try:
                    result = characterize_direction(control, local, source, run, direction)
                except DIR_ERRORS as error:
                    result = {'direction': direction, 'status': 'failed',
                              'failed_stage': 'direction_artifact_or_cleanup',
                              'error_category': type(error).__name__}
                report['tcp']['directions'].append(result)
                write_private(artifact, report)

            stage = 'verify_route_after'
            local_after, mint_after = probe.route(PEER_IPV4, MINT_DEVICE)
            peer_after = inspect_peer(control, local, source)['route']
            report['mint']['route_after'] = mint_after
            report['ubuntu']['route_after'] = peer_after
            if local_after != local or mint_after['classification'] != 'ethernet' or peer_after['classification'] != 'wifi':
                raise RuntimeError('selected IPv4 route or interface classification changed')
        successes = sum(row['status'] == 'completed' for row in report['tcp']['directions'])
        report['status'] = ('completed' if successes == 2 else 'partial' if successes else 'failed')
    except (OSError, ValueError, RuntimeError, KeyError, TypeError, subprocess.SubprocessError) as error:
        # Avoid putting raw subprocess stderr, addresses, arguments or user IDs in evidence.
        report.update(status='failed', failed_stage=stage, error_category=type(error).__name__)
    write_private(artifact, report)
    return report['status']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.parse_args()
    with open(LOCK, 'a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        run = Path(tempfile.mkdtemp(prefix='trace.', dir=HERE))
        print(run, flush=True)
        status = collect(run)
    if status != 'completed':
        raise SystemExit(1)


if __name__ == '__main__':
    main()
