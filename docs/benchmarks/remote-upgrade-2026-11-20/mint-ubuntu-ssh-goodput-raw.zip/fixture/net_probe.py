"""Network measurement helpers shared by the local controller and Ubuntu worker."""
import ipaddress
import json
import math
import os
from pathlib import Path
import re
import select
import shutil
import socket
import struct
import subprocess
import sys
import time


PING_COUNT = 100
PING_INTERVAL = 0.2
TCP_SECONDS = 8
TCP_BYTE_CAP = 256 * 1024 * 1024
BLOCK_BYTES = 64 * 1024
HANDSHAKE_SECONDS = 8
IO_IDLE_SECONDS = 4
RECEIVE_SECONDS = TCP_SECONDS + 2 * IO_IDLE_SECONDS
ECHO = re.compile(
    r'^\[(\d+)\.(\d{1,9})\]\s+.*?\bicmp_seq=(\d+)\b.*?\btime([=<])'
    r'(\d+(?:\.\d+)?)\s*ms(?:\s+\(DUP!\))?\s*$'
)
PING_TOTAL = re.compile(r'^(\d+) packets transmitted, (\d+) received\b', re.M)


def ipv4(value):
    return str(ipaddress.IPv4Address(value))


def run_numeric(argv, timeout):
    return subprocess.run(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                          stderr=subprocess.DEVNULL, encoding='utf-8', errors='replace',
                          env=dict(os.environ, LC_ALL='C'), timeout=timeout)


def route(address, expected_interface):
    result = run_numeric(['ip', '-j', '-4', 'route', 'get', ipv4(address)], 4)
    rows = json.loads(result.stdout) if result.returncode == 0 else []
    if len(rows) != 1:
        raise RuntimeError('selected IPv4 route unavailable or ambiguous')
    record, = rows
    device = record.get('dev')
    if device != expected_interface:
        raise RuntimeError('selected IPv4 route did not use the expected lab interface')
    return ipv4(record.get('prefsrc', record.get('src'))), classify_interface(device)


def classify_interface(device):
    directory = Path('/sys/class/net') / device

    def small_value(name, allowed):
        try:
            value = (directory / name).read_text().strip()
            return value if re.fullmatch(allowed, value) else None
        except (OSError, UnicodeError):
            return None

    def number(name):
        value = small_value(name, r'[0-9]{1,8}')
        return int(value) if value is not None else None

    wireless = (directory / 'wireless').is_dir() or (directory / 'phy80211').exists()
    speed = number('speed') if not wireless else None
    kind = ('wifi' if wireless else
            'ethernet' if number('type') == 1 and (directory / 'device').exists()
            and speed is not None and speed > 0 else 'unknown')
    return {'interface': device, 'classification': kind,
            'carrier': number('carrier'), 'operstate': small_value('operstate', r'[a-z]{2,12}'),
            'reported_ethernet_link_speed_mbps': speed if kind == 'ethernet' else None,
            'reported_ethernet_duplex': small_value('duplex', r'(full|half)') if kind == 'ethernet' else None}


def summary(values):
    if not values:
        return None
    ordered = sorted(values)
    return {'min': ordered[0], 'p50_nearest_rank': ordered[math.ceil(len(ordered) * .5) - 1],
            'p95_nearest_rank': ordered[math.ceil(len(ordered) * .95) - 1], 'max': ordered[-1]}


def parse_ping(text, expected_count):
    totals = PING_TOTAL.findall(text)
    if len(totals) != 1 or int(totals[0][0]) != expected_count:
        raise ValueError('ICMP output has no complete expected transmission count')
    if not 0 <= int(totals[0][1]) <= expected_count:
        raise ValueError('ICMP output has an invalid reply count')
    records = []
    for line in text.splitlines():
        match = ECHO.fullmatch(line)
        if not match:
            continue
        whole, fraction, sequence, operator, value = match.groups()
        sequence = int(sequence)
        if not 1 <= sequence <= expected_count:
            raise ValueError('ICMP sequence outside selected sample scope')
        records.append({'sequence': sequence, 'arrival_realtime_ns': int(whole) * 10**9
                        + int(fraction.ljust(9, '0')), 'rtt_ms': float(value),
                        'rtt_comparison': operator, 'duplicate_reported': line.rstrip().endswith('(DUP!)')})
    first = {}
    for row in records:
        if not row['duplicate_reported']:
            first.setdefault(row['sequence'], row)
    if len(first) != int(totals[0][1]):
        raise ValueError('parsed ICMP replies disagree with the tool summary')
    exact = {seq: row['rtt_ms'] for seq, row in first.items() if row['rtt_comparison'] == '='}
    differences = [abs(value - exact[seq - 1]) for seq, value in exact.items() if seq - 1 in exact]
    missing = [seq for seq in range(1, expected_count + 1) if seq not in first]
    return {'transmitted': expected_count, 'unique_echo_replies': len(first),
            'unanswered_sequences': missing, 'echo_loss_fraction': len(missing) / expected_count,
            'duplicate_replies': len(records) - len(first),
            'rtt_exact_count': len(exact), 'rtt_upper_bound_count': len(first) - len(exact),
            'rtt_ms': summary(list(exact.values())),
            'consecutive_exact_success_pairs': len(differences),
            'absolute_consecutive_rtt_difference_ms': summary(differences),
            'raw_numeric_echoes': records}


def echo(address, interface):
    result = run_numeric(['ping', '-4', '-n', '-D', '-I', interface, '-c', str(PING_COUNT),
                          '-i', str(PING_INTERVAL), '-W', '1', ipv4(address)], 34)
    if result.returncode not in (0, 1):
        raise RuntimeError('ping did not return a complete selected-interface measurement')
    return parse_ping(result.stdout, PING_COUNT)


class Trace:
    """Durable, numeric progress with the exact current blocking operation."""

    def __init__(self, emit):
        self.emit = emit
        self.phase = 'initialize'
        self.bytes = 0
        self.last_payload_ns = None
        self.last_progress_ns = 0

    def event(self, event, **fields):
        self.emit(dict(event=event, phase=self.phase, monotonic_ns=time.monotonic_ns(),
                       payload_bytes=self.bytes, last_payload_monotonic_ns=self.last_payload_ns,
                       **fields))

    def enter(self, phase, **fields):
        self.phase = phase
        self.event('enter', **fields)

    def tick(self, count):
        self.bytes += count
        self.last_payload_ns = time.monotonic_ns()
        if not self.last_progress_ns or self.last_payload_ns - self.last_progress_ns >= 10**9:
            self.event('progress')
            self.last_progress_ns = self.last_payload_ns


def set_bounded_timeout(connection, deadline):
    remaining = (deadline - time.monotonic_ns()) / 10**9
    if remaining <= 0:
        raise TimeoutError('measurement absolute deadline expired')
    connection.settimeout(min(IO_IDLE_SECONDS, remaining))


def transfer_write(connection, data, deadline, trace, *, payload=False):
    data = memoryview(data)
    while data:
        set_bounded_timeout(connection, deadline)
        written = connection.send(data)
        if not written:
            raise RuntimeError('TCP sender made no progress')
        if payload:
            trace.tick(written)
        data = data[written:]


def transfer_read(connection, target, deadline, trace, *, payload=False):
    target = memoryview(target)
    while target:
        set_bounded_timeout(connection, deadline)
        received = connection.recv_into(target)
        if not received:
            raise EOFError('stream closed before the counted transfer completed')
        if payload:
            trace.tick(received)
        target = target[received:]


def send_bytes(connection, trace):
    payload = memoryview(os.urandom(BLOCK_BYTES))
    begin = time.monotonic_ns()
    deadline = begin + TCP_SECONDS * 10**9
    trace.enter('send_payload', target_deadline_ns=deadline)
    while trace.bytes < TCP_BYTE_CAP and time.monotonic_ns() < deadline:
        count = min(BLOCK_BYTES, TCP_BYTE_CAP - trace.bytes)
        # Finish a record started before the target time. Both idle and total
        # overshoot remain bounded even when the socket only creeps forward.
        record_deadline = deadline + IO_IDLE_SECONDS * 10**9
        trace.phase = 'send_chunk_header'
        transfer_write(connection, struct.pack('!I', count), record_deadline, trace)
        trace.phase = 'send_chunk_payload'
        transfer_write(connection, payload[:count], record_deadline, trace, payload=True)
    count = trace.bytes
    if count == 0:
        raise RuntimeError('TCP sender had no measured bytes')
    completed = trace.last_payload_ns
    trace.enter('send_counted_end')
    final_deadline = time.monotonic_ns() + IO_IDLE_SECONDS * 10**9
    transfer_write(connection, struct.pack('!IQ', 0, count), final_deadline, trace)
    trace.enter('wait_receiver_receipt')
    receipt = bytearray(8)
    transfer_read(connection, receipt, final_deadline, trace)
    (receipt_bytes,) = struct.unpack('!Q', receipt)
    if receipt_bytes != count:
        raise ValueError('receipt byte count differs from sender')
    return {'bytes': count, 'start_monotonic_ns': begin, 'end_monotonic_ns': completed,
            'receipt_monotonic_ns': time.monotonic_ns(), 'receipt_bytes': receipt_bytes,
            'stop_condition': 'byte_cap' if count == TCP_BYTE_CAP else 'duration'}


def receive_bytes(connection, trace):
    buffer = bytearray(BLOCK_BYTES)
    header = bytearray(4)
    begin = time.monotonic_ns()
    deadline = begin + RECEIVE_SECONDS * 10**9
    trace.enter('receive_payload', absolute_deadline_ns=deadline)
    while True:
        trace.phase = 'read_chunk_header_or_end'
        transfer_read(connection, header, deadline, trace)
        (length,) = struct.unpack('!I', header)
        if length == 0:
            break
        if length > BLOCK_BYTES or trace.bytes + length > TCP_BYTE_CAP:
            raise RuntimeError('TCP receiver exceeded the chunk or byte cap')
        trace.phase = 'read_chunk_payload'
        transfer_read(connection, memoryview(buffer)[:length], deadline, trace, payload=True)

    trace.enter('read_counted_end')
    expected = bytearray(8)
    transfer_read(connection, expected, deadline, trace)
    (expected_bytes,) = struct.unpack('!Q', expected)
    end_seen = time.monotonic_ns()
    if expected_bytes != trace.bytes or not trace.bytes or trace.last_payload_ns <= begin:
        raise ValueError('end marker byte count differs from receiver')
    trace.enter('send_receiver_receipt')
    transfer_write(connection, expected, deadline, trace)
    return {'bytes': trace.bytes, 'start_monotonic_ns': begin,
            'last_byte_monotonic_ns': trace.last_payload_ns,
            'end_marker_monotonic_ns': end_seen, 'sender_reported_bytes': expected_bytes,
            'receipt_sent_monotonic_ns': time.monotonic_ns()}


def report(value):
    print(json.dumps(value, separators=(',', ':')), flush=True)


def checked_ssh_addresses(local, peer, device):
    fields = os.environ.get('SSH_CONNECTION', '').split()
    if len(fields) != 4 or fields[0] != local or fields[2] != peer:
        raise RuntimeError('SSH socket addresses differ from the selected LAN endpoints')
    source, link = route(local, device)
    if source != peer:
        raise RuntimeError('Ubuntu return-route source differs from the SSH endpoint')
    return link


def worker_inspect(local, peer, device, with_ping):
    link = checked_ssh_addresses(local, peer, device)
    result = {'route': link, 'iperf3_available': shutil.which('iperf3') is not None}
    if with_ping:
        result['icmp'] = echo(local, device)
    report(result)


def read_controller_capability():
    deadline = time.monotonic() + HANDSHAKE_SECONDS
    descriptor = sys.stdin.fileno()
    message = bytearray()
    while len(message) < 65 and b'\n' not in message:
        remaining = deadline - time.monotonic()
        if remaining <= 0 or not select.select([descriptor], [], [], remaining)[0]:
            raise TimeoutError('peer control capability deadline expired')
        received = os.read(descriptor, 65 - len(message))
        if not received:
            raise EOFError('peer control capability was incomplete')
        message.extend(received)
    if not re.fullmatch(rb'[0-9a-f]{64}\n', message):
        raise RuntimeError('the private controller capability had invalid framing')
    return bytes(message[:-1])


def worker_transfer(local, peer, device, direction):
    trace = Trace(report)
    try:
        trace.enter('verify_peer_route')
        checked_ssh_addresses(local, peer, device)
        trace.enter('read_controller_capability')
        capability = read_controller_capability()
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
            trace.enter('bind_peer_loopback_listener')
            listener.bind(('127.0.0.1', 0))
            listener.listen(1)
            listener.settimeout(12)
            trace.enter('accept_peer_loopback_stream', loopback_port=listener.getsockname()[1])
            connection, (client_ip, _) = listener.accept()
            listener.close()
            with connection:
                deadline = time.monotonic_ns() + HANDSHAKE_SECONDS * 10**9
                trace.enter('verify_forwarded_capability')
                received = bytearray(len(capability))
                transfer_read(connection, received, deadline, trace)
                if client_ip != '127.0.0.1' or received != capability:
                    raise RuntimeError('unexpected loopback probe client')
                trace.enter('confirm_forwarded_capability')
                transfer_write(connection, b'\x01', deadline, trace)
                transfer = (send_bytes(connection, trace) if direction == 'ubuntu_to_mint'
                            else receive_bytes(connection, trace))
        trace.enter('transfer_complete')
        trace.event('complete', transfer=transfer)
    except (OSError, EOFError, ValueError, RuntimeError, subprocess.SubprocessError) as error:
        trace.event('failed', error_category=type(error).__name__)
        raise SystemExit(1)


if __name__ == '__main__':
    # The SSH controller supplies a fixed command, addresses from the same route,
    # and no host credentials or identifier output from the peer.
    action, local, peer, device, *options = sys.argv[1:]
    try:
        local, peer = ipv4(local), ipv4(peer)
        if action == 'inspect' and options in ([], ['ping']):
            worker_inspect(local, peer, device, bool(options))
        elif action == 'transfer' and options in (['ubuntu_to_mint'], ['mint_to_ubuntu']):
            worker_transfer(local, peer, device, options[0])
        else:
            raise RuntimeError('invalid network probe worker operation')
    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as error:
        # The controller collects categories. External command stderr may
        # contain addresses and is deliberately discarded.
        report({'worker_error': type(error).__name__})
        raise SystemExit(1)
