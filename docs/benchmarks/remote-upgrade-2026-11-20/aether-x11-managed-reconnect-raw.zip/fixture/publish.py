"""Retain small key-free evidence from the native Aether recovery run."""

import hashlib
import json
from pathlib import Path
import sys
from zipfile import ZIP_DEFLATED, ZipFile


BASE = 'aether-x11-managed-reconnect'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encode(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def trace_report(members):
    rows = [json.loads(line) for line in members['helper-recovery.jsonl'].splitlines()]
    starts = [i for i, row in enumerate(rows) if row['event'] == 'argv']
    require(len(starts) == 2 and starts[0] == 0, 'missing two actual native app commands')
    host = json.loads(members['host-draws.json'])
    cases = []
    for start, end in zip(starts, [starts[1], len(rows)]):
        lane = rows[start:end]
        require(lane[0] == {'event': 'argv', 'attempts': '3', 'view_only': True, 'x11_embed': True},
                'helper arguments did not match the real Aether choice')
        require(lane[-1] == {'event': 'exit', 'code': 0}, 'helper exit not observed')
        snapshots = lane[1:-1]
        retry = [i for i, row in enumerate(snapshots) if row['state'] == 'waiting_to_retry']
        require(len(retry) == 1 and all(row['event'] == 'snapshot' and not row['has_input'] for row in snapshots),
                'retry state or view-only session boundary evidence did not match')
        waiting = snapshots[retry[0]]
        require(waiting['session_scope'] is None and not waiting['has_metrics'], 'old UI scope survived retry')
        presented = list(dict.fromkeys(row['session_scope'] for row in snapshots if row['state'] == 'viewing'))
        require(all(scope in host and host[scope] for scope in presented), 'viewed source has no matching host ACK')
        require(all(row['source_epoch'] == '1' for row in snapshots if row['state'] == 'viewing'),
                'resumed viewer reported unexpected source epoch')
        cases.append({'viewed_session_scopes': len(presented), 'host_drawn_acks': [host[scope][0] for scope in presented],
                      'retry_state_had_no_catalog_metrics_or_input': True, 'managed_helper_exit': 0})
    require([case['viewed_session_scopes'] for case in cases] == [2, 1], 'viewed replacement and cancellation scope mismatch')
    return cases


def publish(stage, run, output):
    result = json.loads((run/'result.json').read_text())
    require(result['status'] == 'passed' and (stage/'native-controller.exit').read_text() == '0\n',
            'Aether sandbox controller did not complete')
    pinned = {}
    files = ('source.sha256', 'aether-source.sha256')
    for name in files:
        for line in (stage/name).read_text().splitlines():
            digest, relative = line.split(maxsplit=1)
            path = stage/relative
            require(sha(path.read_bytes()) == digest, 'fixture/app source moved after measurement')
            artifact_name = path.relative_to('/home/yj/projects/aether') if name == 'aether-source.sha256' else relative
            pinned[str(artifact_name)] = digest
    host = {}
    for line in (run/'host.log').read_text().splitlines():
        if line.startswith('{'):
            row = json.loads(line)
            if row.get('drawn_acks', 0) > 0:
                host.setdefault(sha(row['session_id'].encode()), []).append(row['drawn_acks'])
    members = {name: (run/name).read_bytes() for name in (
        'helper-recovery.jsonl', 'recovered.png', 'stalled-authentication.png')}
    members['host-draws.json'] = encode(host)
    members['fixture/publish.py'] = Path(__file__).read_bytes()
    for line in (stage/'source.sha256').read_text().splitlines():
        _, name = line.split()
        members['fixture/'+name] = (stage/name).read_bytes()
    evidence = trace_report(members)
    require(evidence[0]['host_drawn_acks'] == result['recovery']['old_and_new_host_drawn_acks'],
            'published host counters do not match actual controller')
    archive = output/f'{BASE}-raw.zip'
    with ZipFile(archive, 'x', ZIP_DEFLATED) as bundle:
        for name, content in sorted(members.items()):
            bundle.writestr(name, content)
    report = result | {
        'scope': 'Native Aether WebKitGTK and XEmbed on owned Xvfb displays with authenticated loopback TCP. '
                 'One real recovery and one application-close cancellation while the next greeting was withheld. '
                 'Timing measures the software event to observed proxy socket closure.',
        'native_controller_exit': 0, 'typed_evidence': evidence, 'source_sha256': pinned,
        'raw_archive_sha256': sha(archive.read_bytes()),
        'members_sha256': {name: sha(content) for name, content in members.items()},
    }
    (output/f'{BASE}.json').write_bytes(encode(report))


def replay(report, archive):
    expected = json.loads(report.read_text())
    require(sha(archive.read_bytes()) == expected['raw_archive_sha256'], 'archive digest mismatch')
    with ZipFile(archive) as bundle:
        require(bundle.testzip() is None and set(bundle.namelist()) == set(expected['members_sha256']),
                'incomplete native recovery archive')
        members = {name: bundle.read(name) for name in bundle.namelist()}
    require(all(sha(data) == expected['members_sha256'][name] for name, data in members.items()), 'member mismatch')
    require(trace_report(members) == expected['typed_evidence'], 'native trace replay diverged')


if __name__ == '__main__':
    mode, *paths = sys.argv[1:]
    if mode == 'publish':
        publish(*map(Path, paths))
    else:
        require(mode == 'replay', 'expected publish or replay')
        replay(*map(Path, paths))
        print('Native Aether recovery event and host ACK replay matched.')
