#!/usr/bin/env python3
"""Native Aether WebKitGTK/XEmbed retained view-only recovery with two owned Xvfb servers."""
import argparse
import asyncio
from collections import deque
from contextlib import ExitStack, contextmanager, suppress
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import tempfile
from threading import Thread
import time


ROOT = Path(__file__).resolve().parent


def require(value, message):
    if not value:
        raise RuntimeError(message)


def sha256(path):
    with path.open('rb') as data:
        return hashlib.file_digest(data, 'sha256').hexdigest()


def wait(check, label, timeout=16):
    end = time.monotonic() + timeout
    while time.monotonic() < end:
        if result := check():
            return result
        time.sleep(.08)
    raise RuntimeError(f'Timed out waiting for {label}')


def stop(child):
    if child.poll() is None:
        child.terminate()
        try:
            child.wait(timeout=4)
        except subprocess.TimeoutExpired:
            child.kill()
            child.wait(timeout=4)


def exercise(args, root, report):
    with ExitStack() as owned:
        env = os.environ.copy()
        for name in list(env):
            if name.startswith('JWM_REMOTE_') or name in ('DISPLAY', 'WAYLAND_DISPLAY', 'WAYLAND_SOCKET', 'XAUTHORITY',
                                                           'AT_SPI_BUS_ADDRESS', 'NO_AT_BRIDGE'):
                env.pop(name, None)
        for field in ('CONFIG', 'CACHE', 'RUNTIME', 'DATA', 'STATE'):
            path = root / field.lower()
            path.mkdir(mode=0o700)
            env['XDG_RUNTIME_DIR' if field == 'RUNTIME' else f'XDG_{field}_HOME'] = str(path)

        trace = root / 'helper-recovery.jsonl'
        env.update(GDK_BACKEND='x11', LIBGL_ALWAYS_SOFTWARE='1', GTK_A11Y='always', ACCESSIBILITY_ENABLED='1',
                   GSETTINGS_BACKEND='memory', GIO_USE_VFS='local', GTK_USE_PORTAL='0',
                   AETHER_RECOVERY_SMOKE_HELPER=str(args.helper),
                   AETHER_RECOVERY_SMOKE_TRACE=str(trace))
        env['PATH'] = str(ROOT / 'bin') + ':' + env['PATH']
        if args.lib:
            env['LD_LIBRARY_PATH'] = args.lib

        def launch(argv, name, stdin=subprocess.DEVNULL, pass_fds=()):
            output = owned.enter_context((root / name).open('wb'))
            proc = subprocess.Popen(argv, env=env, stdin=stdin, stdout=output, stderr=subprocess.STDOUT, pass_fds=pass_fds)
            owned.callback(stop, proc)
            return proc

        def display(name):
            path = root / f'{name}-display'
            number = owned.enter_context(path.open('wb'))
            proc = launch(['Xvfb', '-displayfd', str(number.fileno()), '-screen', '0', '1440x1080x24',
                           '-nolisten', 'tcp', '-ac', '-noreset'], f'{name}-xvfb.log', pass_fds=(number.fileno(),))
            picked = wait(lambda: path.read_text().strip(), f'{name} owned Xvfb display')
            require(picked.isascii() and picked.isdigit() and proc.poll() is None, 'invalid owned Xvfb display')
            return ':' + picked, proc

        source, source_x = display('source')
        target, viewer_x = display('viewer')
        env['DISPLAY'] = target
        os.environ.pop('AT_SPI_BUS_ADDRESS', None)
        os.environ.pop('NO_AT_BRIDGE', None)
        os.environ.update({name: env[name] for name in ('DISPLAY', 'GTK_A11Y', 'GDK_BACKEND')})
        import pyatspi as ax
        desktop = ax.Registry.getDesktop(0)

        def cmd(*argv, check=True):
            return subprocess.run(argv, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                  text=True, check=check, timeout=5).stdout

        def xt(*argv):
            return cmd('xdotool', *map(str, argv))

        key = root / 'config' / 'jwm' / 'remote.key'
        key.parent.mkdir(mode=0o700)
        owned.callback(key.unlink, missing_ok=True)
        cmd(args.helper, 'keygen', '--output', key)
        cmd('xsetroot', '-display', source, '-solid', '#ba2441')
        launch(['metacity', '--sm-disable'], 'metacity.log')
        wait(lambda: '_NET_SUPPORTING_WM_CHECK(WINDOW)' in cmd('xprop', '-root', '_NET_SUPPORTING_WM_CHECK'), 'owned WM')
        aether = launch([args.aether], 'aether.log')

        def visible_window(selector, value):
            found = cmd('xdotool', 'search', '--onlyvisible', selector, str(value), check=False).split()
            return int(found[-1]) if found else None

        app = wait(lambda: visible_window('--pid', aether.pid), 'native Aether window')
        xt('windowactivate', '--sync', app)
        xt('windowsize', app, 960, 820)

        def accessibles():
            pending = deque(item for item in desktop if item)
            result = []
            while pending and len(result) < 1024:
                item = pending.popleft()
                if item:
                    result.append(item)
                    pending.extend(item)
            return result

        def by_name(name, role=None):
            for item in accessibles():
                if ((item.name or '').strip() == name and (role is None or item.getRoleName() == role)
                        and item.getState().contains(ax.STATE_SHOWING)):
                    return item
            return None

        def visible_text(text):
            for item in accessibles():
                if not item.getState().contains(ax.STATE_SHOWING):
                    continue
                if (item.name or '').strip() == text:
                    return True
                try:
                    if (item.queryText().getText(0, -1) or '').strip() == text:
                        return True
                except NotImplementedError:
                    pass
            return False

        def click_accessible(item):
            rect = item.queryComponent().getExtents(ax.DESKTOP_COORDS)
            require(rect.width > 0 and rect.height > 0, 'Aether control outside owned window')
            xt('mousemove', rect.x + rect.width // 2, rect.y + rect.height // 2, 'click', 1)

        def screenshot(name):
            cmd('import', '-window', hex(app), root / f'{name}.png')

        def select_control(name, role, fallback):
            item = by_name(name, role)
            if item is not None:
                click_accessible(item)
            else:
                xt('mousemove', '--window', app, *fallback, 'click', 1)
            return item is not None

        time.sleep(1.3)
        (root / 'accessibility-tree.json').write_text(json.dumps([
            {'name': item.name, 'role': item.getRoleName()} for item in accessibles()], indent=2) + '\n')
        screenshot('native-initial')
        select_control('Remote Desktop', 'push button', (183, 35))
        time.sleep(.55)
        screenshot('remote-settings')

        def trace_rows():
            if not trace.exists():
                return []
            return [json.loads(row) for row in trace.read_text().splitlines(keepends=True) if row.endswith('\n')]

        def assert_xembed(xid):
            tree = cmd('xwininfo', '-id', hex(xid), '-tree')
            parent = int(re.search(r'Parent window id: (0x[0-9a-f]+)', tree)[1], 16)
            require(hex(parent) in cmd('xwininfo', '-id', hex(app), '-tree'), 'viewer not under the owned native pane')
            info = cmd('xprop', '-id', hex(xid), '-f', '_XEMBED_INFO', '32c', '_XEMBED_INFO')
            require('_XEMBED_INFO(_XEMBED_INFO) = 0, 1' in info, 'native XEmbed handshake absent')
            return parent

        def state(rows, name):
            return next((r for r in reversed(rows()) if r['event'] == 'snapshot' and r.get('state') == name), None)

        def connect(label, address):
            begin = len(trace_rows())
            checkbox = wait(lambda: by_name('Reconnect automatically', 'check box'), 'native recovery opt-in')
            require(not checkbox.getState().contains(ax.STATE_CHECKED), 'automatic recovery enabled before the user gesture')
            click_accessible(checkbox)
            wait(lambda: by_name('Reconnect automatically', 'check box').getState().contains(ax.STATE_CHECKED),
                 'native checkbox to become checked')
            screenshot(f'{label}-choice')
            select_control('Host', None, (220, 160))
            xt('key', 'ctrl+a', 'BackSpace')
            xt('type', '--clearmodifiers', address)
            xt('key', 'Return')
            viewer = wait(lambda: visible_window('--class', 'JwmRemote'), 'actual native video window')
            rows = lambda: trace_rows()[begin:]
            first = wait(lambda: state(rows, 'viewing'), 'controller first matching presentation')
            expected = {'event': 'argv', 'attempts': '3', 'view_only': True, 'x11_embed': True}
            require(expected in rows(), 'native pane did not launch the expected view-only retry command')
            require(first['session_scope'] and first['source_epoch'] == '1', 'no fresh presented source')
            return rows, viewer, assert_xembed(viewer), first['session_scope']

        def host_session_drawn(path, exclude=None):
            for line in path.read_text().splitlines(keepends=True):
                if line.startswith('{') and line.endswith('\n'):
                    row = json.loads(line)
                    if row.get('drawn_acks', 0) > 0 and row.get('session_id') != exclude:
                        return row
            return None

        host_log = root/'host.log'
        host = launch([args.helper, 'host', '--listen', '127.0.0.1:0', '--key-file', key, '--display', source,
                       '--capture-source', 'root', '--region', '640x480+0+0',
                       '--share-region', '300x200+25+40', '--stats-json'], host_log.name)
        host_port = wait(lambda: (match[1] if (match := re.search(r'listening on 127\.0\.0\.1:(\d+)',
                                                                 host_log.read_text())) else None), 'owned listener')

        def cut_wait(rows, cut):
            require(cut() == 'server_to_viewer_fin', 'fixture did not issue its expected directional EOF')
            waiting = wait(lambda: state(rows, 'waiting_to_retry'), 'actual waiting state')
            require(waiting['session_scope'] is None and not waiting['has_metrics'] and not waiting['has_input'],
                    'old session actions or metrics remained available during recovery')
            return wait(lambda: visible_text('Waiting to reconnect…'), 'native waiting indicator', 2)

        with proxy_context(int(host_port), hold=False) as (endpoint, cut, accepted, stalled):
            rows, viewer, parent, old_session = connect('recover', endpoint)
            first_ack = wait(lambda: host_session_drawn(host_log), 'original host drawn ACK')
            visible_waiting = cut_wait(rows, cut)
            resumed = wait(lambda: row if (row := state(rows, 'viewing')) and row['session_scope'] != old_session else None,
                           'fresh authenticated source presentation')
            fresh_ack = wait(lambda: host_session_drawn(host_log, exclude=first_ack['session_id']), 'new host drawn ACK')
            require(accepted() == 2 and stalled() == (False, False), 'unexpected proxy session count')
            require(visible_window('--class', 'JwmRemote') == viewer and assert_xembed(viewer) == parent,
                    'original XEmbed window or parent was recreated')
            require(resumed['source_epoch'] == '1' and not resumed['has_input'], 'reconnected session was not a fresh view-only source')
            screenshot('recovered')
            item = wait(lambda: by_name('Disconnect', 'push button'), 'native disconnect action')
            click_accessible(item)
            wait(lambda: {'event': 'exit', 'code': 0} in rows(), 'first managed helper exit 0')
            wait(lambda: not visible_window('--class', 'JwmRemote'), 'first XEmbed child retired')
            wait(lambda: hex(parent) not in cmd('xwininfo', '-id', hex(app), '-tree'), 'first XEmbed parent retired')
            report['recovery'] = {'same_embedded_child_and_parent': True, 'authenticated_sessions': accepted(),
                                  'old_and_new_host_drawn_acks': [first_ack['drawn_acks'], fresh_ack['drawn_acks']],
                                  'waiting_status_visible_in_native_app': visible_waiting,
                                  'waiting_cleared_session_metrics_and_input': True, 'explicit_disconnect_exit': 0}

        with proxy_context(int(host_port), hold=True) as (endpoint, cut, accepted, stalled):
            rows, viewer, parent, _ = connect('cancel', endpoint)
            cut_wait(rows, cut)
            wait(lambda: stalled()[0], 'replacement authentication greeting held')
            require(visible_window('--class', 'JwmRemote') == viewer and assert_xembed(viewer) == parent,
                    'original embedded viewer disappeared while waiting for authentication')
            require(accepted() == 2 and stalled() == (True, False), 'stale child was not waiting for owned authentication')
            screenshot('stalled-authentication')
            close_requested = time.monotonic()
            cmd('wmctrl', '-i', '-c', hex(app))
            wait(lambda: stalled()[1], 'owned authentication socket closed with parent pane')
            cancellation_ms = (time.monotonic() - close_requested) * 1000
            require(aether.wait(timeout=10) == 0, 'native Aether app close failed')
            wait(lambda: {'event': 'exit', 'code': 0} in rows(), 'second managed helper exit 0')
            wait(lambda: not visible_window('--class', 'JwmRemote'), 'closed embedded viewer retired')
            require(accepted() == 2, 'unexpected repeat retry after closing Aether')
            report['parent_close'] = {'reconnect_authentication_socket_closed': True,
                                      'no_further_attempt': True, 'native_app_exit': 0,
                                      'managed_helper_exit': 0, 'software_observed_cancellation_ms': cancellation_ms}
        host.send_signal(signal.SIGTERM)
        require(host.wait(timeout=10) == 0, 'owned listener shutdown failed')
        report['host_exit'] = host.returncode
    report['owned_xvfb_exits'] = [source_x.returncode, viewer_x.returncode]


def import_recovery_proxy():
    path = ROOT / 'test-remote-recovery-window.py'
    spec = importlib.util.spec_from_file_location('owned_recovery_fixture', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.RecoveryProxy


@contextmanager
def proxy_context(host_port, *, hold):
    class GracefulCutProxy(import_recovery_proxy()):
        async def _session(self, client):
            if self.accepted != 1 or not hold:
                return await super()._session(client)
            self.accepted += 1
            self.stalled_retry_started = True
            with suppress(ConnectionResetError):
                while await asyncio.get_running_loop().sock_recv(client, 4096):
                    pass
            self.stalled_retry_closed = True

    with asyncio.Runner() as runner:
        loop = runner.get_loop()
        proxy = GracefulCutProxy(('127.0.0.1', host_port), None)
        address, port = runner.run(proxy.start())
        thread = Thread(target=loop.run_forever, name='owned-aether-recovery-proxy')
        thread.start()

        def call(operation):
            return asyncio.run_coroutine_threadsafe(operation(), loop).result(timeout=5)

        try:
            yield (f'{address}:{port}', lambda: call(proxy.cut_connection), lambda: call(proxy.accepted_connections),
                   lambda: call(proxy.stalled_retry_state))
        finally:
            try:
                call(proxy.close)
            finally:
                loop.call_soon_threadsafe(loop.stop)
                thread.join(timeout=5)
                require(not thread.is_alive(), 'isolated proxy teardown timed out')


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--aether', type=Path, required=True)
    cli.add_argument('--helper', type=Path, required=True)
    cli.add_argument('--aether-sha256', required=True)
    cli.add_argument('--helper-sha256', required=True)
    cli.add_argument('--lib', default='/tmp/jwm-remote-ffmpeg/usr/lib/x86_64-linux-gnu')
    args = cli.parse_args()
    require(os.environ.get('DBUS_SESSION_BUS_ADDRESS'), 'run under an owned dbus-run-session')
    require(sha256(args.aether) == args.aether_sha256 and sha256(args.helper) == args.helper_sha256, 'pinned binaries changed')
    root = Path(tempfile.mkdtemp(prefix='jwm-aether-recovery-live.'))
    print(root, flush=True)
    report = {'status': 'failed', 'aether_sha256': args.aether_sha256, 'jwm_remote_sha256': args.helper_sha256}
    signal.signal(signal.SIGTERM, lambda signum, _frame: signal.default_int_handler(signum, _frame))
    try:
        exercise(args, root, report)
        report['status'] = 'passed'
    except BaseException as error:
        report['failure'] = f'{type(error).__name__}: {error}'
        raise
    finally:
        (root / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report), flush=True)


if __name__ == '__main__':
    main()
