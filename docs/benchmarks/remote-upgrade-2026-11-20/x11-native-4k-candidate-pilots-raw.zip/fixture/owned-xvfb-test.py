"""Set the exact display for the ignored live MIT-SHM regression."""
from pathlib import Path
import os
import subprocess
import sys

from processes import get_display, start_display, stop

log = Path(__file__).with_name("direct-shm-xvfb.log")
with log.open("wb") as output:
    display_process = start_display(800, 600, output)
    try:
        display = get_display(display_process)
        environment = os.environ | {"DISPLAY":display, "JWM_TEST_X11_DISPLAY":display}
        result = subprocess.run(sys.argv[1:], env=environment)
        raise SystemExit(result.returncode)
    finally:
        stop(display_process)
