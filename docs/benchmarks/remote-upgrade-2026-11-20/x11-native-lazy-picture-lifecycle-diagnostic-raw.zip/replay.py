#!/usr/bin/env python3
"""Replay archived actual X11 resize, source, pixel and terminal witnesses."""
import hashlib
import json
from pathlib import Path

CORRECT_COLORS = (((214, 49, 32), (181, 62, 139), (87, 174, 45), (224, 164, 69)),
                  ((34, 159, 92), (47, 118, 201), (67, 153, 174), (75, 191, 211)))


def require(condition, detail):
    if not condition:
        raise RuntimeError(detail)


def inspect(root):
    report = json.loads((root / 'result.json').read_text())
    witness = json.loads((root / 'scope.json').read_text())
    runs = witness['windows']
    expected_path = 'x11-vaapi-dmabuf-dri3'
    require(all(row['path'] == expected_path and row['download'] == 0 and row['native'] == row['drawn'] == row['acked']
                and row['frame']['codec'] == 'H.264' for row in runs), 'failed actual X11 native presentation gate')
    require(len({row['session'] for row in runs}) == 1, 'native frames came from multiple sessions')
    require([runs[0]['frame']['source_epoch'], runs[-1]['frame']['source_epoch']] == [1, 2], 'source switch is missing')
    require(runs[0]['frame']['encoded_dimensions'] == [3840, 2160] and runs[-1]['frame']['encoded_dimensions'] == [1920, 1080], 'wrong source geometry')
    require(runs[0]['import'] == report['initial_native_import_count'] > 0 and
            runs[0]['picture'] == report['initial_picture_setup_count'] == 0,
            'exact-size candidate did not defer creating its Picture')
    require(sum(row['picture'] for row in runs) == report['picture_setup_count'] > 0,
            'scaled source did not create its XRender Picture')
    require(sum(row['native'] for row in runs) == report['native_presented'] == report['drawn_acks'] > 0,
            'native frame count differs')
    require(sum(row['drawn_acks'] for row in witness['host_windows']) == report['drawn_acks']
            and {row['session'] for row in witness['host_windows']} == {runs[0]['session']},
            'actual host ACKs do not match native frames')
    require(witness['controller_commands'] == [{'accepted': True, 'request': 1}, {'accepted': True, 'request': 2}]
            and witness['last_viewer_state'] == 'closed', 'real commands or closed event absent')
    sizes = {'initial':[3840,2160], 'resize_retained':[1297,973], 'restored_retained':[3840,2160],
             'second_source_scaled':[3840,2160]}
    for name, size in sizes.items():
        sample = report['samples'][name]
        colors = CORRECT_COLORS[name == 'second_source_scaled']
        require(sample['size'] == size and len(sample['rgb']) == 4, 'wrong sample geometry')
        require(all(max(abs(found-expected) for found,expected in zip(actual,color)) <= 17
                    for actual,color in zip(sample['rgb'],colors)), 'wrong actual drawable colors')
    resized = report['samples']['resize_retained']
    require(resized['content'] == [0,122,1297,729] and resized['bar_rgb'] == [[0,0,0]] * 6
            and report['host_suspended_during_resize'], 'visible retained resize or black bars missing')
    require(report['viewer_exit'] == report['host_exit'] == report['display_launcher_exit'] == 0,
            'actual managed endpoints or the display did not close')
    terminal = (root / 'terminal.txt').read_text()
    expected_terminal = 0 if report['controller_failure'] is None else 1
    require(report['controller_exit'] == expected_terminal and
            ('XIO:' in terminal) == (expected_terminal != 0), 'controller failure mismatched')
    require(witness['owned_output_final']['dmabuf_draws'] > 0 and
            witness['dri3'] == {'path':'/dev/dri/renderD128','major':226,'minor':128},
            'owned native root or DRI3 device witness missing')
    return report


def main():
    root = Path(__file__).resolve().parent
    identities = json.loads((root / 'members.sha256.json').read_text())
    for member, signature in identities.items():
        require(hashlib.sha256((root / member).read_bytes()).hexdigest() == signature,
                'wrong member signature ' + member)
    print(json.dumps(inspect(root), indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
