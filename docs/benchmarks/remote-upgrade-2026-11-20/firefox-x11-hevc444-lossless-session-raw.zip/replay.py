#!/usr/bin/env python3
"""Verify sanitized HEVC trace, geometry, and browser raster in this directory."""
import hashlib
import json
import re
from pathlib import Path

from align import align, read_raster, read_trace, source_reference
from hevc_evidence import CODEC, SIZE, assess, matching_frame_scope, read_jsonl, static_stillness
from score import MEASURE_SECONDS, REQUESTED_FPS, SECOND, TAIL_SECONDS, WARM_SECONDS, score_pixels

def select_telemetry(run_dir, phase, role, dimensions=(960, 640)):
    start = phase['score_start_monotonic_ns']
    last = phase['telemetry_phase_end_monotonic_ns']
    retained = []
    for line in (run_dir / f'{role}-clocked-telemetry.jsonl').read_text().splitlines():
        row = json.loads(line)
        window = row['record']
        end = row['end_monotonic_ns']
        duration = round(window['window_seconds'] * SECOND)
        if duration > 0 and start <= end - duration and end <= last:
            retained.append(row)
    selected = read_jsonl(run_dir / f"{phase['phase']}-{role}.jsonl")
    if selected != [row['record'] for row in retained]:
        raise ValueError('selected phase telemetry did not replay from its endpoint clock')
    scope_field = 'last_sent_frame' if role == 'host' else 'last_frame'
    scopes = [row['record'][scope_field] for row in retained if row['record'].get(scope_field)]
    routes = sorted({route for row in retained for route in (
        row['record'].get('mode' if role == 'host' else 'last_presentation_path'),) if route})
    return {'whole_windows': len(retained),
            'window_seconds': sum(row['record']['window_seconds'] for row in retained),
            'session_ids': sorted({row['record']['session_id'] for row in retained if row['record'].get('session_id')}),
            'routes': routes, 'frame_scopes_observed': len(scopes),
            'viewer_backends': sorted({row['record']['viewer_backend'] for row in retained
                                       if row['record'].get('viewer_backend')}),
            'frame_scopes_match_requested_jpeg': all(
                scope.get('codec') == 'JPEG' and scope.get('source_dimensions') == list(dimensions)
                and scope.get('encoded_dimensions') == list(dimensions) for scope in scopes),
            'first_window_end_monotonic_ns': retained[0]['end_monotonic_ns'] if retained else None,
            'last_window_end_monotonic_ns': retained[-1]['end_monotonic_ns'] if retained else None}


def summarize(run, transport):
    scopes = {}
    for name in ('static', 'motion'):
        host = json.loads((run / f'{name}-scope.json').read_text())
        viewer = json.loads((run / 'viewer' / f'{name}-scope.json').read_text())
        scopes[name] = {'host': host, 'viewer': viewer}
    entries = [(name, endpoint_name, phase['telemetry']) for name, pair in scopes.items()
               for endpoint_name, phase in pair.items()]
    sessions = {session for _, _, stats in entries for session in stats['session_ids']}
    complete = len(sessions) == 1 and all(
        len(stats['session_ids']) == 1 and stats['window_seconds'] >= MEASURE_SECONDS
        and stats['frame_scopes_match_requested_codec']
        and (name == 'static' or stats['frame_scopes_observed'] > 0)
        for name, _, stats in entries)
    for phase in scopes.values():
        capture = phase['host']['telemetry']
        presentation = phase['viewer']['telemetry']
        complete = (complete and capture['routes'] == ['root/xrender/shm/no-damage/cursor-events']
                    and presentation['viewer_backends'] == ['x11'] and presentation['routes'] == ['rgb'])
    host = scopes['motion']['host']['samples']['source']
    viewer = scopes['motion']['viewer']['samples']['viewer']
    scope_complete = complete
    hardware = assess(run, sorted(sessions))
    complete = scope_complete and hardware['verified']
    capable = host['unique_content_fps'] >= REQUESTED_FPS and host['scroll_changes_seen'] >= MEASURE_SECONDS
    result = {'scope': ('diagnostic X11 raster observations on separate machines over OpenSSH'
                        if transport == 'dual' else 'diagnostic X11 raster observations on one machine over loopback'),
              'source_and_requested_viewer_dimensions': SIZE, 'codec': CODEC, 'diagnostic_only': True,
              'hardware_path': hardware, 'static_unchanged': static_stillness(scopes),
              'original_capture_and_presentation_scope_complete': scope_complete,
              'authenticated_session_ids': sorted(sessions), 'telemetry_complete': complete,
              'source_motion_fps': host['unique_content_fps'], 'viewer_motion_fps': viewer['unique_content_fps'],
              'source_qualified': capable,
              'viewer_motion_gate_met': (viewer['unique_content_fps'] >= 0.9 * REQUESTED_FPS
                                         and viewer['scroll_changes_seen'] >= MEASURE_SECONDS)
                                        if capable and complete else None, 'phases': scopes}
    result['diagnostic_motion_and_static_met'] = (result['viewer_motion_gate_met'] is True
                                                   and result['static_unchanged'])
    if not complete:
        raise RuntimeError(f'HEVC diagnostic qualification failed (scope complete={scope_complete}): '
                           f'{hardware["errors"]}')
    return {key: value for key, value in result.items() if key != 'phases'}


def replay_trace(run, sessions):
    host, viewer = run, run / 'viewer'
    host_id, sent = read_trace(host / 'host.log', 'host')
    viewer_id, presented = read_trace(viewer / 'viewer.log', 'viewer')
    if sessions != [host_id] or host_id != viewer_id or {row['codec'] for row in sent} != {CODEC}:
        raise ValueError('trace did not match the qualified authenticated HEVC session')
    sr, sk, s0, s1, source_scope = read_raster(host / 'static-pixels.jsonl', host / 'static-scope.json', 'source')
    vr, vk, v0, v1, viewer_scope = read_raster(viewer / 'static-pixels.jsonl', viewer / 'static-scope.json', 'viewer')
    if sk != vk or s1 - s0 != v1 - v0 or s1 - s0 != MEASURE_SECONDS * 1_000_000_000:
        raise ValueError('trace raster intervals or format changed')
    for path, scope in ((host, source_scope), (viewer, viewer_scope)):
        if scope['telemetry']['session_ids'] != sessions:
            raise ValueError('static phase telemetry differs from the trace session')
        guards = json.loads((path / 'geometry-guard.json').read_text())
        for phase in ('static', 'motion'):
            pre, post = guards[f'before_{phase}'], guards[f'after_{phase}']
            phase_scope = json.loads((path / f'{phase}-scope.json').read_text())
            if not (pre['monotonic_ns'] <= phase_scope['phase_start_monotonic_ns']
                    < phase_scope['observer_end_monotonic_ns'] <= post['monotonic_ns']
                    and pre['drawable_xid'] == post['drawable_xid']
                    and pre['geometry'] == post['geometry']
                    and pre['structure_notify_events'] == post['structure_notify_events'] == 0):
                raise ValueError(f'incomplete fixed-geometry guard in {phase}')
    return align(sent, presented, vr, v0, v1, source_reference(sr, sk, s0, s1))


def read(path):
    return json.loads(path.read_text())


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def verify_phase(raw, role, side, phase, session):
    scope = read(raw / f'{phase}-scope.json')
    warm, first, last, tail = (scope[f'{label}_monotonic_ns'] for label in (
        'phase_start', 'score_start', 'score_end', 'telemetry_phase_end'))
    require(scope['phase'] == phase and (first-warm, last-first, tail-last) == (
        WARM_SECONDS*SECOND, MEASURE_SECONDS*SECOND, TAIL_SECONDS*SECOND), 'wrong phase timing')
    roi = read_jsonl(raw / f'{phase}-pixels.jsonl')
    require(all(row['side'] == side and row['start_monotonic_ns'] <= row['end_monotonic_ns'] for row in roi)
            and all(a['end_monotonic_ns'] < b['start_monotonic_ns'] for a, b in zip(roi, roi[1:])),
            'raster clock or side mismatch')
    require(score_pixels(roi, first, last) == scope['samples'][side], 'raster score changed')
    computed = select_telemetry(raw, scope, role, SIZE)
    computed.pop('frame_scopes_match_requested_jpeg')
    frame_key = 'last_sent_frame' if role == 'host' else 'last_frame'
    selected = read_jsonl(raw / f'{phase}-{role}.jsonl')
    computed['frame_scopes_match_requested_codec'] = all(
        matching_frame_scope(row[frame_key]) for row in selected if row.get(frame_key))
    require(computed == scope['telemetry'] and computed['session_ids'] == session,
            'phase telemetry qualification changed')


OPEN = re.compile(r'^jwm-remote: private NVENC HEVC444 constqp=0 lossless opened at ([0-9]+)x([0-9]+)$')


def runtime_lossless(raw):
    log = (raw / 'host.log').read_text().splitlines()
    opens = [tuple(map(int, match.groups())) for line in log if (match := OPEN.fullmatch(line))]
    return {'encoder_open_dimensions': [list(size) for size in opens],
            'runtime_open_at_visible_size': opens.count(SIZE),
            'probe_open_256x256': opens.count((256, 256)),
            'runtime_marker': next((line for line in log if OPEN.fullmatch(line)
                                    and line.endswith(f'{SIZE[0]}x{SIZE[1]}')), None)}


def throughput(raw):
    report = {}
    for phase in ('static', 'motion'):
        values = read_jsonl(raw / f'{phase}-host.jsonl')
        duration = sum(row['window_seconds'] for row in values)
        require(duration >= MEASURE_SECONDS and all(type(row['bytes']) is int and row['bytes'] >= 0 for row in values),
                'invalid host video payload throughput scope')
        size = sum(row['bytes'] for row in values)
        report[phase] = {'selected_host_windows': len(values), 'window_seconds': duration,
                         'video_payload_bytes': size, 'mean_video_payload_mbps': size * 8 / duration / 1_000_000}
    return report


def verify_identity(root, raw, manifest):
    identity = read(raw / 'identity.json')
    require(identity['two_distinct_machines_verified_before_redaction'] is True and identity['transport'] == 'dual',
            'two-machine endpoint identity was not verified')
    for role in ('host', 'viewer'):
        endpoint = identity[role]
        require(endpoint['release_sha256'] == endpoint['endpoint_executable_sha256'] == manifest['pins'][role]
                and endpoint['trace_env_verified'] and endpoint['drawable_size'] == list(SIZE)
                and endpoint['clock'] == 'CLOCK_MONOTONIC', 'endpoint digest, size, clock or opt-in changed')
    require(identity['host']['firefox_actual_sha256'] == manifest['pins']['firefox'], 'Firefox pin changed')
    build = read(root / 'build-proof.json')
    require(build['candidate_binary_sha256'] == manifest['pins']['host']
            and build['viewer_binary_sha256'] == manifest['pins']['viewer'], 'build pins changed')
    require(read(raw / 'shutdown.json') == {'host_exit': 0, 'peer_exit': 0, 'viewer_disconnect_event': True},
            'session did not end cleanly')


def verify_partial(raw):
    checked = []
    for role, side, lane in (('host', 'source', raw), ('viewer', 'viewer', raw / 'viewer')):
        for phase in ('static', 'motion'):
            scope_path = lane / f'{phase}-scope.json'
            pixels_path = lane / f'{phase}-pixels.jsonl'
            if not (scope_path.is_file() and pixels_path.is_file()):
                continue
            scope = read(scope_path)
            if side not in scope.get('samples', {}) or 'observer_end_monotonic_ns' not in scope:
                continue
            start, end = (scope[f'score_{edge}_monotonic_ns'] for edge in ('start', 'end'))
            require(end - start == MEASURE_SECONDS * SECOND, 'partial phase score duration changed')
            require(score_pixels(read_jsonl(pixels_path), start, end) == scope['samples'][side],
                    'retained partial phase raster did not replay')
            checked.append([phase, role])
    return checked


def verify_full(root, session):
    raw = root / 'raw'
    for phase in ('static', 'motion'):
        verify_phase(raw, 'host', 'source', phase, session)
        verify_phase(raw / 'viewer', 'viewer', 'viewer', phase, session)
    score = json.loads(json.dumps(summarize(raw, 'dual')))
    trace = replay_trace(raw, score['authenticated_session_ids'])
    opening = runtime_lossless(raw)
    require(opening['runtime_open_at_visible_size'] > 0 and opening['runtime_marker'],
            'candidate did not report a 1920x1080 lossless encoder open')
    fraction = trace['source_reference']['source_exact_samples'] / trace['source_reference']['valid_samples']
    return {'score': score, 'trace_alignment': trace, 'runtime_lossless': opening,
            'source_exact_fraction_of_valid_samples': fraction, 'throughput': throughput(raw)}


def verify_bundle(root):
    expected = read(root / 'expected.json')
    raw = root / 'raw'
    for name, digest in expected['offline_fixture_digests'].items():
        require(hashlib.sha256((root / name).read_bytes()).hexdigest() == digest,
                f'offline fixture digest changed for {name}')
    if expected['qualification'] == 'qualified-diagnostic':
        manifest = read(root / 'manifest.json')
        require(expected['controller_exit'] == 0 and expected['trial_exit'] == 0, 'trial controller status changed')
        verify_identity(root, raw, manifest)
        current = verify_full(root, expected['result']['score']['authenticated_session_ids'])
        require(current == expected['result'], 'recorded lossless raster or trace result did not replay')
        return {'status': 'verified', 'qualification': expected['qualification'],
                'runtime_open': current['runtime_lossless']['runtime_marker'],
                'viewer_motion_fps': current['score']['viewer_motion_fps'],
                'static_unchanged': current['score']['static_unchanged'],
                'source_exact_fraction_of_valid_samples': current['source_exact_fraction_of_valid_samples'],
                'throughput': current['throughput']}
    checked = verify_partial(raw)
    require(checked == expected['replayable_complete_lanes'], 'retained partial evidence changed')
    if (raw / 'host.log').is_file():
        require(runtime_lossless(raw) == expected['runtime_lossless'], 'retained encoder provenance changed')
    return {'status': 'verified', 'qualification': 'unqualified', 'terminal_classification': expected['terminal_classification'],
            'verified_complete_raster_lanes': checked, 'controller_exit': expected['controller_exit']}


if __name__ == '__main__':
    print(json.dumps(verify_bundle(Path(__file__).resolve().parent), sort_keys=True))
