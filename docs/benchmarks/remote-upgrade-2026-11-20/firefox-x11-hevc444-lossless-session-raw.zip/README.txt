Extract here and run: python3 -B replay.py
This is one serial private HEVC constant-QP0 Firefox diagnostic. Scope and qualification are in expected.json.
Only typed endpoints, marker hashes and local phase clocks are retained. Session and window IDs are aliases.
No credentials, full pixels, browser data, machine identifiers, network addresses or private paths are included.
The phase counters cover selected whole host telemetry windows and application video payloads.
