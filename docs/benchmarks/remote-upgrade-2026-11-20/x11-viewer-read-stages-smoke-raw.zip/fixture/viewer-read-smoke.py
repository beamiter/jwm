from contextlib import ExitStack
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile
import time

from processes import clean_env, get_display, start_display, stop, wait_for


LAB = Path(__file__).resolve().parent
BINARY = Path("/tmp/jwm-remote-plan-check/debug/jwm-remote")
READ_STAGES = ("frame_header_wait_ms", "frame_body_receive_ms", "frame_authentication_ms")


def telemetry(path, kind):
    rows = [json.loads(line) for line in path.read_text().splitlines() if line.startswith("{")]
    return [row for row in rows if row.get("type") == kind]


def trial(run, mode):
    run.mkdir(mode=0o700)
    with ExitStack() as cleanup:
        def logfile(name):
            return cleanup.enter_context((run / name).open("wb"))

        runtime = cleanup.enter_context(tempfile.TemporaryDirectory(prefix="jwm-read-telemetry-runtime."))
        env = clean_env() | {"XDG_RUNTIME_DIR": runtime, "XDG_CACHE_HOME": runtime}
        if mode == "read-ahead":
            env["JWM_REMOTE_READ_AHEAD"] = "1"
        displays = []
        for role in ("host", "viewer"):
            xvfb = start_display(640, 480, logfile(f"{role}-xvfb.log"))
            cleanup.callback(stop, xvfb)
            displays.append(get_display(xvfb))

        key = Path(runtime) / "key"
        subprocess.run([BINARY, "keygen", "--output", key], env=env, timeout=5,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
        host = subprocess.Popen([BINARY, "host", "--listen", "127.0.0.1:0", "--once",
                                 "--display", displays[0], "--capture-source", "root", "--scaling", "cpu",
                                 "--fps", "30", "--key-file", key, "--stats-json"],
                                env=env, stdout=subprocess.DEVNULL, stderr=logfile("host.log"),
                                stdin=subprocess.DEVNULL)
        cleanup.callback(stop, host)
        host_log = run / "host.log"
        bound = wait_for(host, lambda: re.search(r"listening on (127\.0\.0\.1:\d+)", host_log.read_text()), 12)
        command = [BINARY, "connect", bound[1], "--toggle", "--jpeg", "--view-only", "--stats-json",
                   "--display", displays[1], "--key-file", key, "--scaling", "cpu",
                   "--window-size", "640x480", "--window-position", "0,0"]
        viewer_log = run / "viewer.log"
        viewer = subprocess.Popen(command, env=env, stdout=subprocess.DEVNULL,
                                  stderr=logfile("viewer.log"), stdin=subprocess.DEVNULL)
        cleanup.callback(stop, viewer)
        wait_for(viewer, lambda: "connected;" in viewer_log.read_text(), 12)
        for color in ("red", "green", "blue", "gold", "magenta", "white", "black"):
            subprocess.run(["xsetroot", "-display", displays[0], "-solid", color],
                           env=env, check=True, timeout=3)
            time.sleep(.25)
        time.sleep(.25)
        subprocess.run(command, env=env, check=True, timeout=8,
                       stdout=subprocess.DEVNULL, stderr=logfile("disconnect.log"))
        assert viewer.wait(timeout=10) == 0 and host.wait(timeout=10) == 0

    host_rows = telemetry(host_log, "jwm_remote_host_stats")
    viewer_rows = telemetry(viewer_log, "jwm_remote_viewer_stats")
    matching = {row["session_id"] for row in host_rows + viewer_rows}
    assert len(matching) == 1 and host_rows and viewer_rows and viewer_rows[-1]["final"]
    assert all(row["negotiated_codec"] == "JPEG" for row in viewer_rows)
    for row in viewer_rows:
        samples = {row["stages"][stage]["observations"] for stage in READ_STAGES}
        assert len(samples) == 1
    counts = {stage: sum(row["stages"][stage]["observations"] for row in viewer_rows) for stage in READ_STAGES}
    assert len(set(counts.values())) == 1 and min(counts.values()) >= 3
    queue = sum(row["stages"]["decode_queue_ms"]["observations"] for row in viewer_rows)
    assert (queue > 0) == (mode == "read-ahead")
    drawn = sum(row["drawn"] for row in viewer_rows)
    assert drawn >= 4 and sum(row["acked"] for row in viewer_rows) >= 4
    return {"mode": mode, "session_id": matching.pop(), "codec": "JPEG", "drawn": drawn,
            "read_observations": counts, "decode_queue_observations": queue, "clean_exit": True}


def main():
    with open("/tmp/jwm-p08-p09-release/benchmark.lock", "a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        output = Path(tempfile.mkdtemp(prefix="viewer-read-smoke.", dir=LAB))
        print(f"Evidence directory {output}", flush=True)
        result = {"binary_sha256": hashlib.sha256(BINARY.read_bytes()).hexdigest(),
                  "tests": [trial(output / mode, mode) for mode in ("synchronous", "read-ahead")]}
        (output / "result.json").write_text(json.dumps(result, indent=2) + "\n")
        print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
