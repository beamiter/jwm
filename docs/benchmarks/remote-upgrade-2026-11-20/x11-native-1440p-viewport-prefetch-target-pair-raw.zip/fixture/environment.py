"""Read endpoint metadata outside scored intervals without transmitting probes."""

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import platform
import subprocess


def value(path):
    try:
        return Path(path).read_text().strip()
    except OSError:
        return None


def output(*argv):
    try:
        p = subprocess.run(argv, text=True, capture_output=True, timeout=3,
                           env=os.environ | {'LC_ALL': 'C'})
        return p.stdout.strip() if p.stdout.strip() else None
    except (OSError, subprocess.TimeoutExpired):
        return None


def observe(peer, role, phase):
    route_text = output('ip', '-4', '-j', 'route', 'get', peer)
    rows = json.loads(route_text) if route_text else []
    route = [{k: row[k] for k in ('dst', 'dev', 'prefsrc', 'gateway') if k in row} for row in rows]
    interface = route[0].get('dev') if route else None
    link = Path('/sys/class/net') / interface if interface else None
    rf = value('/proc/net/wireless') or ''
    cpufreq = Path('/sys/devices/system/cpu/cpufreq')
    policies = sorted(cpufreq.glob('policy*'))
    power_supply = Path('/sys/class/power_supply')
    graphics = []
    for device in sorted(Path('/sys/class/drm').glob('renderD*')):
        pci = device / 'device'
        graphics.append({'render_node': f'/dev/dri/{device.name}', 'pci': pci.resolve().name,
                         'driver': (pci / 'driver').resolve().name if (pci / 'driver').is_symlink() else None,
                         'vendor': value(pci / 'vendor'), 'device': value(pci / 'device')})
    nv = value('/proc/driver/nvidia/version')
    nv_models = []
    for info in Path('/proc/driver/nvidia/gpus').glob('*/information'):
        fields = [line.split(':', 1) for line in (value(info) or '').splitlines()
                  if line.startswith(('Model:', 'Bus Location:'))]
        nv_models.append({key: val.strip() for key, val in fields})
    packages = output('dpkg-query', '-W', '-f=${binary:Package}\t${Version}\n',
                      'xwayland', 'xvfb', 'libegl-mesa0', 'libgbm1', 'libgl1-mesa-dri',
                      'libdrm2', 'libva2', 'intel-media-va-driver', 'libavcodec58', 'libavcodec60',
                      'libavcodec61', 'libavcodec62', 'ffmpeg')
    package_versions = {name: version for name, version in
                        (line.split('\t', 1) for line in (packages or '').splitlines()) if version}
    try:
        os_name = platform.freedesktop_os_release().get('PRETTY_NAME')
    except OSError:
        os_name = None
    return {
        'captured_utc': datetime.now(timezone.utc).isoformat(), 'role': role, 'phase': phase,
        'os': os_name, 'kernel': platform.release(), 'architecture': platform.machine(),
        'cpu_model': next((line.split(':', 1)[1].strip()
                           for line in (value('/proc/cpuinfo') or '').splitlines()
                           if line.startswith('model name')), None),
        'gpu_devices': graphics, 'nvidia_kernel_module': nv.splitlines()[0] if nv else None,
        'nvidia_gpu_inventory': nv_models,
        'graphics_and_codec_packages': package_versions,
        'power_profile': output('powerprofilesctl', 'get'),
        'cpu_policy': {field: sorted({setting for policy in policies if (setting := value(policy / field))})
                       for field in ('scaling_driver', 'scaling_governor', 'energy_performance_preference')},
        'power_supplies': [{'type': value(supply / 'type'), 'online': value(supply / 'online')}
                          for supply in sorted(power_supply.iterdir())] if power_supply.is_dir() else [],
        'route_to_peer': route,
        'link': {'interface': interface, 'operstate': value(link / 'operstate'),
                 'kernel_link_speed_mbps': value(link / 'speed'), 'duplex': value(link / 'duplex'),
                 'wireless_interface': (link / 'wireless').is_dir() or (link / 'phy80211').exists(),
                 'proc_wireless_sample': next((line.strip() for line in rf.splitlines()
                                               if line.lstrip().startswith(interface + ':')), None)} if link else None,
        'unobserved': ['physical monitor refresh or scanout', 'optical response', 'measured throughput',
                       'link RTT/jitter/retransmits', 'measured power draw', 'intermediate link devices',
                       'ongoing radio variations during scored intervals'],
    }


if __name__ == '__main__':
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('role', choices=('mint', 'ubuntu'))
    cli.add_argument('phase', choices=('before_pair', 'after_pair'))
    args = cli.parse_args()
    peer = '192.168.0.78' if args.role == 'mint' else os.environ['SSH_CONNECTION'].split()[0]
    print(json.dumps(observe(peer, args.role, args.phase), sort_keys=True, indent=2, allow_nan=False))
