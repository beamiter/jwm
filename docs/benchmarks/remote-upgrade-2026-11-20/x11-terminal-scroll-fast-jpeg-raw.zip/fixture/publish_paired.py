#!/usr/bin/env python3
"""Publish and replay private XTerm JPEG pilot or paired results without X11 or SSH."""

import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import re
import shutil
import tempfile
from zipfile import ZIP_DEFLATED, ZipFile

from dual_terminal import SIZE, TIMINGS, summarize
from paired import FILES, ORDER, PIN, TAG_BASE, valid
from run_baseline import select_telemetry
from score import SECOND, score_pixels
from terminal_scroll import FONT, COLUMNS, ROWS, sample

LAB = Path(__file__).resolve().parent
NAME = 'x11-terminal-scroll-fast-jpeg'
ROI = (0, 20, 1200, 200)
PHASES = ('static', 'motion')
ROLES = {'host': 'source', 'viewer': 'viewer'}
RUN_ID = re.compile(r'[0-9a-f]{32}')
PEER_EVENTS = ['viewer_ready', 'viewer_static_started', 'viewer_static_done',
               'viewer_motion_armed', 'viewer_motion_done', 'viewer_disconnected']
VIEWER_EVENTS = ['static', 'motion', 'disconnect']
MEDIA = {'host': ('source-static.ppm', 'source-static-end.ppm', 'source-motion-end.ppm',
                  'terminal-progress.jsonl'),
         'viewer': ('viewer-static.ppm', 'viewer-motion-end.ppm')}


def need(ok, reason):
    if not ok:
        raise ValueError(reason)


def load(path):
    return json.loads(path.read_bytes())


def jsonl(path):
    return [json.loads(line) for line in path.read_bytes().splitlines()]


def save(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def hash_value(value):
    return hashlib.sha256(value.encode()).hexdigest()


class Photo:
    def __init__(self, data):
        header = f'P6\n{SIZE[0]} {SIZE[1]}\n255\n'.encode()
        need(data.startswith(header) and len(data) == len(header) + SIZE[0] * SIZE[1] * 3,
             'capture does not contain the exact 1080p RGB888 raster')
        self.rgb = data[len(header):]

    def region(self, x, y, width, height):
        need(0 <= x <= x + width <= SIZE[0] and 0 <= y <= y + height <= SIZE[1],
             'raster rectangle outside drawable')
        stride = SIZE[0] * 3
        return (self.rgb[row * stride + x * 3:row * stride + (x + width) * 3]
                for row in range(y, y + height))

    def crop(self, _xid, x, y, width, height):
        rows = []
        for rgb in self.region(x, y, width, height):
            bgra = bytearray(width * 4)
            bgra[0::4], bgra[1::4], bgra[2::4] = rgb[2::3], rgb[1::3], rgb[0::3]
            rows.append(bgra)
        return rows


def compare_static(source, viewer):
    original = b''.join(source.region(*ROI))
    rendered = b''.join(viewer.region(*ROI))
    source_green, viewer_green = original[1::3], rendered[1::3]
    foreground_source = sum(v >= 128 for v in source_green)
    foreground_viewer = sum(v >= 128 for v in viewer_green)
    common = sum(a >= 128 and b >= 128 for a, b in zip(source_green, viewer_green, strict=True))
    pixel_count = ROI[2] * ROI[3]
    channel = {}
    for i, name in enumerate(('red', 'green', 'blue')):
        differences = [abs(a - b) for a, b in zip(original[i::3], rendered[i::3], strict=True)]
        channel[name] = {'mean_absolute_difference': sum(differences) / pixel_count,
                         'root_mean_squared_difference': math.sqrt(sum(d*d for d in differences) / pixel_count),
                         'max_absolute_difference': max(differences),
                         'exact_equal_samples': differences.count(0)}
    return {'rectangle': list(ROI), 'examined_pixels': pixel_count, 'green_channel_threshold': 128,
            'source_foreground_pixels': foreground_source, 'viewer_foreground_pixels': foreground_viewer,
            'matching_foreground_pixels': common,
            'foreground_recall': common / foreground_source if foreground_source else None,
            'foreground_precision': common / foreground_viewer if foreground_viewer else None,
            'mean_absolute_green_difference': channel['green']['mean_absolute_difference'],
            'rgb_channel_errors': channel,
            'exact_equal_rgb_pixels': sum(original[i:i+3] == rendered[i:i+3] for i in range(0, len(original), 3))}


def measured_phase(directory, role, phase, timing, scratch):
    recorded = load(directory / f'{phase}-scope.json')
    warm, score, tail = timing
    phase_start, start, end, telemetry_end, observer_end = (
        recorded[f'{field}_monotonic_ns'] for field in
        ('phase_start', 'score_start', 'score_end', 'telemetry_phase_end', 'observer_end')
    )
    need(recorded['phase'] == phase and
         (start - phase_start, end - start, telemetry_end - end) == (warm * SECOND, score * SECOND, tail * SECOND)
         and observer_end >= telemetry_end, 'endpoint phase timing differs')
    seen = jsonl(directory / f'{phase}-pixels.jsonl')
    previous = phase_start
    for row in seen:
        need(set(row) == {'side', 'start_monotonic_ns', 'end_monotonic_ns', 'marker', 'scroll_signature'}
             and row['side'] == ROLES[role]
             and previous <= row['start_monotonic_ns'] <= row['end_monotonic_ns'] <= observer_end,
             'bad pixel clock or sample record')
        marker, glyph = row['marker'], row['scroll_signature']
        need(marker is None or type(marker) is int and 0 <= marker <= 65535, 'bad marker value')
        need(glyph is None or re.fullmatch(r'[0-9a-f]{16}', glyph), 'bad glyph signature')
        previous = row['end_monotonic_ns']
    need(seen and seen[0]['end_monotonic_ns'] < start and seen[-1]['end_monotonic_ns'] >= end,
         'observer did not cover the score interval')
    raster = score_pixels(seen, start, end)
    need(recorded['samples'] == {ROLES[role]: raster}, 'raster scores differ from original monotonic samples')
    local_trace = f'{role}-clocked-telemetry.jsonl'
    (scratch / local_trace).write_bytes((directory / local_trace).read_bytes())
    selected = select_telemetry(scratch, recorded, role, SIZE)
    got = recorded['telemetry']
    need((selected | {'window_seconds': got['window_seconds']}) == got
         and math.isclose(selected['window_seconds'], got['window_seconds'], rel_tol=0, abs_tol=1e-10),
         'telemetry selection does not replay')
    name = f'{phase}-{role}.jsonl'
    need((scratch / name).read_bytes() == (directory / name).read_bytes(), 'typed telemetry membership changed')
    frame_field = 'last_sent_frame' if role == 'host' else 'last_frame'
    stages = ('codec_ms', 'jpeg_ms', 'capture_ms', 'socket_write_ms', 'send_to_ack_ms') if role == 'host' else (
        'decode_ms', 'presentation_completion_ms'
    )
    windows = jsonl(scratch / name)
    need(all(row['type'] == f'jwm_remote_{role}_stats' and not row.get('final') for row in windows),
         'wrong typed window in endpoint trace')
    frames = [row[frame_field] for row in windows if row.get(frame_field)]
    percentiles = {stage: max((value for row in windows if (value := row['stages'].get(
        stage, {}).get('quantiles', {}).get('p95_ms')) is not None), default=None) for stage in stages}
    return {
        'raster': {key: value for key, value in raster.items() if key != 'accepted_observations_monotonic_ns'},
        'clock_scope': {key: value for key, value in recorded.items() if key.endswith('_monotonic_ns')},
        'telemetry': got, 'max_recent_window_p95_ms': percentiles,
        'frame_epochs': [list(epoch) for epoch in sorted({(f['source_epoch'], f['geometry_epoch']) for f in frames})],
    }


def verify_complete(run, outcome, manifest):
    timing = TIMINGS[outcome['timing']]
    ident = load(run / 'endpoints.json')
    need(RUN_ID.fullmatch(ident['run_id']) and int(ident['run_id'][-2:], 16) == outcome['marker_tag'],
         'run identity and marker tag differ')
    need(ident['host']['boot_id_sha256'] != ident['viewer']['boot_id_sha256'], 'two physical endpoint identities required')
    for role, pin in (('host', manifest[f"host_{outcome['arm'].lower()}_sha256"]),
                      ('viewer', manifest['viewer_sha256'])):
        row = ident[role]
        need(row['role'] == role and row['drawable_size'] == list(SIZE) and row['clock'] == 'CLOCK_MONOTONIC'
             and row['endpoint_executable_sha256'] == row['release_sha256'] == pin, 'endpoint pin or scope differs')
    xterm = ident['host']['xterm']
    need(xterm['sha256'] == manifest['xterm_sha256'] and xterm['font'] == FONT and xterm['grid'] == [COLUMNS, ROWS],
         'different XTerm executable, font or text grid')
    for name, expected in (('peer-events.jsonl', PEER_EVENTS), ('viewer/control-in.jsonl', VIEWER_EVENTS)):
        rows = jsonl(run / name)
        need([event['event'] for event in rows] == expected
             and all(set(event) == {'event', 'run_id'} and event['run_id'] == ident['run_id'] for event in rows),
             'clean test shutdown control sequence is missing')
    final = load(run / 'viewer/final-session.json')
    need(final['end_diagnostic'] == 'jwm-remote: session ended'
         and final['statistics']['type'] == 'jwm_remote_viewer_stats' and final['statistics']['final'],
         'missing clean viewer shutdown line or final statistics')
    phases = {}
    with tempfile.TemporaryDirectory(prefix='xterm-window-replay.') as temp:
        work = Path(temp)
        (work / 'viewer').mkdir()
        for role in ROLES:
            trace = run if role == 'host' else run / role
            dest = work if role == 'host' else work / role
            phases[role] = {}
            for phase in PHASES:
                phases[role][phase] = measured_phase(trace, role, phase, timing, dest)
                shutil.copyfile(trace / f'{phase}-scope.json', dest / f'{phase}-scope.json')
        summarize(work, timing[1])
        reconstructed = load(work / 'result.json')
        result = {key: value for key, value in reconstructed.items() if key != 'phases'}
        need(result == outcome['result'] and reconstructed == load(run / 'result.json'),
             'recorded combined gate or trial scopes do not reproduce')
    if result['telemetry_complete']:
        need(final['statistics']['session_id'] == result['authenticated_session_ids'][0],
             'final viewer statistics come from a different session')
    raw = {(role, name): (run / ('' if role == 'host' else role) / name).read_bytes()
           for role in ROLES for name in MEDIA[role] if name.endswith('.ppm')}
    readbacks = {f'{role}/{name}': sample(Photo(data), 0, SIZE[0], outcome['marker_tag'])
                 for (role, name), data in raw.items()}
    static = compare_static(Photo(raw['host', 'source-static.ppm']), Photo(raw['viewer', 'viewer-static.ppm']))
    static['source_initial_and_end_full_raster_identical'] = (
        raw['host', 'source-static.ppm'] == raw['host', 'source-static-end.ppm'])
    return {'endpoints': ident, 'phases': phases, 'static_crop': static,
            'snapshot_marker_and_glyph': {name: list(value) for name, value in readbacks.items()}}


def copy_trace(source, dest, outcome):
    dest.mkdir()
    (dest / 'viewer').mkdir()
    for role in ROLES:
        original = source if role == 'host' else source / role
        target = dest if role == 'host' else dest / role
        files = [*MEDIA[role], f'{role}-clocked-telemetry.jsonl']
        files.extend(f'{phase}-{kind}' for phase in PHASES
                     for kind in ('scope.json', 'pixels.jsonl', f'{role}.jsonl'))
        for name in files:
            if (original / name).is_file():
                shutil.copyfile(original / name, target / name)
    if outcome['status'] == 'failed':
        error = outcome.pop('error')
        path = source / 'failure.log'
        terminal = path.read_text().splitlines()[-1] if path.exists() else ''
        category = re.match(r'([\w.]+):', terminal)
        outcome['failed_evidence'] = {'error_type': category[1] if category else 'fixture_error',
                                      'error_sha256': hash_value(error)}
        for name in ('failure.log', 'artifact-fetch-failure.log'):
            if (source / name).exists():
                outcome['failed_evidence'][name + '_sha256'] = digest(source / name)
        return
    identity = load(source / 'identity.json')
    need(identity['viewer'] == load(source / 'viewer/identity.json'), 'fetched and live viewer identity differ')
    peer = jsonl(source / 'peer-events.jsonl')
    need(peer and peer[0]['identity'] == identity['viewer'], 'ready event identified a different Ubuntu endpoint')
    redacted = {'run_id': identity['run_id']}
    keys = ('role', 'kernel', 'cpu', 'drawable_size', 'clock', 'release_sha256', 'endpoint_executable_sha256')
    for role in ROLES:
        raw = identity[role]
        row = {key: raw[key] for key in keys}
        row.update({f'{key}_sha256': hash_value(raw[key]) for key in ('hostname', 'boot_id')})
        if role == 'host':
            row['xterm'] = {k: raw['xterm'][k] for k in ('sha256', 'version', 'font', 'grid')}
        redacted[role] = row
    save(dest / 'endpoints.json', redacted)
    for name, records in (('peer-events.jsonl', peer), ('viewer/control-in.jsonl', jsonl(source / 'viewer/control-in.jsonl'))):
        (dest / name).write_text(''.join(json.dumps({k: event[k] for k in ('event', 'run_id')}) + '\n'
                                         for event in records))
    viewer_log = (source / 'viewer/viewer.log').read_text().splitlines()
    final = [json.loads(line) for line in viewer_log if line.startswith('{') and json.loads(line).get('final')]
    need(len(final) == 1 and viewer_log[-1] == 'jwm-remote: session ended', 'missing original viewer normal exit')
    save(dest / 'viewer/final-session.json', {'end_diagnostic': viewer_log[-1], 'statistics': final[0]})
    shutil.copyfile(source / 'result.json', dest / 'result.json')


def validate_plan(manifest, progress, ledger):
    need(manifest['dimensions'] == list(SIZE) and manifest['requested_fps'] == 30
         and manifest['codec'] == 'JPEG' and manifest['jpeg_quality'] == 85
         and manifest['timings_warm_score_tail_seconds'] == {key: list(value) for key, value in TIMINGS.items()}
         and manifest['pair_order'] == [list(pair) for pair in ORDER], 'unexpected paired manifest')
    need(all(PIN.fullmatch(manifest[field]) for field in ('host_a_sha256', 'host_b_sha256', 'viewer_sha256', 'xterm_sha256'))
         and manifest['host_a_sha256'] != manifest['host_b_sha256'], 'missing distinct build pins')
    a, b = (manifest['reported_host_features'][arm] for arm in ('A', 'B'))
    flag = 'remote-fast-jpeg'
    need(a['protocol'] == b['protocol'] and a['reported_features'] == (b['reported_features'] | {flag: False})
         and a['reported_features'][flag] is False and b['reported_features'][flag] is True, 'wrong JPEG feature pair')
    need(ledger and all(row['status'] in ('completed', 'failed') for row in ledger), 'no terminal trial outcome')
    expected = [('pilot-B', 'B', None, TAG_BASE, 'pilot')]
    expected += [(f'pair-{pair:02d}-{arm}', arm, pair, TAG_BASE + pair, 'scored')
                 for pair, arms in enumerate(ORDER, 1) for arm in arms]
    actual = [tuple(row[key] for key in ('trial', 'arm', 'pair', 'marker_tag', 'timing')) for row in ledger]
    need(actual == expected[:len(actual)], 'unexpected or duplicate paired trial schedule')
    for row in ledger:
        need(row['host_release_sha256'] == manifest[f"host_{row['arm'].lower()}_sha256"], 'controller arm pin changed')
    pilot = ledger[0]
    passed = pilot['status'] == 'completed' and pilot['result']['viewer_motion_gate_met'] is True
    if len(ledger) == 1:
        need(not passed or manifest['pilot_only'], 'pilot passed but formal comparison has no terminal results')
        need(progress == {'pilot_gate_passed': passed}, 'pilot-only progress differs')
        return 'pilot-only'
    need(len(ledger) == len(expected) and passed and not manifest['pilot_only'], 'formal series did not reach terminal status')
    scored = ledger[1:]
    comparable = all(row['status'] == 'completed' and valid(row['result']) for row in scored)
    gates = sum(row['arm'] == 'B' and row['status'] == 'completed' and row['result']['viewer_motion_gate_met'] is True
                for row in scored)
    need(progress == {'pilot_gate_passed': True, 'scored_attempts': 6, 'all_six_comparable': comparable,
                      'candidate_cadence_gate_passes': gates, 'qualified': comparable and gates == len(ORDER)},
         'formal progress does not agree with terminal outcomes')
    return 'formal-six-trials'


def evaluate(root, manifest, progress, ledger):
    kind = validate_plan(manifest, progress, ledger)
    trials = []
    previous_endpoint, sessions = None, set()
    for row in ledger:
        trace = root / 'trace' / row['trial']
        trial = {'controller': row}
        if row['status'] == 'completed':
            trial['replayed'] = verify_complete(trace, row, manifest)
            endpoints = trial['replayed']['endpoints']
            stable = {role: {key: value for key, value in endpoints[role].items()
                             if key not in ('release_sha256', 'endpoint_executable_sha256')} for role in ROLES}
            need(previous_endpoint is None or previous_endpoint == stable,
                 'workload or cross-host identity changed across completed attempts')
            previous_endpoint = stable
            current = set(row['result']['authenticated_session_ids'])
            need(not (current & sessions), 'session identity recurred across independent attempts')
            sessions.update(current)
        else:
            trial['retained_partial_files'] = sorted(str(file.relative_to(trace)) for file in trace.rglob('*')
                                                     if file.is_file())
        trials.append(trial)
    return {'result_kind': kind, 'attempt_status_counts': dict(Counter(r['status'] for r in ledger)), 'trials': trials}


def audit_old(report_path, archive_path):
    prior = load(report_path)
    need(digest(archive_path) == prior['archive']['sha256'], 'historical archive pin differs')
    manifest = prior['manifest']
    need((manifest['warm_seconds'], manifest['score_seconds'], manifest['telemetry_tail_seconds']) == TIMINGS['scored']
         and manifest['dimensions'] == list(SIZE) and manifest['requested_fps'] == 30, 'old formal window differs')
    rows = []
    phases = 0
    with ZipFile(archive_path) as z:
        need(z.testzip() is None, 'historical archive integrity failure')
        def entry(name):
            data = z.read(name)
            need(hashlib.sha256(data).hexdigest() == prior['archive']['entries'][name], f'historical member pin differs: {name}')
            return data
        need(entry('fixture/terminal_scroll.py') == (LAB / 'terminal_scroll.py').read_bytes(),
             'previous XTerm fixture differs at the source')
        for old in prior['trials']:
            name = f"trial-{old['trial']:02}"
            turn = {'trial': old['trial']}
            for phase in PHASES:
                for role in ROLES:
                    base = f'{name}/{role}/{phase}'
                    timing = json.loads(entry(base + '-scope.json'))
                    samples = [json.loads(line) for line in entry(base + '-pixels.jsonl').splitlines()]
                    got = score_pixels(samples, timing['score_start_monotonic_ns'], timing['score_end_monotonic_ns'])
                    need(got == old['phases'][phase][role]['raster'], 'old archived score differs')
                    phases += 1
                    if role == 'viewer' and phase == 'motion':
                        turn.update({'viewer_fps': got['unique_content_fps'], 'gap_ms': got['gap_ms']})
            turn['static_crop'] = compare_static(Photo(entry(f'{name}/host/source-static.ppm')),
                                                 Photo(entry(f'{name}/viewer/viewer-static.ppm')))
            rows.append(turn)
    return {'original_report_sha256': digest(report_path), 'original_archive_sha256': digest(archive_path),
            'exact_formal_endpoint_phases_reproduced': phases, 'trials': rows,
            'comparison_scope': 'Historical independent JPEG sessions, outside the paired AB/BA/AB comparison.'}


def manifest_entries(tree):
    return {path.relative_to(tree).as_posix(): digest(path) for path in sorted(tree.rglob('*')) if path.is_file()}


def replay(report_path, archive_path):
    report = load(report_path)
    need(digest(archive_path) == report['archive']['sha256'], 'paired archive digest differs')
    with ZipFile(archive_path) as z, tempfile.TemporaryDirectory(prefix='paired-archive-replay.') as temporary:
        root = Path(temporary)
        expected = report['archive']['members_sha256']
        need(z.testzip() is None and len(z.namelist()) == len(set(z.namelist()))
             and set(z.namelist()) == set(expected), 'paired archive members differ')
        for name, pin in expected.items():
            rel = PurePosixPath(name)
            need(not rel.is_absolute() and '..' not in rel.parts and '\\' not in name, 'invalid archive member')
            path = root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            with z.open(name) as src, path.open('xb') as dest:
                shutil.copyfileobj(src, dest)
            need(digest(path) == pin, f'archive member digest differs: {name}')
        manifest, progress, ledger = (load(root / name) for name in ('manifest.json', 'progress.json', 'outcomes.json'))
        for name in FILES:
            need(digest(root / 'fixture' / name) == manifest['fixture_sha256'][name], 'recorded fixture pin changed')
        reference = root / 'historical-audit.json'
        need(manifest == report['manifest'] and progress == report['terminal_progress']
             and evaluate(root, manifest, progress, ledger) == report['comparison']
             and (load(reference) if reference.is_file() else None) == report.get('historical_1080p_reference'),
             'paired replay summary differs')
    print(f"Replayed {len(report['comparison']['trials'])} attempts ({report['comparison']['result_kind']})")


def publish(batch, out):
    out = out.resolve()
    need(out.is_relative_to(Path('/tmp')) and out != Path('/tmp'), 'this publisher writes only private /tmp output')
    out.mkdir(mode=0o700, parents=True, exist_ok=True)
    manifest, progress, ledger = (load(batch / name) for name in ('manifest.json', 'progress.json', 'outcomes.json'))
    validate_plan(manifest, progress, ledger)
    target_report, target_archive = out / f'{NAME}.json', out / f'{NAME}-raw.zip'
    need(not target_report.exists() and not target_archive.exists(), 'archive destination already exists')
    with tempfile.TemporaryDirectory(prefix='.paired-publish.', dir=out) as work:
        scratch = Path(work)
        tree = scratch / 'members'
        (tree / 'fixture').mkdir(parents=True)
        (tree / 'trace').mkdir()
        for name in (*FILES, 'paired.py', Path(__file__).name):
            shutil.copyfile(LAB / name, tree / 'fixture' / name)
            if name in FILES:
                need(digest(tree / 'fixture' / name) == manifest['fixture_sha256'][name], 'live fixture pin changed')
        for row in ledger:
            name = row['trial']
            copy_trace(batch / name, tree / 'trace' / name, row)
        save(tree / 'manifest.json', manifest)
        save(tree / 'progress.json', progress)
        save(tree / 'outcomes.json', ledger)
        result = evaluate(tree, manifest, progress, ledger)
        historical = LAB / 'historical-audit.json'
        if historical.is_file():
            shutil.copyfile(historical, tree / historical.name)
        for path in tree.rglob('*'):
            if path.is_file() and path.suffix in ('.json', '.jsonl'):
                need(not re.search(rb'127\.0\.0\.1:[1-9][0-9]*|-----BEGIN [A-Z ]*PRIVATE KEY-----|'
                                   rb'"(?:boot_id|hostname|local_port|remote_port|key_file)"\s*:', path.read_bytes()),
                     f'unredacted private fields in {path.relative_to(tree)}')
        archive, report_file = scratch / target_archive.name, scratch / target_report.name
        pins = manifest_entries(tree)
        with ZipFile(archive, 'w', compression=ZIP_DEFLATED, compresslevel=6) as z:
            for name in pins:
                z.write(tree / name, name)
        report = {'schema_version': 1, 'scope': 'Paired XTerm software raster observations, JPEG Q85 at 1080p.',
                  'manifest': manifest, 'terminal_progress': progress, 'comparison': result,
                  'historical_1080p_reference': load(historical) if historical.is_file() else None,
                  'measurement_limits': [
                      'The pilot is diagnostic and excluded from the formal comparison.',
                      'Decisions use independent local clocks and the existing marker/glyph thresholds.',
                      'RGB crop compares the two 1:1 early static XTerm captures. It is a text raster diagnostic.',
                      'Each stage p95 maximum is the maximum of observed recent-window p95s, without merging quantiles.',
                      'Raw endpoint credentials, boot IDs, addresses and remote runtime paths were omitted.',
                  ],
                  'archive': {'file': archive.name, 'sha256': digest(archive), 'members_sha256': pins}}
        save(report_file, report)
        replay(report_file, archive)
        archive.replace(target_archive)
        report_file.replace(target_report)
    print(target_report)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_subparsers(dest='action', required=True)
    write = modes.add_parser('publish')
    write.add_argument('batch', type=Path)
    write.add_argument('scratch_output', type=Path)
    check = modes.add_parser('replay')
    check.add_argument('report', type=Path)
    check.add_argument('archive', type=Path)
    prior = modes.add_parser('audit-old')
    prior.add_argument('report', type=Path)
    prior.add_argument('archive', type=Path)
    args = parser.parse_args()
    if args.action == 'publish':
        publish(args.batch, args.scratch_output)
    elif args.action == 'replay':
        replay(args.report, args.archive)
    else:
        print(json.dumps(audit_old(args.report, args.archive), indent=2))


if __name__ == '__main__':
    main()
