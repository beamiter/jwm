#!/usr/bin/env python3
"""Pinned fast-JPEG pilot and scored paired XTerm comparison."""

import argparse
import fcntl
import json
import os
from pathlib import Path, PurePosixPath
import re
import shlex
import subprocess
import tempfile
import traceback

import dual_terminal as terminal

FILES = ('dual_terminal.py', 'run_baseline.py', 'terminal_scroll.py', 'processes.py', 'score.py')
FEATURES = ('remote-x11', 'remote-wayland', 'remote-h264')
VIEWER_PIN = 'aaa1ed44223181963b3463fb169d56c9a76b31a514f29915f7ad5d47002690a3'
DEFAULT_VIEWER = '/tmp/jwm-p08-p09-release/jwm-remote'
ORDER = (('A', 'B'), ('B', 'A'), ('A', 'B'))
TAG_BASE = 0x60
SCOPE = ('static', 'motion')
PIN = re.compile(r'[0-9a-f]{64}')


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def pinned(path, expected):
    binary = Path(path).resolve(strict=True)
    require(binary.is_file() and os.access(binary, os.X_OK), f'not an executable: {binary}')
    require(terminal.sha256(binary) == expected, 'local executable SHA-256 did not match its pin')
    return str(binary)


def doctor_flags(hosts, batch, common):
    """Read the product's reported features without opening any display."""
    env = terminal.clean_env()
    env.pop('LD_PRELOAD', None)
    with tempfile.TemporaryDirectory(prefix='doctor.', dir=batch) as temp:
        key = Path(temp) / 'fixture-key'
        subprocess.run([hosts['A']['path'], 'keygen', '--output', str(key)], check=True, env=env,
                       stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, timeout=8)
        result = {}
        for label, arm in hosts.items():
            text = subprocess.check_output(
                [arm['path'], 'doctor', '--display', ':999', '--key-file', str(key)],
                stdin=subprocess.DEVNULL, env=env, text=True, timeout=8)
            [flags] = [line.removeprefix('Build features: ') for line in text.splitlines()
                       if line.startswith('Build features: ')]
            actual = {key: value == 'true' for key, value in (word.split('=', 1) for word in flags.split())}
            expected = {feature: feature in common for feature in FEATURES}
            expected['remote-fast-jpeg'] = label == 'B'
            require(actual == expected, f'arm {label} reported unexpected remote build features')
            versions = [line for line in text.splitlines() if line.startswith('Local protocol: ')]
            require(len(versions) == 1, 'doctor did not report local protocol identity')
            result[label] = {'reported_features': actual, 'protocol': versions[0]}
        require(result['A']['protocol'] == result['B']['protocol'], 'host arm protocol versions differ')
        return result


def stage_viewer(args, batch, script_digests):
    def ssh(command, stdin=None):
        quiet_stdin = ['-n'] if stdin is None else []
        return subprocess.run(
            [*terminal.SSH, '-4', *quiet_stdin, '--', args.peer, command], check=True, timeout=30,
            input=stdin, text=True, capture_output=True,
        ).stdout

    found = ssh(shlex.join(['sha256sum', '--', args.remote_release])).split()
    require(found and found[0] == args.viewer_sha256, 'Ubuntu executable SHA-256 did not match its pin')
    remote = ssh('umask 077 && mktemp -d /tmp/jwm-terminal-scroll-fast-jpeg.XXXXXXXX').strip()
    require(re.fullmatch(r'/tmp/jwm-terminal-scroll-fast-jpeg\.[A-Za-z0-9]+', remote),
            'the remote fixture is not in its private stage directory')
    (batch / 'staged-peer-dir').write_text(remote + '\n')
    subprocess.run(['scp', '-q', '-4', '-o', 'BatchMode=yes', '-o', 'StrictHostKeyChecking=yes',
                    '-o', 'ConnectTimeout=5', *FILES, f'{args.peer}:{remote}/'],
                   cwd=terminal.HERE, check=True, stdin=subprocess.DEVNULL, timeout=30)
    hashes = ''.join(f'{script_digests[name]}  {name}\n' for name in FILES)
    (batch / 'staged-source-sha256.txt').write_text(hashes)
    ssh(f'cd {shlex.quote(remote)} && sha256sum --check --status', hashes)
    return remote


def endpoint_signature(identity):
    """Compare only dimensions, peer identity and binary/workload invariants."""
    source, viewer = identity['host'], identity['viewer']
    stable = ('hostname', 'boot_id', 'cpu', 'kernel', 'drawable_size', 'clock')
    return {
        'host': {name: source[name] for name in stable}
                | {'xterm': {field: source['xterm'][field]
                             for field in ('sha256', 'version', 'font', 'grid')}},
        'viewer': {name: viewer[name] for name in (*stable, 'release_sha256')},
    }


def grade_trial(run, role, pin, viewer_pin, tag, expected_xterm):
    identity = json.loads((run / 'identity.json').read_text())
    scope = json.loads((run / 'result.json').read_text())
    start_viewer = json.loads((run / 'viewer/identity.json').read_text())
    require(identity['viewer'] == start_viewer, 'live and fetched Ubuntu viewer identities disagree')
    require(identity['host']['endpoint_executable_sha256'] == identity['host']['release_sha256'] == pin,
            'actual source executable does not match selected arm pin')
    require(identity['viewer']['endpoint_executable_sha256'] == identity['viewer']['release_sha256'] == viewer_pin,
            'actual Ubuntu viewer executable does not match shared viewer pin')
    require(int(identity['run_id'][-2:], 16) == tag
            and identity['host']['xterm']['sha256'] == expected_xterm,
            'paired marker tag or source terminal executable changed')
    if scope['telemetry_complete']:
        for phase in SCOPE:
            for endpoint in ('host', 'viewer'):
                stats = scope['phases'][phase][endpoint]['telemetry']
                require(stats['session_ids'] == scope['authenticated_session_ids'],
                        'phase telemetry did not share one authenticated session')
    routes = {phase: {endpoint: scope['phases'][phase][endpoint]['telemetry']['routes']
                      for endpoint in ('host', 'viewer')} for phase in SCOPE}
    motion = scope['phases']['motion']['viewer']['samples']['viewer']
    host_motion = [json.loads(line) for line in (run / 'motion-host.jsonl').read_text().splitlines()]
    codec_p95 = [value for row in host_motion
                 if (value := row['stages']['codec_ms']['quantiles']['p95_ms']) is not None]
    return {
        'arm': role, 'host_release_sha256': pin, 'viewer_release_sha256': viewer_pin,
        'marker_tag': tag, 'capture_routes': routes, 'session_ids': scope['authenticated_session_ids'],
        'viewer_motion_gap_ms': motion['gap_ms'], 'viewer_motion_zero_bins': motion['zero_unique_bins'],
        'viewer_motion_invalid_marker_reads': motion['invalid_marker_reads'],
        'viewer_motion_reordered_marker_reads': motion['reordered_marker_reads'],
        'host_codec_p95_max_window_ms': max(codec_p95, default=None),
    }, endpoint_signature(identity)


def valid(result):
    return all(result[name] for name in ('source_qualified', 'telemetry_complete', 'static_unchanged'))


def run(args, hosts, common, xterm):
    with open(terminal.LOCK, 'a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        batch = Path(tempfile.mkdtemp(prefix='paired.', dir=terminal.HERE))
        print(batch, flush=True)
        digests = {name: terminal.sha256(terminal.HERE / name) for name in FILES}
        xterm_pin = terminal.sha256(xterm)
        manifest = {'dimensions': terminal.SIZE, 'codec': 'JPEG', 'jpeg_quality': 85,
                    'requested_fps': terminal.REQUESTED_FPS, 'source_fps': terminal.SOURCE_FPS,
                    'xterm_sha256': xterm_pin, 'font': terminal.FONT, 'grid': [terminal.COLUMNS, terminal.ROWS],
                    'host_a_sha256': hosts['A']['sha256'], 'host_b_sha256': hosts['B']['sha256'],
                    'viewer_sha256': args.viewer_sha256, 'fixture_sha256': digests,
                    'reported_host_features': doctor_flags(hosts, batch, common), 'pair_order': ORDER,
                    'timings_warm_score_tail_seconds': terminal.TIMINGS,
                    'marker_tag_policy': 'pilot 96, paired comparison 97–99 shared within each pair',
                    'pilot_only': args.pilot_only}
        terminal.write_json(batch / 'manifest.json', manifest)
        remote = stage_viewer(args, batch, digests)
        outcomes, signatures, sessions = [], [], set()
        pilot_routes = None

        def attempt(name, arm, pair, tag, timing):
            trial = batch / name
            pin = hosts[arm]['sha256']
            dimensions = {'trial': name, 'arm': arm, 'pair': pair, 'marker_tag': tag,
                          'timing': timing, 'host_release_sha256': pin}
            try:
                options = argparse.Namespace(
                    peer=args.peer, remote_dir=remote, release=pinned(hosts[arm]['path'], pin),
                    remote_release=args.remote_release, terminal=xterm, marker_tag=tag, timing=timing,
                    host_sha256=pin, viewer_sha256=args.viewer_sha256,
                )
                result = terminal.run_source_trial(options, trial)
                evidence, signature = grade_trial(trial, arm, pin, args.viewer_sha256, tag, xterm_pin)
                session_ids = result['authenticated_session_ids']
                require(not sessions.intersection(session_ids), 'a session ID recurred between independent attempts')
                require(not signatures or signature == signatures[0], 'host workload or either endpoint identity changed')
                sessions.update(session_ids)
                signatures.append(signature)
                if pilot_routes is not None:
                    require(evidence['capture_routes']['motion'] == pilot_routes,
                            'actual capture or presentation path changed from candidate pilot')
                outcome = dimensions | {'status': 'completed', 'result': result, 'evidence': evidence}
            except Exception as error:
                trial.mkdir(mode=0o700, exist_ok=True)
                (trial / 'failure.log').write_text(traceback.format_exc())
                outcome = dimensions | {'status': 'failed', 'error': str(error)}
            outcomes.append(outcome)
            terminal.write_json(batch / 'outcomes.json', outcomes)
            print(json.dumps(outcome), flush=True)
            return outcome

        pilot = attempt('pilot-B', 'B', None, TAG_BASE, 'pilot')
        pilot_pass = pilot['status'] == 'completed' and pilot['result']['viewer_motion_gate_met'] is True
        terminal.write_json(batch / 'progress.json', {'pilot_gate_passed': pilot_pass})
        if not pilot_pass or args.pilot_only:
            return 0 if pilot_pass else 2
        pilot_routes = pilot['evidence']['capture_routes']['motion']
        for pair, arms in enumerate(ORDER, 1):
            for arm in arms:
                attempt(f'pair-{pair:02d}-{arm}', arm, pair, TAG_BASE + pair, 'scored')
        scored = outcomes[1:]
        comparable = all(row['status'] == 'completed' and valid(row['result']) for row in scored)
        candidate_passes = sum(row['status'] == 'completed' and row['result']['viewer_motion_gate_met'] is True
                               for row in scored if row['arm'] == 'B')
        comparison = {'pilot_gate_passed': True, 'scored_attempts': len(scored),
                      'all_six_comparable': comparable, 'candidate_cadence_gate_passes': candidate_passes,
                      'qualified': comparable and candidate_passes == len(ORDER)}
        terminal.write_json(batch / 'progress.json', comparison)
        return 0 if comparison['qualified'] else 3


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--peer', required=True)
    for arm in ('a', 'b'):
        parser.add_argument(f'--host-{arm}', required=True)
        parser.add_argument(f'--host-{arm}-sha256', required=True)
    parser.add_argument('--remote-release', default=DEFAULT_VIEWER)
    parser.add_argument('--viewer-sha256', default=VIEWER_PIN)
    parser.add_argument('--host-common-features', default=','.join(FEATURES))
    parser.add_argument('--terminal', default='/usr/bin/xterm')
    parser.add_argument('--pilot-only', action='store_true')
    args = parser.parse_args()
    if not re.fullmatch(r'(?:[A-Za-z0-9_.-]+@)?[A-Za-z0-9.][A-Za-z0-9_.-]*', args.peer):
        parser.error('expected an explicit pinned peer hostname')
    if not PurePosixPath(args.remote_release).is_absolute() or '\n' in args.remote_release:
        parser.error('pass an absolute path to the Ubuntu viewer binary')
    expected = (args.host_a_sha256, args.host_b_sha256, args.viewer_sha256)
    if not all(PIN.fullmatch(pin) for pin in expected) or expected[0] == expected[1]:
        parser.error('host A/B require distinct lowercase SHA-256 pins and the viewer needs one fixed pin')
    common = set(args.host_common_features.split(','))
    if not common <= set(FEATURES) or 'remote-x11' not in common:
        parser.error('common remote feature list must include remote-x11 and may include Wayland or H.264')
    hosts = {name: {'path': path, 'sha256': pin} for name, path, pin in
             (('A', args.host_a, expected[0]), ('B', args.host_b, expected[1]))}
    xterm = Path(args.terminal).resolve(strict=True)
    require(xterm.is_file() and os.access(xterm, os.X_OK), 'XTerm executable missing')
    for arm in hosts.values():
        arm['path'] = pinned(arm['path'], arm['sha256'])
    raise SystemExit(run(args, hosts, common, str(xterm)))


if __name__ == '__main__':
    main()
