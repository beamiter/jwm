# Pinned native Wayland RGB reuse correctness evidence

Extract this ZIP and run the offline verifier with `python3 -B replay.py .`.

Both owned Intel hardware tests used the pinned release CLI for host and
viewer and the pinned test observer. The opt-in environment was inherited by
the viewer. Test stdout preserves all typed marker records and test endings,
with a per-case alias replacing the authenticated session ID. The compact
runner log records binary check and command exit lines, with binary paths
reduced to filenames. Source excerpts identify what the harness asserts.
The full 4K test source matches the recorded build digest. The recovery and
spawn/pixel inspections are reviewed excerpts from files outside that list.

The 4K case reads a 96x96 region of the actual composited XRGB DMA-BUF at each
completion. It logs the final four quadrant samples and aggregate completion
count. The other case observes two smaller owned sources and verifies resize,
role change, import rejection and capture capability withdrawal. Both cases use
offscreen private Wayland compositors. Their test logs do not carry allocation
counts or a reuse activation line. The separate same-pin preflight records
actual allocation reuse. No physical scanout, frame-duration score or decoder
leak bound is inferred from these observations.
