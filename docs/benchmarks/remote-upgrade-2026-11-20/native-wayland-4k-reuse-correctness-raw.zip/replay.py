"""Replay the pinned native Wayland correctness observations without starting a viewer."""
import hashlib
import json
from pathlib import Path
import re
import sys

REGION = 'native_cli_wayland_gpu_viewer_presents_owned_4k_region'
RECOVERY = 'native_cli_wayland_gpu_viewer_presents_and_recovers_from_import_rejection'
PHASES = ('first', 'resized', 'second', 'fallback', 'capture_fallback')
REGION_MARKER = 'JWM_NATIVE_WAYLAND_4K'
RECOVERY_MARKER = 'JWM_NATIVE_WAYLAND_GPU_VIEWER'
NATIVE = 'wayland-vaapi-dmabuf'


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def one(items):
    item, = items
    return item


def sha(data):
    return hashlib.sha256(data).hexdigest()


def json_rows(lines, prefix):
    return [json.loads(line.removeprefix(prefix)) for line in lines if line.startswith(prefix)]


def test_status(lines, test, runner):
    require('running 1 test' in lines and 'ok' in lines, f'{test}: missing test start or success')
    named = one(line for line in lines if line.startswith('test remote::'))
    require(f'::{test} ... ' in named, f'{test}: unexpected test assertion')
    summary = one(line for line in lines if line.startswith('test result:'))
    status = re.fullmatch(r'test result: ok\. 1 passed; 0 failed; 0 ignored; 0 measured; \d+ filtered out; finished in ([\d.]+)s', summary)
    require(status is not None, f'{test}: lib test did not finish successfully')
    index = runner.index(f'Running owned hardware case {test}')
    require(runner[index + 1] == 'Hardware case exit 0', f'{test}: runner status is unverified')
    return {'test_passed': True, 'test_exit': 0, 'duration_seconds': float(status[1]),
            'host_exit': 0, 'viewer_exit': 0,
            'endpoint_exit_evidence': 'Successful test after assertions on both child process exit statuses.'}


def joined(host, viewer, session):
    require(host['session_id'] == viewer['session_id'] == session, 'endpoint session changed')
    h, v = host['last_sent_frame'], viewer['last_decoded_frame']
    shared = ('codec', 'source_dimensions', 'encoded_dimensions', 'source_epoch', 'geometry_epoch')
    require(all(h[key] == v[key] for key in shared) and host['drawn_acks'] > 0
            and viewer['acked_frames'] > 0, 'endpoint scope or ACK proof differs')
    return h, v


def require_native_host(host):
    require('vaapi-resize/wayland-dmabuf' in host['mode']
            and host['last_sent_frame']['codec'] == 'H.264'
            and host['h264_frames'] > 0 and host['jpeg_atlases'] == host['hevc444_frames'] == 0
            and host['hardware_encode_stages']['native_dmabuf_import_ms']['observations'] > 0
            and host['hardware_encode_stages']['rgb_copy_ms']['observations'] == 0
            and host.get('wayland_capture') is None, 'native host retained an unexpected CPU path')


def require_native_viewer(viewer):
    require(viewer['last_presentation_path'] == NATIVE
            and viewer['native_presented_frames'] == viewer['presented_frames'] > 0
            and viewer['hardware_download_ms']['observations'] == 0, 'native viewer presented via an unexpected CPU path')


def rollup(host, viewer):
    return {'source_epoch': host['last_sent_frame']['source_epoch'],
            'geometry_epoch': host['last_sent_frame']['geometry_epoch'],
            'source_size': host['last_sent_frame']['source_dimensions'],
            'encoded_size': host['last_sent_frame']['encoded_dimensions'],
            'last_frame_codec': host['last_sent_frame']['codec'],
            'host_capture_mode': host['mode'],
            'host_sent_last_sequence': host['last_sent_frame']['sequence'],
            'host_drawn_acks': host['drawn_acks'], 'host_sent': host['sent'],
            'host_outstanding': host['outstanding'],
            'host_h264_frames': host['h264_frames'], 'host_jpeg_atlases': host['jpeg_atlases'],
            'host_native_dmabuf_imports': host['hardware_encode_stages']['native_dmabuf_import_ms']['observations'],
            'host_shm_readback_bytes': (host.get('wayland_capture') or {}).get('readback_bytes'),
            'viewer_decoded_last_sequence': viewer['last_decoded_frame']['sequence'],
            'viewer_presented_frames': viewer['presented_frames'],
            'viewer_native_presented_frames': viewer['native_presented_frames'],
            'viewer_drawn_acks': viewer['acked_frames'],
            'viewer_hardware_downloads': viewer['hardware_download_ms']['observations'],
            'viewer_last_presentation_path': viewer['last_presentation_path']}


def region(lines, runner, device):
    status = test_status(lines, REGION, runner)
    read = one(json_rows(lines, REGION_MARKER + ' '))
    renderer = one(line.split('JWM_NATIVE_WAYLAND_RENDERER=', 1)[1]
                   for line in lines if 'JWM_NATIVE_WAYLAND_RENDERER=' in line)
    require('Intel' in renderer and read['render_node_device'] == device,
            'unexpected or unproven Intel renderer/device')
    require(read['roi'] == [16, 16, 96, 96] and read['roi_bytes'] == 96 * 96 * 4,
            'ROI size or byte count differs')
    samples = read['samples']
    tones = ((True, False, False), (False, True, False), (False, False, True), (True, True, False))
    require(len(samples) == 4 and all(len(sample) == 4 and sample[3] == 255
            and all(value >= 190 if high else value <= 65 for value, high in zip(sample, tone))
            for sample, tone in zip(samples, tones)), 'quadrant order, color, or opacity differs')
    host, viewer = read['host'], read['viewer']
    h, _ = joined(host, viewer, 'region-session')
    require(h['source_dimensions'] == h['encoded_dimensions'] == [3840, 2160], 'unexpected 4K frame extent')
    require_native_host(host)
    require_native_viewer(viewer)
    require(read['compositor_completions'] > 0 and read['last_completion_monotonic_us'] > 0,
            'missing private compositor finish')
    return {**status, 'renderer': renderer, 'render_node_device': device,
            'private_compositor_completions': read['compositor_completions'],
            'last_completion_monotonic_us': read['last_completion_monotonic_us'],
            'roi_xywh': read['roi'], 'roi_bytes_each': read['roi_bytes'],
            'rgba_quadrants': dict(zip(('top_left_red','top_right_green','bottom_left_blue','bottom_right_yellow'), samples)),
            'session_alias': 'region-session', 'endpoint_windows': rollup(host, viewer),
            'source_content': 'Static 3840×2160 source with four asymmetric color quadrants.',
            'attachment_evidence': 'Each completion asserted a single untransformed imported XRGB8888 root, full visible 4K geometry, and quadrant colors from actual ROI framebuffer readback.'}


def bgrx_color(samples, channel, border=False):
    require(len(samples) == 3, 'missing three-point readback samples')
    if border:
        require(samples[0] == [0, 0, 0, 255], 'letterbox corner is not black')
        samples = samples[1:]
    require(all(len(pixel) == 4 and pixel[channel] >= 245 and pixel[2-channel] <= 12
                and pixel[1] <= 12 and pixel[3] == 255 for pixel in samples), 'source color not preserved')


def recovery(lines, runner):
    status = test_status(lines, RECOVERY, runner)
    data = one(json_rows(lines, RECOVERY_MARKER + ' '))
    expected_scope = [(1, 2), (1, 3), (2, 5), (2, 5), (2, 5)]
    measurements = {}
    previous_h = previous_v = -1
    for position, phase in enumerate(PHASES):
        host, viewer = data['host'][phase], data[phase]
        h, v = joined(host, viewer, 'recovery-session')
        require((h['source_epoch'], h['geometry_epoch']) == expected_scope[position]
                and h['sequence'] > previous_h and v['sequence'] > previous_v,
                f'{phase}: stale or unexpected source/geometry scope')
        expected_size = [200, 150] if position < 2 else [240, 180]
        require(h['source_dimensions'] == h['encoded_dimensions'] == expected_size,
                f'{phase}: source/encoded dimensions changed')
        if position < 4:
            require_native_host(host)
        else:
            require('wayland-surface/cpu-resize/shm' in host['mode'] and h['codec'] == 'JPEG'
                    and host['jpeg_atlases'] > 0 and host['sent'] == host['drawn_acks']
                    and host['outstanding'] == 0 and host['wayland_capture']['readback_bytes'] > 0,
                    'withdrawn capture global did not produce acknowledged SHM JPEG on same source')
        if position < 3:
            require_native_viewer(viewer)
        else:
            require(viewer['last_presentation_path'] == 'rgb', f'{phase}: intended SHM RGB viewer path is missing')
            if phase == 'fallback':
                require(viewer['hardware_download_ms']['observations'] > 0, 'native decode fallback never downloaded')
        samples = data[f'{phase}_bgrx']
        bgrx_color(samples, 2 if position < 2 else 0, border=phase == 'resized')
        measurements[phase] = {**rollup(host, viewer), 'three_bgrx_readback_samples': samples}
        previous_h, previous_v = h['sequence'], v['sequence']
    waits = [line.removeprefix('JWM_NATIVE_WAYLAND_GPU_WAIT ').split(': ', 1)
             for line in lines if line.startswith('JWM_NATIVE_WAYLAND_GPU_WAIT ')]
    require(len({name for name,_ in waits}) == len(PHASES), 'early phase diagnostics did not include each wait')
    for _, payload in waits:
        json.loads(payload)
    return {**status, 'session_alias': 'recovery-session', 'viewer_terminal_state': 'closed',
            'resize_viewport': [481, 320], 'matched_endpoint_windows': measurements,
            'asserted_transitions': [
                'Same viewer role after resize, with a black letterbox and red pixels on a fresh native frame.',
                'Fresh viewer role after authorized switch to the distinct blue source under the same authenticated session.',
                'Injected viewer import rejection led to actual SHM with CPU RGB delivery while the host remained on DMA-BUF H.264.',
                'Withdrawing the capture DMA-BUF global led to actual SHM/JPEG and drawn acknowledgement on the same blue source, geometry and viewer role.',
            ],
            'window_scope': 'Endpoint reporting windows are independently timed. The import-rejection window may include prior native presentations. The final capture transition window includes preceding H.264 records and ends with JPEG.'}


def replay(root):
    pins = json.loads((root / 'pins.json').read_text())
    runner = (root / 'runs/hardware-wrapper.log').read_text().splitlines()
    require(runner[:2] == ['jwm-remote: OK', 'observer: OK'], 'launch-time binary checksum proof is missing')
    for role, binding in pins['binaries'].items():
        require(re.fullmatch(r'[0-9a-f]{64}', binding['sha256'])
                and binding['independently_rehashed'] is True and binding['abba_equal'] is True,
                f'candidate {role} is not the pinned binary')
    require(pins['environment']['JWM_REMOTE_WAYLAND_REUSE_RGB'] == '1', 'candidate opt-in was missing')
    require(sha((root / 'checks/host_wayland_gpu_4k_integration.rs').read_bytes()) ==
            pins['selected_build_sources']['src/remote/host_wayland_gpu_4k_integration.rs'],
            'exact pinned 4K test source differs')
    comparison = pins['separate_same_binary_reuse_proof']
    require(comparison['run_id'] == 88 and comparison['confirmed_activation']
            and comparison['viewer_sha256'] == pins['binaries']['release']['sha256']
            and comparison['observer_sha256'] == pins['binaries']['observer']['sha256']
            and comparison['rgb_target_allocations'] < comparison['native_preparations']
            == comparison['fresh_wayland_dmabuf_imports'], 'cross-run allocation proof differs')
    lines = lambda name: (root / f'runs/{name}.log').read_text().splitlines()
    return {'native_4k': region(lines(REGION), runner, pins['render_node_device']),
            'pipeline_recovery': recovery(lines(RECOVERY), runner)}


if __name__ == '__main__':
    print(json.dumps(replay(Path(sys.argv[1])), indent=2))
