#!/usr/bin/env python3
"""Read-only replay of the completed terminal scroll-copy pair 01 gap."""

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys


SECOND_NS = 1_000_000_000
MOTION_SECONDS = 60
VIEWER_STAGES = (
    'decode_ms', 'decode_queue_ms', 'frame_header_wait_ms',
    'frame_body_receive_ms', 'frame_authentication_ms', 'presentation_queue_ms',
    'presentation_completion_ms', 'sender_control_queue_ms', 'sender_control_write_ms',
)
HOST_STAGES = (
    'capture_ms', 'mailbox_age_ms', 'credit_wait_ms', 'dirty_scan_ms',
    'atlas_pack_ms', 'jpeg_ms', 'writer_wait_ms', 'socket_write_ms',
    'capture_start_to_ack_ms', 'send_to_ack_ms',
)
HOST_COUNTS = (
    'scheduled', 'captured', 'sent', 'jpeg_atlases', 'drawn_acks', 'backpressure_skipped',
    'replaced', 'outstanding', 'max_outstanding', 'scroll_copy_frames',
    'dirty_tiles', 'total_tiles', 'bytes', 'unchanged_suppressed', 'viewer_superseded',
)
VIEWER_COUNTS = ('received', 'decoded', 'drawn', 'acked', 'replaced',
                 'decode_queue_max_sampled_at_dequeue')
ARTIFACTS = (
    'result.json', 'motion-scope.json', 'motion-pixels.jsonl', 'motion-host.jsonl',
    'host-clocked-telemetry.jsonl', 'terminal-progress.jsonl',
    'viewer/motion-scope.json', 'viewer/motion-pixels.jsonl',
    'viewer/motion-viewer.jsonl', 'viewer/viewer-clocked-telemetry.jsonl',
)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load(path):
    return json.loads(path.read_bytes())


def jsonl(path):
    return [json.loads(line) for line in path.read_bytes().splitlines()]


def ms(ns):
    return ns / 1_000_000


def nearest_rank(values, percent):
    return values[(len(values) * percent + 99) // 100 - 1]


def replay_pixels(scope, rows, side):
    start = scope['score_start_monotonic_ns']
    end = scope['score_end_monotonic_ns']
    require(end - start == MOTION_SECONDS * SECOND_NS, 'score interval is not 60 seconds')
    require(start - scope['phase_start_monotonic_ns'] == 30 * SECOND_NS, 'warmup is not 30 seconds')
    require(all(row['side'] == side and row['start_monotonic_ns'] <= row['end_monotonic_ns']
                for row in rows), 'unexpected observer records')
    require(all(right['end_monotonic_ns'] > left['end_monotonic_ns']
                for left, right in zip(rows, rows[1:])), 'observer end timestamps are not strictly increasing')
    accepted = []
    newest = last_text = None
    bins = [0] * MOTION_SECONDS
    text_bins = [0] * MOTION_SECONDS
    invalid_markers = invalid_glyphs = reordered = reads = read_max = 0
    signatures = set()
    for row in rows:
        stamp = row['end_monotonic_ns']
        if stamp >= end:
            break
        marker, text = row['marker'], row['scroll_signature']
        changed = marker is not None and newest is not None and marker > newest
        text_changed = text is not None and last_text is not None and text != last_text
        if stamp >= start:
            slot = (stamp - start) // SECOND_NS
            reads += 1
            read_max = max(read_max, stamp - row['start_monotonic_ns'])
            invalid_markers += marker is None
            invalid_glyphs += text is None
            reordered += marker is not None and newest is not None and marker < newest
            if text is not None:
                signatures.add(text)
            if changed:
                accepted.append(row)
                bins[slot] += 1
            if text_changed:
                text_bins[slot] += 1
        if changed or newest is None:
            newest = marker
        if text is not None:
            last_text = text
    points = [start, *(row['end_monotonic_ns'] for row in accepted), end]
    gap_samples = sorted(right - left for left, right in zip(points, points[1:]))
    metrics = {
        'unique_marker_changes': len(accepted),
        'unique_content_fps': len(accepted) / MOTION_SECONDS,
        'one_second_unique_bins': bins,
        'zero_unique_bins': bins.count(0),
        'scroll_changes_seen': sum(text_bins),
        'one_second_scroll_bins': text_bins,
        'distinct_scroll_signatures': len(signatures),
        'valid_and_invalid_sample_reads': reads,
        'invalid_marker_reads': invalid_markers,
        'reordered_marker_reads': reordered,
        'invalid_scroll_reads': invalid_glyphs,
        'observer_max_read_ms': ms(read_max),
        'gap_ms': {'p50': ms(nearest_rank(gap_samples, 50)),
                   'p95': ms(nearest_rank(gap_samples, 95)), 'max': ms(gap_samples[-1])},
    }
    original = scope['samples'][side]
    require(all(original[key] == value for key, value in metrics.items()),
            f'{side} raw replay differs from recorded score')
    require(original['accepted_observations_monotonic_ns'] == points[1:-1],
            f'{side} accepted samples differ from recorded score')
    return metrics, accepted, points


def gap_detail(scope, accepted, points, index):
    start = scope['score_start_monotonic_ns']
    left, right = points[index:index + 2]
    return {
        'start_monotonic_ns': left,
        'end_monotonic_ns': right,
        'start_from_score_ms': ms(left - start),
        'end_from_score_ms': ms(right - start),
        'duration_ms': ms(right - left),
        'start_marker': accepted[index - 1]['marker'] if index > 0 else None,
        'end_marker': accepted[index]['marker'] if index < len(accepted) else None,
        'left_score_boundary': index == 0,
        'right_score_boundary': index == len(accepted),
    }


def select_windows(path, role, scope, session_ids):
    rows = jsonl(path / f'{role}-clocked-telemetry.jsonl')
    selected = []
    for row in rows:
        record = row['record']
        duration = round(record['window_seconds'] * SECOND_NS)
        end = row['end_monotonic_ns']
        begin = end - duration
        if duration > 0 and scope['score_start_monotonic_ns'] <= begin \
                and end <= scope['telemetry_phase_end_monotonic_ns']:
            selected.append((begin, end, record))
    require([record for _, _, record in selected] == jsonl(path / f'motion-{role}.jsonl'),
            f'{role} typed window selection differs from retained records')
    telemetry = scope['telemetry']
    require(len(selected) == telemetry['whole_windows'], f'{role} selected window count differs')
    retained_ns = round(sum(record['window_seconds'] for _, _, record in selected) * SECOND_NS)
    recorded_ns = round(telemetry['window_seconds'] * SECOND_NS)
    require(telemetry['first_window_end_monotonic_ns'] == selected[0][1]
            and telemetry['last_window_end_monotonic_ns'] == selected[-1][1]
            and abs(recorded_ns - retained_ns) <= 1,
            f'{role} selected window timing differs')
    require(telemetry['session_ids'] == session_ids == sorted({entry[2]['session_id'] for entry in selected})
            and all(record['type'] == f'jwm_remote_{role}_stats' and not record.get('final')
                    for _, _, record in selected), f'{role} motion records do not share one session')
    frame = 'last_sent_frame' if role == 'host' else 'last_frame'
    require(all(record[frame]['codec'] == 'JPEG' and record[frame]['encoded_dimensions'] == [1920, 1080]
                and record[frame]['source_dimensions'] == [1920, 1080]
                and (record[frame]['source_epoch'], record[frame]['geometry_epoch']) == (1, 2)
                for _, _, record in selected), f'{role} motion frame scope changed unexpectedly')
    return selected


def stage_excerpt(record, role, name):
    data = record['stages'][name]
    measured = data.get('observations')
    if role == 'host' and name in ('capture_ms', 'jpeg_ms', 'socket_write_ms',
                                   'send_to_ack_ms', 'capture_start_to_ack_ms'):
        # These host means take their denominators directly from declared counts
        # in jwm_remote_host_stats. Quantile samples can cap at the recent 128.
        count_key = {'capture_ms': 'captured', 'jpeg_ms': 'jpeg_atlases',
                     'socket_write_ms': 'sent', 'send_to_ack_ms': 'drawn_acks',
                     'capture_start_to_ack_ms': 'drawn_acks'}[name]
        measured = record[count_key]
    return {
        'mean_ms': data['mean'],
        'observations': measured,
        'sum_of_observed_ms_from_mean': (round(data['mean'] * measured, 6)
                                         if data['mean'] is not None and measured is not None else None),
        'recent_quantiles': data['quantiles'],
    }


def nearby_windows(selected, scope, role, lo, hi):
    intersect = [i for i,(begin,end,_) in enumerate(selected) if begin < hi and lo <= end]
    require(intersect, f'no {role} telemetry window intersects the local marker range')
    start = scope['score_start_monotonic_ns']
    excerpts = []
    for i in range(max(0, intersect[0] - 1), min(len(selected), intersect[-1] + 2)):
        begin, end, record = selected[i]
        counts = HOST_COUNTS if role == 'host' else VIEWER_COUNTS
        stages = HOST_STAGES if role == 'host' else VIEWER_STAGES
        frame_key = 'last_sent_frame' if role == 'host' else 'last_frame'
        path_key = 'mode' if role == 'host' else 'last_presentation_path'
        excerpts.append({
            'nominal_start_from_score_ms': ms(begin - start),
            'stderr_receipt_from_score_ms': ms(end - start),
            'overlaps_local_interval': i in intersect,
            'path': record[path_key],
            'frame': record[frame_key],
            'counts': {key: record[key] for key in counts if key in record},
            'stages': {name: stage_excerpt(record, role, name)
                       for name in stages if name in record['stages']},
        })
    return excerpts


def read_trial(path, expected_name):
    require(path.name == expected_name, f'replay is scoped only to completed {expected_name}')
    result = load(path / 'result.json')
    sessions = result['authenticated_session_ids']
    require(len(sessions) == 1 and result['codec'] == 'JPEG' and result['jpeg_quality'] == 85
            and result['source_and_requested_viewer_dimensions'] == [1920, 1080]
            and all(result[k] for k in ('static_unchanged', 'source_qualified', 'telemetry_complete')),
            'completed motion result is outside the authorized pair-01 trial scope')
    trial = {}
    for role, directory in (('host', path), ('viewer', path / 'viewer')):
        scope = load(directory / 'motion-scope.json')
        require(scope == result['phases']['motion'][role], f'{role} motion scope differs from result')
        pixels = jsonl(directory / 'motion-pixels.jsonl')
        metrics, accepted, points = replay_pixels(scope, pixels, 'source' if role == 'host' else 'viewer')
        actual_fps = result['source_motion_fps' if role == 'host' else 'viewer_motion_fps']
        require(metrics['unique_content_fps'] == actual_fps, f'{role} reported FPS differs')
        windows = select_windows(directory, role, scope, sessions)
        trial[role] = (scope, pixels, metrics, accepted, points, windows)
    require(all(0 <= record['scroll_copy_frames'] <= record['sent']
                for _, _, record in trial['host'][5]), 'host copy counts exceed successful writes')
    return trial


def trial_summary(path, trial):
    scope, _, viewer, accepted, points, viewer_windows = trial['viewer']
    lengths = [right - left for left, right in zip(points, points[1:])]
    index = max(range(len(lengths)), key=lengths.__getitem__)
    internal = max(range(1, len(accepted)), key=lengths.__getitem__)
    host_, _, host, _, _, host_windows = trial['host']
    local_result = {
        'trial': path.name,
        'authenticated_session_match': True,
        'source_dimensions': [1920, 1080],
        'jpeg_quality': 85,
        'source': host,
        'viewer': viewer,
        'viewer_score_bounds_monotonic_ns': [points[0], points[-1]],
        'source_score_bounds_monotonic_ns': [host_['score_start_monotonic_ns'], host_['score_end_monotonic_ns']],
        'max_viewer_gap': gap_detail(scope, accepted, points, index),
        'max_fully_bracketed_viewer_gap': gap_detail(scope, accepted, points, internal),
        'host_retained_motion_windows': len(host_windows),
        'viewer_retained_motion_windows': len(viewer_windows),
        'viewer_retained_motion_window_seconds': scope['telemetry']['window_seconds'],
        'host_retained_motion_window_seconds': host_['telemetry']['window_seconds'],
        'scroll_copy_frames_in_retained_host_windows': sum(w['scroll_copy_frames'] for _, _, w in host_windows),
        'input_sha256': {name: hashlib.sha256((path/name).read_bytes()).hexdigest() for name in ARTIFACTS},
    }
    return local_result, index


def candidate_detail(trial, summary, index):
    viewer_scope, viewer_pixels, viewer, accepted, _, viewer_windows = trial['viewer']
    host_scope, host_pixels, source, _, _, host_windows = trial['host']
    gap = summary['max_viewer_gap']
    lo, hi = gap['start_monotonic_ns'], gap['end_monotonic_ns']
    require(index > 0 and index + 1 < len(accepted), 'candidate maximum needs both marker endpoints and a recovery sample')
    during = [r for r in viewer_pixels if lo <= r['end_monotonic_ns'] < hi]
    through_end = [*during, accepted[index]]
    signatures = Counter(r['scroll_signature'] for r in during)
    markers = Counter(r['marker'] for r in during)
    require(len(signatures) == len(markers) == 1 and None not in signatures and None not in markers,
            'viewer longest gap is not a stable valid raster plateau')
    after = accepted[index + 1]
    marker_before, marker_after, catch_up = gap['start_marker'], gap['end_marker'], after['marker']
    observed_source_rows = [r for r in host_pixels
                            if r['marker'] is not None and marker_before <= r['marker'] <= catch_up]
    expected = sorted({r['marker'] for r in observed_source_rows})
    require(expected == list(range(marker_before, catch_up + 1)),
            'source did not show each marker spanning the viewer recovery')
    first = {}
    latest = {}
    for row in observed_source_rows:
        marker = row['marker']
        first.setdefault(marker, row['end_monotonic_ns'])
        latest[marker] = row['end_monotonic_ns']
    host_zero = host_scope['score_start_monotonic_ns']
    return {
        'viewer_raster_plateau': {
            'valid_reads_from_start_through_just_before_resume': len(during),
            'distinct_marker_count': len(markers),
            'distinct_glyph_signature_count': len(signatures),
            'max_roi_read_ms': max(ms(r['end_monotonic_ns'] - r['start_monotonic_ns']) for r in through_end),
            'max_adjacent_roi_completion_gap_ms': max(ms(b['end_monotonic_ns'] - a['end_monotonic_ns'])
                                                       for a,b in zip(through_end, through_end[1:])),
            'first_resume_marker': marker_after,
            'following_marker': catch_up,
            'first_resume_to_following_marker_ms': ms(after['end_monotonic_ns'] - hi),
            'nearby_one_second_unique_bins': {i: viewer['one_second_unique_bins'][i] for i in range(13,21)},
        },
        'source_local_marker_witness': {
            'first_marker_from_score_ms': ms(first[marker_before] - host_zero),
            'first_resume_marker_from_score_ms': ms(first[marker_after] - host_zero),
            'first_catch_up_marker_from_score_ms': ms(first[catch_up] - host_zero),
            'first_to_first_resume_marker_ms': ms(first[marker_after] - first[marker_before]),
            'first_to_last_resume_marker_ms': ms(latest[marker_after] - first[marker_before]),
            'first_to_first_catch_up_marker_ms': ms(first[catch_up] - first[marker_before]),
            'source_distinct_markers_inclusive_through_catch_up': len(expected),
            'nearby_one_second_unique_bins': {i: source['one_second_unique_bins'][i] for i in range(13,21)},
        },
        'viewer_windows': nearby_windows(viewer_windows, viewer_scope, 'viewer', lo, hi),
        'host_windows': nearby_windows(host_windows, host_scope, 'host', first[marker_before], first[catch_up]),
    }


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--pair-01-b', type=Path, required=True)
    p.add_argument('--pair-01-a', type=Path)
    a = p.parse_args()
    try:
        candidate = read_trial(a.pair_01_b, 'pair-01-B')
        b, gap_index = trial_summary(a.pair_01_b, candidate)
        b['longest_gap_detail'] = candidate_detail(candidate, b, gap_index)
        result = {
            'schema_version': 1,
            'scope': ('Only the completed, authorized pair 01. Raster scores use exactly 60 seconds '
                      'after the 30-second warmup. Typed windows retain the fixture’s whole-window '
                      'selection with its post-score tail.'),
            'window_clock': ('Each endpoint clocks receipt of its own typed stderr line; '
                             'nominal start subtracts the duration reported in that line.'),
            'cross_endpoint_association': ('Visible terminal marker identities and authenticated frame scopes '
                                           'are used for association. Endpoint clock readings are never subtracted.'),
            'attribution_limit': ('Aggregate windows and copy counters do not identify an individual '
                                  'record or separate forward transport, viewer task scheduling or '
                                  'receive starvation, and ACK return. A window’s last frame sequence '
                                  'is not an exact mapping to a raster marker. No passive TCP trace '
                                  'or record receive timings were captured in this pair.'),
            'candidate': b,
        }
        if a.pair_01_a is not None:
            comparison = read_trial(a.pair_01_a, 'pair-01-A')
            result['control'] = trial_summary(a.pair_01_a, comparison)[0]
    except (ValueError, OSError, KeyError) as err:
        p.error(str(err))
    json.dump(result, sys.stdout, sort_keys=True, indent=2)
    print()


if __name__ == '__main__':
    main()
