import argparse
from contextlib import ExitStack
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import socket
import subprocess
import tempfile

from processes import clean_env, stop, wait_for


LAB = Path(__file__).resolve().parent
REPO = Path(os.environ['JWM_PHASE_REPO'])
PEER = os.environ['JWM_PHASE_PEER']
SSH = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
       '-o', 'ControlMaster=no', '-o', 'ControlPath=none', '-o', 'ServerAliveInterval=5']


def digest(path):
    with path.open('rb') as data:
        return hashlib.file_digest(data, 'sha256').hexdigest()


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.startswith('{')]


def result(run, options, host_sha):
    observed = rows(run / 'viewer' / 'observed.jsonl')
    first, = [row for row in observed if row['type'] == 'p09_start']
    last, = [row for row in observed if row['type'] == 'p09_end']
    markers = [row for row in observed if row['type'] == 'p09_frame']
    assert first['run_id'] == last['run_id'] == options.run_id
    assert all(row['run_id'] == options.run_id for row in markers) and len(markers) >= 2
    assert all(a['source_frame'] < b['source_frame'] for a, b in zip(markers, markers[1:]))
    assert all(a['monotonic_ns'] < b['monotonic_ns'] for a, b in zip(markers, markers[1:]))
    start, end = (last[f'score_{edge}_ns'] for edge in ('start', 'end'))
    assert end - start == options.seconds * 1_000_000_000
    assert all(row['scored'] == (start <= row['monotonic_ns'] < end) for row in markers)
    scored = [row['monotonic_ns'] for row in markers if row['scored']]
    gaps = [b - a for a, b in zip([start, *scored], [*scored, end])]
    assert len(scored) == last['scored_unique'] and max(gaps) == last['longest_scored_gap_ns']
    paint = rows(run / 'source' / 'paint.jsonl')
    assert any(row.get('type') == 'p09_start' and row['run_id'] == options.run_id for row in paint)
    painting, = [row for row in paint if row.get('type') == 'p09_end']
    source_fps = ((painting['submitted'] - 1) * 1e9
                  / (painting['last_submit_ns'] - painting['first_submit_ns']))
    host = [row for row in rows(run / 'source' / 'host.log') if row.get('type') == 'jwm_remote_host_stats']
    active = [row for row in host if row['h264_frames']]
    assert active and any(row['drawn_acks'] for row in active)
    assert all(row['encoded_dimensions'] == row['source_dimensions'] == [3840, 2160] for row in active)
    assert all(not row['jpeg_atlases'] and not row['hevc444_frames'] for row in host)
    assert {row['session_id'] for row in host} == {first['scope']['session_id']}
    trace = (run / 'marker-test.log').read_text()
    assert re.search(r'test result: ok\. 1 passed; 0 failed;', trace)
    payload = {
        'source_artifact': 'P09 moving markers on an owned Ubuntu Xvfb',
        'scope': 'Isolated actual 4K H.264 native Intel Wayland with uncapped SSH',
        'diagnostic_only': True,
        'rgb_backing_reuse_arm': options.arm,
        'run_id': options.run_id, 'warmup_seconds': options.warmup,
        'requested_observe_seconds': options.seconds, 'unique_markers': len(markers),
        'scored_unique_markers': len(scored), 'unique_markers_per_second': len(scored) / options.seconds,
        'longest_gap_ms': max(gaps) / 1e6,
        'source_submitted_frames_per_second': source_fps,
        'source_qualified_for_30_fps_request': source_fps >= 30,
        'host_binary_sha256': host_sha, 'viewer_binary_sha256': digest(options.viewer_bin),
        'viewer_test_binary_sha256': digest(options.lib_bin),
        'observer_start': first, 'observer_end': last,
        'host_h264_frames': sum(row['h264_frames'] for row in active),
        'host_drawn_acks': sum(row['drawn_acks'] for row in host),
    }
    (run / 'result.json').write_text(json.dumps(payload, indent=2) + '\n')
    print(json.dumps(payload, indent=2), flush=True)


def run(options):
    remote_dir = (LAB / 'remote-dir').read_text().strip()
    assert re.fullmatch(r'/tmp/jwm-p09-candidate\.[A-Za-z0-9]+', remote_dir)
    host_sha = subprocess.check_output(SSH + ['-n', PEER, 'sha256sum /tmp/jwm-p09-resolution-candidate/jwm-remote'],
                                       text=True, timeout=12).split()[0]
    assert host_sha == (LAB / 'host-binary-sha256').read_text().strip()
    assert digest(options.viewer_bin) == options.viewer_sha256, 'actual viewer binary differs from its pin'
    assert digest(options.lib_bin) == options.observer_sha256, 'observer binary differs from its pin'
    run = Path(tempfile.mkdtemp(prefix=f'phase-{options.run_id:03d}.', dir=LAB))
    label = run.name
    print(f'Native Wayland phase diagnostic directory: {run}', flush=True)
    with ExitStack() as cleanup:
        def log(name):
            return cleanup.enter_context((run / name).open('wb'))

        key = run / 'key'
        cleanup.callback(key.unlink, missing_ok=True)
        env = clean_env()
        subprocess.run([options.viewer_bin, 'keygen', '--output', key], env=env, check=True, timeout=5,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        source_command = [
            'python3', '-u', f'{remote_dir}/source.py', label, '--arm', 'treatment',
            '--width', '3840', '--height', '2160', '--fps', '30', '--paint-fps', '60',
            '--seconds', str(options.warmup + options.seconds), '--run-id', str(options.run_id),
            '--cap', '0', '--send-buffer', '0', '--recv-buffer', '0', '--capture-scaling', 'auto',
            '--feature-flag', 'JWM_REMOTE_PARALLEL_YUV420', '--enable-at', 'host',
        ]
        ready_path = run / 'remote-ready.jsonl'
        source = subprocess.Popen(SSH + [PEER, shlex.join(source_command)], stdin=subprocess.PIPE,
                                  stdout=log(ready_path.name), stderr=log('remote-stderr.log'))
        cleanup.callback(stop, source, natural=True)
        source.stdin.write(key.read_bytes())
        source.stdin.flush()

        def port_announced():
            ready = rows(ready_path)
            return ready[0]['upstream_port'] if ready else None

        remote_port = wait_for(source, port_announced, 20)
        with socket.socket() as choose:
            choose.bind(('127.0.0.1', 0))
            local_port = choose.getsockname()[1]
        ssh_log = run / 'tunnel.log'
        tunnel = subprocess.Popen(SSH + ['-vN', '-o', 'ExitOnForwardFailure=yes', '-L',
                                          f'127.0.0.1:{local_port}:127.0.0.1:{remote_port}', PEER],
                                  stdin=subprocess.DEVNULL, stdout=log(ssh_log.name), stderr=subprocess.STDOUT)
        cleanup.callback(stop, tunnel)
        wait_for(tunnel, lambda: 'Local forwarding listening on 127.0.0.1 port' in ssh_log.read_text(), 12)
        print(f'Starting owned Wayland marker test {run}', flush=True)
        env.update(JWM_PHASE_REAL_VIEWER=str(options.viewer_bin), JWM_PHASE_EVIDENCE=str(run / 'viewer'),
                   JWM_PHASE_REUSE_ARM=options.arm)
        command = [REPO / 'scripts/test-remote-wayland-4k-marker.sh', options.lib_bin,
                   LAB / 'viewer-stats-wrapper.sh',
                   '/dev/dri/renderD128', f'127.0.0.1:{local_port}', key, str(options.run_id),
                   run / 'viewer', str(options.warmup), str(options.seconds)]
        outcome = subprocess.run(command, env=env, stdout=log('marker-test.log'), stderr=subprocess.STDOUT,
                                 timeout=options.warmup + options.seconds + 55)
        if outcome.returncode == 0:
            assert source.wait(timeout=15) == 0
    subprocess.run(['scp', '-Bqr', f'{PEER}:{remote_dir}/{label}', str(run / 'source')],
                   check=True, timeout=20, stderr=subprocess.PIPE)
    if outcome.returncode:
        raise RuntimeError(f'Wayland marker test exited {outcome.returncode}; see {run / "marker-test.log"}')
    assert digest(options.viewer_bin) == options.viewer_sha256, 'actual viewer binary changed during run'
    assert digest(options.lib_bin) == options.observer_sha256, 'observer binary changed during run'
    result(run, options, host_sha)
    from validate_reuse import write_diagnostic
    write_diagnostic(run)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('lib_bin', type=Path)
    parser.add_argument('viewer_bin', type=Path)
    parser.add_argument('--viewer-sha256', required=True)
    parser.add_argument('--observer-sha256', required=True)
    parser.add_argument('--arm', required=True, choices=('A', 'B'))
    parser.add_argument('--run-id', type=int, default=91, choices=range(1, 256))
    parser.add_argument('--warmup', type=int, default=6, choices=range(0, 121))
    parser.add_argument('--seconds', type=int, default=18, choices=range(3, 121))
    run(parser.parse_args())
