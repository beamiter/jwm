#!/usr/bin/env bash
# Only used by the isolated phase diagnostic. The Rust test still owns the viewer PID.
set -euo pipefail
lab=$(cd "$(dirname "$0")" && pwd)
[[ ${1-} == session && -x ${JWM_PHASE_REAL_VIEWER:?} && -d ${JWM_PHASE_EVIDENCE:?} ]]
case ${JWM_PHASE_REUSE_ARM:?} in
  A) unset JWM_REMOTE_WAYLAND_REUSE_RGB ;;
  B) export JWM_REMOTE_WAYLAND_REUSE_RGB=1 ;;
  *) exit 2 ;;
esac
exec "$JWM_PHASE_REAL_VIEWER" "$@" --stats-json \
    2> >(python3 -B "$lab/tee_stderr.py" "$JWM_PHASE_EVIDENCE" >&2)
