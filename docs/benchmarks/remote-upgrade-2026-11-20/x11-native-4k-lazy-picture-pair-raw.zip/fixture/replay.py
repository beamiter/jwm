"""Reproduce the recorded gate from raw 4K X11 endpoint evidence."""

import argparse
import json
from pathlib import Path

from evidence import analyze, records, require
from processes import sha256
from run import REMOTE_PINS, summarize


def load(path):
    return json.loads(path.read_text())


def replay(run):
    protocol = load(run / 'protocol.json')
    require(protocol['remote_pins'] == REMOTE_PINS, 'unexpected remote source manifest')
    require(all(sha256(Path(__file__).with_name(name)) == digest
                for name, digest in protocol['fixture_sha256'].items()),
            'live benchmark and replay source pins differ')
    rows = []
    for trial in protocol['schedule']:
        case = run / trial['name']
        result = load(case / 'result.json')
        require(all(result[key] == value for key, value in trial.items()), 'slot differs from schedule')
        if result['status'] == 'valid':
            require(load(case / 'source-pins-before.json') == load(case / 'source-pins-after.json')
                    == REMOTE_PINS, 'source pins changed between trial boundaries')
            control = load(case / 'viewer-control.json')
            require(control['viewer_sha256'] == protocol['viewer_sha256'] and control['mode'] == trial['mode']
                    and control['lazy_picture_env'] == ('1' if trial['mode'] == 'on' else None),
                    'viewer launch controls differ from protocol')
            if trial['mode'] != 'cpu':
                display = load(case / 'display' / 'result.json')
                require(display['production_doctor_passed'] is True
                        and display['compositor_exit'] == 0
                        and display['binary_sha256']['doctor'] == protocol['viewer_sha256'],
                        'private Intel display attestation differs from the live manifest')
            actual, host, viewer, markers = analyze(case, trial)
            actual['status'] = 'valid'
            require(actual == result, f'{trial["name"]} does not reproduce recorded statistics')
            for lane, kept in (('host', host), ('viewer', viewer), ('markers', markers)):
                require(records(case / f'retained-{lane}.jsonl') == kept, f'{lane} retention differs')
        else:
            require(result.get('marker') is None and result.get('meets_27_fps_gate') is None,
                    'unsuccessful or preflight-only attempt claimed scored evidence')
        rows.append(result)
    summary = summarize(protocol['study'], rows)
    require(summary == load(run / 'summary.json'), 'comparison summary does not replay')
    return summary


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('run', type=Path)
    args = parser.parse_args()
    print(json.dumps(replay(args.run), indent=2, allow_nan=False))
