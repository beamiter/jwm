"""Network measurement helpers shared by the local controller and Ubuntu worker."""
import ipaddress
import json
import math
import os
from pathlib import Path
import re
import shutil
import socket
import subprocess
import sys
import time


PING_COUNT = 100
PING_INTERVAL = 0.2
TCP_SECONDS = 8
TCP_BYTE_CAP = 256 * 1024 * 1024
BLOCK_BYTES = 64 * 1024
ECHO = re.compile(
    r'^\[(\d+)\.(\d{1,9})\]\s+.*?\bicmp_seq=(\d+)\b.*?\btime([=<])'
    r'(\d+(?:\.\d+)?)\s*ms(?:\s+\(DUP!\))?\s*$'
)
PING_TOTAL = re.compile(r'^(\d+) packets transmitted, (\d+) received\b', re.M)


def ipv4(value):
    return str(ipaddress.IPv4Address(value))


def run_numeric(argv, timeout):
    return subprocess.run(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                          stderr=subprocess.DEVNULL, encoding='utf-8', errors='replace',
                          env=dict(os.environ, LC_ALL='C'), timeout=timeout)


def route(address, expected_interface):
    result = run_numeric(['ip', '-j', '-4', 'route', 'get', ipv4(address)], 4)
    rows = json.loads(result.stdout) if result.returncode == 0 else []
    if len(rows) != 1:
        raise RuntimeError('selected IPv4 route unavailable or ambiguous')
    record, = rows
    device = record.get('dev')
    if device != expected_interface:
        raise RuntimeError('selected IPv4 route did not use the expected lab interface')
    return ipv4(record.get('prefsrc', record.get('src'))), classify_interface(device)


def classify_interface(device):
    directory = Path('/sys/class/net') / device

    def small_value(name, allowed):
        try:
            value = (directory / name).read_text().strip()
            return value if re.fullmatch(allowed, value) else None
        except (OSError, UnicodeError):
            return None

    def number(name):
        value = small_value(name, r'[0-9]{1,8}')
        return int(value) if value is not None else None

    wireless = (directory / 'wireless').is_dir() or (directory / 'phy80211').exists()
    speed = number('speed') if not wireless else None
    kind = ('wifi' if wireless else
            'ethernet' if number('type') == 1 and (directory / 'device').exists()
            and speed is not None and speed > 0 else 'unknown')
    return {'interface': device, 'classification': kind,
            'carrier': number('carrier'), 'operstate': small_value('operstate', r'[a-z]{2,12}'),
            'reported_ethernet_link_speed_mbps': speed if kind == 'ethernet' else None,
            'reported_ethernet_duplex': small_value('duplex', r'(full|half)') if kind == 'ethernet' else None}


def summary(values):
    if not values:
        return None
    ordered = sorted(values)
    return {'min': ordered[0], 'p50_nearest_rank': ordered[math.ceil(len(ordered) * .5) - 1],
            'p95_nearest_rank': ordered[math.ceil(len(ordered) * .95) - 1], 'max': ordered[-1]}


def parse_ping(text, expected_count):
    totals = PING_TOTAL.findall(text)
    if len(totals) != 1 or int(totals[0][0]) != expected_count:
        raise ValueError('ICMP output has no complete expected transmission count')
    if not 0 <= int(totals[0][1]) <= expected_count:
        raise ValueError('ICMP output has an invalid reply count')
    records = []
    for line in text.splitlines():
        match = ECHO.fullmatch(line)
        if not match:
            continue
        whole, fraction, sequence, operator, value = match.groups()
        sequence = int(sequence)
        if not 1 <= sequence <= expected_count:
            raise ValueError('ICMP sequence outside selected sample scope')
        records.append({'sequence': sequence, 'arrival_realtime_ns': int(whole) * 10**9
                        + int(fraction.ljust(9, '0')), 'rtt_ms': float(value),
                        'rtt_comparison': operator, 'duplicate_reported': line.rstrip().endswith('(DUP!)')})
    first = {}
    for row in records:
        if not row['duplicate_reported']:
            first.setdefault(row['sequence'], row)
    if len(first) != int(totals[0][1]):
        raise ValueError('parsed ICMP replies disagree with the tool summary')
    exact = {seq: row['rtt_ms'] for seq, row in first.items() if row['rtt_comparison'] == '='}
    differences = [abs(value - exact[seq - 1]) for seq, value in exact.items() if seq - 1 in exact]
    missing = [seq for seq in range(1, expected_count + 1) if seq not in first]
    return {'transmitted': expected_count, 'unique_echo_replies': len(first),
            'unanswered_sequences': missing, 'echo_loss_fraction': len(missing) / expected_count,
            'duplicate_replies': len(records) - len(first),
            'rtt_exact_count': len(exact), 'rtt_upper_bound_count': len(first) - len(exact),
            'rtt_ms': summary(list(exact.values())),
            'consecutive_exact_success_pairs': len(differences),
            'absolute_consecutive_rtt_difference_ms': summary(differences),
            'raw_numeric_echoes': records}


def echo(address, interface):
    result = run_numeric(['ping', '-4', '-n', '-D', '-I', interface, '-c', str(PING_COUNT),
                          '-i', str(PING_INTERVAL), '-W', '1', ipv4(address)], 34)
    if result.returncode not in (0, 1):
        raise RuntimeError('ping did not return a complete selected-interface measurement')
    return parse_ping(result.stdout, PING_COUNT)


def send_bytes(connection):
    payload = memoryview(os.urandom(BLOCK_BYTES))
    begin = time.monotonic_ns()
    deadline = begin + TCP_SECONDS * 10**9
    count = 0
    while count < TCP_BYTE_CAP and time.monotonic_ns() < deadline:
        written = connection.send(payload[:min(BLOCK_BYTES, TCP_BYTE_CAP - count)])
        if not written:
            raise RuntimeError('TCP sender made no progress')
        count += written
    completed = time.monotonic_ns()
    connection.shutdown(socket.SHUT_WR)
    return {'bytes': count, 'start_monotonic_ns': begin, 'end_monotonic_ns': completed,
            'stop_condition': 'byte_cap' if count == TCP_BYTE_CAP else 'duration'}


def receive_bytes(connection):
    buffer = bytearray(BLOCK_BYTES)
    begin = time.monotonic_ns()
    deadline = begin + (TCP_SECONDS + 6) * 10**9
    count = 0
    last_bytes = None
    while time.monotonic_ns() < deadline:
        received = connection.recv_into(buffer)
        received_at = time.monotonic_ns()
        if not received:
            if not count or last_bytes <= begin:
                raise RuntimeError('TCP receiver had no measured bytes')
            return {'bytes': count, 'start_monotonic_ns': begin, 'last_byte_monotonic_ns': last_bytes,
                    'eof_monotonic_ns': received_at}
        count += received
        last_bytes = received_at
        if count > TCP_BYTE_CAP:
            raise RuntimeError('TCP receiver exceeded the byte cap')
    raise RuntimeError('TCP receiver exceeded the measurement deadline')


def exact_bytes(connection, size):
    data = bytearray()
    while len(data) < size:
        part = connection.recv(size - len(data))
        if not part:
            raise RuntimeError('connection closed before the private probe handshake')
        data.extend(part)
    return bytes(data)


def report(value):
    print(json.dumps(value, separators=(',', ':')), flush=True)


def checked_ssh_addresses(local, peer, device):
    fields = os.environ.get('SSH_CONNECTION', '').split()
    if len(fields) != 4 or fields[0] != local or fields[2] != peer:
        raise RuntimeError('SSH socket addresses differ from the selected LAN endpoints')
    source, link = route(local, device)
    if source != peer:
        raise RuntimeError('Ubuntu return-route source differs from the SSH endpoint')
    return link


def worker_inspect(local, peer, device, with_ping):
    link = checked_ssh_addresses(local, peer, device)
    result = {'route': link, 'iperf3_available': shutil.which('iperf3') is not None}
    if with_ping:
        result['icmp'] = echo(local, device)
    report(result)


def worker_transfer(local, peer, device, direction):
    checked_ssh_addresses(local, peer, device)
    capability = sys.stdin.buffer.readline(65).strip()
    if not re.fullmatch(rb'[0-9a-f]{64}', capability):
        raise RuntimeError('the private controller handshake was not received')
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
        listener.bind(('127.0.0.1', 0))
        listener.listen(1)
        listener.settimeout(9)
        report({'loopback_port': listener.getsockname()[1]})
        connection, (client_ip, _) = listener.accept()
        listener.close()
        with connection:
            connection.settimeout(2.5)
            if client_ip != '127.0.0.1' or exact_bytes(connection, len(capability)) != capability:
                raise RuntimeError('unexpected loopback probe client')
            connection.sendall(b'\x01')
            transfer = send_bytes(connection) if direction == 'ubuntu_to_mint' else receive_bytes(connection)
    report(transfer)


if __name__ == '__main__':
    # The SSH controller supplies a fixed command, addresses from the same route,
    # and no host credentials or identifier output from the peer.
    action, local, peer, device, *options = sys.argv[1:]
    try:
        local, peer = ipv4(local), ipv4(peer)
        if action == 'inspect' and options in ([], ['ping']):
            worker_inspect(local, peer, device, bool(options))
        elif action == 'transfer' and options in (['ubuntu_to_mint'], ['mint_to_ubuntu']):
            worker_transfer(local, peer, device, options[0])
        else:
            raise RuntimeError('invalid network probe worker operation')
    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as error:
        # The controller collects categories. External command stderr may
        # contain addresses and is deliberately discarded.
        report({'worker_error': type(error).__name__})
        raise SystemExit(1)
