"""Offline parser and counter tests. Does not launch commands or open sockets."""
import json
import unittest
from unittest.mock import MagicMock, patch

import characterize
import net_probe


class PingSamples(unittest.TestCase):
    def test_reordered_duplicate_loss_and_upper_bound(self):
        data = """
PING redacted.peer (192.0.2.1) 56(84) bytes of data.
[1790000000.100001] 64 bytes from 192.0.2.1: icmp_seq=2 ttl=64 time=4.00 ms
[1790000000.200001] 64 bytes from 192.0.2.1: icmp_seq=1 ttl=64 time=2.00 ms
[1790000000.300001] 64 bytes from 192.0.2.1: icmp_seq=2 ttl=64 time=5.00 ms (DUP!)
[1790000000.400001] 64 bytes from 192.0.2.1: icmp_seq=4 ttl=64 time<1.00 ms
[1790000000.500001] 64 bytes from 192.0.2.1: icmp_seq=5 ttl=64 time=8.00 ms
5 packets transmitted, 4 received, +1 duplicates, 20% packet loss, time 804ms
"""
        result = net_probe.parse_ping(data, 5)
        self.assertEqual(result['echo_loss_fraction'], .2)
        self.assertEqual(result['unanswered_sequences'], [3])
        self.assertEqual(result['duplicate_replies'], 1)
        self.assertEqual(result['rtt_exact_count'], 3)
        self.assertEqual(result['rtt_upper_bound_count'], 1)
        self.assertEqual(result['rtt_ms']['p50_nearest_rank'], 4)
        self.assertEqual(result['rtt_ms']['p95_nearest_rank'], 8)
        self.assertEqual(result['consecutive_exact_success_pairs'], 1)
        self.assertEqual(result['absolute_consecutive_rtt_difference_ms']['max'], 2)
        self.assertEqual(result['raw_numeric_echoes'][0]['arrival_realtime_ns'], 1790000000100001000)
        self.assertNotIn('192.0.2.1', json.dumps(result))
        self.assertNotIn('redacted.peer', json.dumps(result))

    def test_complete_absence_and_bad_clip(self):
        result = net_probe.parse_ping('2 packets transmitted, 0 received, 100% packet loss', 2)
        self.assertEqual(result['unanswered_sequences'], [1, 2])
        self.assertIsNone(result['rtt_ms'])
        self.assertIsNone(result['absolute_consecutive_rtt_difference_ms'])
        with self.assertRaisesRegex(ValueError, 'transmission count'):
            net_probe.parse_ping('1 packets transmitted, 0 received, 100% packet loss', 2)
        with self.assertRaisesRegex(ValueError, 'replies disagree'):
            net_probe.parse_ping('2 packets transmitted, 1 received, 50% packet loss', 2)


class TransferSamples(unittest.TestCase):
    def test_receiver_rate_is_independent_of_sender_clock(self):
        sender = dict(bytes=1_000_000, start_monotonic_ns=23_000_000_000,
                      end_monotonic_ns=24_000_000_000, stop_condition='duration')
        receiver = dict(bytes=1_000_000, start_monotonic_ns=2_000_000_000,
                        last_byte_monotonic_ns=3_000_000_000, eof_monotonic_ns=3_500_000_000)
        summary = characterize.throughput_report('ubuntu_to_mint', sender, receiver)
        self.assertEqual(summary['receiver_observed_goodput_mbps'], 8)
        self.assertEqual(summary['receiver_observed_duration_seconds'], 1)
        with self.assertRaisesRegex(ValueError, 'byte counts'):
            characterize.throughput_report('ubuntu_to_mint', sender, receiver | {'bytes': 500})

    def test_sender_stops_at_exact_byte_cap(self):
        with patch.multiple(net_probe, TCP_BYTE_CAP=7, BLOCK_BYTES=3), \
                patch.object(net_probe.time, 'monotonic_ns', side_effect=[0, 1, 2, 3, 4]):
            fake = MagicMock()
            fake.send.side_effect = lambda payload: len(payload)
            reported = net_probe.send_bytes(fake)
        self.assertEqual(reported['bytes'], 7)
        self.assertEqual(reported['stop_condition'], 'byte_cap')
        self.assertEqual([len(call.args[0]) for call in fake.send.call_args_list], [3, 3, 1])
        fake.shutdown.assert_called_once()

    def test_receiver_rejects_byte_overrun(self):
        fake = MagicMock()
        fake.recv_into.return_value = 5
        with patch.object(net_probe, 'TCP_BYTE_CAP', 4):
            with self.assertRaisesRegex(RuntimeError, 'byte cap'):
                net_probe.receive_bytes(fake)


class SelectedRoute(unittest.TestCase):
    def test_rejects_wrong_device_and_ignores_ip_identifiers_in_classification(self):
        fake = MagicMock(returncode=0)
        fake.stdout = json.dumps([{'dev': 'wrong', 'prefsrc': '192.0.2.2'}])
        with patch.object(net_probe, 'run_numeric', return_value=fake):
            with self.assertRaisesRegex(RuntimeError, 'expected lab interface'):
                net_probe.route('192.0.2.1', 'eno1')

    def test_rejects_mismatched_ssh_peer(self):
        with patch.dict(net_probe.os.environ, {'SSH_CONNECTION': '192.0.2.3 1 192.0.2.2 22'}):
            with self.assertRaisesRegex(RuntimeError, 'socket addresses differ'):
                net_probe.checked_ssh_addresses('192.0.2.1', '192.0.2.2', 'wlp3s0')


if __name__ == '__main__':
    unittest.main()
