#!/usr/bin/env python3
"""Characterize the existing authorized Mint/Ubuntu lab route without network changes."""
import argparse
from contextlib import ExitStack, suppress
import fcntl
import json
import os
from pathlib import Path
import secrets
import selectors
import shlex
import shutil
import socket
import stat
import subprocess
import tempfile
import time

import net_probe as probe


HERE = Path(__file__).resolve().parent
LOCK = '/tmp/jwm-p08-p09-release/benchmark.lock'
PEER_IPV4 = '192.168.0.78'
DESTINATION = 'ubuntu@' + PEER_IPV4
MINT_DEVICE = 'eno1'
UBUNTU_DEVICE = 'wlp3s0'
SSH = ['ssh', '-4', '-T', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
       '-o', 'ConnectionAttempts=1', '-o', 'StrictHostKeyChecking=yes',
       '-o', 'ForwardX11=no', '-o', 'ForwardAgent=no', '-o', 'ProxyCommand=none',
       '-o', 'ProxyJump=none', '-o', 'ExitOnForwardFailure=yes',
       '-o', 'ServerAliveInterval=8', '-o', 'ServerAliveCountMax=2',
       '-o', 'Compression=no', '-o', 'StreamLocalBindMask=0177',
       '-o', 'StreamLocalBindUnlink=no']


def close_process(process):
    if process.stdin is not None and not process.stdin.closed:
        process.stdin.close()
    if process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=3)
    if process.stdout is not None:
        process.stdout.close()


def write_private(path, record):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(record, indent=2, ensure_ascii=False) + '\n')
    temporary.chmod(0o600)
    temporary.replace(path)


def ssh(control, local, *options):
    return SSH + ['-b', local, '-S', str(control), *options]


def command(control, local, source, action, *options):
    args = ['python3', '-B', '-u', '-c', source, action, local, PEER_IPV4,
            UBUNTU_DEVICE, *options]
    return ssh(control, local, '--', DESTINATION, shlex.join(args))


def control_operation(control, local, *options):
    return subprocess.run(ssh(control, local, '-O', *options, '--', DESTINATION),
                          stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                          stderr=subprocess.DEVNULL, timeout=6).returncode


def forget_forward(control, local, forward):
    with suppress(OSError, subprocess.SubprocessError):
        control_operation(control, local, 'cancel', '-L', forward)


def wait_master(master, control, local):
    deadline = time.monotonic() + 10
    while master.poll() is None and time.monotonic() < deadline:
        if control_operation(control, local, 'check') == 0:
            return
        time.sleep(.05)
    raise RuntimeError('private SSH master did not become ready')


def worker_json(raw, status=0):
    result = json.loads(raw)
    if not isinstance(result, dict) or status or 'worker_error' in result:
        raise RuntimeError('peer worker did not complete the selected measurement')
    return result


def inspect_peer(control, local, source, with_ping=False):
    result = subprocess.run(command(control, local, source, 'inspect', *(['ping'] if with_ping else [])),
                            stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                            stderr=subprocess.DEVNULL, timeout=42 if with_ping else 12)
    return worker_json(result.stdout, result.returncode)


def first_message(stream):
    deadline = time.monotonic() + 8
    message = bytearray()
    with selectors.DefaultSelector() as ready:
        ready.register(stream, selectors.EVENT_READ)
        while len(message) < 512:
            remaining = deadline - time.monotonic()
            if remaining <= 0 or not ready.select(remaining):
                raise RuntimeError('peer loopback listener did not become ready')
            character = os.read(stream.fileno(), 1)
            if not character:
                raise RuntimeError('peer worker ended before listening')
            if character == b'\n':
                return worker_json(message)
            message.extend(character)
    raise RuntimeError('peer readiness record exceeded its allowed length')


def throughput_report(direction, sender, receiver):
    count = receiver['bytes']
    if not 0 < count <= probe.TCP_BYTE_CAP or sender['bytes'] != count:
        raise ValueError('sender and receiver byte counts do not match')
    if not receiver['start_monotonic_ns'] < receiver['last_byte_monotonic_ns'] <= receiver['eof_monotonic_ns']:
        raise ValueError('receiver reports an invalid transfer span')
    if not sender['start_monotonic_ns'] < sender['end_monotonic_ns']:
        raise ValueError('sender clock did not advance')
    if sender['stop_condition'] != ('byte_cap' if count == probe.TCP_BYTE_CAP else 'duration'):
        raise ValueError('invalid transfer stop condition')
    elapsed = receiver['last_byte_monotonic_ns'] - receiver['start_monotonic_ns']
    return {'direction': direction, 'receiver_observed_goodput_mbps': 8000 * count / elapsed,
            'receiver_observed_duration_seconds': elapsed / 10**9,
            'sender': sender, 'receiver': receiver}


def characterize_direction(control, local, source, runtime, direction):
    short = 'from-ubuntu' if direction == 'ubuntu_to_mint' else 'to-ubuntu'
    unix_socket = runtime / short
    capability = secrets.token_hex(32).encode()
    worker = subprocess.Popen(command(control, local, source, 'transfer', direction),
                              stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                              bufsize=0)
    with ExitStack() as cleanup:
        cleanup.callback(close_process, worker)
        worker.stdin.write(capability + b'\n')
        worker.stdin.close()
        message = first_message(worker.stdout)
        port = message.get('loopback_port')
        if not isinstance(port, int) or not 1 <= port <= 65535:
            raise RuntimeError('peer loopback listener did not report a usable port')
        forward = f'{unix_socket}:127.0.0.1:{port}'
        if control_operation(control, local, 'forward', '-L', forward) != 0:
            raise RuntimeError('private Unix socket forwarding could not be established')
        cleanup.callback(forget_forward, control, local, forward)
        mode = unix_socket.stat().st_mode
        if not stat.S_ISSOCK(mode) or mode & 0o077:
            raise RuntimeError('local tunnel socket is not private')
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as connection:
            connection.settimeout(2.5)
            connection.connect(str(unix_socket))
            connection.sendall(capability)
            if probe.exact_bytes(connection, 1) != b'\x01':
                raise RuntimeError('peer did not confirm the private stream')
            result = (probe.receive_bytes(connection) if direction == 'ubuntu_to_mint'
                      else probe.send_bytes(connection))
        # Avoid Popen.communicate attempting to flush the already closed stdin.
        worker.stdin = None
        raw, _ = worker.communicate(timeout=6)
        peer = worker_json(raw, worker.returncode)
        sender, receiver = (peer, result) if direction == 'ubuntu_to_mint' else (result, peer)
        return throughput_report(direction, sender, receiver)


def collect(run):
    source = (HERE / 'net_probe.py').read_text()
    artifact = run / 'result.json'
    report = {
        'status': 'started',
        'scope': 'Independent IPv4 measurement of the existing authorized Wi-Fi/Ethernet lab route.',
        'icmp': {'configuration': {'count_each_direction': probe.PING_COUNT,
                                    'interpacket_seconds': probe.PING_INTERVAL,
                                    'variation': 'absolute difference across consecutive successful exact sequence pairs'}},
        'tcp': {'configuration': {'sender_target_seconds': probe.TCP_SECONDS,
                                   'sender_maximum_bytes': probe.TCP_BYTE_CAP,
                                   'transport': 'private OpenSSH forward with compression disabled',
                                   'rate_scope': 'receiver TCP goodput through SSH including endpoint/cipher effects'},
                'directions': []},
    }
    stage = 'selected_local_route'
    try:
        local, mint = probe.route(PEER_IPV4, MINT_DEVICE)
        if mint['classification'] != 'ethernet':
            raise RuntimeError('Mint route did not verify as Ethernet')
        report['mint'] = {'route_before': mint, 'iperf3_available': shutil.which('iperf3') is not None}
        stage = 'private_ssh_master'
        # The short control path avoids sockaddr_un length limits and remains private.
        with ExitStack() as cleanup:
            runtime = Path(cleanup.enter_context(tempfile.TemporaryDirectory(prefix='jwnet.')))
            control = runtime / 'control'
            master = subprocess.Popen(ssh(control, local, '-N', '-M', '-o', 'ControlPersist=no',
                                           '-o', 'ClearAllForwardings=yes', '--', DESTINATION),
                                      stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                      stderr=subprocess.DEVNULL)
            cleanup.callback(close_process, master)
            wait_master(master, control, local)
            stage = 'selected_peer_route'
            peer = inspect_peer(control, local, source)
            if peer['route']['classification'] != 'wifi':
                raise RuntimeError('Ubuntu route did not verify as Wi-Fi')
            report['ubuntu'] = {'route_before': peer['route'], 'iperf3_available': peer['iperf3_available']}

            stage = 'mint_icmp'
            report['icmp']['mint_to_ubuntu'] = probe.echo(PEER_IPV4, MINT_DEVICE)
            write_private(artifact, report)

            stage = 'ubuntu_icmp'
            peer = inspect_peer(control, local, source, with_ping=True)
            report['icmp']['ubuntu_to_mint'] = peer['icmp']
            write_private(artifact, report)

            for direction in ('mint_to_ubuntu', 'ubuntu_to_mint'):
                stage = direction + '_ssh_goodput'
                report['tcp']['directions'].append(
                    characterize_direction(control, local, source, runtime, direction))
                write_private(artifact, report)

            stage = 'verify_route_after'
            local_after, mint_after = probe.route(PEER_IPV4, MINT_DEVICE)
            peer_after = inspect_peer(control, local, source)['route']
            report['mint']['route_after'] = mint_after
            report['ubuntu']['route_after'] = peer_after
            if local_after != local or mint_after['classification'] != 'ethernet' or peer_after['classification'] != 'wifi':
                raise RuntimeError('selected IPv4 route or interface classification changed')
        report['status'] = 'completed'
    except (OSError, ValueError, RuntimeError, KeyError, TypeError, subprocess.SubprocessError) as error:
        # Avoid putting raw subprocess stderr, addresses, arguments or user IDs in evidence.
        report.update(status='failed', failed_stage=stage, error_category=type(error).__name__)
    write_private(artifact, report)
    return report['status']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.parse_args()
    with open(LOCK, 'a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        run = Path(tempfile.mkdtemp(prefix='trace.', dir=HERE))
        print(run, flush=True)
        status = collect(run)
    if status != 'completed':
        raise SystemExit(1)


if __name__ == '__main__':
    main()
