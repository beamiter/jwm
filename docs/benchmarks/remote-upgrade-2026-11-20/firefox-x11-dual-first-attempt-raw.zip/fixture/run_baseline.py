#!/usr/bin/env python3
"""Score real Firefox static and motion phases on two owned local Xvfb displays."""
import argparse
from contextlib import ExitStack, suppress
import ctypes as C
import fcntl
import hashlib
import json
import os
import platform
from pathlib import Path
import re
import signal
import subprocess
import tempfile
import threading
import time
import traceback

from processes import clean_env, get_display, start_display, stop, wait_for
from score import (MEASURE_SECONDS, REQUESTED_FPS, SECOND, TAIL_SECONDS, WARM_SECONDS,
                   score_pixels, write_json)

HERE = Path(__file__).resolve().parent
RELEASE = Path('/tmp/jwm-p08-p09-release/jwm-remote')


class Image(C.Structure):
    _fields_ = [(name, C.c_int) for name in ('width', 'height', 'xoffset', 'format')]
    _fields_ += [('data', C.c_void_p)]
    _fields_ += [(name, C.c_int) for name in (
        'byte_order', 'bitmap_unit', 'bitmap_bit_order', 'bitmap_pad', 'depth',
        'bytes_per_line', 'bits_per_pixel')]
    _fields_ += [(name, C.c_ulong) for name in ('red_mask', 'green_mask', 'blue_mask')]


class Pixels:
    def __init__(self, display):
        self.xlib = C.CDLL('libX11.so.6')
        for name, inputs, result in (
            ('XOpenDisplay', [C.c_char_p], C.c_void_p),
            ('XCloseDisplay', [C.c_void_p], C.c_int),
            ('XDefaultRootWindow', [C.c_void_p], C.c_ulong),
            ('XGetImage', [C.c_void_p, C.c_ulong, C.c_int, C.c_int, C.c_uint,
                           C.c_uint, C.c_ulong, C.c_int], C.POINTER(Image)),
            ('XDestroyImage', [C.POINTER(Image)], C.c_int),
        ):
            fn = getattr(self.xlib, name)
            fn.argtypes, fn.restype = inputs, result
        self.display = self.xlib.XOpenDisplay(display.encode())
        if not self.display:
            raise RuntimeError(f'could not open owned X display {display}')
        self.root = self.xlib.XDefaultRootWindow(self.display)

    def close(self):
        self.xlib.XCloseDisplay(self.display)

    def crop(self, xid, x, y, width, height):
        ptr = self.xlib.XGetImage(self.display, xid, x, y, width, height, C.c_ulong(-1), 2)
        if not ptr:
            raise RuntimeError('owned drawable did not return pixels')
        try:
            info = ptr.contents
            layout = (info.width, info.height, info.byte_order, info.bits_per_pixel,
                      info.red_mask, info.green_mask, info.blue_mask)
            if layout != (width, height, 0, 32, 0xff0000, 0xff00, 0xff):
                raise RuntimeError(f'unexpected owned Xvfb pixel format {layout}')
            packed = C.string_at(info.data, info.bytes_per_line * height)
            return tuple(packed[y:y + width * 4]
                         for y in range(0, len(packed), info.bytes_per_line))
        finally:
            self.xlib.XDestroyImage(ptr)


def tile_span(pixels):
    cyan = [i for i, (b, g, r) in enumerate(zip(pixels[0::4], pixels[1::4], pixels[2::4]))
            if r < 100 and g - r >= 70 and b - r >= 100]
    if not 51 <= len(cyan) <= 75 or not 56 <= cyan[-1] - cyan[0] + 1 <= 72:
        return None
    return cyan[1] - 1


def find_static_page(rows):
    # Locate the complete painted CSS tile in the captured drawable. The
    # browser viewport and its rendering child determine where it lands.
    last_x = None
    start = 0
    for y, row in enumerate((*rows, b'')):
        x = tile_span(row)
        if x == last_x:
            continue
        if last_x is not None and 56 <= y - start <= 72 and start >= 32:
            header_end = start - 8
            header_top = header_end
            header_bgr = bytes((0x20, 0x18, 0x10))
            while header_top and rows[header_top - 1][16:19] == header_bgr:
                header_top -= 1
            if header_end - header_top > 45:
                return last_x, start, header_top
        start, last_x = y, x
    return None


def write_capture(path, rows):
    with path.open('wb') as image:
        image.write(f'P6\n{len(rows[0]) // 4} {len(rows)}\n255\n'.encode())
        for row in rows:
            rgb = bytearray(len(row) // 4 * 3)
            rgb[0::3], rgb[1::3], rgb[2::3] = row[2::4], row[1::4], row[0::4]
            image.write(rgb)


def sample(pixels, xid, width, top):
    rows = pixels.crop(xid, 0, top + 28, width, 3)
    positions = sorted(pos for row in rows if (pos := tile_span(row)) is not None)
    x = positions[len(positions) // 2] if len(positions) >= 2 else None
    text = pixels.crop(xid, 0, top + 76, 33, 32)
    mask = bytes(g > 137 for row in text for g in row[1::4])
    signature = hashlib.blake2s(mask, digest_size=8).hexdigest() if sum(mask) >= 10 else None
    return x, signature


def wait_for_window(process, display, title, env, tree_log, seconds, geometry=None):
    pattern = rf'^ +(0x[0-9a-f]+) "[^"\n]*{re.escape(title)}[^"\n]*":'
    if geometry is not None:
        size = f'{geometry[0]}x{geometry[1]}+0+0'
        pattern += rf' [^\n]* {re.escape(size)}(?= |$)'
    tree = ''

    def inspect():
        nonlocal tree
        tree = subprocess.check_output(['xwininfo', '-display', display, '-root', '-tree'],
                                       env=env, text=True, timeout=4)
        matches = re.findall(pattern, tree, re.MULTILINE | re.IGNORECASE)
        if len(matches) > 1:
            raise RuntimeError(f'more than one owned drawable for {title!r}')
        return int(matches[0], 16) if matches else None

    try:
        return wait_for(process, inspect, seconds)
    finally:
        tree_log.write_text(tree)


def stop_group(process):
    with suppress(ProcessLookupError):
        os.killpg(process.pid, signal.SIGTERM)
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        with suppress(ProcessLookupError):
            os.killpg(process.pid, signal.SIGKILL)
        process.wait(timeout=5)
    with suppress(ProcessLookupError):
        os.killpg(process.pid, signal.SIGKILL)


def collect_phase(name, run_dir, lanes, processes, width, top):
    phase_start = time.monotonic_ns()
    start = phase_start + WARM_SECONDS * SECOND
    end = start + MEASURE_SECONDS * SECOND
    deadline = end + TAIL_SECONDS * SECOND
    phase = {'phase': name, 'phase_start_monotonic_ns': phase_start,
             'score_start_monotonic_ns': start, 'score_end_monotonic_ns': end,
             'telemetry_phase_end_monotonic_ns': deadline}
    write_json(run_dir / f'{name}-scope.json', phase)
    samples = {side: [] for side in lanes}
    slot, last_health_check = 0, 0
    with (run_dir / f'{name}-pixels.jsonl').open('w') as observer:
        while (now := time.monotonic_ns()) < deadline:
            if now - last_health_check >= SECOND:
                dead = [proc.args[0] for proc in processes if proc.poll() is not None]
                if dead:
                    raise RuntimeError(f'{name} ended before the full observation period: {dead}')
                last_health_check = now
            for side, (pixels, xid) in lanes.items():
                began = time.monotonic_ns()
                tile, scroll = sample(pixels, xid, width, top)
                row = {'side': side, 'start_monotonic_ns': began,
                       'end_monotonic_ns': time.monotonic_ns(),
                       'tile_x': tile, 'scroll_text': scroll}
                samples[side].append(row)
                print(json.dumps(row, separators=(',', ':')), file=observer)
            slot = max(slot + 1, (time.monotonic_ns() - phase_start) * 90 // SECOND + 1)
            next_tick = min(deadline, phase_start + slot * SECOND // 90)
            time.sleep(max(0, (next_tick - time.monotonic_ns()) / SECOND))
    phase['observer_end_monotonic_ns'] = time.monotonic_ns()
    phase['samples'] = {side: score_pixels(rows, start, end) for side, rows in samples.items()}
    write_json(run_dir / f'{name}-scope.json', phase)
    return phase


def monitor_stderr(process, role, run_dir):
    trace = run_dir / f'{role}-clocked-telemetry.jsonl'
    log = run_dir / f'{role}.log'
    failures = []

    def relay():
        try:
            with log.open('wb') as raw, trace.open('w') as typed:
                for line in iter(process.stderr.readline, b''):
                    arrived = time.monotonic_ns()
                    raw.write(line)
                    raw.flush()
                    if not line.startswith(b'{'):
                        continue
                    payload = json.loads(line)
                    if payload.get('type') != f'jwm_remote_{role}_stats' or payload.get('final'):
                        continue
                    print(json.dumps({'end_monotonic_ns': arrived, 'record': payload},
                                     separators=(',', ':')), file=typed, flush=True)
        except (OSError, ValueError) as error:
            failures.append(str(error))

    worker = threading.Thread(target=relay, daemon=True)
    worker.start()
    return worker, failures


def select_telemetry(run_dir, phase, role, dimensions=(960, 640)):
    start = phase['score_start_monotonic_ns']
    last = phase['telemetry_phase_end_monotonic_ns']
    retained = []
    for line in (run_dir / f'{role}-clocked-telemetry.jsonl').read_text().splitlines():
        row = json.loads(line)
        window = row['record']
        end = row['end_monotonic_ns']
        duration = round(window['window_seconds'] * SECOND)
        if duration > 0 and start <= end - duration and end <= last:
            retained.append(row)
    with (run_dir / f"{phase['phase']}-{role}.jsonl").open('w') as selected:
        for row in retained:
            print(json.dumps(row['record'], separators=(',', ':')), file=selected)
    scope_field = 'last_sent_frame' if role == 'host' else 'last_frame'
    scopes = [row['record'][scope_field] for row in retained if row['record'].get(scope_field)]
    routes = sorted({route for row in retained for route in (
        row['record'].get('mode' if role == 'host' else 'last_presentation_path'),) if route})
    return {'whole_windows': len(retained),
            'window_seconds': sum(row['record']['window_seconds'] for row in retained),
            'session_ids': sorted({row['record']['session_id'] for row in retained if row['record'].get('session_id')}),
            'routes': routes, 'frame_scopes_observed': len(scopes),
            'viewer_backends': sorted({row['record']['viewer_backend'] for row in retained
                                       if row['record'].get('viewer_backend')}),
            'frame_scopes_match_requested_jpeg': all(
                scope.get('codec') == 'JPEG' and scope.get('source_dimensions') == list(dimensions)
                and scope.get('encoded_dimensions') == list(dimensions) for scope in scopes),
            'first_window_end_monotonic_ns': retained[0]['end_monotonic_ns'] if retained else None,
            'last_window_end_monotonic_ns': retained[-1]['end_monotonic_ns'] if retained else None}


def run(args, run_dir):
    run_dir.mkdir(mode=0o700)
    print(f'Browser trial: {run_dir}', flush=True)
    profile = run_dir / 'firefox-profile'
    runtime = run_dir / 'runtime'
    profile.mkdir(mode=0o700)
    runtime.mkdir(mode=0o700)
    (profile / 'user.js').write_text('''user_pref("browser.shell.checkDefaultBrowser", false);
user_pref("browser.startup.page", 0);
user_pref("browser.aboutwelcome.enabled", false);
user_pref("browser.newtabpage.enabled", false);
// This profile runs an offline page. Keep the 60-second data-policy infobar out of its raster.
user_pref("datareporting.policy.dataSubmissionEnabled", false);
user_pref("gfx.webrender.software", true);
user_pref("network.proxy.type", 1);
user_pref("network.proxy.http", "127.0.0.1");
user_pref("network.proxy.http_port", 9);
user_pref("network.proxy.ssl", "127.0.0.1");
user_pref("network.proxy.ssl_port", 9);
''')
    env = clean_env()
    env.update(XDG_RUNTIME_DIR=str(runtime), XDG_SESSION_TYPE='x11')
    width, height = 960, 640
    size = f'{width}x{height}'
    with ExitStack() as cleanup:
        def log(name):
            return cleanup.enter_context((run_dir / name).open('wb'))

        displays = []
        for side in ('source', 'viewer'):
            display = start_display(width, height, log(f'{side}-xvfb.log'))
            cleanup.callback(stop, display)
            displays.append(get_display(display))
        source_display, viewer_display = displays
        firefox_env = dict(env, DISPLAY=source_display, GDK_BACKEND='x11',
                           MOZ_NO_REMOTE='1', MOZ_ENABLE_WAYLAND='0', LIBGL_ALWAYS_SOFTWARE='1',
                           XDG_CACHE_HOME=str(profile / 'cache'), XDG_CONFIG_HOME=str(profile / 'config'))
        firefox_env.pop('MOZ_HEADLESS', None)
        firefox = subprocess.Popen(
            ['dbus-run-session', '--', args.firefox, '--new-instance', '--profile', str(profile),
             '--kiosk', (HERE / 'browser-trial.html').as_uri()], env=firefox_env,
            stdout=subprocess.DEVNULL, stderr=log('firefox.log'), start_new_session=True)
        cleanup.callback(stop_group, firefox)
        source_title = 'JWM remote browser workload (offline)'
        source_window = wait_for_window(firefox, source_display, source_title, env,
                                        run_dir / 'source-discovery-tree.log', 25)
        # Bare Xvfb has no window manager to apply Firefox's maximization
        # request. Size the owned XID directly, then verify its actual extent.
        subprocess.run(['xdotool', 'windowmove', str(source_window), '0', '0', 'windowsize',
                        str(source_window), str(width), str(height)],
                       env=dict(env, DISPLAY=source_display), check=True, timeout=5)
        placed_window = wait_for_window(firefox, source_display, source_title, env,
                                        run_dir / 'source-positioned-tree.log', 10, (width, height))
        if placed_window != source_window:
            raise RuntimeError('Firefox replaced the selected drawable while it was being sized')
        source_pixels = Pixels(source_display)
        cleanup.callback(source_pixels.close)
        source_rows = ()

        def inspect_page():
            nonlocal source_rows
            source_rows = source_pixels.crop(source_pixels.root, 0, 0, width, height)
            return find_static_page(source_rows)

        placement = None
        try:
            placement = wait_for(firefox, inspect_page, 10)
        finally:
            if source_rows:
                window_rows = source_pixels.crop(source_window, 0, 0, width, height)
                write_capture(run_dir / 'source-static-root.ppm', source_rows)
                write_capture(run_dir / 'source-static-window.ppm', window_rows)
                old_column_top = tile_span(b''.join(row[24 * 4:25 * 4] for row in window_rows))
                (run_dir / 'source-static.json').write_text(json.dumps({
                    'tile_x_y_and_header_top': placement,
                    'old_window_column_tile_top': old_column_top,
                    'root_and_window_active_pixels_equal': source_rows == window_rows,
                }, indent=2) + '\n')
        origin_x, top, header_top = placement
        if top < 50 or top + 108 >= height:
            raise RuntimeError(f'unexpected document tile location: y={top}')

        key = run_dir / 'key'
        cleanup.callback(key.unlink, missing_ok=True)
        subprocess.run([args.release, 'keygen', '--output', str(key)], env=env,
                       stdout=subprocess.DEVNULL, check=True, timeout=8)
        host_path = run_dir / 'host.log'
        host = subprocess.Popen(
            [args.release, 'host', '--display', source_display, '--capture-source', 'root',
             '--scaling', 'auto', '--once', '--listen', '127.0.0.1:0', '--key-file', str(key),
             '--stats-json', '--fps', str(REQUESTED_FPS), '--jpeg-quality', '85', '--fixed-jpeg-quality'],
            env=env, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        cleanup.callback(stop, host)
        host_monitor, host_errors = monitor_stderr(host, 'host', run_dir)

        def find_address():
            if not host_path.exists():
                return None
            match = re.search(r'listening on (127\.0\.0\.1:[0-9]+)', host_path.read_text())
            return match.group(1) if match else None

        address = wait_for(host, find_address)
        viewer_args = [args.release, 'connect', address, '--display', viewer_display,
                       '--window-size', size, '--window-position', '0,0', '--scaling', 'cpu',
                       '--view-only', '--jpeg', '--toggle', '--stats-json', '--key-file', str(key)]
        viewer = subprocess.Popen(viewer_args, env=env, stdout=subprocess.DEVNULL,
                                  stderr=subprocess.PIPE)
        cleanup.callback(stop, viewer)
        viewer_monitor, viewer_errors = monitor_stderr(viewer, 'viewer', run_dir)
        viewer_window = wait_for_window(viewer, viewer_display, f'{address} - JWM Remote', env,
                                        run_dir / 'viewer-window-tree.log', 15, (width, height))
        viewer_pixels = Pixels(viewer_display)
        cleanup.callback(viewer_pixels.close)
        def initial_tile():
            x, text = sample(viewer_pixels, viewer_window, width, top)
            return x if x is not None and abs(x - origin_x) <= 4 and text else None
        try:
            wait_for(viewer, initial_tile)
        finally:
            write_capture(run_dir / 'viewer-static-window.ppm',
                          viewer_pixels.crop(viewer_window, 0, 0, width, height))
        lanes = {'source': (source_pixels, source_pixels.root), 'viewer': (viewer_pixels, viewer_window)}
        phases = [collect_phase('static', run_dir, lanes, (firefox, host, viewer), width, top)]
        final_static_rows = source_pixels.crop(source_pixels.root, 0, 0, width, height)
        write_capture(run_dir / 'source-static-end-root.ppm', final_static_rows)
        final_static_placement = find_static_page(final_static_rows)
        if final_static_placement != placement:
            raise RuntimeError(f'Firefox fixture moved during static phase: {placement} to {final_static_placement}')
        initial_scroll = sample(source_pixels, source_pixels.root, width, top)[1]
        subprocess.run(['xdotool', 'mousemove', '80', str(header_top + 30), 'click', '1', 'mousemove',
                        str(width - 5), str(height - 5)], env=dict(env, DISPLAY=source_display),
                       check=True, timeout=5)
        # Anchor motion to its first actual raster change instead of crediting
        # the click or an animation callback as producer work.
        def motion_seen():
            x, scroll = sample(source_pixels, source_pixels.root, width, top)
            return x if x is not None and abs(x - origin_x) >= 8 and scroll and scroll != initial_scroll else None

        try:
            wait_for(firefox, motion_seen, 5)
        except RuntimeError:
            write_capture(run_dir / 'source-activation-failed-root.ppm',
                          source_pixels.crop(source_pixels.root, 0, 0, width, height))
            raise
        phases.append(collect_phase('motion', run_dir, lanes, (firefox, host, viewer), width, top))
        for side, (pixels, xid) in lanes.items():
            write_capture(run_dir / f'{side}-motion-end.ppm', pixels.crop(xid, 0, 0, width, height))
        subprocess.run(viewer_args, env=env, stdout=subprocess.DEVNULL,
                       stderr=log('disconnect.log'), timeout=8, check=True)
        viewer_status, host_status = viewer.wait(timeout=10), host.wait(timeout=10)
        host_monitor.join(timeout=3)
        viewer_monitor.join(timeout=3)
        if viewer_status or host_status or host_monitor.is_alive() or viewer_monitor.is_alive() or host_errors or viewer_errors:
            raise RuntimeError(f'owned CLI closure/telemetry failed: {host_status}, {viewer_status}, {host_errors}, {viewer_errors}')
        for phase in phases:
            phase['telemetry'] = {role: select_telemetry(run_dir, phase, role) for role in ('host', 'viewer')}
        static, motion = phases
        session_ids = {session for phase in phases for windows in phase['telemetry'].values()
                       for session in windows['session_ids']}
        telemetry_complete = len(session_ids) == 1 and all(
            windows['window_seconds'] >= MEASURE_SECONDS and len(windows['session_ids']) == 1
            and windows['frame_scopes_match_requested_jpeg']
            for phase in phases for windows in phase['telemetry'].values())
        telemetry_complete = telemetry_complete and all(
            windows['frame_scopes_observed'] > 0 for windows in motion['telemetry'].values())
        source_score, viewer_score = (motion['samples'][side] for side in ('source', 'viewer'))
        source_qualified = (source_score['unique_content_fps'] >= REQUESTED_FPS
                            and source_score['scroll_changes_seen'] >= MEASURE_SECONDS)
        viewer_gate = (viewer_score['unique_content_fps'] >= REQUESTED_FPS * .9
                       and viewer_score['scroll_changes_seen'] >= MEASURE_SECONDS) if source_qualified else None
        result = {'scope': 'scored single-machine X11 software observation on owned Xvfb displays',
                  'source_size': [width, height], 'viewer_size': [width, height],
                  'codec': 'JPEG', 'jpeg_quality': 85, 'requested_fps': REQUESTED_FPS,
                  'source_qualified_for_viewer_motion_gate': source_qualified,
                  'viewer_motion_gate_met': viewer_gate,
                  'static_source_tile_changes': static['samples']['source']['unique_tile_changes'],
                  'static_source_scroll_changes': static['samples']['source']['scroll_changes_seen'],
                  'telemetry_complete': telemetry_complete, 'phases': phases}
        write_json(run_dir / 'result.json', result)
        print(json.dumps({'run': str(run_dir), 'source_fps': source_score['unique_content_fps'],
                          'viewer_fps': viewer_score['unique_content_fps'], 'source_qualified': source_qualified,
                          'viewer_motion_gate_met': viewer_gate, 'telemetry_complete': telemetry_complete}), flush=True)
        return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--release', default=str(RELEASE))
    parser.add_argument('--firefox', default='/usr/bin/firefox')
    parser.add_argument('--trials', type=int, default=3)
    args = parser.parse_args()
    if args.trials < 3:
        parser.error('at least three independent completed observations are requested')
    fixture = json.loads((HERE / 'fixture-manifest.json').read_text())
    original = (HERE / 'browser-original.html').read_bytes()
    trial_doc = (HERE / 'browser-trial.html').read_bytes()
    if (original.count(b'elapsed >= 30000') != 1 or trial_doc != original.replace(b'elapsed >= 30000', b'elapsed >= 105000')
            or fixture['original_sha256'] != hashlib.sha256(original).hexdigest()
            or fixture['trial_sha256'] != hashlib.sha256(trial_doc).hexdigest()):
        parser.error('browser HTML fixture differs from its documented cutoff change')
    with open('/tmp/jwm-p08-p09-release/benchmark.lock', 'a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        batch = Path(tempfile.mkdtemp(prefix='scored.', dir=HERE))
        args.release = str(Path(args.release).resolve(strict=True))
        args.firefox = str(Path(args.firefox).resolve(strict=True))
        private_browser_ini = Path('/usr/lib/firefox/application.ini')
        browser_metadata = dict(re.findall(r'^(Version|BuildID)=(.+)$', private_browser_ini.read_text(), re.MULTILINE)) \
            if args.firefox == '/usr/bin/firefox' and private_browser_ini.is_file() else None
        with open(args.release, 'rb') as binary:
            release_sha256 = hashlib.file_digest(binary, 'sha256').hexdigest()
        write_json(batch / 'manifest.json', {
            'workload': fixture, 'trials': args.trials, 'kernel': platform.release(),
            'machine': platform.machine(), 'release': args.release, 'release_sha256': release_sha256,
            'firefox_executable': args.firefox, 'local_firefox_application_ini': browser_metadata,
            'scope': 'one machine, private source/viewer Xvfb, X11 software WebRender, authenticated loopback TCP',
            'resolution': [960, 640], 'viewer_scale': '1:1', 'render_mode': 'Firefox Software WebRender',
            'capture': 'X11 root with Auto scaling and expected MIT-SHM', 'codec': 'fixed JPEG 85',
            'firefox_test_profile_extra_prefs': {'datareporting.policy.dataSubmissionEnabled': False},
            'phase_warmup_s': WARM_SECONDS, 'phase_pixel_measure_s': MEASURE_SECONDS,
            'phase_telemetry_tail_s': TAIL_SECONDS, 'requested_source_capture_fps': REQUESTED_FPS,
            'pixel_poll_hz': 90, 'software_measurement': 'local XGetImage from source root and viewer window',
        })
        outcomes = []
        for index in range(1, args.trials + 1):
            run_dir = batch / f'trial-{index:02}'
            try:
                result = run(args, run_dir)
                outcomes.append({'trial': index, 'status': 'completed',
                                 'source_qualified': result['source_qualified_for_viewer_motion_gate'],
                                 'viewer_motion_gate_met': result['viewer_motion_gate_met'],
                                 'telemetry_complete': result['telemetry_complete']})
            except (OSError, RuntimeError, ValueError, subprocess.SubprocessError) as error:
                run_dir.mkdir(mode=0o700, exist_ok=True)
                (run_dir / 'failure.log').write_text(traceback.format_exc())
                outcomes.append({'trial': index, 'status': 'failed', 'reason': str(error)})
                print(f'Browser trial {index} failed: {error}', flush=True)
            write_json(batch / 'outcomes.json', outcomes)
        if any(row['status'] != 'completed' for row in outcomes):
            raise SystemExit(f'One or more browser trials failed; retained all results in {batch}')
