from hashlib import sha256
import json
from pathlib import Path
import tarfile
from zipfile import ZIP_DEFLATED, ZipFile

from score import score_pixels


instrument = Path('/tmp/jwm-firefox-dual.7JkDCe')
attempt = instrument / 'dual.4yyz1efp'
host = attempt / 'trial-01'
peer_archive = Path(__file__).with_name('previous-peer') / 'trace.tar.gz'
evidence = Path('docs/benchmarks/remote-upgrade-2026-11-20')


def strong_hash(data):
    return sha256(data).hexdigest()


def decode_jsonl(data):
    return [json.loads(line) for line in data.splitlines()]


def identity(role, record):
    return {key: record[key] for key in ('cpu', 'kernel', 'drawable_size', 'clock', 'release_sha256')} | {
        'role': role, 'boot_id_sha256': strong_hash(record['boot_id'].encode()),
    }


def static_raster(scope, samples, lane):
    start, end = scope['score_start_monotonic_ns'], scope['score_end_monotonic_ns']
    assert start - scope['phase_start_monotonic_ns'] == 30_000_000_000
    assert end - start == 60_000_000_000
    rows = decode_jsonl(samples)
    assert all(row['side'] == lane for row in rows)
    raster = score_pixels(rows, start, end)
    assert raster == scope['samples'][lane]
    assert raster['unique_tile_changes'] == raster['scroll_changes_seen'] == 0
    assert raster['invalid_tile_reads'] == raster['invalid_scroll_reads'] == 0
    assert raster['valid_and_invalid_sample_reads'] > 5000
    return {'warmup_seconds': 30, 'measured_seconds': 60, 'raster': raster}


local_identity = json.loads((host / 'identity.json').read_text())
with tarfile.open(peer_archive, 'r:gz') as peer:
    def peer_bytes(name):
        with peer.extractfile('./' + name) as member:
            return member.read()

    identities = {role: identity(role, local_identity[role]) for role in ('host', 'viewer')}
    assert identities['viewer'] == identity('viewer', json.loads(peer_bytes('identity.json')))
    assert identities['host']['boot_id_sha256'] != identities['viewer']['boot_id_sha256']
    assert all(record['drawable_size'] == [1920, 1080] for record in identities.values())
    host_trace = decode_jsonl((host / 'host-clocked-telemetry.jsonl').read_bytes())
    viewer_trace = decode_jsonl(peer_bytes('viewer-clocked-telemetry.jsonl'))
    sessions = {row['record']['session_id'] for row in host_trace + viewer_trace}
    assert len(sessions) == 1
    frames = [row['record']['last_frame'] for row in viewer_trace if row['record']['last_frame']]
    assert frames and all(frame['codec'] == 'JPEG' and
                          frame['encoded_dimensions'] == frame['source_dimensions'] == [1920, 1080]
                          for frame in frames)
    static = {
        'host': static_raster(json.loads((host / 'static-scope.json').read_text()),
                              (host / 'static-pixels.jsonl').read_bytes(), 'source'),
        'viewer': static_raster(json.loads(peer_bytes('static-scope.json')),
                                peer_bytes('static-pixels.jsonl'), 'viewer'),
    }
    assert b'remote protocol I/O error: Resource temporarily unavailable' in (host / 'host.log').read_bytes()
    assert b'the connection closed without a goodbye from the host' in peer_bytes('viewer.log')
    phase_events = decode_jsonl((host / 'peer-events.jsonl').read_bytes())
    assert [event['event'] for event in phase_events] == [
        'viewer_ready', 'viewer_static_started', 'viewer_static_done',
    ]
    entries = {f'fixture/{name}': (instrument / name).read_bytes()
               for name in ('browser-trial.html', 'dual_browser.py', 'firefox-profile-user.js',
                            'fixture-manifest.json', 'run_baseline.py', 'processes.py', 'score.py')}
    entries['fixture/archive-first-attempt.py'] = Path(__file__).read_bytes()
    for name in ('failure.log', 'artifact-fetch-failure.log', 'peer.log', 'host.log',
                 'host-clocked-telemetry.jsonl', 'static-scope.json', 'static-pixels.jsonl',
                 'source-static.ppm', 'source-static-end.ppm'):
        entries[f'trace/host/{name}'] = (host / name).read_bytes()
    for name in ('viewer.log', 'viewer-clocked-telemetry.jsonl', 'static-scope.json',
                 'static-pixels.jsonl', 'viewer-static.ppm', 'control-in.jsonl'):
        entries[f'trace/viewer/{name}'] = peer_bytes(name)
    entries['trace/phase-events.json'] = (json.dumps([
        {'event': event['event'], 'run_id': event['run_id']} for event in phase_events
    ], indent=2) + '\n').encode()

raw = evidence / 'firefox-x11-dual-first-attempt-raw.zip'
with ZipFile(raw, 'w', compression=ZIP_DEFLATED) as writer:
    for name, raw_bytes in entries.items():
        writer.writestr(name, raw_bytes)
with ZipFile(raw) as reader:
    assert reader.testzip() is None
    assert all(reader.read(name) == raw_bytes for name, raw_bytes in entries.items())
report = {
    'schema_version': 1,
    'scope': '1080p Mint Firefox and an owned Ubuntu X11 viewer via private OpenSSH reverse forwarding',
    'status': 'ended_after_static_before_motion',
    'authenticated_session_ids': sorted(sessions),
    'observed_codec': 'JPEG',
    'dimensions': [1920, 1080],
    'endpoints': identities,
    'firefox_application': local_identity['host']['installed_firefox_application'],
    'static_observations': static,
    'host_io_error': 'Resource temporarily unavailable (os error 11)',
    'viewer_termination': 'connection closed without a goodbye from the host',
    'motion_observations': None,
    'viewer_motion_gate_met': None,
    'archive': {'path': raw.name, 'sha256': strong_hash(raw.read_bytes()),
                'entries': {name: strong_hash(raw_bytes) for name, raw_bytes in entries.items()}},
}
(evidence / 'firefox-x11-dual-first-attempt.json').write_text(json.dumps(report, indent=2) + '\n')
print(report['status'], report['archive']['sha256'])
