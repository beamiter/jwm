"""Reconstruct benchmark scores from raster ledgers, typed transport windows and PNG pairs."""

import argparse
import json
from pathlib import Path
from statistics import median

from PIL import Image

from capture_quality import compare_images
from run_workbench import FULL, MODE_ORDER, REQUESTED_FPS, SECOND, score_pixels, score_telemetry, sha

PHASES = ('static', 'ordinary-motion', 'pressured-motion')


def expect(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_text())


def canonical(value):
    return json.loads(json.dumps(value, allow_nan=False))


def pixels(path):
    return (json.loads(line) for line in path.read_text().splitlines())


def anchor_metric(directory, tag):
    with Image.open(directory/f'{tag}-source.png') as source, Image.open(directory/f'{tag}-viewer.png') as viewer:
        return compare_images(source, viewer)


def median_if_any(items):
    values = [item for item in items if item is not None]
    return median(values) if values else None


def phase_values(root, phase):
    name = phase['phase']
    start = phase['score_start_monotonic_ns']
    end = phase['score_end_monotonic_ns']
    expect((end - start) == phase['scored_seconds'] * SECOND
           and (start - phase['phase_start_monotonic_ns']) == phase['warmup_seconds'] * SECOND,
           f'{root}: adaptive window does not match the run manifest')
    lanes = {side: [] for side in ('source', 'viewer')}
    for row in pixels(root/f'{name}-pixels.jsonl'):
        expect(row['end_monotonic_ns'] >= row['start_monotonic_ns'], 'X11 observation clock reversed')
        lanes[row['side']].append(row)
    visible = {role: score_pixels(samples, start, end) for role, samples in lanes.items()}
    expect(visible == phase['samples'], f'{root}: drawable gap or frame count mismatch')
    telemetry = {role: score_telemetry(root, phase, role) for role in ('host', 'viewer')}
    expect(canonical(telemetry) == phase['telemetry'], f'{root}: recorded transport windows differ')
    quality = [anchor_metric(root, item['label']) for item in phase['quality']]
    expect(quality == [item['metrics'] for item in phase['quality']], f'{root}: actual drawable anchor quality differs')
    with Image.open(root/f"{phase['quality'][0]['label']}-source.png") as first:
        for item, drift in zip(phase['quality'], phase['source_ui_stability'], strict=True):
            with Image.open(root/f"{item['label']}-source.png") as sample:
                expect(compare_images(first, sample)['rgb_mae'] == drift, 'source UI stability check changed')
    return {
        'source_distinct_fps': visible['source']['unique_content_fps'],
        'viewer_distinct_fps': visible['viewer']['unique_content_fps'],
        'viewer_distinct_gap_p95_ms': visible['viewer']['gap_ms']['p95'],
        'viewer_longest_gap_ms': visible['viewer']['gap_ms']['max'],
        'viewer_reads': visible['viewer']['reads'],
        'viewer_invalid_cube_reads': visible['viewer']['invalid_mesh_reads'],
        'viewer_zero_unique_second_bins': visible['viewer']['zero_unique_bins'],
        'encoded_rasters': {key: lane['encoded_rasters'] for key, lane in telemetry.items()},
        'scoped_telemetry_seconds': {key: lane['window_seconds'] for key, lane in telemetry.items()},
        'scoped_h264_only': all(lane['codecs'] == ['H.264'] and lane['source_rasters'] == [tuple(FULL)]
                               for lane in telemetry.values()),
        'transport_identity': sorted(set(session for lane in telemetry.values() for session in lane['sessions'])),
        'video_payload_mbit_per_second': telemetry['host'].get('video_payload_mbit_per_second'),
        'capture_to_drawn_ack_median_window_p95_ms': telemetry['host']['stage_tails'].get(
            'capture_start_to_ack_ms', {}).get('median_window_p95_ms'),
        'viewer_decode_median_window_p95_ms': telemetry['viewer']['stage_tails'].get(
            'decode_ms', {}).get('median_window_p95_ms'),
        'peak_outstanding': telemetry['host'].get('peak_outstanding'),
        'ui_rgb_mae': median(row['rgb_mae'] for row in quality),
        'ui_rgb_psnr_db': median_if_any([row['rgb_psnr_db'] for row in quality]),
        'ui_edge_contrast_preserved': median_if_any([row['relative_edge_contrast'] for row in quality]),
        'ui_source_mae_drift': max(phase['source_ui_stability']),
        'resource_samples': [item['resources'] for item in phase['quality']],
    }
