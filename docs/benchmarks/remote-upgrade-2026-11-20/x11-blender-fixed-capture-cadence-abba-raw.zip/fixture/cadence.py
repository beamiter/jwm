"""Matched JWM X11 cadence study using actual Blender Workbench drawables."""
import argparse
import json
from pathlib import Path
import shutil
import subprocess
from statistics import median
from tempfile import TemporaryDirectory
import traceback
from zipfile import ZIP_DEFLATED, ZipFile

from replay_workbench import canonical, expect, phase_values, read
from run_workbench import BLENDER, FULL, MEDIA_LIBS, REQUESTED_FPS, SCENE, SECOND, observed_telemetry, run, sha, write_json

HERE=Path(__file__).resolve().parent
ORDER=('baseline','precise','precise','baseline')*2
STEM='x11-blender-fixed-capture-cadence-abba'
REPLAY_FILES=('cadence.py','run_workbench.py','replay_workbench.py','processes.py',
              'x11_session.py','capture_quality.py','workbench_scene.py','candidate.patch')
HOST_COUNTS=('scheduled','captured','sent','backpressure_skipped')
VIEWER_COUNTS=('received','decoded','drawn','replaced')
KEYS=('source_distinct_fps','viewer_distinct_fps','viewer_distinct_gap_p95_ms','viewer_longest_gap_ms',
      'capture_to_drawn_ack_median_window_p95_ms','ui_edge_contrast_preserved')


def clocked_rates(root, phase, role, fields):
    start,end=(phase[f'score_{field}_monotonic_ns'] for field in ('start','end'))
    rows=[row['record'] for row in observed_telemetry(root/f'{role}-clocked-telemetry.jsonl')
          if start<=row['end_monotonic_ns']-round(row['record']['window_seconds']*SECOND)
          and row['end_monotonic_ns']<=end]
    span=sum(row['window_seconds'] for row in rows)
    return {name:sum(row[name] for row in rows)/span for name in fields}


def replay(root):
    manifest=read(root/'manifest.json')
    expect(tuple(manifest['order'])==ORDER, 'unexpected or incomplete schedule')
    expect(all(sha(root/'fixture'/name)==digest for name,digest in manifest['fixture_sha256'].items()),
           'fixture member pin differs')
    attempts=read(root/'outcomes.json')
    expect([(row['slot'],row['variant']) for row in attempts]==list(enumerate(ORDER,1)),
           'the attempt ledger does not cover every scheduled trial')
    results=[]
    for attempt in attempts:
        role=attempt['variant']
        path=root/f"trial-{attempt['slot']:02}-{role}"
        if attempt['status']!='completed':
            expect((path/'failure.log').stat().st_size>0,'failed attempt was not preserved')
            results.append(attempt)
            continue
        seen=read(path/'result.json')
        expect(seen['mode']==role and seen['binary_sha256']==manifest['binary_sha256'][role]
               and seen['host_exit']==seen['viewer_exit']==0 and seen['codec']=='H.264 NVENC YUV420'
               and not seen['host_tier_events'] and not seen['host_rate_events'],
               'mode, negotiated route or shutdown differed')
        phase,=seen['phases']
        expect((phase['phase'],phase['warmup_seconds'],phase['scored_seconds'])==('ordinary-motion',30,60),
               'cadence score differs from the declared observation window')
        pixels=phase_values(path,phase)
        expect(pixels['scoped_h264_only'] and len(pixels['transport_identity'])==1
               and all(size==[tuple(FULL)] for size in pixels['encoded_rasters'].values())
               and all(seconds>=49 for seconds in pixels['scoped_telemetry_seconds'].values()),
               'retained transport differed from the exact fixed-raster scope')
        results.append(attempt | {name:pixels[name] for name in KEYS} | {
            'host_rates_fps':clocked_rates(path,phase,'host',HOST_COUNTS),
            'viewer_rates_fps':clocked_rates(path,phase,'viewer',VIEWER_COUNTS),
            'handoff_windows_seconds':pixels['scoped_telemetry_seconds'],
            'ordinary_motion_target_met':min(pixels['source_distinct_fps']/REQUESTED_FPS,
                                             pixels['viewer_distinct_fps']/(.9*REQUESTED_FPS))>=1,
        })
    comparisons=[]
    for left,right in zip(results[::2],results[1::2],strict=True):
        fixed,precise=sorted((left,right),key=lambda item:item['variant'])
        complete=fixed['status']==precise['status']=='completed'
        comparison={'baseline_slot':fixed['slot'],'precise_slot':precise['slot'],'complete':complete}
        if complete:
            comparison['precise_minus_baseline']={
                key:precise[key]-fixed[key] if precise[key] is not None and fixed[key] is not None else None
                for key in KEYS}
            comparison['scheduled_fps_delta']=precise['host_rates_fps']['scheduled']-fixed['host_rates_fps']['scheduled']
        comparisons.append(comparison)
    overview={}
    for role in ('baseline','precise'):
        selected=[row for row in results if row['variant']==role and row['status']=='completed']
        overview[role]={
            'completed':len(selected),
            'ordinary_motion_target_met':sum(row['ordinary_motion_target_met'] for row in selected),
            'medians':{key:median(values) if (values:=[row[key] for row in selected if row[key] is not None]) else None
                       for key in KEYS},
            'scheduled_fps_median':median(row['host_rates_fps']['scheduled'] for row in selected) if selected else None,
        }
    return {'manifest':manifest,'trials':results,'matched_pairs':comparisons,'overview':overview}


def keep(member):
    return (member.name in ('manifest.json','outcomes.json')
            or member.parts[0]=='fixture' and member.name in REPLAY_FILES and len(member.parts)==2
            or member.parts[0].startswith('trial-') and len(member.parts)==2
            and member.suffix in ('.json','.jsonl','.log','.png'))


def verify(summary, bundle):
    expected=read(summary)
    pinned=expected.pop('archive')
    expect(sha(bundle)==pinned['sha256'] and bundle.name==pinned['name'],'archive pin differs')
    with TemporaryDirectory(prefix='jwm-cadence-replay.') as text:
        root=Path(text)
        with ZipFile(bundle) as entries:
            names=entries.namelist()
            expect(len(names)==len(set(names)) and set(names)==set(pinned['members'])
                   and entries.testzip() is None, 'archive roster differs')
            for name in names:
                path=Path(name)
                expect(not path.is_absolute() and '..' not in path.parts and keep(path),
                       'archive path escaped cadence scope')
                entries.extract(name,root)
        expect(all(sha(root/name)==digest for name,digest in pinned['members'].items()),'archived member digest differs')
        expect(canonical(replay(root))==expected,'archive did not reproduce the cadence comparison')
    print('Replayed distinct Blender poses, FPS, endpoint cadence and paired gap results.')


def save_bundle(root, out):
    result=canonical(replay(root))
    out.mkdir(mode=0o700)
    members={p.relative_to(root).as_posix():sha(p) for p in root.rglob('*')
             if p.is_file() and keep(p.relative_to(root))}
    bundle=out/f'{STEM}-raw.zip'
    with ZipFile(bundle,'x',compression=ZIP_DEFLATED,compresslevel=6) as writer:
        for name in sorted(members):
            writer.write(root/name,name)
    summary=out/f'{STEM}.json'
    write_json(summary,result | {'archive':{'name':bundle.name,'sha256':sha(bundle),'members':members}})
    verify(summary,bundle)
    return all(t['status']=='completed' for t in result['trials'])


def measure(args):
    binary={key:Path(getattr(args,key)).resolve(strict=True) for key in ('baseline','precise')}
    blender=Path(BLENDER).resolve(strict=True)
    provenance=read(args.provenance)
    pins={key:sha(path) for key,path in binary.items()}
    expect(pins==provenance['binary_sha256'] and len(set(pins.values()))==2, 'staged release pins differ')
    expect(sha(blender)=='c752cdc50bc29b5968e23b6e5588936bb05046e29dbc119e26aab79a9de2b55b',
           'Blender changed from the prior study')
    args.blender=str(blender)
    args.root.mkdir(mode=0o700)
    fixture=args.root/'fixture'
    fixture.mkdir(mode=0o700)
    for name in REPLAY_FILES:
        shutil.copyfile(HERE/name,fixture/name)
    manifest={
        'order':ORDER,'binary_sha256':pins,'provenance':provenance,'source_and_viewer_raster':FULL,
        'requested_fps':REQUESTED_FPS,'scene_sha256':sha(SCENE),'blender_sha256':sha(blender),
        'fixture_sha256':{name:sha(fixture/name) for name in REPLAY_FILES},
        'ffmpeg_lib_sha256':{f'lib{name}.so':sha(Path(MEDIA_LIBS)/f'lib{name}.so')
                             for name in ('avcodec','avutil','swscale')},
        'phase':'ordinary Blender Workbench motion with fixed-rate NVENC, local authenticated X11 loopback',
        'warmup_seconds':30,'retained_seconds':60,
    }
    write_json(args.root/'manifest.json',manifest)
    attempts=[]
    for slot,role in enumerate(ORDER,1):
        args.release=str(binary[role])
        path=args.root/f'trial-{slot:02}-{role}'
        try:
            run(args,path,role)
        except (OSError,RuntimeError,ValueError,subprocess.SubprocessError) as error:
            path.mkdir(mode=0o700,exist_ok=True)
            (path/'failure.log').write_text(traceback.format_exc())
            attempts.append({'slot':slot,'variant':role,'status':'failed','error_type':type(error).__name__})
        else:
            attempts.append({'slot':slot,'variant':role,'status':'completed'})
        write_json(args.root/'outcomes.json',attempts)
    return save_bundle(args.root,args.out)


if __name__=='__main__':
    cli=argparse.ArgumentParser(description=__doc__)
    commands=cli.add_subparsers(dest='command',required=True)
    main=commands.add_parser('measure')
    for name in ('baseline','precise','provenance','root','out'):
        main.add_argument(f'--{name}',type=Path,required=True)
    existing=commands.add_parser('replay')
    existing.add_argument('summary',type=Path)
    existing.add_argument('bundle',type=Path)
    opts=cli.parse_args()
    if opts.command=='measure':
        raise SystemExit(0 if measure(opts) else 1)
    verify(opts.summary,opts.bundle)
