# Blender Workbench software viewport baseline

The repo already records Blender 4.5.16 LTS build `3f6797307da5` orbit, zoom and
shading changes through real managed native Wayland. That used a 640×480 private
factory session and software GL. The archived official download SHA-256 is
`23432b064977908beb1ab4b7f32f024e7331105c875c187dce002aff84b10c11`.
The executable is present at
`/tmp/jwm-blender-acceptance.VR4FQlr0/blender-4.5.16-linux-x64/blender`.
The existing evidence has no sustained source/viewer frame series.

This scratch runner pins the same build with a new private factory profile. Its
versioned `workbench_scene.py` uses the actual factory cube and camera, a fixed
orthographic projection, solid Workbench shading, a red mesh material and linear
translation/rotation keyframes on a 60 FPS timeline. Static keeps the first
actual pose. The controller starts Blender's interactive playback operator for
motion and waits for actual source-pixel change. The viewport is rendered by
Blender itself. Its application report identifies the build, engine, camera,
software GL renderer and viewport bounds. Frame counters and state verify the
setup without being used as display observations.

Once the current coordinated work releases the lock, start with a short unscored
calibration. The runner acquires the lock itself.

```sh
LD_LIBRARY_PATH=/tmp/jwm-remote-ffmpeg/usr/lib/x86_64-linux-gnu \
  python3 -B /tmp/jwm-blender-workbench-baseline.IkBZWNfj/run_workbench.py --calibrate
```

This requires the pinned executable above, the pinned release under
`/tmp/jwm-p08-p09-release`, Xvfb, xwininfo, xdotool, dbus-run-session and libX11.
It uses two owned 960×640 Xvfb displays, 1:1 source/encoded/viewer dimensions and
fixed JPEG quality 85 with a 30 FPS host limit. Calibration verifies window and
camera geometry, one consistent saturated red cube scanline across both actual
drawables, playback activation, and a short series of visibly distinct mesh
positions. It retains the relevant PPM captures, X11 window trees, application
state and typed telemetry even when a gate fails. The expected material color,
projection and playback behavior require that runtime calibration. There was no
application launch while preparing the fixture.

Once calibrated, replace `--calibrate` with `--trials 3` for the software baseline.
Static and motion each get 30 s warm-up and an exact 60 s pixel observation window.
The observer uses the visible red mesh silhouette center from three narrow rows in
the actual viewport. Two-pixel hysteresis rejects edge jitter. It records source
and viewer independently, including invalid reads, all one-second bins, and
nearest-rank gaps with both endpoints. The source must show at least 30 distinct
mesh positions per second for the viewer's 27 FPS gate to apply. The additional
8 s phase tail supports complete 5 s telemetry windows spanning at least 60 s;
the telemetry window bounds are distinct from the exact local pixel interval.

The archived scene hash, binary version, logical viewport, actual encoded size,
software renderer, fixed transport settings and both trace phases identify the
result. This bounds a local X11 software Workbench workload, separate from the
existing managed-input workflow and any physical-display or two-machine GPU
baseline. Isaac Sim remains its own unmeasured actual application row, requiring
an installed pinned version, target GPU, fixed scene, render settings and action
sequence. Blender playback supplies no Isaac Sim evidence.
