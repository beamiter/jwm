#!/usr/bin/env bash
set -euo pipefail
cd /home/yj/projects/jwm
artifact=$(cd "$(dirname "$0")" && pwd)
exec 9>/tmp/jwm-p08-p09-release/benchmark.lock
flock 9
export CARGO_TARGET_DIR=/tmp/jwm-remote-plan-check RUSTUP_TOOLCHAIN=stable CARGO_NET_OFFLINE=true CARGO_BUILD_JOBS=4
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_INCREMENTAL=0
export PKG_CONFIG_PATH=/tmp/jwm-remote-ffmpeg/usr/lib/x86_64-linux-gnu/pkgconfig
export LD_LIBRARY_PATH=/tmp/jwm-remote-ffmpeg/usr/lib/x86_64-linux-gnu
unset PKG_CONFIG_SYSROOT_DIR DISPLAY WAYLAND_DISPLAY JWM_REMOTE_GPU_PRESENT JWM_REMOTE_READ_AHEAD JWM_REMOTE_KEEP_WINDOW
runtime=$(mktemp -d -t jwm-matrix.XXXXXXXX)
trap 'rmdir -- "$runtime" 2>/dev/null || true' EXIT
export XDG_RUNTIME_DIR="$runtime" TMPDIR="$runtime" EGL_PLATFORM=surfaceless JWM_REQUIRE_HEADLESS_GL=1
sha256sum Cargo.toml Cargo.lock src/remote/{client.rs,client_decode_queue.rs,client_native_video.rs,gpu_present.rs,host.rs} \
   > "$artifact/source-sha256.txt"
status=0
check() {
    local label=$1
    shift
    printf 'Running %s\n' "$label"
    local result=0
    "$@" > "$artifact/$label.log" 2>&1 || result=$?
    printf '%d\n' "$result" > "$artifact/$label.exit"
    rg -n '^test result:|^error|^warning|Finished' "$artifact/$label.log" | tail -n 12 || true
    if ((result)); then status=$result; fi
}
check x11-cli cargo test --locked --no-default-features --features remote-x11 --bin jwm-remote
check x11-library cargo test --locked --no-default-features --features remote-x11 --lib 'remote::' -- --test-threads=4
check x11-h264 cargo check --locked --no-default-features --features remote-h264 --lib --bin jwm-remote
check wayland-cli cargo test --locked --no-default-features --features remote-wayland,backend-wayland-udev --bin jwm-remote
check wayland-h264-library cargo test --locked --no-default-features --features remote-wayland,backend-wayland-udev,remote-h264 --lib 'remote::' -- --test-threads=4
sha256sum --check "$artifact/source-sha256.txt"
exit "$status"
