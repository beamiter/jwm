import argparse
from contextlib import ExitStack
import fcntl
import json
import math
from pathlib import Path
import re
import shlex
import socket
import sys
import subprocess
import tempfile
import threading
import traceback
import time

from processes import clean_env, get_display, sha256, start_display, stop, wait_for

lab = Path(__file__).parent
release = Path("/tmp/jwm-p08-p09-release/jwm-remote")
painter_bin = Path("/tmp/jwm-p09-workload/p09-workload")
remote = "ubuntu@<private-peer>"
HOST_PIN = "aaa1ed44223181963b3463fb169d56c9a76b31a514f29915f7ad5d47002690a3"
VIEWER_PIN = "5e1951ed8bbc23f41db5b5918931d91a37baa1e9fa213c8ef9067a214a1511e5"
OBSERVER_PIN = "b79b433f17f1e061d30dc9fc4d5bb7cf867535c8ed4ca002987cc30640a21706"
SCALING_ORDER = ("cpu", "auto", "auto", "cpu") * 2
ssh = ["ssh", "-o", "BatchMode=yes", "-o", "ConnectTimeout=5", "-o", "ServerAliveInterval=8"]

def read_jsonl(file):
    records = []
    for line in file.read_text().splitlines():
        if line.startswith("{") and line.endswith("}"):
            records.append(json.loads(line))
    return records

def locate_viewer(display, size, port):
    tree = subprocess.check_output(["xwininfo", "-display", display, "-root", "-tree"], text=True, timeout=3)
    title = re.escape(f"127.0.0.1:{port} - JWM Remote")
    geometry = re.escape(size + "+0+0")
    matches = re.findall(rf'^ +(0x[\da-f]+) "{title}(?: - [^"]*)?": .* {geometry}(?= |$)', tree, re.M)
    if len(matches) > 1:
        raise RuntimeError("more than one full-sized drawable in the owned viewer")
    return matches[0] if matches else None

def telemetry(path, kind):
    return [row for row in read_jsonl(path) if row.get("type") == kind and not row.get("final")]

def keep_windows(rows, pilot=False):
    if pilot:
        if len(rows) < 2:
            raise RuntimeError("pilot needs completed telemetry windows")
        return rows
    warm_ms = 0.
    measured_ms = 0.
    kept = []
    for row in rows:
        duration = row["window_seconds"] * 1000
        if warm_ms < 30000:
            warm_ms += duration
        else:
            kept.append(row)
            measured_ms += duration
            if measured_ms >= 60000:
                break
    if measured_ms < 60000 or len(kept) < 12:
        raise RuntimeError(f"insufficient telemetry after {warm_ms:.1f} ms warmup: {measured_ms:.1f} ms")
    return kept

def nearest_p(values, p):
    return sorted(values)[math.ceil(len(values) * p)-1]

def require_readback_route(host, policy):
    if policy not in ("cpu", "auto"):
        raise ValueError("unsupported host scaling policy")
    observed_active = 0
    for row in host:
        stages = row.get("x11_capture", {}).get("stages", {})
        def observations(name):
            return stages.get(name, {}).get("observations", 0)
        core = observations("core_readback_ms")
        shm = observations("shm_readback_ms")
        if observations("cpu_resize_ms"):
            raise RuntimeError("unexpected CPU rescaling in native-size A/B")
        if row["captured"] or core or shm:
            observed_active += 1
            expected, other = (core, shm) if policy == "cpu" else (shm, core)
            if not expected or other:
                raise RuntimeError(f"{policy} arm measured the wrong readback route")
    if not observed_active:
        raise RuntimeError("A/B did not measure an active readback window")


def analyze(run, opts, run_id):
    host_path = run / "remote" / "host.log"
    viewer_path = run / "viewer.log"
    host = [row for row in telemetry(host_path, "jwm_remote_host_stats") if row["window_seconds"] >= 4.999]
    viewer = telemetry(viewer_path, "jwm_remote_viewer_stats")
    arrivals = [entry["end_ns"] for entry in read_jsonl(run/"viewer-clock.jsonl")]
    if len(arrivals) != len(viewer):
        raise RuntimeError("viewer window arrival timestamps do not match telemetry")
    for row, arrival in zip(viewer, arrivals):
        row["end_ns"] = arrival
        row["start_ns"] = arrival - round(row["window_seconds"] * 1e9)
    observation = read_jsonl(run/"observed.jsonl")
    start_summary, = [row for row in observation if row["type"]=="p09_start"]
    end_summary, = [row for row in observation if row["type"]=="p09_end"]
    source_end, = [row for row in read_jsonl(run/"remote"/"paint.jsonl") if row["type"]=="p09_end"]
    if any(row["run_id"] != run_id for row in (start_summary,end_summary,source_end)):
        raise RuntimeError("source and observer trial markers did not match")
    if end_summary["target_lost"] or end_summary["interrupted"] or end_summary["wrong_run"] or end_summary["reordered"]:
        raise RuntimeError("the exact observation drawable or trial was lost")
    observed_start = start_summary["monotonic_ns"]
    observed_end = end_summary["monotonic_ns"]
    source_fps = (source_end["submitted"]-1) / ((source_end["last_submit_ns"]-source_end["first_submit_ns"])/1e9)
    if source_fps < opts.fps:
        raise RuntimeError(f"source was not capable of the requested rate: {source_fps:.3f} fps")
    viewer = [row for row in viewer if row["start_ns"] >= observed_start and row["end_ns"] <= observed_end]
    host = keep_windows(host, opts.pilot)
    viewer = keep_windows(viewer, opts.pilot)
    session_id = host[0]["session_id"]
    if not session_id or {row["session_id"] for row in host+viewer} != {session_id}:
        raise RuntimeError("host and viewer telemetry are from different authenticated sessions")
    if opts.pilot:
        start = viewer[0]["start_ns"]
        end = viewer[-1]["end_ns"]
    else:
        # Count new visible content over one exact local observation interval.
        # Host and viewer stage windows have independent 5-second boundaries.
        start = observed_start + 30_000_000_000
        end = start + 60_000_000_000
        if end > observed_end:
            raise RuntimeError("the observer ended before the full measured interval")
    marks = [row for row in observation if row.get("type")=="p09_frame"]
    kept_marks = [row for row in marks if start <= row["monotonic_ns"] < end]
    if not kept_marks or len({row["run_id"] for row in kept_marks}) != 1:
        raise RuntimeError("viewer pixels did not produce a valid marker stream")
    if any(b["source_frame"] <= a["source_frame"] or b["monotonic_ns"] < a["monotonic_ns"]
           for a,b in zip(kept_marks, kept_marks[1:])):
        raise RuntimeError("observer retained stale or duplicate markers")
    points = [start, *[row["monotonic_ns"] for row in kept_marks], end]
    gaps_ms = [(b-a)/1e6 for a,b in zip(points, points[1:])]
    text = host_path.read_text()
    rates = [{"fps": int(fps), "percent": int(percent), "pressure": pressure}
             for fps,percent,pressure in re.findall(r"hardware rate target (\d+) fps, (\d+)% nominal bitrate \((\w+)\)", text)]
    applied = [{"fps": int(fps), "percent": int(percent)}
               for fps,percent in re.findall(r"NVENC opened (\d+) fps at (\d+)% nominal bitrate", text)]
    # Retain stalled windows. Zero frames with no last frame scope is a
    # measured timing result and does not imply a codec switch.
    host_last = [r["last_sent_frame"] for r in host if r["last_sent_frame"]]
    viewer_last = [r["last_frame"] for r in viewer if r["last_frame"]]
    if (not host_last or not viewer_last or not sum(r["h264_frames"] for r in host)
        or any(r["hevc444_frames"] or r["jpeg_atlases"] for r in host)
        or any(f["codec"] != "H.264" for f in host_last + viewer_last)
        or any(r["negotiated_codec"] != "H.264" for r in viewer)
        or "host switched to JPEG" in viewer_path.read_text()):
        raise RuntimeError("the measured windows did not keep the fixed H.264 codec")
    size = [opts.width,opts.height]
    if any(f["encoded_dimensions"] != size or f["source_dimensions"] != size
           for f in host_last + viewer_last):
        raise RuntimeError("source or encoded image was resized unexpectedly")
    require_readback_route(host, opts.host_scaling)
    binaries = json.loads((run/"remote"/"binaries.json").read_text())
    if (binaries["host_binary_sha256"] != opts.host_binary_sha256 or
            binaries["painter_sha256"] != opts.painter_sha256 or
            binaries["host_scaling_policy"] != opts.host_scaling):
        raise RuntimeError("source manifest does not match the requested A/B case")
    seconds = sum(row["window_seconds"] for row in host)
    observed_seconds = (end-start)/1e9
    metrics = {
        "host_scaling_policy":opts.host_scaling, "viewer_scaling_policy":"cpu",
        "binary_pins":binaries | {"viewer_binary_sha256":opts.viewer_binary_sha256,
                                  "observer_sha256":opts.observer_sha256},
        "arm":opts.arm, "configured_cap_bytes_per_second":opts.cap, "send_buffer_bytes_requested":opts.send_buffer,
        "pilot":opts.pilot, "session_id":session_id, "ffmpeg_encoder":"h264_nvenc", "codec":"H.264",
        "source_and_encoded_dimensions":size, "requested_fps":opts.fps,
        "host_window_seconds":seconds,"observer_window_seconds":observed_seconds,
        "host_h264_frames":sum(row["h264_frames"] for row in host),
        "host_drawn_acks":sum(row["drawn_acks"] for row in host),
        "host_zero_frame_windows":sum(row["h264_frames"]==0 for row in host),
        "viewer_zero_drawn_windows":sum(row["drawn"]==0 for row in viewer),
        "viewer_drawn_frames":sum(row["drawn"] for row in viewer),
        "observer_unique_source_frames":len(kept_marks),
        "observer_unique_frames_per_second":len(kept_marks)/observed_seconds,
        "observer_gap_ms": {"median":nearest_p(gaps_ms,.5),"p95":nearest_p(gaps_ms,.95),"max":max(gaps_ms)},
        "host_payload_mbps":8e-6*sum(row["bytes"] for row in host)/seconds,
        "host_write_mean_ms_max_window":max(row["stages"]["socket_write_ms"]["mean"] or 0 for row in host),
        "host_credit_wait_mean_ms_max_window":max(row["stages"]["credit_wait_ms"]["mean"] or 0 for row in host),
        "source_observed_submit_fps":source_fps, "source_summary":source_end, "viewer_observer_summary":end_summary,
        "host_rate_targets":rates, "host_nvenc_applies":applied,
        "host_send_buffer_diagnostics":[line for line in text.splitlines() if line.startswith("P09_SOCKET_BUFFER")],
        "viewer_observer_start_ns":start, "viewer_observer_end_ns":end,
    }
    if opts.send_buffer:
        buffers = re.findall(r"P09_SOCKET_BUFFER requested=(\d+) effective=(\d+)", text)
        if len(buffers) != 1 or int(buffers[0][0]) != opts.send_buffer or int(buffers[0][1]) < opts.send_buffer:
            raise RuntimeError("the requested private send buffer was not applied to the accepted stream")
        metrics["host_send_buffer_effective_bytes"] = int(buffers[0][1])
    if opts.cap:
        config, = read_jsonl(run/"remote"/"proxy.log")
        if config["config"]["s2c_bytes_per_second"] != opts.cap or config["config"]["c2s_bytes_per_second"] != 0:
            raise RuntimeError("private forward and reverse proxy pacing do not match the trial")
    if opts.recv_buffer:
        text = (run/"remote"/"proxy.log").read_text()
        buffers = re.findall(r"P09_PROXY_RCVBUF requested=(\d+) effective=(\d+)", text)
        if len(buffers) != 1 or int(buffers[0][0]) != opts.recv_buffer or int(buffers[0][1]) < opts.recv_buffer:
            raise RuntimeError("the requested proxy receive buffer was not applied on the upstream socket")
        metrics["proxy_upstream_buffer_bytes_requested"] = opts.recv_buffer
        metrics["proxy_upstream_buffer_effective_bytes"] = int(buffers[0][1])
    metrics["uncapped_unique_fps_gate_met"] = (
        metrics["observer_unique_frames_per_second"] >= 0.9*opts.fps if not opts.cap and not opts.pilot else None
    )
    metrics["adaptive_bitrate_step_applied"] = any(
        target["pressure"] == "Write" and target["percent"] < 100
        and {"fps":target["fps"], "percent":target["percent"]} in applied for target in rates
    )
    metrics["adaptive_fps_step_applied"] = any(
        target["fps"] < opts.fps and {"fps":target["fps"], "percent":target["percent"]} in applied for target in rates
    )
    if opts.arm == "fixed" and (rates or applied):
        raise RuntimeError("fixed arm unexpectedly changed the rate")
    for lane, rows in (("host",host),("viewer",viewer),("markers",kept_marks)):
        (run/f"retained-{lane}.jsonl").write_text("".join(json.dumps(row)+"\n" for row in rows))
    (run/"result.json").write_text(json.dumps(metrics,indent=2)+"\n")
    print(json.dumps(metrics),flush=True)

def run_trial(opts, trial, run_id):
    run = lab / trial
    run.mkdir(mode=0o700)
    size = f"{opts.width}x{opts.height}"
    try:
        with ExitStack() as stack:
            key = run / "key"
            subprocess.run([str(release),"keygen","--output",str(key)],stdout=subprocess.DEVNULL,check=True)
            stack.callback(key.unlink,missing_ok=True)
            env = clean_env()
            runtime = stack.enter_context(tempfile.TemporaryDirectory(prefix="jwm-p09-runtime."))
            env["XDG_RUNTIME_DIR"] = runtime

            def log(name):
                return stack.enter_context((run/name).open("wb"))

            xvfb = start_display(opts.width,opts.height,log("xvfb.log"))
            stack.callback(stop,xvfb)
            display = get_display(xvfb)
            host_cmd = ["python3","-u", opts.remote_dir+"/source.py",trial,"--arm",opts.arm,
                        "--width",str(opts.width),"--height",str(opts.height),"--fps",str(opts.fps),
                        "--paint-fps",str(opts.paint_fps),"--seconds",str(opts.seconds),
                        "--run-id",str(run_id),"--cap",str(opts.cap),"--send-buffer",str(opts.send_buffer),
                        "--recv-buffer",str(opts.recv_buffer),
                        "--host-scaling",opts.host_scaling,
                        "--host-binary-sha256",opts.host_binary_sha256,
                        "--painter-sha256",opts.painter_sha256]
            bridge_file = run/"remote-ready.log"
            source = subprocess.Popen(ssh+[remote,shlex.join(host_cmd)],stdin=subprocess.PIPE,
                                      stdout=log(bridge_file.name),stderr=log("remote-stderr.log"))
            stack.callback(stop,source,natural=True)
            source.stdin.write(key.read_bytes())
            source.stdin.flush()

            def upstream():
                rows = read_jsonl(bridge_file)
                return rows[0]["upstream_port"] if rows else None

            port = wait_for(source,upstream,20)
            with socket.socket() as chooser:
                chooser.bind(("127.0.0.1",0))
                local_port = chooser.getsockname()[1]
            tunnel_file = run/"tunnel.log"
            tunnel = subprocess.Popen(ssh+["-vN","-o","ExitOnForwardFailure=yes",
                                          "-L",f"127.0.0.1:{local_port}:127.0.0.1:{port}",remote],
                                      stdin=subprocess.DEVNULL,stdout=log(tunnel_file.name),stderr=subprocess.STDOUT)
            stack.callback(stop,tunnel)
            wait_for(tunnel,lambda: re.search(r"Local forwarding listening on 127\.0\.0\.1 port",tunnel_file.read_text()))

            viewer_args = [str(release),"connect",f"127.0.0.1:{local_port}","--view-only","--toggle",
                           "--stats-json","--key-file",str(key),"--display",display,"--window-size",size,
                           "--window-position","0,0","--scaling","cpu"]
            view = subprocess.Popen(viewer_args,env=env,stdin=subprocess.DEVNULL,
                                    stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
            stack.callback(stop,view)
            view_log = log("viewer.log")
            clock_log = log("viewer-clock.jsonl")

            def relay():
                for line in iter(view.stderr.readline,b""):
                    arrived = time.monotonic_ns()
                    view_log.write(line)
                    view_log.flush()
                    if line.startswith(b"{") and line.rstrip().endswith(b"}"):
                        item = json.loads(line)
                        if item.get("type")=="jwm_remote_viewer_stats" and not item.get("final"):
                            clock_log.write(json.dumps({"end_ns":arrived}).encode()+b"\n")
                            clock_log.flush()

            drain = threading.Thread(target=relay,daemon=True)
            drain.start()
            viewer_window = wait_for(view,lambda:locate_viewer(display,size,local_port),20)
            observer = subprocess.Popen(
                [str(painter_bin),"observe","--display",display,"--window",viewer_window,
                 "--width",str(opts.width),"--height",str(opts.height),
                 "--seconds",str(opts.seconds),"--run-id",str(run_id)],
                env=env,stdin=subprocess.DEVNULL,stdout=log("observed.jsonl"),stderr=log("observer-stderr.log"))
            stack.callback(stop,observer)
            if observer.wait(timeout=opts.seconds+10):
                raise RuntimeError("the presentation observer failed")
            if view.poll() is not None:
                raise RuntimeError("viewer exited before the presentation observer")
            subprocess.run(viewer_args,env=env,stdout=subprocess.DEVNULL,stderr=log("disconnect.log"),
                           timeout=8,check=True)
            if view.wait(timeout=10):
                raise RuntimeError("viewer failed to close")
            drain.join(timeout=5)
            if drain.is_alive():
                raise RuntimeError("viewer telemetry drain did not finish")
            if source.wait(timeout=15):
                raise RuntimeError("remote host failed to close")
    finally:
        # Copy raw scoped logs after the children stop even on failed trials.
        original_failure = sys.exc_info()[0]
        try:
            subprocess.run(["scp","-qr",f"{remote}:{opts.remote_dir}/{trial}",str(run/"remote")],
                           timeout=15,check=True,stderr=subprocess.PIPE)
        except (OSError,subprocess.SubprocessError):
            if original_failure is None:
                raise
            (run/"remote-copy-error.log").write_text(traceback.format_exc())
    analyze(run,opts,run_id)

def parser():
    p = argparse.ArgumentParser()
    p.add_argument("--remote-dir",required=True)
    p.add_argument("--label",required=True)
    p.add_argument("--pilot",action="store_true")
    p.add_argument("--host-scaling-order", nargs="+", choices=("cpu", "auto"), default=list(SCALING_ORDER))
    p.add_argument("--host-binary-sha256", default=HOST_PIN)
    p.add_argument("--viewer-binary-sha256", default=VIEWER_PIN)
    p.add_argument("--observer-sha256", default=OBSERVER_PIN)
    p.add_argument("--painter-sha256", required=True, help="known SHA-256 of the existing Ubuntu fixture")

    p.add_argument("--width",type=int,default=3840)
    p.add_argument("--height",type=int,default=2160)
    p.add_argument("--fps",type=int,default=30)
    p.add_argument("--paint-fps",type=int,default=60)
    p.add_argument("--seconds",type=int,default=105)
    p.add_argument("--cap",type=int,default=0)
    p.add_argument("--send-buffer",type=int,default=0)
    p.add_argument("--recv-buffer",type=int,default=0)
    p.add_argument("--retry-failed-trial",action="store_true")
    return p

if __name__ == "__main__":
    p = parser()
    opts = p.parse_args()
    if not re.fullmatch(r"[a-z0-9-]+",opts.label) or not re.fullmatch(r"/tmp/jwm-p09-stage-ab\.[A-Za-z0-9]+",opts.remote_dir):
        p.error("invalid trial label or private remote directory")
    opts.arms = ["fixed"] * len(opts.host_scaling_order)
    if opts.cap or opts.send_buffer or opts.recv_buffer or opts.fps != 30:
        p.error("the stage comparison requires fixed 30 FPS and uncapped, ordinary TCP")
    if not opts.pilot and (tuple(opts.host_scaling_order) != SCALING_ORDER or opts.seconds != 105):
        p.error("scored A/B requires two ABBA blocks and the 105-second session window")
    if any(not re.fullmatch(r"[0-9a-f]{64}", digest) for digest in (
        opts.host_binary_sha256, opts.viewer_binary_sha256, opts.observer_sha256, opts.painter_sha256
    )):
        p.error("all binaries require an explicit SHA-256 digest")
    if sha256(release) != opts.viewer_binary_sha256 or sha256(painter_bin) != opts.observer_sha256:
        p.error("viewer release or observer does not match its pinned SHA-256")
    def link_snapshot(stage):
        with (lab / f"{opts.label}-link-{stage}.txt").open("wb") as log:
            try:
                subprocess.run(["ping","-q","-c","8","-i","0.25","-W","1","<private-peer>"],
                               stdout=log,stderr=subprocess.STDOUT,timeout=8,check=False)
            except (OSError,subprocess.TimeoutExpired) as error:
                log.write(f"Link observation unavailable: {error}\n".encode())

    failures = []
    with open("/tmp/jwm-p08-p09-release/benchmark.lock","a") as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        if not opts.pilot:
            link_snapshot("before")
        for index,arm in enumerate(opts.arms,1):
            opts.arm = arm
            opts.host_scaling = opts.host_scaling_order[index-1]
            attempts = ("","-retry") if opts.retry_failed_trial else ("",)
            for suffix in attempts:
                name = f"{opts.label}-{index:02}-{opts.host_scaling}-{arm}{suffix}"
                print(f"started {name}",flush=True)
                try:
                    run_trial(opts,name,index)
                except (OSError, RuntimeError, subprocess.SubprocessError, ValueError, KeyError) as error:
                    print(f"failed {name}: {error}",flush=True)
                    (lab/f"{name}-error.log").write_text(traceback.format_exc())
                    if suffix == attempts[-1]:
                        failures.append(name)
                else:
                    break
        if not opts.pilot:
            link_snapshot("after")
    if failures:
        raise SystemExit(f"required benchmark cases failed: {', '.join(failures)}")
