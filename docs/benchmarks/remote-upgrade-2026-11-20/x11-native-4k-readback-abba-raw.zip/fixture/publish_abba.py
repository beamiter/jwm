#!/usr/bin/env python3
"""Publish and verify a terminal 4K X11 SHM comparison entirely offline."""

import argparse
import ast
import hashlib
import json
from pathlib import Path
import re
import tempfile
from zipfile import ZIP_DEFLATED, ZipFile

from finalize_abba import EXPECTED_SIZE, ORDER, PIN_FIELDS, finalize, require
from stages import bounded_read


LABEL = "readback-4k-20261121"
STEM = "x11-native-4k-readback-abba"
SCRATCH_POINTER = Path("/tmp/jwm-x11-4k-shm-abba-dir")
STATIC = {
    "benchmark.py": "benchmark.py",
    "processes.py": "processes.py",
    "source.py": "source.py",
}
RAW_FIELDS = (
    "result.json",
    "observed.jsonl",
    "viewer-clock.jsonl",
    "retained-host.jsonl",
    "retained-viewer.jsonl",
    "retained-markers.jsonl",
    "remote/paint.jsonl",
    "remote/binaries.json",
)
ROLE_LOGS = {
    "host": ("remote/host.log", "remote/host-telemetry.jsonl", {
        "nvenc_negotiated": "H.264 NVENC negotiated",
        "hardware_encode_failed": "hardware encoding failed",
    }),
    "viewer": ("viewer.log", "viewer-telemetry.jsonl", {
        "vaapi_active": "H.264 hardware decoder active (VAAPI)",
        "session_ended": "jwm-remote: session ended",
        "jpeg_switch": "host switched to JPEG",
    }),
}
FAILURE_REASONS = (
    "source and observer trial markers did not match",
    "the exact observation drawable or trial was lost",
    "the observer ended before the full measured interval",
    "viewer pixels did not produce a valid marker stream",
    "observer retained stale or duplicate markers",
    "the measured windows did not keep the fixed H.264 codec",
    "source or encoded image was resized unexpectedly",
    "source manifest does not match the requested A/B case",
    "insufficient telemetry",
    "arm measured the wrong readback route",
    "unexpected CPU rescaling in native-size A/B",
    "A/B did not measure an active readback window",
    "the presentation observer failed",
    "viewer exited before the presentation observer",
    "viewer failed to close",
    "viewer telemetry drain did not finish",
    "remote host failed to close",
    "source painter ended during the benchmark",
    "source was not capable of the requested rate",
    "host and viewer telemetry are from different authenticated sessions",
)
SHA = re.compile(r"[0-9a-f]{64}")
IP4 = re.compile(rb"(?<![0-9.])(?:192\.168|10\.\d{1,3}|172\.(?:1[6-9]|2\d|3[01]))\.\d{1,3}\.\d{1,3}(?![0-9.])")
ERROR = re.compile(r"^(?:\w+\.)*(\w*(?:Error|Exception|Timeout)):", re.M)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encoded(data):
    return (json.dumps(data, indent=2, allow_nan=False) + "\n").encode()


def read_json(data):
    return json.loads(data)


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)


def trial_names(label):
    return [f"{label}-{i:02}-{arm}-fixed{retry}" for i, arm in enumerate(ORDER, 1)
            for retry in ("", "-retry")]


def read_pins(benchmark, painter=None):
    constants = {}
    expected = ("HOST_PIN", "VIEWER_PIN", "OBSERVER_PIN")
    for node in ast.parse(benchmark.decode()).body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and (
                isinstance(node.targets[0], ast.Name) and node.targets[0].id in expected):
            constants[node.targets[0].id] = ast.literal_eval(node.value)
    values = [constants[key] for key in expected]
    if painter is not None:
        values.append(painter.decode().strip())
    require(all(isinstance(item, str) and SHA.fullmatch(item) for item in values), "invalid predeclared binary pin")
    return dict(zip(PIN_FIELDS, values if painter is not None else values + [None]))


def typed_log(data, role):
    allowed = {f"jwm_remote_{role}_stats", "jwm_remote_command_result"}
    rows = []
    malformed = 0
    for line in data.splitlines(keepends=True):
        if not line.startswith(b"{"):
            continue
        try:
            parsed = json.loads(line)
            if parsed.get("type") in allowed:
                rows.append(line.rstrip(b"\r\n") + b"\n")
        except (ValueError, AttributeError):
            malformed += 1
    return b"".join(rows), malformed


def failure_summary(data):
    text = data.decode(errors="replace")
    return {
        "sha256_before_omission": digest(data),
        "recognized_reasons": [reason for reason in FAILURE_REASONS if reason in text],
        "terminal_error_types": ERROR.findall(text),
    }


def route_diagnostics(folder, archive_name, entries):
    result = {}
    for role, (log_file, raw_file, phrases) in ROLE_LOGS.items():
        path = folder / log_file
        if path.is_file():
            data = bounded_read(path)
            clean, malformed = typed_log(data, role)
            entries[f"run/{archive_name}/{raw_file}"] = clean
            result[role] = {
                "sha256_before_omission": digest(data),
                "unparsed_json_candidates": malformed,
                "matches": {key: data.count(phrase.encode()) for key, phrase in phrases.items()},
            }
        else:
            result[role] = None
    return result


def link_summary(path):
    data = bounded_read(path)
    text = data.decode(errors="replace")
    count = re.findall(r"(\d+) packets transmitted, (\d+)(?: packets)? received", text)
    timing = re.findall(r"rtt min/avg/max/mdev = ([0-9.]+)/([0-9.]+)/([0-9.]+)/([0-9.]+) ms", text)
    return {
        "sha256_before_omission": digest(data),
        "packets": dict(zip(("transmitted", "received"), map(int, count[-1]))) if count else None,
        "rtt_ms": dict(zip(("min", "mean", "max", "mdev"), map(float, timing[-1]))) if timing else None,
    }


def gather(stage, source, painter_c, terminal_exit, label):
    entries = {}
    source_index = {}
    for name, path in STATIC.items():
        candidate = source if name == "source.py" and source is not None else stage / path
        if not candidate.is_file() and name == "source.py":
            continue
        data = bounded_read(candidate)
        clean = IP4.sub(b"<private-peer>", data)
        entries["fixture/" + name] = clean
        source_index[name] = {"sha256_before_redaction": digest(data), "redacted": data != clean,
                              "record_origin": "supplied local copy" if candidate == source else "staged local file"}
    if painter_c is not None:
        entries["fixture/p09-workload.c"] = bounded_read(painter_c)
    for name in ("publish_abba.py", "finalize_abba.py", "stages.py"):
        entries["fixture/" + name] = bounded_read(Path(__file__).with_name(name))
    painter_pin = stage / "painter-sha256"
    if painter_pin.is_file():
        entries["run/painter-sha256"] = bounded_read(painter_pin)
    pins = read_pins(entries["fixture/benchmark.py"], entries.get("run/painter-sha256"))
    entries["run/pins.json"] = encoded(pins)
    for name in trial_names(label):
        folder = stage / name
        if folder.is_dir():
            for filename in RAW_FIELDS:
                path = folder / filename
                if path.is_file():
                    entries[f"run/{name}/{filename}"] = bounded_read(path)
            diagnostics = route_diagnostics(folder, name, entries)
            for filename in ("observer-stderr.log", "remote/paint-stderr.log", "disconnect.log", "remote-copy-error.log"):
                path = folder / filename
                if path.is_file():
                    data = bounded_read(path)
                    diagnostics[filename] = {"bytes": len(data), **failure_summary(data)}
            # Inventory exists even when the attempt never produced a result.
            entries[f"run/{name}/diagnostics.json"] = encoded(diagnostics)
        error = stage / f"{name}-error.log"
        if error.is_file():
            entries[f"run/{name}-error.json"] = encoded(failure_summary(bounded_read(error)))
    for phase in ("before", "after"):
        path = stage / f"{label}-link-{phase}.txt"
        if path.is_file():
            entries[f"run/link-{phase}.json"] = encoded(link_summary(path))
    controller = stage / "live.log"
    if controller.is_file():
        data = bounded_read(controller)
        text = data.decode(errors="replace")
        started = re.findall(r"^started ([a-z0-9-]+)$", text, re.M)
        failed = re.findall(r"^failed ([a-z0-9-]+):", text, re.M)
        valid_names = set(trial_names(label))
        entries["run/controller-diagnostics.json"] = encoded({
            **failure_summary(data),
            "reported_starts": [name for name in started if name in valid_names],
            "reported_failures": [name for name in failed if name in valid_names],
        })
    entries["run/terminal.json"] = encoded({
        "label": label, "exit_status": terminal_exit, "source_files": source_index,
    })
    return entries


def reconstruct(entries, expected_label=LABEL, expected_size=EXPECTED_SIZE):
    terminal = read_json(entries["run/terminal.json"])
    require(terminal["label"] == expected_label and type(terminal["exit_status"]) is int,
            "unexpected terminal label or controller exit")
    pins = read_pins(entries["fixture/benchmark.py"], entries.get("run/painter-sha256"))
    require(read_json(entries["run/pins.json"]) == pins, "normalized pins differ from the retained manifest")
    allowed = set(trial_names(expected_label))
    control = {}
    with tempfile.TemporaryDirectory(prefix="jwm-4k-readback-replay.") as scratch:
        sandbox = Path(scratch)
        for key, data in entries.items():
            relative = Path(key)
            require(not relative.is_absolute() and ".." not in relative.parts, "unsafe archive member")
            if len(relative.parts) >= 2 and relative.parts[0] == "run":
                name = relative.parts[1]
                if name.endswith("-error.json"):
                    name = name.removesuffix("-error.json")
                if name in allowed:
                    write(sandbox.joinpath(*relative.parts[1:]), data)
        report = finalize(sandbox, expected_label, pins, terminal["exit_status"], expected_size)
    report["fixture_provenance"] = terminal["source_files"]
    report["link_context"] = {phase: read_json(entries[f"run/link-{phase}.json"])
                              for phase in ("before", "after") if f"run/link-{phase}.json" in entries}
    if "run/controller-diagnostics.json" in entries:
        control = read_json(entries["run/controller-diagnostics.json"])
    report["controller_diagnostics"] = control
    report["route_and_scope"] = (
        "Two isolated Xvfb desktops, Ubuntu host and Mint viewer, authenticated fixed NVENC H.264 over "
        "an unpaced SSH forward on the measured Wi-Fi link. Planned CPU/core XGetImage and AUTO/MIT-SHM "
        "arms differ only in host readback selection. Valid attempts establish the actual host readback, "
        "VA-API decode, and X11 RGB presentation. "
        "Observer-visible unique frame counts are local to this workload."
    )
    return read_json(encoded(report))


def publish(entries, output, label=LABEL, size=EXPECTED_SIZE):
    result = reconstruct(entries, label, size)
    output.mkdir(parents=True, exist_ok=True)
    raw = output / (STEM + "-raw.zip")
    summary = output / (STEM + ".json")
    require(not raw.exists() and not summary.exists(), "output already exists; use a fresh scratch directory")
    with ZipFile(raw, "x", compression=ZIP_DEFLATED, compresslevel=7) as writer:
        for name, data in sorted(entries.items()):
            writer.writestr(name, data)
    result["archive"] = {"path": raw.name, "sha256": digest(raw.read_bytes()),
                         "entries": {name: digest(data) for name, data in entries.items()}}
    with summary.open("xb") as stream:
        stream.write(encoded(result))
    replay(summary, raw, label, size)
    print(result["status"], summary, raw)


def replay(summary, raw, label=LABEL, size=EXPECTED_SIZE):
    result = read_json(summary.read_bytes())
    archive = result.pop("archive")
    require(raw.name == archive["path"] and digest(raw.read_bytes()) == archive["sha256"], "archive identity differs")
    with ZipFile(raw) as reader:
        members = reader.namelist()
        require(len(members) == len(set(members)) and set(members) == set(archive["entries"]),
                "archive inventory differs")
        entries = {name: reader.read(name) for name in members}
    require({name: digest(data) for name, data in entries.items()} == archive["entries"], "archive entry digest differs")
    require(reconstruct(entries, label, size) == result, "offline result differs from published summary")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    pack = sub.add_parser("publish")
    pack.add_argument("--stage", type=Path, help="defaults to the queued 4K scratch stage pointer")
    pack.add_argument("--source", type=Path, help="exact staged source.py copy when the controller staged it from elsewhere")
    pack.add_argument("--painter-c", type=Path, default=Path("/tmp/jwm-p09-workload/p09-workload.c"))
    pack.add_argument("--out", type=Path, required=True)
    check = sub.add_parser("replay")
    check.add_argument("summary", type=Path)
    check.add_argument("raw", type=Path)
    args = parser.parse_args()
    if args.command == "publish":
        stage = args.stage if args.stage is not None else Path(SCRATCH_POINTER.read_text().strip())
        exit_file = stage / "live.exit"
        if not exit_file.is_file():
            parser.error("controller exit record missing; publish only a confirmed terminal batch")
        status = int(exit_file.read_text().strip())
        publish(gather(stage, args.source, args.painter_c, status, LABEL), args.out)
    else:
        result = replay(args.summary, args.raw)
        print(result["status"], "reproduced from", args.raw)


if __name__ == "__main__":
    main()
