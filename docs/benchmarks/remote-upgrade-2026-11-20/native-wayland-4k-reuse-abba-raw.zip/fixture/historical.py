import hashlib
import json
import math
from pathlib import Path
from statistics import median
import sys
import traceback
from zipfile import ZIP_DEFLATED, ZipFile


LAB = Path(__file__).resolve().parent
TRIAL_IDS = (82, 83, 84)


def digest(path):
    with path.open('rb') as data:
        return hashlib.file_digest(data, 'sha256').hexdigest()


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.startswith('{')]


def read_viewer_windows(run, scope, start_ns, end_ns):
    events = [event['metrics'] for event in rows(run / 'viewer/viewer-events.jsonl') if event.get('metrics')]
    clock_rows = rows(run / 'viewer/viewer-clock.jsonl')
    unique = []
    scored = []
    seen = set()
    for event, clock in zip(events, clock_rows, strict=True):
        assert scope['session_id'] == event['session_id'] == clock['session_id']
        assert event['window_ms'] == clock['window_ms'] and event['final'] == clock['final']
        assert event['negotiated_codec'] == 'H.264'
        assert event['hardware_download_ms']['observations'] == 0
        assert event['native_presented_frames'] == event['presented_frames']
        if event['presented_frames']:
            assert event['last_presentation_path'] == 'wayland-vaapi-dmabuf'
        frame = event['last_decoded_frame']
        if frame:
            assert frame['sequence'] == clock['last_decoded_sequence']
            assert frame['source_epoch'] == scope['source_epoch']
            assert frame['geometry_epoch'] == scope['geometry_epoch']
            assert frame['source_dimensions'] == frame['encoded_dimensions'] == [3840, 2160]
            assert frame['codec'] == 'H.264'
        identity = json.dumps(event, sort_keys=True)
        if identity in seen:
            continue
        seen.add(identity)
        record = {'arrival_monotonic_ns': clock['monotonic_ns'], 'metrics': event}
        unique.append(record)
        finish = clock['monotonic_ns']
        duration = round(event['window_ms'] * 1e6)
        if not event['final'] and start_ns <= finish - duration and finish <= end_ns:
            scored.append(record)
    assert unique and unique[-1]['metrics']['final']
    assert scored and any(row['metrics']['acked_frames'] for row in scored)
    return {
        'managed_snapshot_count': len(events),
        'repeated_managed_snapshot_count': len(events) - len(unique),
        'whole_session_windows': unique,
        'windows_wholly_inside_the_observer_interval': scored,
        'whole_window_coverage_seconds': sum(row['metrics']['window_ms'] for row in scored) / 1000,
    }


def validate(run, result, preflight):
    for field in ('host_binary_sha256', 'viewer_binary_sha256', 'viewer_test_binary_sha256'):
        assert result[field] == preflight[field]
    assert result['warmup_seconds'] == 30 and result['requested_observe_seconds'] == 60
    assert result['scored_native_trial']
    observed = rows(run / 'viewer/observed.jsonl')
    start, = [row for row in observed if row['type'] == 'p09_start']
    end, = [row for row in observed if row['type'] == 'p09_end']
    assert start == result['observer_start'] and end == result['observer_end']
    assert start['run_id'] == end['run_id'] == result['run_id']
    assert start['scope'] == end['scope'] and start['backend'] == 'private-wayland-dmabuf'
    assert [start['width'], start['height']] == [3840, 2160]
    assert start['roi_bytes'] == 96 * 96 * 4 and not end['target_lost'] and not end['interrupted']
    assert end['wrong_run'] == end['reordered'] == 0
    first, last = (end[f'score_{edge}_ns'] for edge in ('start', 'end'))
    assert first - start['monotonic_ns'] == 30_000_000_000 and last - first == 60_000_000_000
    marks = [row for row in observed if row['type'] == 'p09_frame']
    assert all(row['observed_run_id'] == start['run_id'] for row in marks)
    assert all(a['source_frame'] < b['source_frame'] for a, b in zip(marks, marks[1:]))
    retained = [row['monotonic_ns'] for row in marks if row['scored']]
    assert retained == [row['monotonic_ns'] for row in marks if first <= row['monotonic_ns'] < last]
    assert len(retained) == end['scored_unique'] == result['scored_unique_markers']
    assert len(retained) / 60 == result['unique_markers_per_second']
    points = [first, *retained, last]
    gaps = sorted(b - a for a, b in zip(points, points[1:]))
    assert max(gaps) == end['longest_scored_gap_ns']
    result['p95_observed_gap_ms'] = gaps[math.ceil(len(gaps) * .95) - 1] / 1e6
    result['viewer_telemetry'] = read_viewer_windows(run, start['scope'], first, last)
    host = [row for row in rows(run / 'source/host.log') if row.get('type') == 'jwm_remote_host_stats']
    assert host and {row['session_id'] for row in host} == {start['scope']['session_id']}
    assert sum(row['h264_frames'] for row in host) == result['host_h264_frames']
    assert sum(row['drawn_acks'] for row in host) == result['host_drawn_acks']
    assert all(row['encoded_dimensions'] == row['source_dimensions'] == [3840, 2160]
               for row in host if row['h264_frames'])
    assert all(not row['jpeg_atlases'] and not row['hevc444_frames'] for row in host)
    return result


def publish(evidence, trial_ids):
    preflight = json.loads((LAB / 'p09-wayland-native-081/result.json').read_text())
    trials = []
    entries = {f'fixture/{name}': LAB / name for name in ('preflight.py', 'processes.py', 'run-scored.sh',
                                                         'marker-source-sha256.txt', 'finalize_scored.py')}
    for run_id in trial_ids:
        label = f'p09-wayland-native-{run_id:03d}'
        folder = LAB / label
        result = folder / 'result.json'
        if result.is_file():
            try:
                verified = validate(folder, json.loads(result.read_text()), preflight)
            except (AssertionError, KeyError, OSError, ValueError):
                trial = {'status': 'invalid_evidence', 'run_id': run_id,
                         'validation_error': traceback.format_exc(limit=5)}
            else:
                trial = {'status': 'valid', 'run_id': run_id, 'result': verified}
        else:
            trial = {'status': 'no_valid_result', 'run_id': run_id}
            events_path = folder / 'viewer/viewer-events.jsonl'
            if events_path.is_file():
                failures = [event['failure'] for event in rows(events_path)
                            if event.get('state') == 'failed' and event.get('failure')]
                if failures:
                    trial['last_viewer_failure'] = failures[-1]
        trials.append(trial)
        for field in ('result.json', 'marker-test.log', 'source/host.log', 'source/paint.jsonl',
                      'viewer/observed.jsonl', 'viewer/viewer-events.jsonl', 'viewer/viewer-clock.jsonl',
                      'viewer/viewer-stderr.log'):
            if (folder / field).is_file():
                entries[f'trace/{label}/{field}'] = folder / field
    rates = [trial['result']['unique_markers_per_second'] for trial in trials if trial['status'] == 'valid']
    report = {'schema_version': 1, 'trials': trials, 'initial_trial_ids': TRIAL_IDS,
              'scope': ('Native 4K repetitions, retaining failed or additional attempts. The host uses Ubuntu Xvfb and NVENC. '
                        'An owned Intel Wayland compositor observes visible content and completes Wayland feedback. '
                        'Viewer windows are deduplicated; host windows cover the whole session on the host clock.'),
              'summary': {'trial_fps': rates, 'median_fps': median(rates) if rates else None,
                          'trials_meeting_27_fps': sum(trial['result']['viewer_27_fps_gate_met'] is True
                                                    for trial in trials if trial['status'] == 'valid')}}
    archive = evidence / 'native-wayland-4k-motion-scored-raw.zip'
    staged = archive.with_suffix('.zip.tmp')
    digests = {member: digest(path) for member, path in entries.items()}
    with ZipFile(staged, 'w', compression=ZIP_DEFLATED, compresslevel=6) as writer:
        for member, path in entries.items():
            writer.write(path, member)
    with ZipFile(staged) as reader:
        assert reader.testzip() is None
        assert {member: hashlib.sha256(reader.read(member)).hexdigest() for member in reader.namelist()} == digests
    staged.replace(archive)
    report['archive'] = {'path': archive.name, 'sha256': digest(archive), 'entries': digests}
    output = evidence / 'native-wayland-4k-motion-scored.json'
    pending = output.with_suffix('.json.tmp')
    pending.write_text(json.dumps(report, indent=2) + '\n')
    pending.replace(output)
    print(report['summary'])


if __name__ == '__main__':
    ids = (*TRIAL_IDS, *(int(arg) for arg in sys.argv[2:]))
    assert len(set(ids)) == len(ids) and all(1 <= case <= 255 for case in ids)
    publish(Path(sys.argv[1]), ids)
