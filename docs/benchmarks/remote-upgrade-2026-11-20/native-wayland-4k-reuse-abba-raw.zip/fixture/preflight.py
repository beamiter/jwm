from contextlib import ExitStack
import hashlib
import json
from pathlib import Path
import re
import shlex
import socket
import subprocess

from processes import clean_env, stop, wait_for


LAB = Path(__file__).resolve().parent
PEER = 'offline@invalid.example'
SSH = ['ssh', '-4', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
       '-o', 'ControlMaster=no', '-o', 'ControlPath=none', '-o', 'ServerAliveInterval=5',
       '-o', 'Compression=no', '-o', 'ProxyJump=none', '-o', 'ProxyCommand=none',
       '-o', 'ForwardAgent=no', '-o', 'ForwardX11=no', '-o', 'StrictHostKeyChecking=yes']


def digest(path):
    with path.open('rb') as data:
        return hashlib.file_digest(data, 'sha256').hexdigest()


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.startswith('{')]


def result(run, options, host_sha):
    observed = rows(run / 'viewer' / 'observed.jsonl')
    first, = [row for row in observed if row['type'] == 'p09_start']
    last, = [row for row in observed if row['type'] == 'p09_end']
    markers = [row for row in observed if row['type'] == 'p09_frame']
    assert first['run_id'] == last['run_id'] == options.run_id
    assert all(row['run_id'] == options.run_id for row in markers) and len(markers) >= 2
    assert all(a['source_frame'] < b['source_frame'] for a, b in zip(markers, markers[1:]))
    assert all(a['monotonic_ns'] < b['monotonic_ns'] for a, b in zip(markers, markers[1:]))
    start, end = (last[f'score_{edge}_ns'] for edge in ('start', 'end'))
    assert end - start == options.seconds * 1_000_000_000
    assert all(row['scored'] == (start <= row['monotonic_ns'] < end) for row in markers)
    scored = [row['monotonic_ns'] for row in markers if row['scored']]
    gaps = [b - a for a, b in zip([start, *scored], [*scored, end])]
    assert len(scored) == last['scored_unique'] and max(gaps) == last['longest_scored_gap_ns']
    paint = rows(run / 'source' / 'paint.jsonl')
    assert any(row.get('type') == 'p09_start' and row['run_id'] == options.run_id for row in paint)
    painting, = [row for row in paint if row.get('type') == 'p09_end']
    source_fps = ((painting['submitted'] - 1) * 1e9
                  / (painting['last_submit_ns'] - painting['first_submit_ns']))
    host = [row for row in rows(run / 'source' / 'host.log') if row.get('type') == 'jwm_remote_host_stats']
    active = [row for row in host if row['h264_frames']]
    assert active and any(row['drawn_acks'] for row in active)
    assert all(row['encoded_dimensions'] == row['source_dimensions'] == [3840, 2160] for row in active)
    assert all(not row['jpeg_atlases'] and not row['hevc444_frames'] for row in host)
    assert {row['session_id'] for row in host} == {first['scope']['session_id']}
    trace = (run / 'marker-test.log').read_text()
    assert re.search(r'test result: ok\. 1 passed; 0 failed;', trace)
    payload = {
        'source_artifact': 'P09 moving markers on an owned Ubuntu Xvfb',
        'scope': 'Isolated actual 4K H.264 native Intel Wayland with uncapped SSH',
        'scored_native_trial': options.warmup == 30 and options.seconds == 60,
        'viewer_27_fps_gate_met': len(scored) >= 27 * 60
                                 if options.warmup == 30 and options.seconds == 60 and source_fps >= 30
                                 else None,
        'arm': options.arm,
        'run_id': options.run_id, 'warmup_seconds': options.warmup,
        'requested_observe_seconds': options.seconds, 'unique_markers': len(markers),
        'scored_unique_markers': len(scored), 'unique_markers_per_second': len(scored) / options.seconds,
        'longest_gap_ms': max(gaps) / 1e6,
        'source_submitted_frames_per_second': source_fps,
        'source_qualified_for_30_fps_request': source_fps >= 30,
        'host_binary_sha256': host_sha, 'viewer_binary_sha256': digest(options.viewer_bin),
        'viewer_test_binary_sha256': digest(options.lib_bin),
        'observer_start': first, 'observer_end': last,
        'host_h264_frames': sum(row['h264_frames'] for row in active),
        'host_drawn_acks': sum(row['drawn_acks'] for row in host),
    }
    (run / 'result.json').write_text(json.dumps(payload, indent=2) + '\n')
    return payload


def run(options):
    remote_dir = options.pins['remote_dir']
    host_sha = options.pins['sha256']['host']
    run = options.directory
    label = f'{run.parent.name}-{run.name}'
    assert re.fullmatch(r'[A-Za-z0-9_.-]+', label)
    options.stage = 'ownership_setup'
    harvest = None
    try:
        outcome = start_trial(run, label, remote_dir, options)
    finally:
        if (run / 'remote-ready.jsonl').exists():
            with (run / 'source-harvest.log').open('wb') as log:
                try:
                    harvest = subprocess.run(
                        ['scp', '-4Bqr', '-o', 'ConnectTimeout=5',
                         f'{PEER}:{remote_dir}/{label}', str(run / 'source')],
                        stdout=log, stderr=subprocess.STDOUT, timeout=20,
                    )
                except subprocess.TimeoutExpired:
                    log.write(b'Source harvest exceeded the deadline.\n')
                except OSError as error:
                    log.write(f'Source harvest failed: {type(error).__name__}\n'.encode())
    if outcome.returncode:
        raise RuntimeError(f'Wayland marker test exited {outcome.returncode}; see {run / "marker-test.log"}')
    options.stage = 'source_harvest'
    if harvest is None or harvest.returncode:
        raise RuntimeError('source archive could not be harvested')
    options.stage = 'assemble_exact_marker_result'
    return result(run, options, host_sha)


def start_trial(run, label, remote_dir, options):
    print(f'4K Wayland {options.arm} run {options.run_id}: {run}', flush=True)
    with ExitStack() as cleanup:
        def log(name):
            return cleanup.enter_context((run / name).open('wb'))

        key = run / 'key'
        cleanup.callback(key.unlink, missing_ok=True)
        env = clean_env()
        options.stage = 'keygen'
        subprocess.run([options.viewer_bin, 'keygen', '--output', key], env=env, check=True, timeout=5,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        source_command = [
            'python3', '-u', f'{remote_dir}/source.py', label, '--arm', 'treatment',
            '--width', '3840', '--height', '2160', '--fps', '30', '--paint-fps', '60',
            '--seconds', str(options.warmup + options.seconds), '--run-id', str(options.run_id),
            '--cap', '0', '--send-buffer', '0', '--recv-buffer', '0', '--capture-scaling', 'auto',
            '--feature-flag', 'JWM_REMOTE_PARALLEL_YUV420', '--enable-at', 'host',
        ]
        ready_path = run / 'remote-ready.jsonl'
        options.stage = 'source_start'
        source = subprocess.Popen(SSH + [PEER, shlex.join(source_command)], stdin=subprocess.PIPE,
                                  stdout=log(ready_path.name), stderr=log('remote-stderr.log'))
        cleanup.callback(stop, source, natural=True)
        source.stdin.write(key.read_bytes())
        source.stdin.flush()

        def port_announced():
            ready = rows(ready_path)
            return ready[0]['upstream_port'] if ready else None

        remote_port = wait_for(source, port_announced, 20)
        options.stage = 'tunnel_start'
        with socket.socket() as choose:
            choose.bind(('127.0.0.1', 0))
            local_port = choose.getsockname()[1]
        ssh_log = run / 'tunnel.log'
        tunnel = subprocess.Popen(SSH + ['-vN', '-o', 'ExitOnForwardFailure=yes', '-L',
                                          f'127.0.0.1:{local_port}:127.0.0.1:{remote_port}', PEER],
                                  stdin=subprocess.DEVNULL, stdout=log(ssh_log.name), stderr=subprocess.STDOUT)
        cleanup.callback(stop, tunnel)
        wait_for(tunnel, lambda: 'Local forwarding listening on 127.0.0.1 port' in ssh_log.read_text(), 12)
        # clean_env strips all inherited JWM_REMOTE_* options. Supply the
        # experiment switch only to the actual viewer launch path.
        if options.arm == 'B':
            env['JWM_REMOTE_WAYLAND_REUSE_RGB'] = '1'
        env.update(JWM_PHASE_REAL_VIEWER=str(options.viewer_bin), JWM_PHASE_EVIDENCE=str(run / 'viewer'))
        command = [LAB / 'test-remote-wayland-4k-marker.sh', options.lib_bin,
                   LAB / 'viewer-stats-wrapper.sh',
                   '/dev/dri/renderD128', f'127.0.0.1:{local_port}', key, str(options.run_id),
                   run / 'viewer', str(options.warmup), str(options.seconds)]
        options.stage = 'viewer_observer'
        outcome = subprocess.run(command, env=env, stdout=log('marker-test.log'), stderr=subprocess.STDOUT,
                                 timeout=options.warmup + options.seconds + 55)
        if outcome.returncode == 0:
            options.stage = 'source_close'
            assert source.wait(timeout=15) == 0
        return outcome
