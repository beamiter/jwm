"""Private 4K Wayland RGB backing experiment and offline replay."""
import argparse
import fcntl
import ipaddress
import json
import math
import os
from pathlib import Path
import re
import shlex
from statistics import median
import subprocess
import tempfile
import traceback
from types import SimpleNamespace
from zipfile import ZIP_DEFLATED, ZipFile

import historical
import preflight
from preflight import LAB, PEER, SSH, digest
from validate_phases import NATIVE_STAGES, join_windows, marker_scope, records, require


LOCK = LAB / 'offline-benchmark.lock'
FFMPEG = ''
RENDER_NODE = Path('/dev/dri/renderD128')
PEER_ADDRESS = PEER.split('@', 1)[1]
HOST_BIN = 'offline-host-binary'
ACTIVE = 'jwm-remote: native Wayland XRGB DMA-BUF backing reuse active'
FIXTURES = ('preflight.py', 'processes.py', 'viewer-stats-wrapper.sh', 'tee_stderr.py',
            'historical.py', 'validate_phases.py', 'test-remote-wayland-4k-marker.sh', 'run_abba.py')


def write_json(path, value):
    staged = path.with_suffix(path.suffix + '.tmp')
    staged.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    staged.replace(path)


def remote(*arguments):
    return subprocess.check_output(SSH + ['-n', PEER, shlex.join(arguments)], text=True, timeout=15)


def route_summary():
    def route(raw, expected):
        row, = json.loads(raw)
        require(row['dev'] == expected, f'expected original {expected} lab route')
        return row

    mint = route(subprocess.check_output(['ip', '-j', '-4', 'route', 'get', PEER_ADDRESS],
                                         text=True, timeout=5), 'eno1')
    mint_source = str(ipaddress.IPv4Address(mint.get('prefsrc', mint.get('src'))))
    ubuntu = route(remote('ip', '-j', '-4', 'route', 'get', mint_source), 'wlp3s0')
    ubuntu_source = str(ipaddress.IPv4Address(ubuntu.get('prefsrc', ubuntu.get('src'))))
    require(ubuntu_source == PEER_ADDRESS, 'return IPv4 address differs from SSH endpoint')
    return {'mint_interface': mint['dev'], 'ubuntu_interface': ubuntu['dev'],
            'address_family': 'IPv4', 'tunnel': 'SSH compression disabled, no rate cap'}


def current_pins(viewer, observer, remote_dir):
    require(re.fullmatch(r'/tmp/jwm-p09-candidate\.[A-Za-z0-9]+', remote_dir), 'unexpected source fixture path')
    paths = {'host': HOST_BIN, 'source_controller': f'{remote_dir}/source.py',
             'source_process_helpers': f'{remote_dir}/processes.py', 'painter': f'{remote_dir}/p09-workload'}
    digests = {}
    for line in remote('sha256sum', '--', *paths.values()).splitlines():
        checksum, path = line.split(maxsplit=1)
        require(re.fullmatch(r'[0-9a-f]{64}', checksum), 'invalid remote digest')
        digests[path] = checksum
    require(digests.keys() == set(paths.values()), 'remote digests are incomplete')
    host_pin = (LAB / 'host-binary-sha256').read_text().strip()
    require(digests[HOST_BIN] == host_pin, 'Ubuntu host differs from the characterized fixed encoder')
    driver = Path('/sys/class/drm') / RENDER_NODE.name / 'device'
    require((driver / 'vendor').read_text().strip() == '0x8086', 'expected pinned Intel render device')
    return {
        'viewer': str(viewer), 'observer': str(observer), 'remote_dir': remote_dir,
        'sha256': {**{kind: digests[path] for kind, path in paths.items()},
                   'viewer': digest(viewer), 'observer': digest(observer),
                   'fixture': {name: digest(LAB / name) for name in FIXTURES}},
        'render_node': str(RENDER_NODE), 'render_node_device': RENDER_NODE.stat().st_rdev,
        'render_pci_device': driver.resolve().name,
        'route': route_summary(),
    }


def check_pins(pins):
    require(pins == current_pins(Path(pins['viewer']), Path(pins['observer']), pins['remote_dir']),
            'binary, fixture, device or route differed from its pin')


def schedule(smoke, first_id):
    order = 'AB' if smoke else 'ABBAABBA'
    require(90 <= first_id and first_id + len(order) <= 256, 'run IDs must be unused IDs in 90..255')
    return [{'run_id': first_id + ordinal, 'block': None if smoke else ordinal // 4 + 1,
             'arm': arm, 'warmup': 6 if smoke else 30, 'seconds': 18 if smoke else 60,
             'mode': 'smoke' if smoke else 'scored',
             'viewer_reuse_env': '1' if arm == 'B' else None}
            for ordinal, arm in enumerate(order)]


def phase_counts(retained, arm, viewer_stderr):
    enabled = [line for line in viewer_stderr.splitlines() if line == ACTIVE]
    require(len(enabled) == (arm == 'B'), 'actual backing reuse diagnostic differs from arm')
    grouped = {name: [] for name in NATIVE_STAGES}
    for item in retained:
        group = item['record'].get('native_wayland_stages', {})
        require(isinstance(group, dict) and group.keys() <= grouped.keys(), 'invalid Native Wayland phase group')
        counts = {}
        for name, stage in group.items():
            count, q = stage['observations'], stage['quantiles']
            bands = [q[k] for k in ('p50_ms', 'p95_ms', 'p99_ms')]
            require(type(count) is int and count > 0 and q['samples'] == min(count, 128)
                    and all(type(v) in (int, float) and math.isfinite(v) and v >= 0
                            for v in [stage['mean'], *bands]) and bands == sorted(bands),
                    f'invalid Native Wayland phase value {name}')
            counts[name] = count
            grouped[name].append(stage)
        alloc = counts.get('rgb_target_allocation_ms', 0)
        fence = counts.get('egl_fence_wait_ms', 0)
        imported = counts.get('wayland_dmabuf_import_ms', 0)
        require(fence == imported and alloc <= imported and (arm == 'B' or alloc == imported),
                'allocation/fence/import counts disagree with the expected fresh-import path')
    require(all(grouped[name] for name in NATIVE_STAGES if name != 'rgb_target_allocation_ms'),
            'no whole-window evidence for a native phase')
    allocations = sum(stage['observations'] for stage in grouped['rgb_target_allocation_ms'])
    imports = sum(stage['observations'] for stage in grouped['wayland_dmabuf_import_ms'])
    require(0 < imports and (allocations < imports if arm == 'B' else allocations == imports),
            'observed allocation reduction does not match treatment')
    summaries = {}
    for name, stages in grouped.items():
        if not stages:
            continue
        count = sum(stage['observations'] for stage in stages)
        summaries[name] = {'windows': len(stages), 'observations': count,
                           'weighted_mean_ms': sum(s['mean'] * (s['observations'] / count) for s in stages),
                           'max_recent_window_p95_ms': max(s['quantiles']['p95_ms'] for s in stages)}
    return {'fresh_rgb_allocations': allocations, 'wayland_imports': imports,
            'fresh_allocations_per_import': allocations / imports, 'observed_phase_summaries': summaries}


def validate_trial(run, trial, pins):
    result = json.loads((run / 'result.json').read_text())
    expected = {'host_binary_sha256': pins['sha256']['host'], 'viewer_binary_sha256': pins['sha256']['viewer'],
                'viewer_test_binary_sha256': pins['sha256']['observer']}
    require(all(result[key] == value for key, value in expected.items()), 'trial digests differ from the pins')
    require(result['run_id'] == trial['run_id'] and result['arm'] == trial['arm']
            and result['warmup_seconds'] == trial['warmup'] and result['requested_observe_seconds'] == trial['seconds'],
            'trial metadata differs from schedule')
    scored = trial['mode'] == 'scored'
    require(result['scored_native_trial'] == scored, 'a diagnostic trial cannot be scored')
    if scored:
        historical.validate(run, result, expected)
    scope, begin, end, markers = marker_scope(run, result)
    require(result['observer_start']['render_node_device'] == pins['render_node_device'], 'trial render node differs')
    renderer, = re.findall(r'JWM_NATIVE_WAYLAND_RENDERER=([^\n]+)', (run / 'marker-test.log').read_text())
    require('Intel' in renderer, 'actual 4K compositor EGL renderer is not Intel')

    paint = records(run / 'source/paint.jsonl')
    first, = [row for row in paint if row['type'] == 'p09_start']
    final, = [row for row in paint if row['type'] == 'p09_end']
    require(first['run_id'] == final['run_id'] == trial['run_id'] and [first['width'], first['height']] == [3840, 2160]
            and [first['fps'], first['seed']] == [60, 7], 'painter trial, extent or workload changed')
    source_fps = (final['submitted'] - 1) * 1e9 / (final['last_submit_ns'] - final['first_submit_ns'])
    require(source_fps == result['source_submitted_frames_per_second'] and source_fps >= 30,
            'source painter did not support the requested 30 fps')
    host_log = run / 'source/host.log'
    require('hardware H.264 encoding active (NVENC)' in host_log.read_text(), 'expected active Ubuntu NVENC host')
    host = [row for row in records(host_log, mixed=True) if row['type'] == 'jwm_remote_host_stats']
    require(host and {row['session_id'] for row in host} == {scope['session_id']}
            and any(row['h264_frames'] and row['drawn_acks'] for row in host)
            and all(row['jpeg_atlases'] == row['hevc444_frames'] == 0 for row in host), 'host transport scope changed')
    for row in host:
        if row['h264_frames']:
            frame = row['last_sent_frame']
            require(frame['source_epoch'] == scope['source_epoch'] and frame['geometry_epoch'] == scope['geometry_epoch']
                    and frame['source_dimensions'] == frame['encoded_dimensions'] == [3840, 2160]
                    and frame['codec'] == 'H.264', 'host left the exact 4K H.264 geometry scope')

    viewer = run / 'viewer'
    require((viewer / 'viewer-stderr-relay-complete').is_file(), 'viewer stderr relay did not complete')
    raw = records(viewer / 'viewer-stage-windows.jsonl')
    snapshots, matched, whole = join_windows(raw, records(viewer / 'viewer-events.jsonl'),
                                             records(viewer / 'viewer-clock.jsonl'), scope, begin, end)
    phases = phase_counts(whole, trial['arm'], (viewer / 'viewer-complete-stderr.log').read_text())
    points = [begin, *[mark['monotonic_ns'] for mark in markers], end]
    gaps = sorted(b - a for a, b in zip(points, points[1:]))
    fps = len(markers) / trial['seconds']
    return {'scope': scope, 'renderer': renderer.strip(), 'render_device': pins['render_pci_device'],
            'marker_seconds': trial['seconds'], 'distinct_visible_markers': len(markers), 'fps': fps,
            'p95_gap_ms': gaps[math.ceil(.95 * len(gaps)) - 1] / 1e6, 'max_gap_ms': max(gaps) / 1e6,
            'viewer_27_fps_gate_met': fps >= 27 if scored else None,
            'source_fps': source_fps, 'host_h264_frames': sum(row['h264_frames'] for row in host),
            'host_drawn_acks': sum(row['drawn_acks'] for row in host), 'viewer_download_observations': 0,
            'raw_window_count': len(raw), 'managed_snapshots': len(snapshots), 'matched_windows': len(matched),
            'whole_scored_window_count': len(whole),
            'whole_scored_window_seconds': sum(row['record']['window_seconds'] for row in whole), **phases}


def replay(suite):
    batch = json.loads((suite / 'plan.json').read_text())
    pins, schedule_rows = batch['pins'], batch['trials']
    expected_schedule = schedule(batch['smoke'], schedule_rows[0]['run_id'])
    require(schedule_rows == expected_schedule, 'noncanonical ABBA schedule')
    outcomes = []
    for trial in schedule_rows:
        run = suite / f"run-{trial['run_id']:03d}"
        status_path = run / 'execution.json'
        outcome = dict(trial)
        try:
            status = json.loads(status_path.read_text()) if status_path.is_file() else {'status': 'not_started'}
            kind = status['status']
            require(kind in ('completed', 'failed', 'started', 'not_started'), 'invalid execution state')
            outcome['execution'] = status
            if kind == 'completed':
                require(status.get('pins_verified_before_and_after') is True, 'trial did not verify both pins')
                outcome['measurement'] = validate_trial(run, trial, pins)
                outcome['status'] = 'diagnostic_valid' if batch['smoke'] else 'valid'
            else:
                outcome['status'] = kind
        except (AssertionError, KeyError, OSError, TypeError, ValueError, ZeroDivisionError):
            outcome.update(status='invalid_evidence', error=traceback.format_exc(limit=5))
        outcomes.append(outcome)
    eligible = [row for row in outcomes if row['status'] == 'valid']
    arms = {arm: [row['measurement'] for row in eligible if row['arm'] == arm] for arm in 'AB'}
    complete = len(eligible) == 8
    block_comparisons = []
    for block in (1, 2):
        rows = [row for row in eligible if row['block'] == block]
        if len(rows) == 4:
            values = {arm: [row['measurement'] for row in rows if row['arm'] == arm] for arm in 'AB'}
            block_comparisons.append({'block': block, **{
                f'B_minus_A_median_{field}': median(item[field] for item in values['B'])
                - median(item[field] for item in values['A']) for field in ('fps', 'p95_gap_ms', 'max_gap_ms')
            }})
    overall = {'balanced_scored_comparison': complete, 'completed_blocks': block_comparisons,
               'valid_trials': {arm: sum(row['arm'] == arm for row in eligible) for arm in 'AB'},
               'fps': {arm: [row['fps'] for row in arms[arm]] for arm in 'AB'},
               'trials_meeting_27_fps': {arm: sum(row['viewer_27_fps_gate_met'] for row in arms[arm]) for arm in 'AB'},
               'all_treatment_trials_meet_27_fps': (all(row['viewer_27_fps_gate_met'] for row in arms['B'])
                                                    if len(arms['B']) == 4 else None),
               'B_minus_A_median_fps': (median(row['fps'] for row in arms['B'])
                                         - median(row['fps'] for row in arms['A']) if complete else None)}
    data = {'schema_version': 1, 'scope': batch['scope'], 'pins': pins, 'trials': outcomes, 'summary': overall}
    write_json(suite / 'comparison.json', data)
    return data


def archive(suite):
    with ZipFile(suite / 'raw-evidence.zip', 'x', compression=ZIP_DEFLATED, compresslevel=4) as target:
        for file in suite.rglob('*'):
            if file.is_file() and file.name not in ('key', 'raw-evidence.zip', 'archive-sha256'):
                target.write(file, file.relative_to(suite))
        for fixture in FIXTURES:
            target.write(LAB / fixture, f'fixture/{fixture}')
    with ZipFile(suite / 'raw-evidence.zip') as evidence:
        require(evidence.testzip() is None, 'invalid raw evidence archive')
    (suite / 'archive-sha256').write_text(digest(suite / 'raw-evidence.zip') + '\n')


def execute(pins, smoke, first_id):
    suite = Path(tempfile.mkdtemp(prefix='smoke.' if smoke else 'abba.', dir=LAB))
    rows = schedule(smoke, first_id)
    scope = ('Owned Ubuntu Xvfb P09 motion over the uncapped IPv4 SSH route. Local Intel private Wayland '
             'output uses actual software compositor completion and a 96x96 marker crop. GPU and driver '
             'results are specific to the pinned hardware, source and binaries. The timing is not physical scanout.')
    write_json(suite / 'plan.json', {'smoke': smoke, 'pins': pins, 'trials': rows, 'scope': scope})
    print(suite, flush=True)
    pass_environment = os.environ.get('LD_LIBRARY_PATH', '')
    os.environ['LD_LIBRARY_PATH'] = FFMPEG + (':' + pass_environment if pass_environment else '')
    try:
        for row in rows:
            run = suite / f"run-{row['run_id']:03d}"
            run.mkdir(mode=0o700)
            options = SimpleNamespace(**row, directory=run, pins=pins, viewer_bin=Path(pins['viewer']),
                                      lib_bin=Path(pins['observer']), stage='verify_pins_before')
            write_json(run / 'execution.json', {'status': 'started'})
            try:
                check_pins(pins)
                preflight.run(options)
                options.stage = 'verify_pins_after'
                check_pins(pins)
            except (AssertionError, KeyError, OSError, RuntimeError, TypeError, ValueError, subprocess.SubprocessError):
                write_json(run / 'execution.json', {'status': 'failed', 'stage': options.stage,
                                                      'error': traceback.format_exc(limit=5)})
            else:
                write_json(run / 'execution.json', {'status': 'completed', 'pins_verified_before_and_after': True})
    finally:
        report = replay(suite)
        archive(suite)
        print(json.dumps(report['summary'], indent=2), flush=True)
    valid = 'diagnostic_valid' if smoke else 'valid'
    return 0 if all(row['status'] == valid for row in report['trials']) else 1


def main():
    require(__debug__, 'run without Python optimization so the existing validator assertions are active')
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_subparsers(dest='mode', required=True)
    pin = mode.add_parser('pin')
    pin.add_argument('viewer_release', type=Path)
    pin.add_argument('observer_release', type=Path)
    pin.add_argument('manifest', type=Path)
    run = mode.add_parser('run')
    run.add_argument('manifest', type=Path)
    run.add_argument('--smoke', action='store_true')
    run.add_argument('--first-id', type=int)
    offline = mode.add_parser('replay')
    offline.add_argument('suite', type=Path)
    args = parser.parse_args()
    require(args.mode == 'replay', 'this copy is offline replay only')
    if args.mode == 'replay':
        print(json.dumps(replay(args.suite)['summary'], indent=2))
        return 0
    with LOCK.open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        if args.mode == 'pin':
            require(not args.manifest.exists(), 'pin manifest already exists')
            viewer, observer = args.viewer_release.resolve(strict=True), args.observer_release.resolve(strict=True)
            require(all(os.access(path, os.X_OK) for path in (viewer, observer)), 'prebuilt release binaries required')
            write_json(args.manifest, current_pins(viewer, observer, (LAB / 'remote-dir').read_text().strip()))
            return 0
        pins = json.loads(args.manifest.read_text())
        first_id = args.first_id if args.first_id is not None else (90 if args.smoke else 92)
        return execute(pins, args.smoke, first_id)


if __name__ == '__main__':
    raise SystemExit(main())
