# Offline replay

From the extracted archive root:

    python3 -B fixture/run_abba.py replay .

This rechecks raw host and viewer windows, exact marker scopes, phase counts,
and each terminal status. The fixture's network launch defaults were replaced
in this portable copy. Its original measured-run digests are in plan.json.
comparison.json leaves out private launch paths and traceback command arguments.
The summary preserves failed attempts without inventing a measurement for them.
