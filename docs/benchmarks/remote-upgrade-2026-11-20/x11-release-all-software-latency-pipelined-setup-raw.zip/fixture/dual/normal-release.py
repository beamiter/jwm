#!/usr/bin/env python3
"""Measure repeated explicit X11 ReleaseAll on isolated unshaped sessions."""
import argparse
import base64
from collections import deque
from contextlib import ExitStack
import hashlib
import json
import math
import os
from pathlib import Path
import re
import select
import shlex
import signal
import socket
import subprocess
import sys
import tempfile
import time

from Xlib import X, XK, display
from Xlib.ext import xtest
from Xlib.protocol import event

KEY_NAMES = ('F8', 'F9', 'Control_L', 'Super_L', 'F12')
PIPELINED_SETUP = 'pipelined_reacquisition_and_inline_held_key'
EDGES = {X.KeyPress, X.KeyRelease, X.ButtonPress, X.ButtonRelease}
MASK = X.KeyPressMask | X.KeyReleaseMask | X.ButtonPressMask | X.ButtonReleaseMask
SSH = ['ssh', '-4', '-T', '-o', 'BatchMode=yes', '-o', 'StrictHostKeyChecking=yes', '-o', 'ConnectTimeout=6',
       '-o', 'ServerAliveInterval=3', '-o', 'ServerAliveCountMax=2', '-o', 'ForwardAgent=no', '-o', 'ForwardX11=no',
       '-o', 'Compression=no', '-o', 'ControlPersist=no', '-o', 'ExitOnForwardFailure=yes']


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for content in iter(lambda: stream.read(1 << 20), b''):
            digest.update(content)
    return digest.hexdigest()


def publish(path, value):
    temporary = path.with_suffix('.next')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def stop(process):
    if process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=3)


def own_process(cleanup, argv, **kw):
    process = subprocess.Popen(argv, **kw)
    cleanup.callback(stop, process)
    return process


def clean_env(lib):
    env = {name: value for name, value in os.environ.items()
           if not name.startswith('JWM_REMOTE_')
           and name not in {'DISPLAY', 'WAYLAND_DISPLAY', 'WAYLAND_SOCKET', 'XAUTHORITY', 'LD_LIBRARY_PATH'}}
    if lib:
        env['LD_LIBRARY_PATH'] = lib
    return env


def route_device(ip):
    result = subprocess.run(['ip', '-j', '-4', 'route', 'get', ip], check=True, capture_output=True, timeout=4)
    routes = json.loads(result.stdout)
    require(len(routes) == 1 and 'dev' in routes[0], 'unexpected IPv4 route')
    return routes[0]['dev']


def launch_x(cleanup):
    xserver = own_process(cleanup, ['Xvfb', '-displayfd', '1', '-screen', '0', '1920x1080x24',
                                   '-nolisten', 'tcp', '-ac', '-noreset'], stdin=subprocess.DEVNULL,
                         stdout=subprocess.PIPE, env=clean_env(None))
    require(select.select([xserver.stdout], [], [], 12)[0], 'Xvfb display announcement timeout')
    number = xserver.stdout.readline(32).strip()
    require(number.isdigit() and xserver.poll() is None, 'invalid owned Xvfb display announcement')
    name = ':' + number.decode('ascii')
    conn = display.Display(name)
    cleanup.callback(conn.close)
    require(conn.has_extension('XTEST'), 'owned display has no XTEST')
    conn.change_keyboard_control(auto_repeat_mode=X.AutoRepeatModeOff)
    conn.sync()
    return name, conn


def key_codes(conn):
    codes = {name: conn.keysym_to_keycode(XK.string_to_keysym(name)) for name in KEY_NAMES}
    require(0 not in codes.values() and len(set(codes.values())) == len(KEY_NAMES), 'probe keymap unavailable')
    return codes


def normalize_key(row):
    first, second, third, fourth = (*row[:4], *([0] * max(0, 4 - len(row))))
    a = [first, second or first]
    b = a if not (third or fourth) else [third, fourth or third]
    return a + b


def core_table(conn):
    info = conn.display.info
    first = info.min_keycode
    count = info.max_keycode - first + 1
    require(8 <= first <= info.max_keycode <= 255, 'invalid owned X11 keycode range')
    rows = conn.get_keyboard_mapping(first, count)
    modifiers = conn.get_modifier_mapping()
    require(len(rows) == count and len(modifiers) == 8, 'incomplete owned X11 core keymap')
    return {'first': first, 'rows': [normalize_key(row) for row in rows],
            'modifiers': [sorted(set(codes) - {0}) for codes in modifiers]}


def compare_core(host, viewer):
    def bound(table):
        return {code: row for code, row in enumerate(table['rows'], table['first']) if any(row)}
    a, b = bound(host), bound(viewer)
    common = a.keys() & b.keys()
    differing = [code for code in sorted(common) if a[code] != b[code]]
    modifiers_equal = host['modifiers'] == viewer['modifiers']
    return {'common_bound': len(common), 'differing_keycodes': differing,
            'modifiers_equal': modifiers_equal,
            'compatible': modifiers_equal and not differing and len(common) >= 32}


def xkb_from_owned_source(directory, x_display, conn):
    path = directory / 'source.xkb'
    subprocess.run(['xkbcomp', '-xkb', '-w', '0', x_display, str(path)], check=True,
                   stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, timeout=6, env=clean_env(None))
    source_xkb = path.read_bytes()
    require(0 < len(source_xkb) <= 256 << 10 and b'xkb_keymap' in source_xkb,
            'owned source XKB export is missing or invalid')
    return {'xkb_b64': base64.b64encode(source_xkb).decode('ascii'), 'core': core_table(conn)}


def match_source_xkb(ready, directory, x_display, conn, cleanup, scope):
    source = ready['source_keymap']
    exported = base64.b64decode(source['xkb_b64'], validate=True)
    require(0 < len(exported) <= 256 << 10 and b'xkb_keymap' in exported,
            'SSH observer returned an invalid XKB export')
    path = directory / 'host-authority.xkb'
    path.write_bytes(exported)
    witness = {'authority': 'private Ubuntu source Xvfb',
               'source_xkb_sha256': hashlib.sha256(exported).hexdigest(),
               'before': compare_core(source['core'], core_table(conn))}
    scope['keymap_alignment'] = witness
    if not witness['before']['compatible']:
        with (directory / 'xkb-import.stderr').open('wb') as diagnostics:
            subprocess.run(['xkbcomp', '-synch', '-w', '1', str(path), x_display], check=True,
                           stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=diagnostics,
                           timeout=6, env=clean_env(None))
        # A new client reads the map afresh rather than retaining Python Xlib's
        # cached keysym/code lookup from before the owned server was aligned.
        conn = display.Display(x_display)
        cleanup.callback(conn.close)
        witness['viewer_map_loaded'] = True
    else:
        witness['viewer_map_loaded'] = False
    witness['after'] = compare_core(source['core'], core_table(conn))
    require(witness['after']['compatible'],
            f"owned source/viewer X11 keymaps remain incompatible after XKB import: {witness['after']}")
    return conn


def held(conn, codes):
    state = conn.query_keymap()
    return [code for code in codes if state[code // 8] & (1 << (code % 8))]


def grab_probe(conn):
    root = conn.screen().root
    keyboard = root.grab_keyboard(False, X.GrabModeAsync, X.GrabModeAsync, X.CurrentTime)
    try:
        pointer = root.grab_pointer(False, X.ButtonPressMask, X.GrabModeAsync, X.GrabModeAsync,
                                    X.NONE, X.NONE, X.CurrentTime)
        if pointer == X.GrabSuccess:
            conn.ungrab_pointer(X.CurrentTime)
        return [keyboard, pointer]
    finally:
        if keyboard == X.GrabSuccess:
            conn.ungrab_keyboard(X.CurrentTime)
        conn.sync()


def owned_receiver(conn):
    screen = conn.screen()
    window = screen.root.create_window(0, 0, 1920, 1080, 0, screen.root_depth, X.InputOutput, X.CopyFromParent,
                                       background_pixel=0x284050, event_mask=MASK)
    window.set_wm_name('P07 isolated source input receiver')
    window.map()
    window.set_input_focus(X.RevertToParent, X.CurrentTime)
    conn.sync()
    return window


def send(stream, value):
    stream.write(json.dumps(value, separators=(',', ':')).encode() + b'\n')
    stream.flush()


class Lines:
    """Timestamp complete decoded lines using the reader's monotonic clock."""
    def __init__(self, stream):
        self.stream = stream
        self.data = b''
        self.pending = deque()
        self.eof = False

    def read_ready(self):
        block = os.read(self.stream.fileno(), 65536)
        arrived = time.monotonic_ns()
        if not block:
            self.eof = True
            require(not self.data, 'partial observer line at EOF')
            return
        self.data += block
        require(len(self.data) <= 1 << 20, 'observer line exceeds limit')
        while b'\n' in self.data:
            line, self.data = self.data.split(b'\n', 1)
            if line:
                self.pending.append((json.loads(line), arrived))

    def next(self, deadline):
        while not self.pending:
            if self.eof:
                raise RuntimeError('observer channel closed')
            remaining = deadline - time.monotonic()
            if remaining <= 0 or not select.select([self.stream], [], [], remaining)[0]:
                raise TimeoutError('observer message deadline expired')
            self.read_ready()
        return self.pending.popleft()


def await_setup(predicate, deadline, child):
    while time.monotonic() < deadline:
        require(child.poll() is None, f'endpoint exited during setup ({child.returncode})')
        found = predicate()
        if found:
            return found
        time.sleep(.015)
    raise TimeoutError('endpoint setup deadline expired')


def log_text(path):
    return path.read_text(errors='replace')


def stats(log, role):
    kind = 'jwm_remote_' + role + '_stats'
    return [row for line in log.splitlines() if line.startswith('{')
            and (row := json.loads(line)).get('type') == kind]


def source_service(config, commands, output):
    with ExitStack() as cleanup:
        work = Path(cleanup.enter_context(tempfile.TemporaryDirectory(prefix='jwm-p07-host.')))
        source_display, conn = launch_x(cleanup)
        receiver = owned_receiver(conn)
        codes = key_codes(conn)
        source_keymap = (xkb_from_owned_source(work, source_display, conn)
                         if config['profile'] == 'dual' else None)
        key = work / 'key'
        with os.fdopen(os.open(key, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600), 'wb') as key_file:
            key_file.write(base64.b64decode(config['auth_key'], validate=True))
        binary = config['host_binary']
        binary_sha = sha256(binary)
        require(binary_sha == config['host_binary_sha256'], 'source binary digest mismatch')
        interface = 'lo'
        if config['profile'] == 'dual':
            peer = os.environ.get('SSH_CONNECTION', '').split()
            require(len(peer) == 4, 'source observer is not on an SSH connection')
            interface = route_device(peer[0])
            require(interface == config['expected_interface'], 'observer connection uses unexpected source interface')
        log = work / 'host.log'
        output_log = cleanup.enter_context(log.open('wb'))
        host = own_process(cleanup, [binary, 'host', '--display', source_display, '--capture-source', 'root',
                                    '--once', '--listen', '127.0.0.1:0', '--key-file', key, '--fps', '15',
                                    '--stats-json', '--allow-input'], stdin=subprocess.DEVNULL, stdout=output_log,
                           stderr=subprocess.STDOUT, env=clean_env(config['host_lib']))
        listener = await_setup(lambda: re.search(r'listening on 127\.0\.0\.1:(\d+)', log_text(log)),
                               time.monotonic() + 12, host)
        key_set = list(codes.values())
        send(output, {'event': 'ready', 'port': int(listener[1]), 'keys': codes, 'interface': interface,
                      'host_binary_sha256': binary_sha, 'clock': 'CLOCK_MONOTONIC',
                      'source_keymap': source_keymap})
        seq, index, held_key = 0, 0, None
        inline_release_proof = config.get('inline_release_proof', False)
        pipelined = config.get('pipelined_setup', False)

        def reply(command, kind, command_read_ns, **fields):
            send(output, {'event': kind, 'seq': seq, 'request_id': command['request_id'],
                          'request_seq': command['seq'], 'host_command_read_ns': command_read_ns,
                          'host_reply_ns': time.monotonic_ns(), **fields})

        def drain_edges():
            nonlocal index
            while conn.pending_events():
                received = conn.next_event()
                observed = time.monotonic_ns()
                if received.type not in EDGES:
                    continue
                require(seq and received.window.id == receiver.id and not received.send_event,
                        'input edge failed actual owned-source receiver checks')
                index += 1
                observation = {'event': 'edge', 'seq': seq, 'index': index, 'type': received.type,
                               'detail': received.detail, 'host_ns': observed}
                if pipelined and received.type == X.KeyPress and received.detail == held_key:
                    observation['host_held_at_press'] = held(conn, key_set)
                    observation['host_press_keymap_checked_ns'] = time.monotonic_ns()
                if inline_release_proof and received.type == X.KeyRelease and received.detail == held_key:
                    observation['host_held_at_release'] = held(conn, key_set)
                    observation['host_keymap_checked_ns'] = time.monotonic_ns()
                send(output, observation)

        while True:
            drain_edges()
            if not commands.pending:
                ready, _, _ = select.select([commands.stream, conn.fileno()], [], [], 2)
                if commands.stream in ready:
                    commands.read_ready()
                if commands.eof:
                    return
                drain_edges()
            if not commands.pending:
                continue
            command, command_read_ns = commands.pending.popleft()
            op, sample = command['op'], command['seq']
            if op == 'arm':
                require(sample == seq + 1, 'source arm identity is out of sequence')
                keys = held(conn, key_set)
                drain_edges()
                require(not keys, 'source keys remained held across arm boundary')
                held_key = command['held_keycode']
                require(held_key == codes[KEY_NAMES[(sample - 1) % 2]], 'source arm key identity mismatch')
                seq, index = sample, 0
                reply(command, 'armed', command_read_ns, host_held=keys)
            elif op == 'snapshot':
                require(sample == seq, 'source snapshot identity mismatch')
                keys = held(conn, key_set)
                drain_edges()
                reply(command, 'snapshot', command_read_ns, token=command['token'], host_held=keys)
            elif op == 'finish':
                # If the controller's arm timed out, that arm may already
                # have taken effect. This exception is terminal-only and
                # specifically names the single outstanding arm identity.
                abandoned_arm = command.get('abandoned_arm_seq')
                require(sample == seq or abandoned_arm == sample + 1 == seq,
                        'source finish identity mismatch')
                status = host.wait(timeout=8)
                keys = held(conn, key_set)
                drain_edges()
                raw_log = log_text(log)
                grant = [line for line in raw_log.splitlines()
                         if line.startswith('jwm-remote: authenticated session started')]
                keymap_diag = [line for line in raw_log.splitlines()
                               if line.startswith(('jwm-remote: peer X11 keymap differs',
                                                   'jwm-remote: could not verify the host X11 keymap'))]
                host_stats = stats(raw_log, 'host')
                reply(command, 'finished', command_read_ns, host_exit=status,
                      host_auth_starts=raw_log.count('authenticated session started'),
                      host_session_ids=sorted({record['session_id'] for record in host_stats}),
                      host_held_when_finished=keys, host_authenticated_grant=grant,
                      host_keymap_diagnostic=keymap_diag, host_stat_windows=len(host_stats))
                return
            else:
                raise RuntimeError('unknown observer command')


def observer():
    wire = Lines(sys.stdin.buffer)
    try:
        config, _ = wire.next(time.monotonic() + 12)
        source_service(config, wire, sys.stdout.buffer)
    except (Exception, KeyboardInterrupt) as error:
        try:
            send(sys.stdout.buffer, {'event': 'error', 'error': type(error).__name__, 'detail': str(error)})
        except OSError:
            pass
        return 1
    return 0


def xwindow(conn):
    title_atom = conn.intern_atom('_NET_WM_NAME')
    for window in conn.screen().root.query_tree().children:
        prop = window.get_full_property(title_atom, X.AnyPropertyType)
        title = prop.value.decode(errors='replace') if prop and isinstance(prop.value, bytes) else window.get_wm_name()
        if isinstance(title, str) and ' - JWM Remote' in title:
            return window
    return None


def tunnel(cleanup, peer, remote_port, error, route_interface):
    require(route_device(peer.split('@', 1)[1]) == route_interface, 'viewer route interface mismatch')
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as reserved:
        reserved.bind(('127.0.0.1', 0))
        local_port = reserved.getsockname()[1]
    short_dir = cleanup.enter_context(tempfile.TemporaryDirectory(prefix='p07-ssh.'))
    control = str(Path(short_dir) / 'c')
    cmd = SSH + ['-S', control, '-M', '-N', '-L', f'127.0.0.1:{local_port}:127.0.0.1:{remote_port}', peer]
    proc = own_process(cleanup, cmd, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=error)

    def connected():
        if not Path(control).is_socket():
            return False
        return subprocess.run(SSH + ['-S', control, '-O', 'check', peer], stdin=subprocess.DEVNULL,
                              stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=3).returncode == 0

    await_setup(connected, time.monotonic() + 14, proc)
    return local_port, proc


def expected_edges(row, codes):
    actual = [(edge['type'], edge['detail']) for edge in row['source_edges']]
    old = row['held_keycode']
    modifier_keys = [codes['Control_L'], codes['Super_L']]
    modifiers = [detail for kind, detail in actual[3:] if kind == X.KeyPress]
    require(modifiers == [code for code in modifier_keys if code in modifiers], 'unexpected forwarded chord press')
    expected = ([(X.ButtonPress, 1), (X.ButtonRelease, 1), (X.KeyPress, old)]
                + [(X.KeyPress, code) for code in modifiers]
                + [(X.KeyRelease, code) for code in reversed(modifiers)] + [(X.KeyRelease, old)])
    require(actual == expected, f'wrong actual order {actual}; expected {expected}')
    require([edge['index'] for edge in row['source_edges']] == list(range(1, len(expected) + 1)),
            'missing or duplicate source observer record')


class Watch:
    def __init__(self, worker):
        self.worker = worker
        self.lines = Lines(worker.stdout)
        self.edges = {0: []}
        self.seq = 0
        self.request_id = 0
        self.pending_control = None

    def control_identity(self, op, seq, **fields):
        self.request_id += 1
        return {'op': op, 'seq': seq, 'request_id': self.request_id, **fields}

    def request(self, op, seq, **fields):
        require(self.pending_control is None, 'source control already has an outstanding request')
        command = self.control_identity(op, seq, **fields)
        self.pending_control = {**command, 'viewer_request_ns': time.monotonic_ns()}
        send(self.worker.stdin, command)
        return self.pending_control.copy()

    def next_reply(self, deadline):
        reply, received = self.lines.next(deadline)
        reply['viewer_receipt_ns'] = received
        if reply['event'] == 'error':
            raise RuntimeError(f"owned source observer {reply['error']}: {reply['detail']}")
        return reply

    @staticmethod
    def matches_control(reply, command, name, *, actual_seq=None, **matches):
        return (reply.get('event') == name and reply.get('seq') == (command['seq'] if actual_seq is None else actual_seq)
                and reply.get('request_id') == command['request_id'] and reply.get('request_seq') == command['seq']
                and all(reply.get(key) == value for key, value in matches.items()))

    def until(self, deadline, predicate):
        while True:
            reply = self.next_reply(deadline)
            if reply['event'] == 'edge':
                seq = reply['seq']
                require(seq in self.edges and seq == self.seq, 'source edge tagged outside the active sample')
                self.edges[seq].append(reply)
            if predicate(reply):
                return reply
            require(reply['event'] == 'edge', 'unexpected source reply type')

    def control(self, deadline, name, seq, **matches):
        command = self.pending_control
        require(command is not None and command['seq'] == seq, 'no matching source control request')
        reply = self.until(deadline, lambda item: self.matches_control(item, command, name, **matches))
        self.pending_control = None
        return reply

    def finish_after_failure(self, deadline, diagnostic):
        # Scoring has already stopped. Preserve an actual late echo and any
        # terminal edges separately. Never append them to measured rows.
        pending = self.pending_control
        terminal_fields = {}
        valid_seqs = {self.seq}
        if pending and pending['op'] == 'arm':
            require(pending['seq'] == self.seq + 1, 'abandoned source arm identity mismatch')
            terminal_fields['abandoned_arm_seq'] = pending['seq']
            valid_seqs.add(pending['seq'])
        terminal = self.control_identity('finish', self.seq, **terminal_fields)
        diagnostic.update(pending_control=pending, finish_command=terminal, late_replies=[])
        send(self.worker.stdin, terminal)
        may_consume_pending = pending is not None
        while len(diagnostic['late_replies']) < 32:
            reply = self.next_reply(deadline)
            actual_seq = reply.get('seq')
            if (actual_seq in valid_seqs
                    and self.matches_control(reply, terminal, 'finished', actual_seq=actual_seq)):
                diagnostic['finished_receipt_ns'] = reply['viewer_receipt_ns']
                self.pending_control = None
                return reply
            diagnostic['late_replies'].append(reply)
            if reply['event'] == 'edge' and actual_seq in valid_seqs:
                continue
            if may_consume_pending and pending['op'] == 'snapshot' and self.matches_control(
                    reply, pending, 'snapshot', token=pending['token']):
                may_consume_pending = False
                continue
            if may_consume_pending and pending['op'] == 'arm' and self.matches_control(reply, pending, 'armed'):
                may_consume_pending = False
                continue
            raise RuntimeError('unexpected source reply identity during failed-measurement teardown')
        raise RuntimeError('too many replies during failed-measurement teardown')

    def edge(self, deadline, seq, kind, detail):
        return self.until(deadline, lambda reply: reply['event'] == 'edge' and reply['seq'] == seq
                          and (reply['type'], reply['detail']) == (kind, detail))


def timed_out(_signum, _frame):
    raise TimeoutError('per-sample deadline expired')


def measure_sample(row, watch, conn, grab_conn, win, codes, duration, profile, inline_release_proof, pipelined):
    seq = row['seq']
    deadline = time.monotonic() + duration
    old = row['held_keycode']
    chord = [codes['Control_L'], codes['Super_L'], codes['F12']]
    key_set = list(codes.values())

    def stage(value):
        row['stage'] = value

    def issue(label, kind, detail=0, *, x=0, y=0):
        started = time.monotonic_ns()
        xtest.fake_input(conn, kind, detail, x=x, y=y)
        conn.flush()
        row['viewer_actions'].append({'event': label, 'type': kind, 'detail': detail, 'at_ns': started})
        return started

    signal.setitimer(signal.ITIMER_REAL, duration)
    try:
        stage('arm')
        watch.edges[seq] = row['source_edges']
        arm = watch.request('arm', seq, held_keycode=old)
        if pipelined:
            row['pipelined_setup'] = True
            row['arm_exchange'] = arm
        armed = watch.control(deadline, 'armed', seq)
        if pipelined:
            arm.update({field: armed[field] for field in
                        ('host_command_read_ns', 'host_reply_ns', 'viewer_receipt_ns')})
        watch.seq = seq
        stage('reacquire')
        win.set_input_focus(X.RevertToParent, X.CurrentTime)
        geo = win.get_geometry()
        issue('focus_pointer', X.MotionNotify, x=geo.x + geo.width // 2, y=geo.y + geo.height // 2)
        issue('reacquire_button_down', X.ButtonPress, 1)
        if pipelined:
            # Both click edges still reach the same authenticated host. Drain
            # the two ordered X11 witnesses before attempting a held key.
            issue('reacquire_button_up', X.ButtonRelease, 1)
            watch.edge(deadline, seq, X.ButtonPress, 1)
        else:
            watch.edge(deadline, seq, X.ButtonPress, 1)
            issue('reacquire_button_up', X.ButtonRelease, 1)
        watch.edge(deadline, seq, X.ButtonRelease, 1)
        row['grab_before'] = grab_probe(grab_conn)
        require(row['grab_before'] == [X.AlreadyGrabbed] * 2, 'viewer did not reacquire both local grabs')
        stage('host_held_key')
        issue('held_key_down', X.KeyPress, old)
        pressed = watch.edge(deadline, seq, X.KeyPress, old)
        if pipelined:
            row['host_held_before'] = pressed['host_held_at_press']
            row['host_press_keymap_checked_ns'] = pressed['host_press_keymap_checked_ns']
            require(row['host_press_keymap_checked_ns'] >= pressed['host_ns'],
                    'source keymap proof preceded its held-key press')
        else:
            watch.request('snapshot', seq, token='held')
            row['host_held_before'] = watch.control(deadline, 'snapshot', seq, token='held')['host_held']
        row['viewer_held_before'] = held(conn, key_set)
        require(row['host_held_before'] == row['viewer_held_before'] == [old], 'original key not held on both systems')
        stage('host_release')
        for code in chord[:2]:
            issue('shortcut_modifier_down', X.KeyPress, code)
        row['viewer_issue_ns'] = issue('shortcut_trigger_down', X.KeyPress, chord[-1])
        released = watch.edge(deadline, seq, X.KeyRelease, old)
        row['host_edge_ns'], row['viewer_receipt_ns'] = released['host_ns'], released['viewer_receipt_ns']
        end = row['host_edge_ns'] if profile == 'loopback' else row['viewer_receipt_ns']
        row['latency_ns'] = end - row['viewer_issue_ns']
        require(row['latency_ns'] >= 0, 'noncausal release observation')
        stage('prove_release_before_local_key_up')
        if inline_release_proof:
            row['host_held_after'] = released['host_held_at_release']
            row['host_keymap_checked_ns'] = released['host_keymap_checked_ns']
            require(row['host_keymap_checked_ns'] >= row['host_edge_ns'], 'source keymap proof preceded the release edge')
        else:
            watch.request('snapshot', seq, token='released')
            row['host_held_after'] = watch.control(deadline, 'snapshot', seq, token='released')['host_held']
        row['viewer_held_before_cleanup'] = held(conn, key_set)
        require(row['host_held_after'] == [] and set(row['viewer_held_before_cleanup']) == {old, *chord},
                'source did not clear keys before local held-key release')
        row['grab_after'] = grab_probe(grab_conn)
        require(row['grab_after'] == [X.GrabSuccess] * 2, 'viewer did not relinquish both local grabs')
        stage('cleanup')
        for code in reversed(chord):
            issue('shortcut_cleanup_up', X.KeyRelease, code)
        row['viewer_local_key_up_ns'] = issue('held_key_local_up', X.KeyRelease, old)
        conn.sync()
        row['viewer_held_after_cleanup'] = held(conn, key_set)
        require(not row['viewer_held_after_cleanup'], 'probe left a locally held key')
        expected_edges(row, codes)
        row['status'] = 'passed'
        row['stage'] = 'complete'
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)


def normal_close(conn, win, viewer):
    close = event.ClientMessage(window=win, client_type=conn.intern_atom('WM_PROTOCOLS'),
                                data=(32, [conn.intern_atom('WM_DELETE_WINDOW'), 0, 0, 0, 0]))
    win.send_event(close)
    conn.flush()
    return viewer.wait(timeout=8)


def terminate_signal(signum, _frame):
    raise KeyboardInterrupt(f'owned probe stopped by signal {signum}')


def phase_samples(kind, total, start_ns, duration_ns, session, ledger, watch, conn, probe, win, codes, args):
    rows = session['warmup_samples'] if kind == 'warmup' else session['samples']
    end_ns = start_ns + duration_ns
    for slot in range(total):
        slot_at = start_ns + (duration_ns * slot // total)
        next_slot = start_ns + (duration_ns * (slot + 1) // total)
        delay = (slot_at - time.monotonic_ns()) / 1_000_000_000
        if delay > 0:
            time.sleep(delay)
        row = {'phase': kind, 'slot': slot + 1, 'planned_slot_ns': slot_at, 'viewer_actions': [], 'source_edges': []}
        try:
            now_ns = time.monotonic_ns()
            if now_ns >= next_slot:
                row['status'] = 'not_issued'
                row['stage'] = 'slot_elapsed_while_prior_sample_in_flight'
                continue
            row['seq'] = watch.seq + 1
            row['held_keycode'] = codes[KEY_NAMES[(row['seq'] - 1) % 2]]
            row['started_ns'] = now_ns
            deadline = min(args.deadline_ms / 1000, (end_ns - now_ns) / 1_000_000_000)
            if deadline <= 0:
                row['status'] = 'not_issued'
                row['stage'] = 'window_ended'
                continue
            measure_sample(row, watch, conn, probe, win, codes, deadline, args.profile,
                           args.inline_release_proof, args.pipelined_setup)
            if not start_ns <= row['viewer_issue_ns'] <= row['viewer_receipt_ns'] < end_ns:
                raise TimeoutError('shortcut or observer receipt fell outside the exact phase')
        except (TimeoutError, subprocess.TimeoutExpired) as error:
            row['status'] = 'timeout'
            row['error'] = type(error).__name__
            row['detail'] = str(error)
            raise
        except BaseException as error:
            row['status'] = 'failed'
            row['error'] = type(error).__name__
            row['detail'] = str(error)
            raise
        finally:
            row['observations_finished_locally_ns'] = time.monotonic_ns()
            rows.append(row)
            ledger.write(json.dumps(row, separators=(',', ':')) + '\n')
            ledger.flush()
    remaining = (end_ns - time.monotonic_ns()) / 1_000_000_000
    if remaining > 0:
        time.sleep(remaining)


def distribution(rows):
    values = sorted(row['latency_ns'] for row in rows if row['status'] == 'passed')
    if not values:
        return None
    def percentile(p):
        return values[math.ceil(len(values) * p) - 1] / 1_000_000
    return {'observations': len(values), 'p50_ms': percentile(.5), 'p95_ms': percentile(.95), 'max_ms': values[-1] / 1_000_000}


def run_session(args, directory, session, sha):
    scope = session['endpoint_witness']
    with ExitStack() as cleanup:
        x_display, conn = launch_x(cleanup)
        key = directory / 'key'
        cleanup.callback(key.unlink, missing_ok=True)
        env = clean_env(args.viewer_lib)
        env['XDG_CACHE_HOME'] = str(directory / 'viewer-cache')
        subprocess.run([args.viewer_binary, 'keygen', '--output', key], stdin=subprocess.DEVNULL,
                       stdout=subprocess.DEVNULL, env=env, check=True, timeout=6)
        worker_error = cleanup.enter_context((directory / 'source-observer.stderr').open('wb'))
        ledger = cleanup.enter_context((directory / 'samples.jsonl').open('w'))
        if args.profile == 'loopback':
            worker_command = [sys.executable, '-B', '-u', str(Path(__file__).resolve()), 'worker']
            worker_env = clean_env(None)
        else:
            code = Path(__file__).read_text()
            prefix = 'PYTHONPATH=' + shlex.quote(args.peer_pythonpath) + ' ' if args.peer_pythonpath else ''
            worker_command = SSH + ['-S', 'none', '-o', 'ControlMaster=no', '-o', 'ClearAllForwardings=yes', args.peer,
                                     prefix + '/usr/bin/python3 -B -u -c ' + shlex.quote(code) + ' worker']
            worker_env = clean_env(None)
        worker = own_process(cleanup, worker_command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                             stderr=worker_error, env=worker_env)
        watch = Watch(worker)
        send(worker.stdin, {'profile': args.profile, 'auth_key': base64.b64encode(key.read_bytes()).decode('ascii'),
             'host_binary': str(args.viewer_binary) if args.profile == 'loopback' else args.peer_binary,
             'host_binary_sha256': sha, 'host_lib': args.viewer_lib if args.profile == 'loopback' else args.peer_lib,
             'expected_interface': args.host_interface, 'inline_release_proof': args.inline_release_proof,
             'pipelined_setup': args.pipelined_setup})
        ready = watch.until(time.monotonic() + 22, lambda reply: reply['event'] == 'ready')
        if args.profile == 'dual':
            conn = match_source_xkb(ready, directory, x_display, conn, cleanup, scope)
        probe = display.Display(x_display)
        cleanup.callback(probe.close)
        codes = key_codes(conn)
        session['probe_keycodes'] = codes
        require(ready['keys'] == codes and ready['host_binary_sha256'] == sha and ready['clock'] == 'CLOCK_MONOTONIC',
                'source scope or probe keycodes do not match')
        scope['host_interface'] = ready['interface']
        scope['viewer_interface'] = args.viewer_interface if args.profile == 'dual' else 'lo'
        port = ready['port']
        if args.profile == 'dual':
            tunnel_log = cleanup.enter_context((directory / 'ssh-forward.stderr').open('wb'))
            port, forward = tunnel(cleanup, args.peer, port, tunnel_log, args.viewer_interface)
        viewer_log = directory / 'viewer.log'
        output_log = cleanup.enter_context(viewer_log.open('wb'))
        viewer = own_process(cleanup, [args.viewer_binary, 'connect', f'127.0.0.1:{port}',
                                      '--display', x_display, '--window-size', '1920x1080', '--jpeg',
                                      '--key-file', key, '--grab-input', '--stats-json', '--escape-key', 'F12'],
                             stdin=subprocess.DEVNULL, stdout=output_log, stderr=subprocess.STDOUT, env=env)
        setup_deadline = time.monotonic() + 16
        connected = await_setup(lambda: next((line for line in log_text(viewer_log).splitlines()
                                             if line.startswith('jwm-remote: connected;')), None),
                                setup_deadline, viewer)
        scope['viewer_authenticated_grant'] = connected
        win = await_setup(lambda: xwindow(conn), setup_deadline, viewer)
        geo = win.get_geometry()
        require((geo.width, geo.height) == (1920, 1080), 'unexpected viewer geometry')
        scope['viewer_dimensions'] = [geo.width, geo.height]
        error = None
        try:
            require(connected == 'jwm-remote: connected; keyboard + pointer; clipboard off',
                    'endpoint did not grant the required keyboard+pointer scope')
            session['setup_status'] = 'passed'
            warm_start = time.monotonic_ns()
            score_start = warm_start + args.warmup_seconds * 1_000_000_000
            score_end = score_start + args.score_seconds * 1_000_000_000
            session['warmup_start_ns'] = warm_start
            session['score_start_ns'] = score_start
            session['score_end_ns'] = score_end
            phase_samples('warmup', args.warmup_samples, warm_start, score_start - warm_start, session,
                          ledger, watch, conn, probe, win, codes, args)
            phase_samples('scored', args.samples, score_start, score_end - score_start, session,
                          ledger, watch, conn, probe, win, codes, args)
        except Exception as failure:
            error = failure
            session['measurement_error'] = {'kind': type(failure).__name__, 'detail': str(failure)}
        finally:
            # An ambiguous local sample may leave keys on this wholly owned X
            # server. Never inject cleanup key-ups into it before preserving
            # the timeout, and never reuse the viewer after it.
            final_geometry = win.get_geometry()
            scope['viewer_dimensions_at_close'] = [final_geometry.width, final_geometry.height]
            scope['viewer_exit'] = normal_close(conn, win, viewer)
            logs = log_text(viewer_log)
            viewer_stats = stats(logs, 'viewer')
            viewer_ids = sorted({row['session_id'] for row in viewer_stats})
            scope['viewer_auth_starts'] = logs.count('connection opened; authenticating and negotiating permissions')
            scope['viewer_session_ids'] = viewer_ids
            scope['final_viewer_stats'] = bool(viewer_stats and viewer_stats[-1]['final'])
            scope['observed_route'] = [row['last_frame'] for row in viewer_stats if row.get('last_frame')]
            try:
                if error is None:
                    watch.request('finish', watch.seq)
                    terminal = watch.control(time.monotonic() + 10, 'finished', watch.seq)
                else:
                    diagnostics = scope['failed_measurement_teardown'] = {}
                    terminal = watch.finish_after_failure(time.monotonic() + 10, diagnostics)
                scope.update({name: value for name, value in terminal.items() if name.startswith('host_')})
                scope['observer_exit'] = worker.wait(timeout=5)
                scope['authenticated_scope_equal'] = len(viewer_ids) == 1 and viewer_ids == scope['host_session_ids']
            except Exception as terminal_error:
                scope['terminal_error'] = {'kind': type(terminal_error).__name__, 'detail': str(terminal_error)}
                if error is None:
                    raise
            for row in (*session['warmup_samples'], *session['samples']):
                if row['status'] == 'passed':
                    expected_edges(row, codes)
            if args.profile == 'dual':
                require(forward.poll() is None, 'owned SSH forward ended during test')
        if error is not None:
            raise error
        require(scope['viewer_exit'] == scope['host_exit'] == scope['observer_exit'] == 0
                and scope['host_auth_starts'] == scope['viewer_auth_starts'] == 1
                and scope['authenticated_scope_equal'] and scope['final_viewer_stats']
                and scope['host_held_when_finished'] == [] and scope['observed_route']
                and scope['host_authenticated_grant'] == ['jwm-remote: authenticated session started (screen + pointer + keyboard)']
                and not scope['host_keymap_diagnostic']
                and scope['viewer_dimensions'] == scope['viewer_dimensions_at_close'],
                'session or route witnesses did not establish a clean healthy single scope')
        for frame in scope['observed_route']:
            require(frame.get('codec') == 'JPEG' and frame.get('encoded_dimensions')
                    == frame.get('source_dimensions') == [1920, 1080],
                    'unexpected observed codec or encoded geometry')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--profile', required=True, choices=('loopback', 'dual'))
    parser.add_argument('--viewer-binary', required=True, type=lambda path: Path(path).resolve())
    parser.add_argument('--viewer-sha256', required=True)
    parser.add_argument('--viewer-lib', default='')
    parser.add_argument('--peer')
    parser.add_argument('--peer-binary')
    parser.add_argument('--peer-sha256')
    parser.add_argument('--peer-pythonpath', default='')
    parser.add_argument('--peer-lib', default='')
    parser.add_argument('--viewer-interface', default='eno1')
    parser.add_argument('--host-interface', default='wlp3s0')
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--sessions', type=int, default=3)
    parser.add_argument('--samples', type=int, default=100)
    parser.add_argument('--warmup-samples', type=int, default=30)
    parser.add_argument('--warmup-seconds', type=int, default=30)
    parser.add_argument('--score-seconds', type=int, default=60)
    parser.add_argument('--deadline-ms', type=int, default=2500)
    parser.add_argument('--pilot', action='store_true')
    parser.add_argument('--inline-release-proof', action='store_true',
                        help='include source keymap proof in the actual key-up observer line on the dual route')
    parser.add_argument('--pipelined-setup', action='store_true',
                        help='pipeline click edges and attach proof to the held-key press observer event')
    args = parser.parse_args()
    if args.profile == 'dual' and not (re.fullmatch(r'[A-Za-z0-9_.-]+@(?:[0-9]{1,3}\.){3}[0-9]{1,3}', args.peer or '')
            and args.peer_binary and args.peer_sha256):
        parser.error('dual profile requires explicit user@IPv4 peer, peer binary and peer SHA-256')
    if args.inline_release_proof and args.profile != 'dual':
        parser.error('inline release proof is a separate dual-only observer profile')
    if args.pipelined_setup and not args.inline_release_proof:
        parser.error('pipelined setup uses the inline dual-machine proof profile')
    if min(args.sessions, args.samples, args.warmup_samples, args.warmup_seconds, args.score_seconds, args.deadline_ms) <= 0:
        parser.error('trial counts and timing budgets must be positive')
    if not args.pilot and (args.warmup_seconds < 30 or args.score_seconds != 60 or args.samples != 100 or args.sessions < 3):
        parser.error('formal scope requires >=30 seconds warm-up, 60 seconds scored, and >=3 sessions of 100')
    require(sha256(args.viewer_binary) == args.viewer_sha256, 'viewer binary digest mismatch')
    signal.signal(signal.SIGALRM, timed_out)
    signal.signal(signal.SIGTERM, terminate_signal)
    host_sha = args.viewer_sha256 if args.profile == 'loopback' else args.peer_sha256
    report = {'schema_version': 1, 'profile': args.profile, 'pilot': args.pilot,
              'metric': 'same_clock_host_edge' if args.profile == 'loopback' else 'viewer_receive_upper_bound',
              'clock': 'one system CLOCK_MONOTONIC' if args.profile == 'loopback' else 'separate CLOCK_MONOTONIC clocks, viewer issue through independent SSH observer receipt only',
              'samples_requested_per_session': args.samples, 'sessions_requested': args.sessions,
              'release_proof_transport': ('in_key_up_observer_reply_after_source_xquerykeymap'
                                          if args.inline_release_proof else 'separate_source_snapshot_reply'),
              'deadline_ms': args.deadline_ms, 'warmup_seconds': args.warmup_seconds,
              'score_seconds': args.score_seconds, 'warmup_samples_requested': args.warmup_samples,
              'viewer_binary_sha256': args.viewer_sha256, 'local_binary_sha256': args.viewer_sha256,
              'host_binary_sha256': host_sha,
              'fixture_sha256': sha256(Path(__file__)), 'sessions': [],
              'route': {'application_path': 'unshaped IPv4 loopback' if args.profile == 'loopback' else 'unshaped SSH IPv4 local forward over an ordinary link with an Ubuntu Wi-Fi segment',
                        'observer_path': 'same-device stdio' if args.profile == 'loopback' else 'independent SSH TCP stdio control and observer connection, no multiplexing with data forward',
                        'source_dimensions': [1920, 1080], 'capture_fps': 15, 'codec': 'JPEG', 'clipboard': 'disabled'}}
    if args.pipelined_setup:
        report['setup_method'] = PIPELINED_SETUP
    args.out.mkdir(mode=0o700)
    publish(args.out / 'result.json', report)
    for index in range(1, args.sessions + 1):
        directory = args.out / f'session-{index}'
        directory.mkdir(mode=0o700)
        trial = {'session_index': index, 'setup_status': 'pending', 'requested': args.samples,
                 'status': 'failed', 'warmup_samples': [], 'samples': [], 'endpoint_witness': {}}
        try:
            run_session(args, directory, trial, host_sha)
            trial['status'] = 'passed' if len(trial['samples']) == args.samples and all(
                row['status'] == 'passed' for row in trial['samples']) else 'incomplete'
        except (Exception, KeyboardInterrupt) as error:
            trial['error'] = type(error).__name__
            trial['detail'] = str(error)
            if trial['setup_status'] == 'pending':
                trial['setup_status'] = 'failed'
            if isinstance(error, KeyboardInterrupt):
                raise
        finally:
            trial['attempted'] = sum('seq' in row for row in trial['samples'])
            trial['not_attempted'] = args.samples - trial['attempted']
            trial['shortcut_issued'] = sum('viewer_issue_ns' in row for row in trial['samples'])
            trial['observed_distribution'] = distribution(trial['samples'])
            publish(directory / 'session.json', trial)
            report['sessions'].append(trial)
            publish(args.out / 'result.json', report)
        print(json.dumps({name: trial[name] for name in ('session_index', 'status', 'attempted', 'not_attempted',
                                                         'shortcut_issued', 'observed_distribution')}), flush=True)
    qualified = len(report['sessions']) == args.sessions and all(row['status'] == 'passed' for row in report['sessions'])
    report['qualified_population'] = qualified
    report['qualified_distribution'] = distribution([sample for row in report['sessions'] for sample in row['samples']]) if qualified else None
    report['all_sessions_at_or_below_50_ms'] = (all(row['observed_distribution']['p95_ms'] <= 50
                                                for row in report['sessions']) if qualified and not args.pilot else None)
    report['p95_threshold_evaluation'] = ('pilot' if args.pilot else 'incomplete' if not qualified else
        'met_by_measured_upper_bound' if args.profile == 'dual' and report['qualified_distribution']['p95_ms'] <= 50 else
        'upper_bound_above_50_ms_exact_one_way_inconclusive' if args.profile == 'dual' else
        'met' if report['qualified_distribution']['p95_ms'] <= 50 else 'not_met')
    publish(args.out / 'result.json', report)
    return 0 if qualified else 1


if __name__ == '__main__':
    if sys.argv[1:] == ['worker']:
        signal.signal(signal.SIGTERM, terminate_signal)
        signal.signal(signal.SIGHUP, terminate_signal)
        sys.exit(observer())
    sys.exit(main())
