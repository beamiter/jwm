#!/usr/bin/env python3
"""Replay the P07 release diagnostic from staged JSON and owned endpoint logs."""
import argparse
import json
from pathlib import Path
import runpy


FIXTURE = Path(__file__).resolve().with_name('p07-release.py')
FUNCTIONS = runpy.run_path(str(FIXTURE))
X = FUNCTIONS['X']
BUDGET = FUNCTIONS['budget']
PROFILES = FUNCTIONS['BULK_KBIT']
EXPECTED_BINARY_SHA256 = '5e1951ed8bbc23f41db5b5918931d91a37baa1e9fa213c8ef9067a214a1511e5'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def actions_with_label(actions, label):
    return [action for action in actions if action['event'] == label]


def action_with_label(actions, label):
    found = actions_with_label(actions, label)
    require(len(found) == 1, f'expected exactly one {label} witness')
    return found[0]


def verify_trial(row, trace, host_log, viewer_log):
    profile, release, total = row['profile'], row['explicit_release'], row['upload_bytes']
    chunk, window = BUDGET(PROFILES[profile])
    require(row['configured_rate_kbit_per_second'] == PROFILES[profile]
            and (row['chunk_bytes'], row['window_bytes']) == (chunk, window)
            and row['uplink_configured_bytes_per_second'] == 1_250_000, 'unexpected transport budget')
    active_budget_log = 'clipboard file/image budget rate='
    if PROFILES[profile] is None:
        require(active_budget_log not in viewer_log, 'logged configured budget in the default arm')
    else:
        exact_line = f'{active_budget_log}{PROFILES[profile]} kbit/s chunk={chunk} bytes window={window} bytes'
        require(exact_line in viewer_log, 'missing proof of small budget activation')
    require(host_log.count('authenticated session started') == 1
            and viewer_log.count('connection opened; authenticating and negotiating permissions') == 1
            and viewer_log.count('sharing 1 file') == 1 and viewer_log.count('shared 1 file') == 1
            and host_log.count('clipboard update queued') == 1
            and 'restricting clipboard' not in viewer_log and 'clipboard restriction confirmed' not in viewer_log,
            'expected one successful authenticated file transfer without policy restriction')
    require(row['viewer_exit'] == 0 and row['host_exit'] == 0, 'unclean endpoint exit')
    telemetry = row['sender_telemetry']
    require(len({item['session_id'] for item in telemetry}) == 1 and telemetry[-1]['final'],
            'missing terminal telemetry from the same viewer session')
    require(row['sha256'] == row['host_staged_sha256'] and row['host_clipboard_uri_matches_staged_file'],
            'missing original host file SHA-256 and clipboard URI witness')

    actions, stages, edges, keys = (trace[name] for name in ('actions', 'staging', 'source_edges', 'keycodes'))
    old, fresh, ctrl, sup, escape = (keys[name] for name in ('held', 'fresh', 'control', 'super', 'escape'))
    for records in (actions, stages, edges):
        witnesses = [record['at_ns'] for record in records]
        require(witnesses == sorted(witnesses), 'monotonic event witness out of order')
    forwarded = FUNCTIONS['verify_release_sequence'](edges, old, fresh, (ctrl, sup))
    require(forwarded == release['forwarded_shortcut_modifiers'], 'source modifier witness disagrees')
    require([row['event'] for row in stages] == ['before_hold', 'before_release_shortcut',
            'after_source_key_up_pre_local_key_up', 'after_reacquire', 'after_fresh_pair', 'completed_original_file'],
            'missing transfer progress around release and reacquisition')
    sizes = [item['staged_bytes'] for item in stages]
    require(len({(row['device'], row['inode']) for row in stages}) == 1 and sizes == sorted(sizes)
            and row['active_started_bytes'] <= sizes[0] <= sizes[-2] < sizes[-1] == total,
            'expected one independently measured partial file to reach completion')
    require(sizes[1:3] == [release['partial_bytes_pre_shortcut'], release['partial_bytes_post_release']],
            'release record disagrees with raw staged bytes')
    cleanup = actions_with_label(actions, 'shortcut_cleanup_up')
    require([(record['type'], record['detail']) for record in cleanup]
            == [(X.KeyRelease, key) for key in (escape, sup, ctrl)], 'missing local chord cleanup')
    for label, kind, code in (('held_key_press', X.KeyPress, old), ('shortcut_control_down', X.KeyPress, ctrl),
                               ('shortcut_super_down', X.KeyPress, sup), ('shortcut_escape_down', X.KeyPress, escape),
                               ('held_key_local_up', X.KeyRelease, old), ('reacquire_click_down', X.ButtonPress, 1),
                               ('reacquire_click_up', X.ButtonRelease, 1), ('fresh_key_press', X.KeyPress, fresh),
                               ('fresh_key_up', X.KeyRelease, fresh)):
        witness = action_with_label(actions, label)
        require((witness['type'], witness['detail']) == (kind, code), f'unexpected XTEST issue for {label}')
    local_press = action_with_label(actions, 'held_key_press')['at_ns']
    chord = action_with_label(actions, 'shortcut_escape_down')['at_ns']
    initially_held = action_with_label(actions, 'held_on_both_displays')
    grabs_released = action_with_label(actions, 'viewer_grabs_available_before_local_key_up')
    clear_keys = action_with_label(actions, 'source_keys_clear_while_viewer_keys_held')
    local_up = action_with_label(actions, 'held_key_local_up')['at_ns']
    regrab = action_with_label(actions, 'viewer_grabbed_after_click')['at_ns']
    local_fresh_down = action_with_label(actions, 'fresh_key_press')['at_ns']
    local_fresh_up = action_with_label(actions, 'fresh_key_up')['at_ns']
    source_press, source_release = (next(edge['at_ns'] for edge in edges if edge['type'] == kind and edge['detail'] == old)
                                    for kind in (X.KeyPress, X.KeyRelease))
    source_fresh_press, source_fresh_release = [edge['at_ns'] for edge in edges[-2:]]
    require(initially_held['host_held'] == initially_held['viewer_held'] == [old],
            'missing hold witness on both X servers before shortcut')
    require(clear_keys['host_held'] == [] and clear_keys['viewer_held'] == [old, ctrl, sup, escape],
            'missing cleared host and physically held viewer keys at the same checkpoint')
    require(local_press <= source_press <= initially_held['at_ns'] <= stages[1]['at_ns'] <= chord
            <= source_release <= stages[2]['at_ns'] <= clear_keys['at_ns'] <= grabs_released['at_ns']
            <= cleanup[0]['at_ns'] <= cleanup[-1]['at_ns'] <= local_up < regrab
            <= stages[3]['at_ns'] <= local_fresh_down <= source_fresh_press <= local_fresh_up
            <= source_fresh_release <= stages[-2]['at_ns'] <= stages[-1]['at_ns'], 'operation timestamps crossed the release boundary')
    for label, status, earliest, latest in (
            ('viewer_grabbed_before_hold', X.AlreadyGrabbed, 0, local_press),
            ('viewer_grabs_available_before_local_key_up', X.GrabSuccess, clear_keys['at_ns'], local_up),
            ('viewer_grabbed_after_click', X.AlreadyGrabbed, local_up, local_fresh_down)):
        witness = action_with_label(actions, label)
        require(witness['keyboard_status'] == status == witness['pointer_status']
                and earliest <= witness['at_ns'] <= latest, f'invalid keyboard/pointer grab evidence for {label}')
    require((local_press, source_press, chord, source_release, local_up, source_fresh_press, source_fresh_release)
            == tuple(release[key] for key in ('held_issue_ns', 'source_held_ns', 'shortcut_issued_ns',
                    'source_released_ns', 'viewer_local_held_key_up_ns', 'source_fresh_key_down_ns',
                    'source_fresh_key_up_ns')), 'recorded release timestamps differ from raw evidence')
    latency_ms = (source_release - chord) / 1_000_000
    require(latency_ms == release['shortcut_to_source_key_up_ms'], 'incorrect release duration')
    return {'trial': row['trial'], 'profile': profile, 'shortcut_to_source_key_up_ms': latency_ms,
            'partial_bytes_pre_and_post_release': sizes[1:3], 'file_bytes': total, 'file_sha256': row['sha256']}


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('result', type=Path)
    args = cli.parse_args()
    report = json.loads(args.result.read_text())
    require(report['binary_sha256'] == EXPECTED_BINARY_SHA256, 'unexpected benchmark binary digest')
    require(not report['errors'], 'fixture recorded failures')
    require(report['fixture_sha256'] == {name: FUNCTIONS['file_hash'](FIXTURE.with_name(name))
            for name in ('p07-release.py', 'test-remote-viewer-e2e.py', 'remote-fault-proxy.py')},
            'fixture source digests differ from the recorded inputs')
    expected_cases = [(1, 'default'), (1, 'rate-6000'), (2, 'rate-6000'), (2, 'default')]
    require([(row['trial'], row['profile']) for row in report['runs']] == expected_cases,
            'expected all four shaped diagnostics in ABBA order')
    result = []
    for row in report['runs']:
        directory = args.result.parent / f"{row['trial']}-release-{row['profile']}"
        trace = json.loads((directory / 'release-trace.json').read_text())
        result.append(verify_trial(row, trace, (directory / 'host.log').read_text(), (directory / 'viewer.log').read_text()))
    print(json.dumps({'scope': 'four shaped software cancellation diagnostics', 'trials': result}, indent=2))


if __name__ == '__main__':
    main()
