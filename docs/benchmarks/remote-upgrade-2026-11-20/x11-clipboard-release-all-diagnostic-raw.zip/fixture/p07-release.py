#!/usr/bin/env python3
"""Check explicit X11 release of held input during an authenticated clipboard upload."""
import argparse
from contextlib import ExitStack
import hashlib
import json
import math
import os
from pathlib import Path
import random
import re
import runpy
import select
import signal
import statistics
import subprocess
import time
from urllib.parse import unquote, urlsplit

from Xlib import X, XK, display
from Xlib.ext import xtest
from Xlib.protocol import event


UPLINK_BYTES_PER_SECOND = 1_250_000
BULK_KBIT = {'default': None, 'rate-6000': 6000}
RELEASE_QUIET_SECONDS = .18
INPUT_MASK = X.KeyPressMask | X.KeyReleaseMask | X.ButtonPressMask | X.ButtonReleaseMask
EDGE_TYPES = {X.KeyPress, X.KeyRelease, X.ButtonPress, X.ButtonRelease}
FILE_NAME = 'clipboard-fixture.bin'


def stop(process):
    if process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=4)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=4)


def wait_for(label, predicate, *children, timeout=12):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        for child in children:
            if child.poll() is not None:
                raise RuntimeError(f'{label}: child exited with status {child.returncode}')
        result = predicate()
        if result:
            return result
        time.sleep(.01)
    raise RuntimeError(f'timed out waiting for {label}')


def read(path):
    return path.read_text(encoding='utf-8', errors='replace')


def make_payload(path, count):
    rng = random.Random(24877)
    digest = hashlib.sha256()
    with path.open('wb') as stream:
        while count:
            block = rng.randbytes(min(count, 1 << 20))
            stream.write(block)
            digest.update(block)
            count -= len(block)
    return digest.hexdigest()


def file_hash(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def owned_app(connection, *, mask=0):
    screen = connection.screen()
    root = screen.root
    window = root.create_window(0, 0, screen.width_in_pixels, screen.height_in_pixels, 0,
                                screen.root_depth, X.InputOutput, X.CopyFromParent,
                                background_pixel=0x284050, event_mask=mask)
    window.set_wm_name('P07 isolated input receiver')
    window.map()
    window.set_input_focus(X.RevertToParent, X.CurrentTime)
    connection.sync()
    return window


def viewer_window(connection):
    name_atom = connection.intern_atom('_NET_WM_NAME')
    for window in connection.screen().root.query_tree().children:
        prop = window.get_full_property(name_atom, X.AnyPropertyType)
        name = prop.value.decode(errors='replace') if prop and isinstance(prop.value, bytes) else window.get_wm_name()
        if isinstance(name, str) and ' - JWM Remote' in name:
            return window
    return None


def inject(connection, event_type, detail=0, *, x=0, y=0):
    issued = time.monotonic_ns()
    xtest.fake_input(connection, event_type, detail, x=x, y=y)
    connection.flush()
    return issued


def pending_edges(connection, receiver):
    while connection.pending_events():
        event = connection.next_event()
        when = time.monotonic_ns()
        if event.type in EDGE_TYPES:
            if event.window.id != receiver.id or event.send_event:
                raise RuntimeError('expected an XTEST input edge at the owned receiver window')
            yield event.type, event.detail, when


def input_schedule(client, server, receiver, count, bytes_so_far, *, minimum=0, maximum=0):
    keys = [client.keysym_to_keycode(keysym) for keysym in (XK.XK_F7, XK.XK_F8, XK.XK_F9)]
    records = []
    sequence = []
    for i in range(count):
        code = keys[i % len(keys)]
        sequence.extend(((X.KeyPress, code, 0), (X.KeyRelease, code, .021)))
    sent = received = 0
    next_send = time.monotonic() + .02
    deadline = next_send + count * .18 + 8
    while time.monotonic() < deadline:
        now = time.monotonic()
        if sent < len(sequence) and now >= next_send:
            typ, code, _ = sequence[sent]
            progress = bytes_so_far()
            if maximum and not minimum <= progress < maximum:
                raise RuntimeError(f'input probe outside active file upload: {progress} bytes')
            issue = inject(client, typ, code)
            records.append({'type': 'press' if typ == X.KeyPress else 'release',
                            'keycode': code, 'issue_ns': issue, 'staged_bytes': progress})
            sent += 1
            if sent < len(sequence):
                next_send = now + (sequence[sent][2] if sent % 2 else .057 + .008 * ((sent // 2) % 5))
        for typ, code, observed in pending_edges(server, receiver):
            if received >= sent or sequence[received][:2] != (typ, code):
                raise RuntimeError(f'out-of-order or unmatched key {typ}/{code} at edge {received}')
            record = records[received]
            record['received_ns'] = observed
            record['latency_ms'] = (observed - record['issue_ns']) / 1_000_000
            received += 1
        if received == len(sequence):
            return records
        until = next_send if sent < len(sequence) else deadline
        select.select([server.fileno()], [], [], max(0, min(.01, until - time.monotonic())))
    raise RuntimeError(f'expected {len(sequence)} input edges, sent {sent}, observed {received}')


def compact(edges):
    releases = sorted(row['latency_ms'] for row in edges if row['type'] == 'release')
    rank = lambda p: releases[math.ceil(p * len(releases)) - 1]
    return {'count': len(releases), 'median_ms': statistics.median(releases),
            'p95_ms': rank(.95), 'p99_ms': rank(.99), 'max_ms': releases[-1]}


def budget(rate):
    if rate is None:
        return 128 << 10, 1 << 20
    return rate * 25 // 8, rate * 60 // 8


def keymap_held(connection, codes):
    keymap = connection.query_keymap()
    return [code for code in codes if keymap[code // 8] & (1 << (code % 8))]


def local_grab_status(probe):
    root = probe.screen().root
    keyboard = root.grab_keyboard(False, X.GrabModeAsync, X.GrabModeAsync, X.CurrentTime)
    try:
        pointer = root.grab_pointer(False, X.ButtonPressMask, X.GrabModeAsync,
                                    X.GrabModeAsync, X.NONE, X.NONE, X.CurrentTime)
        if pointer == X.GrabSuccess:
            probe.ungrab_pointer(X.CurrentTime)
        return keyboard, pointer
    finally:
        if keyboard == X.GrabSuccess:
            probe.ungrab_keyboard(X.CurrentTime)
        probe.sync()


def verify_release_sequence(edges, old, fresh, modifiers):
    # The fence may discard unsent modifier downs. The host must unwind any
    # forwarded chord modifiers in reverse order before releasing the held key.
    actual = [(row['type'], row['detail']) for row in edges]
    old_up = (X.KeyRelease, old)
    if old_up not in actual:
        raise RuntimeError('held key did not reach its source release edge')
    preceding = actual[1:actual.index(old_up)]
    forwarded = [code for kind, code in preceding if kind == X.KeyPress]
    if forwarded != [code for code in modifiers if code in forwarded]:
        raise RuntimeError(f'unexpected modifiers or ordering before ReleaseAll: {forwarded}')
    expected = ([(X.KeyPress, old)] + [(X.KeyPress, code) for code in forwarded]
                + [(X.KeyRelease, code) for code in reversed(forwarded)]
                + [old_up, (X.ButtonPress, 1), (X.ButtonRelease, 1),
                   (X.KeyPress, fresh), (X.KeyRelease, fresh)])
    if actual != expected:
        raise RuntimeError(f'source edges crossed the release boundary: {actual}; expected {expected}')
    return forwarded


def run(args, directory, source, digest, profile):
    fixture = Path(__file__).resolve().parent
    xvfb_launch = runpy.run_path(str(fixture / 'test-remote-viewer-e2e.py'))['launch']
    with ExitStack() as cleanup:
        xhost, host_display = xvfb_launch()
        cleanup.callback(stop, xhost)
        xviewer, viewer_display = xvfb_launch()
        cleanup.callback(stop, xviewer)
        host_conn = display.Display(host_display)
        cleanup.callback(host_conn.close)
        viewer_conn = display.Display(viewer_display)
        cleanup.callback(viewer_conn.close)
        for connection in (host_conn, viewer_conn):
            assert connection.has_extension('XTEST')
            connection.change_keyboard_control(auto_repeat_mode=X.AutoRepeatModeOff)
            connection.sync()
        receiver = owned_app(host_conn, mask=INPUT_MASK)
        env = os.environ.copy()
        for name in ('DISPLAY', 'WAYLAND_DISPLAY', 'WAYLAND_SOCKET', 'XAUTHORITY',
                     'JWM_REMOTE_CLIPBOARD_BULK_KBIT', 'JWM_REMOTE_READ_AHEAD',
                     'JWM_REMOTE_KEEP_WINDOW', 'JWM_REMOTE_X11_REGIONS', 'JWM_REMOTE_GPU_CAPTURE',
                     'JWM_REMOTE_GPU_PRESENT'):
            env.pop(name, None)
        host_cache, viewer_cache = directory / 'host-cache', directory / 'viewer-cache'
        for cache in (host_cache, viewer_cache):
            cache.mkdir(mode=0o700)
        host_env = env | {'XDG_CACHE_HOME': str(host_cache)}
        viewer_env = env | {'XDG_CACHE_HOME': str(viewer_cache)}
        configured_rate = BULK_KBIT[profile]
        if configured_rate is not None:
            viewer_env['JWM_REMOTE_CLIPBOARD_BULK_KBIT'] = str(configured_rate)
        key = directory / 'key'
        cleanup.callback(key.unlink, missing_ok=True)
        subprocess.run([args.binary, 'keygen', '--output', key], env=env, check=True,
                       stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, timeout=6)

        def start(name, command, process_env, *, stdin=None):
            log = directory / (name + '.log')
            output = cleanup.enter_context(log.open('wb'))
            proc = subprocess.Popen(command, env=process_env, stdout=output, stderr=subprocess.STDOUT,
                                    stdin=subprocess.DEVNULL if stdin is None else stdin)
            cleanup.callback(stop, proc)
            return proc, log

        host, host_log = start('host', [args.binary, 'host', '--display', host_display,
                                       '--capture-source', 'root', '--once', '--listen', '127.0.0.1:0',
                                       '--key-file', key, '--fps', '15', '--stats-json',
                                       '--allow-input', '--allow-clipboard', '--clipboard-direction', 'to-host',
                                       '--clipboard-file-limit', str(args.bytes)], host_env)
        port = wait_for('authenticated host listener', lambda: re.search(r'listening on 127\.0\.0\.1:(\d+)',
                                                                         read(host_log)), host)[1]
        proxy_args = ['python3', fixture / 'remote-fault-proxy.py', '--upstream-host', '127.0.0.1',
                      '--upstream-port', port, '--max-connections', '1', '--chunk-bytes', '16384',
                      '--c2s-bytes-per-second', str(UPLINK_BYTES_PER_SECOND)]
        proxy, proxy_log = start('proxy', proxy_args, env)
        listener = wait_for('private shaped proxy listener', lambda: read(proxy_log).splitlines(), proxy)
        proxy_port = json.loads(listener[0])['listening'][1]
        viewer, viewer_log = start('viewer', [args.binary, 'connect', f'127.0.0.1:{proxy_port}',
                                              '--display', viewer_display, '--window-size', '640x400', '--jpeg',
                                              '--key-file', key, '--grab-input', '--clipboard',
                                              '--clipboard-direction', 'to-host', '--stats-json',
                                              '--clipboard-file-limit', str(args.bytes), '--escape-key', 'F12'],
                                   viewer_env)
        wait_for('viewer connected', lambda: 'connected;' in read(viewer_log), host, viewer)
        chunk, window = budget(configured_rate)
        budget_line = 'clipboard file/image budget rate='
        viewer_setup = read(viewer_log)
        if configured_rate is None:
            if budget_line in viewer_setup or 'JWM_REMOTE_CLIPBOARD_BULK_KBIT' in viewer_env:
                raise RuntimeError('viewer did not use the default clipboard budget')
        elif f'{budget_line}{configured_rate} kbit/s chunk={chunk} bytes window={window} bytes' not in viewer_setup:
            raise RuntimeError('viewer did not apply the intended clipboard chunk/window')
        win = wait_for('private viewer window', lambda: viewer_window(viewer_conn), host, viewer)
        win.set_input_focus(X.RevertToParent, X.CurrentTime)
        geometry = win.get_geometry()
        inject(viewer_conn, X.MotionNotify, x=geometry.x + geometry.width // 2, y=geometry.y + geometry.height // 2)
        inject(viewer_conn, X.ButtonPress, 1)
        time.sleep(.075)
        inject(viewer_conn, X.ButtonRelease, 1)
        time.sleep(.2)
        list(pending_edges(host_conn, receiver))
        preflight = input_schedule(viewer_conn, host_conn, receiver, args.idle_samples, lambda: 0)

        def offer(name, target, value):
            owner, _ = start(name, ['xclip', '-quiet', '-display', viewer_display, '-selection',
                                    'clipboard', '-t', target, '-i'], viewer_env, stdin=subprocess.PIPE)
            owner.stdin.write(value)
            owner.stdin.close()
            return owner

        def paste(target):
            return subprocess.check_output(['xclip', '-display', host_display, '-selection',
                                            'clipboard', '-t', target, '-o'],
                                           env=host_env, timeout=8, text=True)

        def close_session(result):
            close = event.ClientMessage(window=win, client_type=viewer_conn.intern_atom('WM_PROTOCOLS'),
                                        data=(32, [viewer_conn.intern_atom('WM_DELETE_WINDOW'), 0, 0, 0, 0]))
            win.send_event(close)
            viewer_conn.flush()
            result['viewer_exit'] = viewer.wait(timeout=8)
            result['host_exit'] = host.wait(timeout=8)
            if result['viewer_exit'] or result['host_exit']:
                raise RuntimeError('session did not close cleanly')

        staging = host_cache / 'jwm' / 'remote-clipboard'
        upload_start_ns = time.monotonic_ns()
        uri = (source.as_uri() + '\r\n').encode()
        owner = offer('xclip', 'text/uri-list', uri)
        host_clip = host_conn.intern_atom('CLIPBOARD')

        def staged_file():
            copies = list(staging.rglob(FILE_NAME)) if staging.exists() else []
            if len(copies) > 1:
                raise RuntimeError('unexpected duplicate staged file')
            return copies[0] if copies else None

        def staged_size():
            path = staged_file()
            if path is not None:
                try:
                    return path.stat().st_size
                except FileNotFoundError:
                    pass
            return 0

        def progress():
            size = staged_size()
            return size if args.start_bytes <= size < args.bytes and host_conn.get_selection_owner(host_clip) else None

        await_bytes = wait_for('partial file staged by the host', progress, host, viewer, owner, timeout=14)
        active_start_ns = time.monotonic_ns()
        result = {'profile': profile, 'operation': 'release', 'upload_bytes': args.bytes, 'sha256': digest,
                  'configured_rate_kbit_per_second': configured_rate,
                  'chunk_bytes': chunk, 'window_bytes': window,
                  'uplink_configured_bytes_per_second': UPLINK_BYTES_PER_SECOND, 'active_started_bytes': await_bytes,
                  'idle': compact(preflight), 'idle_edges': preflight, 'offered_ns': upload_start_ns,
                  'active_start_ns': active_start_ns}
        def upload_completed():
            return ('clipboard update queued' in read(host_log) and staged_size() == args.bytes
                    and 'shared 1 file' in read(viewer_log))

        def require_landed_file():
            end = time.monotonic_ns()
            landed = staged_file()
            landed_digest = file_hash(landed)
            if landed.stat().st_size != args.bytes or landed_digest != digest:
                raise RuntimeError('host staging did not contain the exact original synthetic file')
            result['host_staged_sha256'] = landed_digest
            pasted = paste('text/uri-list')
            offered = [urlsplit(line) for line in pasted.splitlines() if line and not line.startswith('#')]
            assert len(offered) == 1 and offered[0].scheme == 'file'
            assert Path(unquote(offered[0].path)).resolve() == landed.resolve()
            result['completion_observed_ns'] = end
            result['throughput_file_mbit_per_sec'] = args.bytes * 8_000 / (end - upload_start_ns)
            result['active_staged_mbit_per_sec'] = (args.bytes - await_bytes) * 8_000 / (end - active_start_ns)
            result['host_clipboard_uri_matches_staged_file'] = True
            return landed

        def release_during_upload(trace):
            source_edges = trace['source_edges']
            actions = trace['actions']
            stage_samples = trace['staging']
            old, fresh, control, super_key, escape = (viewer_conn.keysym_to_keycode(keysym) for keysym in
                (XK.XK_F10, XK.XK_F9, XK.XK_Control_L, XK.XK_Super_L, XK.XK_F12))
            held_keys = (old, control, super_key, escape)
            if 0 in (*held_keys, fresh) or len({*held_keys, fresh}) != 5:
                raise RuntimeError('owned X server lacks the distinct probe keys')
            trace['keycodes'] = {'held': old, 'fresh': fresh, 'control': control, 'super': super_key, 'escape': escape}
            probe = display.Display(viewer_display)
            cleanup.callback(probe.close)
            grabbed = (X.AlreadyGrabbed, X.AlreadyGrabbed)
            released = (X.GrabSuccess, X.GrabSuccess)

            def note(label, **values):
                actions.append({'event': label, 'at_ns': time.monotonic_ns(), **values})

            def send(label, kind, detail):
                issued = inject(viewer_conn, kind, detail)
                actions.append({'event': label, 'at_ns': issued, 'type': kind, 'detail': detail})
                return issued

            def drain():
                source_edges.extend({'type': kind, 'detail': detail, 'at_ns': observed}
                                    for kind, detail, observed in pending_edges(host_conn, receiver))

            def wait_observed(label, predicate, timeout=8):
                deadline = time.monotonic() + timeout
                while (remaining := deadline - time.monotonic()) > 0:
                    drain()
                    for child in (host, viewer, owner, proxy):
                        if child.poll() is not None:
                            raise RuntimeError(f'{label}: owned child exited {child.returncode}')
                    found = predicate()
                    if found:
                        return found
                    select.select([host_conn.fileno()], [], [], min(.01, remaining))
                raise RuntimeError(f'timed out waiting for {label}')

            def edge_after(label, kind, detail, since):
                return wait_observed(label, lambda: next((edge for edge in source_edges
                    if (edge['type'], edge['detail']) == (kind, detail) and edge['at_ns'] >= since), None))

            def observe_grabs(label, expected):
                actual = local_grab_status(probe)
                note(label, keyboard_status=actual[0], pointer_status=actual[1])
                if actual != expected:
                    raise RuntimeError(f'{label}: grabs {actual}, expected {expected}')

            def sample_staging(label, *, complete=False):
                path = staged_file()
                if path is None:
                    raise RuntimeError(f'{label}: lost the original staging file')
                info = path.stat()
                sample = {'event': label, 'at_ns': time.monotonic_ns(), 'staged_bytes': info.st_size,
                          'device': info.st_dev, 'inode': info.st_ino}
                if stage_samples:
                    if (sample['device'], sample['inode']) != (stage_samples[0]['device'], stage_samples[0]['inode']):
                        raise RuntimeError(f'{label}: attempted to use a replacement staging file')
                    if sample['staged_bytes'] < stage_samples[-1]['staged_bytes']:
                        raise RuntimeError(f'{label}: the original upload regressed')
                stage_samples.append(sample)
                active = args.start_bytes <= info.st_size < args.bytes
                if not (info.st_size == args.bytes if complete else active):
                    raise RuntimeError(f'{label}: unexpected staging size {info.st_size}')
                return sample

            observe_grabs('viewer_grabbed_before_hold', grabbed)
            sample_staging('before_hold')
            held_issue = send('held_key_press', X.KeyPress, old)
            target_down = edge_after('held key down at the source window', X.KeyPress, old, held_issue)
            host_held = keymap_held(host_conn, held_keys)
            viewer_held = keymap_held(viewer_conn, held_keys)
            note('held_on_both_displays', host_held=host_held, viewer_held=viewer_held)
            if host_held != [old] or viewer_held != [old]:
                raise RuntimeError('the probe key was not held on both X servers before the shortcut')
            send('shortcut_control_down', X.KeyPress, control)
            send('shortcut_super_down', X.KeyPress, super_key)
            before_chord = sample_staging('before_release_shortcut')
            chord_ns = send('shortcut_escape_down', X.KeyPress, escape)
            target_up = edge_after('source release before viewer XTEST key-up', X.KeyRelease, old, chord_ns)
            after_release = sample_staging('after_source_key_up_pre_local_key_up')
            host_held = keymap_held(host_conn, held_keys)
            viewer_held = keymap_held(viewer_conn, held_keys)
            note('source_keys_clear_while_viewer_keys_held', host_held=host_held, viewer_held=viewer_held)
            if host_held or viewer_held != list(held_keys):
                raise RuntimeError('source keys must be clear while the viewer still physically holds the chord and target')
            observe_grabs('viewer_grabs_available_before_local_key_up', released)
            for code in (escape, super_key, control):
                send('shortcut_cleanup_up', X.KeyRelease, code)
            physical_up_ns = send('held_key_local_up', X.KeyRelease, old)
            viewer_conn.sync()
            if keymap_held(viewer_conn, held_keys):
                raise RuntimeError('viewer physical cleanup did not release the original chord')
            count = len(source_edges)
            quiet_until = time.monotonic() + RELEASE_QUIET_SECONDS
            wait_observed('source remains quiet after viewer physical key-up', lambda: time.monotonic() >= quiet_until)
            if len(source_edges) != count:
                raise RuntimeError('late source edge while viewer was released')

            win.set_input_focus(X.RevertToParent, X.CurrentTime)
            inject(viewer_conn, X.MotionNotify, x=geometry.x + geometry.width // 2, y=geometry.y + geometry.height // 2)
            clicked = send('reacquire_click_down', X.ButtonPress, 1)
            edge_after('source accepted reacquisition click', X.ButtonPress, 1, clicked)
            click_up = send('reacquire_click_up', X.ButtonRelease, 1)
            edge_after('source accepted reacquisition click release', X.ButtonRelease, 1, click_up)
            observe_grabs('viewer_grabbed_after_click', grabbed)
            sample_staging('after_reacquire')
            fresh_down = send('fresh_key_press', X.KeyPress, fresh)
            target_fresh_down = edge_after('fresh source key down', X.KeyPress, fresh, fresh_down)
            # Await actual source down before issuing its matching up; the
            # corresponding pair must be after the original ReleaseAll.
            fresh_up = send('fresh_key_up', X.KeyRelease, fresh)
            target_fresh_up = edge_after('fresh source key up', X.KeyRelease, fresh, fresh_up)
            if keymap_held(host_conn, (*held_keys, fresh)) or keymap_held(viewer_conn, (*held_keys, fresh)):
                raise RuntimeError('a probe key or shortcut modifier remained stuck')
            note('source_and_viewer_keymaps_clear')
            sample_staging('after_fresh_pair')

            wait_observed('completion on the same healthy connection', upload_completed,
                          timeout=args.bytes / UPLINK_BYTES_PER_SECOND + 18)
            landed = require_landed_file()
            sample_staging('completed_original_file', complete=True)
            if file_hash(source) != digest or landed.stat().st_size != args.bytes:
                raise RuntimeError('the original synthetic file changed')
            drain()
            verify_release_sequence(source_edges, old, fresh, (control, super_key))
            close_session(result)
            drain()
            forwarded = verify_release_sequence(source_edges, old, fresh, (control, super_key))
            if keymap_held(host_conn, (*held_keys, fresh)):
                raise RuntimeError('a probe key was still held after clean closure')
            host_end, viewer_end = read(host_log), read(viewer_log)
            if (host_end.count('authenticated session started') != 1
                    or viewer_end.count('connection opened; authenticating and negotiating permissions') != 1
                    or viewer_end.count('sharing 1 file') != 1
                    or viewer_end.count('shared 1 file') != 1
                    or 'restricting clipboard' in viewer_end or 'clipboard restriction confirmed' in viewer_end):
                raise RuntimeError('session, transfer, or clipboard policy changed across ordinary input release')
            result['explicit_release'] = {
                'held_issue_ns': held_issue, 'source_held_ns': target_down['at_ns'],
                'shortcut_issued_ns': chord_ns, 'source_released_ns': target_up['at_ns'],
                'viewer_local_held_key_up_ns': physical_up_ns,
                'shortcut_to_source_key_up_ms': (target_up['at_ns'] - chord_ns) / 1_000_000,
                'source_fresh_key_down_ns': target_fresh_down['at_ns'],
                'source_fresh_key_up_ns': target_fresh_up['at_ns'],
                'partial_bytes_pre_shortcut': before_chord['staged_bytes'],
                'partial_bytes_post_release': after_release['staged_bytes'],
                'source_keymap_cleared_before_viewer_key_up': True,
                'viewer_keyboard_and_pointer_grabs_freed_before_local_key_up': True,
                'fresh_edges_balanced_after_reacquisition': True,
                'source_edge_order_verified': True,
                'forwarded_shortcut_modifiers': forwarded,
                'single_authenticated_session_and_clipboard_offer': True,
                'same_staging_file_and_source_sha256': True,
            }

        trace = {'source_edges': [], 'actions': [], 'staging': []}
        try:
            release_during_upload(trace)
        finally:
            (directory / 'release-trace.json').write_text(json.dumps(trace, indent=2) + '\n')
        windows = []
        for line in read(viewer_log).splitlines():
            if line.startswith('{'):
                report = json.loads(line)
                if report.get('type') == 'jwm_remote_viewer_stats':
                    windows.append({'session_id': report['session_id'],
                                    'window_seconds': report['window_seconds'], 'final': report['final'],
                                    'sender_depth': report['sender_max_sampled_at_dequeue'],
                                    'sender_stages': {name: value for name, value in report['stages'].items()
                                                      if name.startswith('sender_')}})
        if not windows or len({row['session_id'] for row in windows}) != 1:
            raise RuntimeError('viewer sender telemetry missing or shows a replacement session')
        result['sender_telemetry'] = windows
        return result


def terminated(signum, _frame):
    raise KeyboardInterrupt(f'owned benchmark received signal {signum}')


def main():
    signal.signal(signal.SIGTERM, terminated)
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('binary', type=lambda path: Path(path).resolve())
    cli.add_argument('--out', type=lambda path: Path(path).resolve(), required=True)
    cli.add_argument('--profile', choices=(*BULK_KBIT, 'both'), default='both')
    cli.add_argument('--bytes', type=int, default=12 << 20)
    cli.add_argument('--start-bytes', type=int, default=256 << 10)
    cli.add_argument('--idle-samples', type=int, default=6)
    cli.add_argument('--trials', type=int, default=1)
    args = cli.parse_args()
    if not (args.bytes > args.start_bytes >= 32768 and args.idle_samples > 0 and args.trials > 0):
        cli.error('require total bytes > start bytes >= 32768, positive idle samples and positive trials')
    args.out.mkdir(mode=0o700)
    payload = args.out / FILE_NAME
    digest = make_payload(payload, args.bytes)
    profiles = tuple(BULK_KBIT) if args.profile == 'both' else (args.profile,)
    report = {'binary_sha256': file_hash(args.binary), 'runs': [], 'errors': [],
              'instrument': 'owned-viewer XTEST issue to actual target-window X11 event on one monotonic clock',
              'proxy_scope': 'client-to-host user-space TCP transfer only, nominal 1,250,000 bytes/s',
              'clipboard_direction': 'to-host',
              'host_video': 'static owned Xvfb root, 15 FPS capture scheduling, JPEG',
              'scope': 'shaped client-to-host functional diagnostic; no normal-network p95 or physical timing',
              'bulk_policy': {profile: {'rate_kbit_per_second': rate, 'chunk_bytes': budget(rate)[0],
                                        'window_bytes': budget(rate)[1]}
                              for profile, rate in BULK_KBIT.items()},
              'fixture_sha256': {name: file_hash(Path(__file__).resolve().with_name(name))
                                 for name in ('p07-release.py', 'remote-fault-proxy.py', 'test-remote-viewer-e2e.py')}}
    for index in range(args.trials):
        for profile in (profiles if index % 2 == 0 else profiles[::-1]):
            directory = args.out / f'{index + 1}-release-{profile}'
            directory.mkdir(mode=0o700)
            try:
                row = run(args, directory, payload, digest, profile)
            except Exception as error:
                report['errors'].append({'trial': index + 1, 'profile': profile, 'operation': 'release',
                                         'message': repr(error)})
                print(json.dumps(report['errors'][-1]), flush=True)
            else:
                row['trial'] = index + 1
                report['runs'].append(row)
                print(json.dumps({k: v for k, v in row.items()
                                  if not k.endswith('_edges') and k != 'sender_telemetry'}), flush=True)
            (args.out / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
    if report['errors']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
