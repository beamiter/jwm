#!/usr/bin/env python3
"""Exercise good and bad synthetic records without opening an X display."""
from copy import deepcopy
from pathlib import Path
import runpy

source = Path(__file__).with_name('verify-release.py')
module = runpy.run_path(str(source))
X, verify_trial, budget = (module[name] for name in ('X', 'verify_trial', 'BUDGET'))


def sample(profile, forwarded):
    old, fresh, ctrl, sup, escape = 76, 75, 37, 133, 96
    actions = []

    def note(label, at_ms, **fields):
        actions.append(dict(event=label, at_ns=at_ms * 1_000_000, **fields))

    def grabbed(label, at_ms, status):
        note(label, at_ms, keyboard_status=status, pointer_status=status)

    def issue(label, at_ms, kind, detail):
        note(label, at_ms, type=kind, detail=detail)

    grabbed('viewer_grabbed_before_hold', 1, X.AlreadyGrabbed)
    issue('held_key_press', 3, X.KeyPress, old)
    note('held_on_both_displays', 5, host_held=[old], viewer_held=[old])
    issue('shortcut_control_down', 6, X.KeyPress, ctrl)
    issue('shortcut_super_down', 7, X.KeyPress, sup)
    issue('shortcut_escape_down', 12, X.KeyPress, escape)
    note('source_keys_clear_while_viewer_keys_held', 85, host_held=[], viewer_held=[old, ctrl, sup, escape])
    grabbed('viewer_grabs_available_before_local_key_up', 86, X.GrabSuccess)
    for when, code in enumerate((escape, sup, ctrl), 87):
        issue('shortcut_cleanup_up', when, X.KeyRelease, code)
    issue('held_key_local_up', 90, X.KeyRelease, old)
    issue('reacquire_click_down', 300, X.ButtonPress, 1)
    issue('reacquire_click_up', 304, X.ButtonRelease, 1)
    grabbed('viewer_grabbed_after_click', 307, X.AlreadyGrabbed)
    issue('fresh_key_press', 310, X.KeyPress, fresh)
    issue('fresh_key_up', 315, X.KeyRelease, fresh)
    note('source_and_viewer_keymaps_clear', 320)
    staged = [('before_hold', 2, 300000), ('before_release_shortcut', 11, 330000),
              ('after_source_key_up_pre_local_key_up', 84, 390000), ('after_reacquire', 308, 410000),
              ('after_fresh_pair', 330, 450000), ('completed_original_file', 15000, 12582912)]
    trace = {'actions': actions, 'staging': [dict(event=event, at_ns=when * 1_000_000,
             staged_bytes=size, inode=7777, device=12) for event, when, size in staged],
             'keycodes': {'held': old, 'fresh': fresh, 'control': ctrl, 'super': sup, 'escape': escape}}
    source_edges = ([(X.KeyPress, old, 4)] + [(X.KeyPress, code, 8 + i) for i, code in enumerate(forwarded)]
                    + [(X.KeyRelease, code, 80 + i) for i, code in enumerate(reversed(forwarded))]
                    + [(X.KeyRelease, old, 83), (X.ButtonPress, 1, 303), (X.ButtonRelease, 1, 306),
                       (X.KeyPress, fresh, 314), (X.KeyRelease, fresh, 319)])
    trace['source_edges'] = [dict(type=kind, detail=code, at_ns=when * 1_000_000)
                             for kind, code, when in source_edges]
    release = dict(forwarded_shortcut_modifiers=list(forwarded), partial_bytes_pre_shortcut=330000,
                   partial_bytes_post_release=390000, shortcut_to_source_key_up_ms=71.0)
    for key, when in zip(('held_issue_ns', 'source_held_ns', 'shortcut_issued_ns', 'source_released_ns',
                          'viewer_local_held_key_up_ns', 'source_fresh_key_down_ns', 'source_fresh_key_up_ns'),
                         (3, 4, 12, 83, 90, 314, 319)):
        release[key] = when * 1_000_000
    rate = module['PROFILES'][profile]
    chunk, window = budget(rate)
    row = dict(profile=profile, trial=1, explicit_release=release, upload_bytes=12582912,
               configured_rate_kbit_per_second=rate, chunk_bytes=chunk, window_bytes=window,
               uplink_configured_bytes_per_second=1250000, viewer_exit=0, host_exit=0,
               sender_telemetry=[{'session_id': 'synthetic', 'final': True}],
               sha256='synthetic', host_staged_sha256='synthetic', host_clipboard_uri_matches_staged_file=True,
               active_started_bytes=262144)
    viewer_log = 'connection opened; authenticating and negotiating permissions\nsharing 1 file\nshared 1 file\n'
    if rate is not None:
        viewer_log += f'clipboard file/image budget rate={rate} kbit/s chunk={chunk} bytes window={window} bytes\n'
    return row, trace, 'authenticated session started\nclipboard update queued\n', viewer_log


for profile, forwarded in [('default', ()), ('rate-6000', (37,)), ('rate-6000', (133,)), ('default', (37, 133))]:
    assert verify_trial(*sample(profile, forwarded))['shortcut_to_source_key_up_ms'] == 71.0

row, trace, host_log, viewer_log = sample('default', (37, 133))
for mutate in (lambda item: item['source_edges'].append(dict(type=X.KeyRelease, detail=76, at_ns=999_000_000)),
               lambda item: item['source_edges'].pop(3),
               lambda item: item['staging'][2].update(inode=7778),
               lambda item: item['staging'][2].update(staged_bytes=12582912),
               lambda item: module['action_with_label'](item['actions'], 'viewer_grabs_available_before_local_key_up').update(pointer_status=X.AlreadyGrabbed),
               lambda item: module['action_with_label'](item['actions'], 'viewer_grabs_available_before_local_key_up').update(at_ns=99_000_000)):
    broken = deepcopy(trace)
    mutate(broken)
    try:
        verify_trial(row, broken, host_log, viewer_log)
    except (ValueError, RuntimeError):
        continue
    raise AssertionError('offline replay wrongly accepted altered evidence')
print('offline fixture replay accepted 4 valid edge variants and rejected 6 altered records')
