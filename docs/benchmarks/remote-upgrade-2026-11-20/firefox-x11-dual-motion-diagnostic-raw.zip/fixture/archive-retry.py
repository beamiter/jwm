from hashlib import sha256
import json
from math import isclose
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile

from run_baseline import select_telemetry
from score import score_pixels


fixture = Path(__file__).resolve().parent
trial = fixture / 'dual._qlefpn7/trial-01'
evidence = Path('docs/benchmarks/remote-upgrade-2026-11-20')
dimensions = 1920, 1080


def digest(data):
    return sha256(data).hexdigest()


def endpoint(record):
    return {key: record[key] for key in ('role', 'kernel', 'cpu', 'drawable_size', 'clock',
                                         'release_sha256')} | {
        'boot_id_sha256': digest(record['boot_id'].encode()),
    }


def rows(data):
    return [json.loads(line) for line in data.splitlines()]


def verify_phase(source, output, name, role, lane):
    raw = json.loads((source / f'{name}-scope.json').read_text())
    start, end = (raw[f'score_{edge}_monotonic_ns'] for edge in ('start', 'end'))
    assert start - raw['phase_start_monotonic_ns'] == 30_000_000_000
    assert end - start == 60_000_000_000 and raw['observer_end_monotonic_ns'] >= end
    samples = rows((source / f'{name}-pixels.jsonl').read_bytes())
    assert all(row['side'] == lane for row in samples)
    assert all(a['end_monotonic_ns'] <= b['end_monotonic_ns'] for a, b in zip(samples, samples[1:]))
    raster = score_pixels(samples, start, end)
    assert raster == raw['samples'][lane]
    assert raster['valid_and_invalid_sample_reads'] == 5400
    assert raster['invalid_tile_reads'] == raster['invalid_scroll_reads'] == 0
    assert (raster['unique_tile_changes'] > 0) == (name == 'motion')
    telemetry = select_telemetry(output, raw, role, dimensions)
    assert telemetry['window_seconds'] >= 60 and telemetry['frame_scopes_match_requested_jpeg']
    assert len(telemetry['session_ids']) == 1 and telemetry['frame_scopes_observed']
    if 'telemetry' in raw:
        reference = raw['telemetry']
        assert isclose(telemetry['window_seconds'], reference['window_seconds'])
        assert {key: value for key, value in telemetry.items() if key != 'window_seconds'} == {
            key: value for key, value in reference.items() if key != 'window_seconds'
        }
    return {'warmup_seconds': 30, 'observed_seconds': 60,
            'raster': raster, 'telemetry': telemetry}


records = json.loads((trial / 'identity.json').read_text())
identities = {role: endpoint(records[role]) for role in ('host', 'viewer')}
assert identities['viewer'] == endpoint(json.loads((trial / 'viewer/identity.json').read_text()))
assert identities['host']['boot_id_sha256'] != identities['viewer']['boot_id_sha256']
assert all(record['drawable_size'] == list(dimensions) for record in identities.values())
assert b'_enter_buffered_busy' in (trial / 'peer.log').read_bytes()
failures = json.loads((trial.parent / 'outcomes.json').read_text())
assert failures == [{'trial': 1, 'status': 'failed',
                     'error': 'endpoint did not close cleanly: peer=255, host=0'}]
phase_events = rows((trial / 'peer-events.jsonl').read_bytes())
assert [event['event'] for event in phase_events] == [
    'viewer_ready', 'viewer_static_started', 'viewer_static_done',
    'viewer_motion_armed', 'viewer_motion_done', 'viewer_disconnected',
]
assert all(event['run_id'] == records['run_id'] for event in phase_events)
entries = {f'fixture/{name}': (fixture / name).read_bytes()
           for name in ('browser-trial.html', 'dual_browser.py', 'firefox-profile-user.js',
                        'fixture-manifest.json', 'run_baseline.py', 'processes.py', 'score.py')}
entries['fixture/archive-retry.py'] = Path(__file__).read_bytes()
raw = evidence / 'firefox-x11-dual-motion-diagnostic-raw.zip'
with TemporaryDirectory(prefix='jwm-firefox-dual-replay.') as scratch:
    output = Path(scratch)
    phases = {'static': {}, 'motion': {}}
    for role, lane, src in [('host', 'source', trial), ('viewer', 'viewer', trial / 'viewer')]:
        trace = f'{role}-clocked-telemetry.jsonl'
        (output / trace).symlink_to(src / trace)
        for name, scope in phases.items():
            scope[role] = verify_phase(src, output, name, role, lane)
            for kind in ('scope.json', 'pixels.jsonl'):
                filename = f'{name}-{kind}'
                entries[f'trace/{role}/{filename}'] = (src / filename).read_bytes()
            entries[f'trace/{role}/{name}-retained-{role}.jsonl'] = (output / f'{name}-{role}.jsonl').read_bytes()
        for filename in (f'{role}.log', trace):
            entries[f'trace/{role}/{filename}'] = (src / filename).read_bytes()
    for name in ('source-static.ppm', 'source-static-end.ppm', 'source-motion-end.ppm',
                 'failure.log', 'peer.log'):
        entries[f'trace/host/{name}'] = (trial / name).read_bytes()
    for name in ('viewer-static.ppm', 'viewer-motion-end.ppm', 'control-in.jsonl'):
        entries[f'trace/viewer/{name}'] = (trial / 'viewer' / name).read_bytes()
    entries['trace/phase-events.json'] = (json.dumps([
        {'event': event['event'], 'run_id': event['run_id']} for event in phase_events
    ], indent=2) + '\n').encode()
    with ZipFile(raw, 'w', compression=ZIP_DEFLATED) as writer:
        for name, data in entries.items():
            writer.writestr(name, data)
with ZipFile(raw) as reader:
    assert reader.testzip() is None
    assert all(reader.read(name) == data for name, data in entries.items())

sessions = {session for pair in phases.values() for trial_end in pair.values()
            for session in trial_end['telemetry']['session_ids']}
assert len(sessions) == 1
assert all(route.startswith('root/') for route in phases['motion']['host']['telemetry']['routes'])
assert phases['motion']['viewer']['telemetry']['viewer_backends'] == ['x11']
assert phases['motion']['viewer']['telemetry']['routes'] == ['rgb']
source = phases['motion']['host']['raster']
viewer = phases['motion']['viewer']['raster']
assert source['unique_content_fps'] >= 30 and source['scroll_changes_seen'] >= 60
report = {
    'schema_version': 1,
    'scope': 'single 1080p Mint Firefox trial and owned Ubuntu X11 viewer over loopback-only SSH reverse forwarding',
    'status': 'motion_observed_control_harness_exited_after_finish',
    'dimensions': dimensions, 'codec': 'JPEG', 'jpeg_quality': 85,
    'authenticated_session_ids': sorted(sessions),
    'endpoints': identities, 'firefox_application': records['host']['installed_firefox_application'],
    'phases': phases,
    'single_observation_viewer_at_least_27_fps': viewer['unique_content_fps'] >= 27,
    'shutdown': {'host_exited': 0, 'ssh_viewer_harness_exited': 255,
                 'viewer_disconnected_event_received': True,
                 'harness_failure': 'Python daemon control reader held stdin at interpreter shutdown'},
    'archive': {'path': raw.name, 'sha256': digest(raw.read_bytes()),
                'entries': {name: digest(data) for name, data in entries.items()}},
}
(evidence / 'firefox-x11-dual-motion-diagnostic.json').write_text(json.dumps(report, indent=2) + '\n')
print(source['unique_content_fps'], viewer['unique_content_fps'], report['archive']['sha256'])
