#!/usr/bin/env python3
"""Observe autonomous queue expiry with an owned X11 viewer blocked inside libswscale."""
import argparse
from contextlib import ExitStack
import hashlib
import json
import os
from pathlib import Path
import re
import runpy
import select
import socket
import subprocess
import time

from Xlib import X, XK, display


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('binary', type=Path)
    cli.add_argument('--shim', type=Path, required=True)
    cli.add_argument('--repo', type=Path, required=True)
    cli.add_argument('--out', type=Path, required=True)
    cli.add_argument('--expect', choices=('old', 'candidate'), required=True)
    cli.add_argument('--p07', type=Path, default=Path('/tmp/jwm-p07-lab/p07.py'))
    args = cli.parse_args()
    args.out.mkdir(mode=0o700)
    p07 = runpy.run_path(str(args.p07))
    launch = runpy.run_path(str(args.repo / 'scripts/test-remote-viewer-e2e.py'))['launch']
    env = {key: value for key, value in os.environ.items()
           if key not in ('DISPLAY', 'WAYLAND_DISPLAY', 'WAYLAND_SOCKET', 'XAUTHORITY', 'LD_PRELOAD')
           and not key.startswith('JWM_REMOTE_')}
    env.update(XDG_RUNTIME_DIR=str(args.out.resolve()),
               XDG_CACHE_HOME=str((args.out / 'cache').resolve()))
    with ExitStack() as cleanup:
        host_x, host_display = launch()
        cleanup.callback(p07['stop'], host_x)
        viewer_x, viewer_display = launch()
        cleanup.callback(p07['stop'], viewer_x)
        host_x11 = display.Display(host_display)
        cleanup.callback(host_x11.close)
        viewer_x11 = display.Display(viewer_display)
        cleanup.callback(viewer_x11.close)
        for connection in (host_x11, viewer_x11):
            assert connection.has_extension('XTEST')
            connection.change_keyboard_control(auto_repeat_mode=X.AutoRepeatModeOff)
            connection.sync()
        receiver = p07['owned_app'](host_x11, mask=p07['INPUT_MASK'])
        gc = receiver.create_gc(foreground=0xc05020)
        key = args.out / 'key'
        cleanup.callback(key.unlink, missing_ok=True)
        binary = args.binary.resolve()
        subprocess.run([binary, 'keygen', '--output', key], env=env, check=True, timeout=5)

        def start(name, argv, proc_env, *, fds=()):
            path = args.out / f'{name}.log'
            log = cleanup.enter_context(path.open('wb'))
            process = subprocess.Popen([binary, *argv], env=proc_env, stdin=subprocess.DEVNULL,
                                       stdout=log, stderr=subprocess.STDOUT, pass_fds=fds)
            cleanup.callback(p07['stop'], process)
            return process, path

        host, host_log = start(
            'host', ['host', '--display', host_display, '--capture-source', 'root', '--listen',
                     '127.0.0.1:0', '--once', '--allow-h264', '--allow-input', '--max-width', '0',
                     '--fps', '30', '--stats-json', '--key-file', key], env)
        port = p07['wait_for']('private host listener', lambda: re.search(
            r'listening on 127\.0\.0\.1:(\d+)', p07['read'](host_log)), host)[1]
        gate, child_gate = socket.socketpair()
        cleanup.callback(gate.close)
        cleanup.callback(child_gate.close)
        gate.settimeout(3)
        viewer_env = env | {'LD_PRELOAD': str(args.shim.resolve()), 'JWM_REMOTE_READ_AHEAD': '1',
                            'JWM_FIXTURE_DECODER_FD': str(child_gate.fileno())}
        viewer, viewer_log = start(
            'viewer', ['connect', f'127.0.0.1:{port}', '--display', viewer_display, '--window-size',
                       '640x400', '--grab-input', '--scaling', 'cpu', '--key-file', key,
                       '--diagnostics-json', '--stats-json'],
            viewer_env, fds=(child_gate.fileno(),))
        child_gate.close()
        p07['wait_for']('connected viewer', lambda: 'connected;' in p07['read'](viewer_log), host, viewer)
        log = p07['read'](viewer_log)
        assert 'authenticated reader and ordered decoder running independently' in log
        assert 'hardware H.264 decoding active (' in log and 'keyboard + pointer' in log
        window = p07['wait_for']('private viewer window', lambda: p07['viewer_window'](viewer_x11),
                                 host, viewer)
        window.set_input_focus(X.RevertToParent, X.CurrentTime)
        geometry = window.get_geometry()
        p07['inject'](viewer_x11, X.MotionNotify,
                      x=geometry.x + geometry.width // 2, y=geometry.y + geometry.height // 2)
        name_atom = viewer_x11.intern_atom('_NET_WM_NAME')

        def grabbed():
            prop = window.get_full_property(name_atom, X.AnyPropertyType)
            return prop is not None and b'; grabbed -' in bytes(prop.value)

        def wait_edge(kind, code, label, limit_ns, *, while_gated=False, allow_missing=False):
            while time.monotonic_ns() < limit_ns:
                assert viewer.poll() is None, f'{label}: decoder process exited prematurely'
                if not while_gated:
                    assert host.poll() is None, f'{label}: source host exited prematurely'
                observed = list(p07['pending_edges'](host_x11, receiver))
                if observed:
                    assert len(observed) == 1 and observed[0][:2] == (kind, code), (
                        f'{label}: unrelated, duplicate or out-of-order source edge {observed}')
                    if while_gated:
                        assert not select.select([gate], [], [], 0)[0], 'codec gate already ended'
                    return observed[0][2]
                descriptors = [host_x11.fileno(), gate] if while_gated else [host_x11.fileno()]
                ready, _, _ = select.select(descriptors, [], [], .005)
                assert gate not in ready, 'codec gate already ended'
            if allow_missing:
                return None
            raise RuntimeError(f'missing host input edge: {label}')

        click_edges = []
        for typ, label in ((X.ButtonPress, 'grab_click_down'), (X.ButtonRelease, 'grab_click_up')):
            click_at = p07['inject'](viewer_x11, typ, 1)
            seen_at = wait_edge(typ, 1, label, click_at + 2_000_000_000)
            click_edges.append({'event': label, 'button': 1, 'issue_ns': click_at, 'host_seen_ns': seen_at})
            if typ == X.ButtonPress:
                p07['wait_for']('owned click-to-grab', grabbed, host, viewer, timeout=2)
        assert not host_x11.screen().root.query_pointer().mask & X.Button1Mask, 'source click remained held'
        assert not list(p07['pending_edges'](host_x11, receiver)), 'unexpected source edge after grab click'
        preflight = p07['input_schedule'](viewer_x11, host_x11, receiver, 1, lambda: 0)
        (args.out / 'preflight.json').write_text(json.dumps({'mouse': click_edges, 'keyboard': preflight}, indent=2) + '\n')

        gate.sendall(b'A')
        receiver.fill_rectangle(gc, 12, 12, 160, 120)
        host_x11.sync()
        assert gate.recv(1) == b'E', 'viewer never entered gated swscale'
        entered = time.monotonic_ns()
        expected_release = entered + 2_550_000_000
        results = []

        def write_edge(label, issued, when):
            results.append({'edge': label, 'issue_ns': issued, 'host_seen_ns': when,
                            'elapsed_ms': (when - issued) / 1_000_000})

        # A second changed source image is produced only after the prior
        # frame is inside the sequential decoder. The real host is limited
        # to two unsatisfied frame credits.
        gc.change(foreground=0x4489ba)
        receiver.fill_rectangle(gc, 12, 12, 160, 120)
        host_x11.sync()
        second_paint_finished = time.monotonic_ns()
        assert not select.select([gate], [], [], 0)[0], 'decoder did not remain gated'

        def down(connection, code):
            return bool(connection.query_keymap()[code // 8] & (1 << (code % 8)))

        keycode = viewer_x11.keysym_to_keycode(XK.XK_F8)
        assert keycode and keycode == host_x11.keysym_to_keycode(XK.XK_F8)
        arm_held_key_at = entered + 1_650_000_000
        while time.monotonic_ns() < arm_held_key_at:
            remaining = max(0, arm_held_key_at - time.monotonic_ns()) / 1e9
            assert not select.select([gate], [], [], min(.025, remaining))[0], 'decoder gate ended early'
            assert host.poll() is None and viewer.poll() is None
        physical = p07['inject'](viewer_x11, X.KeyPress, keycode)
        physical_up = None
        try:
            down_seen = wait_edge(X.KeyPress, keycode, 'held_down', physical + 200_000_000, while_gated=True)
            write_edge('held_down', physical, down_seen)
            assert down(host_x11, keycode) and down(viewer_x11, keycode)
            observe_until = down_seen + 590_000_000
            released = wait_edge(X.KeyRelease, keycode, 'release_on_queue_expiry', observe_until,
                                 while_gated=True, allow_missing=args.expect == 'old')
            keymap = {'source_down': down(host_x11, keycode), 'viewer_down': down(viewer_x11, keycode)}
            keymap_sample = time.monotonic_ns()
            root = viewer_x11.screen().root
            keyboard_grab = root.grab_keyboard(False, X.GrabModeAsync, X.GrabModeAsync, X.CurrentTime)
            if keyboard_grab == X.GrabSuccess:
                viewer_x11.ungrab_keyboard(X.CurrentTime)
            pointer_grab = root.grab_pointer(False, X.PointerMotionMask, X.GrabModeAsync,
                                             X.GrabModeAsync, X.NONE, X.NONE, X.CurrentTime)
            if pointer_grab == X.GrabSuccess:
                viewer_x11.ungrab_pointer(X.CurrentTime)
            viewer_x11.sync()
            grab_sample = time.monotonic_ns()
            assert not select.select([gate], [], [], 0)[0], 'decoder exited before local grab check'
            assert viewer.poll() is None
            if args.expect == 'candidate':
                assert released - entered > 1_800_000_000
                assert keymap == {'source_down': False, 'viewer_down': True}, keymap
                assert (keyboard_grab, pointer_grab) == (X.GrabSuccess, X.GrabSuccess), (keyboard_grab, pointer_grab)
                write_edge('release_on_queue_expiry', physical, released)
            else:
                assert released is None and keymap == {'source_down': True, 'viewer_down': True}, keymap
                assert keymap_sample >= entered + 2_200_000_000
                assert (keyboard_grab, pointer_grab) == (X.AlreadyGrabbed, X.AlreadyGrabbed), (keyboard_grab, pointer_grab)
                physical_up = p07['inject'](viewer_x11, X.KeyRelease, keycode)
                remote_up = wait_edge(X.KeyRelease, keycode, 'explicit_control_release',
                                      physical_up + 180_000_000, while_gated=True)
                write_edge('explicit_control_release', physical_up, remote_up)
                assert not down(host_x11, keycode) and not down(viewer_x11, keycode)
                assert remote_up < expected_release, 'controlled keyup exceeded hold deadline'
            snapshot = {'arm': args.expect, 'codec': 'H.264', 'gate_entered_ns': entered,
                        'source_repaint_while_gated_ns': second_paint_finished,
                        'expected_gate_release_ns': expected_release,
                        'observed_until_ns': keymap_sample, 'keymap_while_gate_held': keymap,
                        'grab_query_ns': grab_sample,
                        'independent_keyboard_grab_status': keyboard_grab,
                        'independent_pointer_grab_status': pointer_grab,
                        'physical_release_ns': physical_up, 'initial_mouse': click_edges,
                        'initial_input': preflight, 'edges': results}
            (args.out / 'during-gate.json').write_text(json.dumps(snapshot, indent=2) + '\n')
            while time.monotonic_ns() < expected_release:
                remaining = (expected_release - time.monotonic_ns()) / 1e9
                assert not select.select([gate], [], [], max(0, min(.025, remaining)))[0], 'decoder gate ended early'
        finally:
            if physical_up is None:
                physical_up = p07['inject'](viewer_x11, X.KeyRelease, keycode)
                viewer_x11.sync()
            try:
                gate.sendall(b'R')
            except BrokenPipeError:
                pass
        assert gate.recv(1) == b'L', 'libswscale gate was not released by the fixture'
        gate_released = time.monotonic_ns()
        assert 0 <= gate_released - expected_release <= 75_000_000, 'matched fixture hold outside scheduling tolerance'
        assert viewer.wait(timeout=5) == 1
        viewer_exited = time.monotonic_ns()
        host_status = host.wait(timeout=5)
        assert host_status >= 0, 'owned host needed forced termination'
        assert not down(host_x11, keycode)

        def records(path, kind):
            rows = [json.loads(line) for line in p07['read'](path).splitlines() if line.startswith('{')]
            return [row for row in rows if row.get('type') == kind]

        viewers = records(viewer_log, 'jwm_remote_viewer_stats')
        hosts = records(host_log, 'jwm_remote_host_stats')
        sessions = {row['session_id'] for row in viewers}
        assert len(sessions) == 1 and sessions == {row['session_id'] for row in hosts}
        assert any(row.get('max_outstanding') == 2 for row in hosts), 'host never observed both frame credits in use'
        assert 'with input held; releasing keys and buttons' not in p07['read'](host_log)
        assert 'authenticated remote decode queue exceeded its age limit' in p07['read'](viewer_log)
        [diagnostic] = records(viewer_log, 'jwm_remote_command_result')
        assert diagnostic['outcome'] == 'error' and diagnostic['stage'] == 'session', diagnostic
        assert diagnostic['category'] == 'io' and diagnostic['io_kind'] == 'timed_out', diagnostic
        assert not diagnostic['reconnect_certified'], diagnostic
        with binary.open('rb') as stream:
            binary_digest = hashlib.file_digest(stream, 'sha256').hexdigest()

        report = snapshot | {'session_id': sessions.pop(), 'gate_released_ns': gate_released,
                             'viewer_exited_ns': viewer_exited, 'host_exit_status': host_status,
                             'viewer_exit_status': viewer.returncode, 'viewer_diagnostic': diagnostic,
                             'binary_sha256': binary_digest,
                             'host_max_outstanding': max(row.get('max_outstanding', 0) for row in hosts),
                             'viewer_read_ahead_queue_limit_seconds': 2,
                             'physical_release_ns': physical_up}
        (args.out / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
        print(json.dumps(report))


if __name__ == '__main__':
    main()
