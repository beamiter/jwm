"""Replay saved paired queue-expiry ownership and shutdown evidence using Python's standard library."""
import json
from pathlib import Path
import sys


PINS = {
    'old': '5e1951ed8bbc23f41db5b5918931d91a37baa1e9fa213c8ef9067a214a1511e5',
    'candidate': '34d05abf098d238f3fd4fdaf6c1e875c0516ec312ea67de5011ca8c3ad68c86b',
}
CONTROL_NS = 2_550_000_000
HOLD_TOLERANCE_NS = 75_000_000
HOST_WATCHDOG_NS = 600_000_000
QUEUE_TIMEOUT = 'authenticated remote decode queue exceeded its age limit'
STATS_ROLE = {'host': ('last_sent_frame', 'drawn_acks'), 'viewer': ('last_frame', 'acked')}


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def selected(log, kind):
    return [row for line in log.splitlines() if line.startswith('{')
            for row in (json.loads(line),) if row.get('type') == kind]


def verify_stats(directory, session, expected_diagnostic):
    host, viewer = [(directory / f'{who}.log').read_text() for who in STATS_ROLE]
    require('hardware H.264 encoding active (NVENC)' in host
            and host.count('authenticated session started (screen + pointer + keyboard)') == 1
            and 'with input held; releasing keys and buttons' not in host, 'host path or watchdog mismatch')
    require('authenticated reader and ordered decoder running independently' in viewer
            and 'H.264 hardware decoder active (VAAPI)' in viewer and QUEUE_TIMEOUT in viewer,
            'viewer missed the hardware-decode, read-ahead or queue timeout witness')
    diagnostic, = selected(viewer, 'jwm_remote_command_result')
    require(diagnostic == expected_diagnostic
            and (diagnostic['outcome'], diagnostic['stage'], diagnostic['category'], diagnostic['io_kind'])
            == ('error', 'session', 'io', 'timed_out') and not diagnostic['reconnect_certified'],
            'timeout did not preserve the diagnostic or was certified for reconnect')

    routes = {}
    for who, log in (('host', host), ('viewer', viewer)):
        rows = selected(log, f'jwm_remote_{who}_stats')
        frame_field, ack = STATS_ROLE[who]
        row = rows[-1]
        frames = [item[frame_field] for item in rows if item.get(frame_field)]
        require(rows and {item['session_id'] for item in rows} == {session}
                and frames and sum(item[ack] for item in rows) > 0, 'session or presented frame scope missing')
        require(all(frame['codec'] == 'H.264' and frame['source_dimensions'] == [1280, 800]
                    and frame['encoded_dimensions'] == [640, 400]
                    and frame['source_epoch'] == 1 and frame['geometry_epoch'] == 2 for frame in frames),
                'unexpected frame route, dimensions or scope')
        if who == 'host':
            require(max(item['max_outstanding'] for item in rows) == 2 and row['outstanding'] == 2,
                    'host did not report both frame credits outstanding')
            require('failed to fill whole buffer' in log and row['mode'] == 'root/xrender/shm/no-damage/cursor-events',
                    'host capture or terminal transport different from the pair')
            routes['host'] = row['mode']
        else:
            require(row['final'] and row['viewer_backend'] == 'x11' and row['last_presentation_path'] == 'rgb',
                    'viewer did not report final X11 RGB scope')
            routes['viewer'] = 'x11/rgb'
    return routes


def verify_preflight(path, arm):
    preflight = read(path / 'preflight.json')
    mouse, keys = preflight['mouse'], preflight['keyboard']
    require(mouse == arm['initial_mouse'] and keys == arm['initial_input']
            and [edge['event'] for edge in mouse] == ['grab_click_down', 'grab_click_up']
            and [edge['button'] for edge in mouse] == [1, 1]
            and [edge['type'] for edge in keys] == ['press', 'release']
            and keys[0]['keycode'] == keys[1]['keycode'], 'mouse or keyboard preflight changed')
    require(mouse[0]['issue_ns'] <= mouse[0]['host_seen_ns'] < mouse[1]['issue_ns']
            <= mouse[1]['host_seen_ns'] < keys[0]['issue_ns'] <= keys[0]['received_ns'] < keys[1]['issue_ns']
            <= keys[1]['received_ns'] < arm['gate_entered_ns'], 'mouse/keyboard preflight was not source-ordered')


def verify_arm(folder, label):
    arm = read(folder / 'result.json')
    held = read(folder / 'during-gate.json')
    require(all(key == 'physical_release_ns' or arm.get(key) == value for key, value in held.items()),
            'held-gate witness changed at shutdown')
    require(arm['arm'] == label and arm['codec'] == 'H.264' and arm['binary_sha256'] == PINS[label],
            'arm label, binary pin or codec differs')
    verify_preflight(folder, arm)
    first, second = arm['edges']
    start, end = arm['gate_entered_ns'], arm['gate_released_ns']
    observed, grabs, physical = (arm[key] for key in ('observed_until_ns', 'grab_query_ns', 'physical_release_ns'))
    require(arm['expected_gate_release_ns'] - start == CONTROL_NS
            and 0 <= end - start - CONTROL_NS <= HOLD_TOLERANCE_NS, 'actual gate hold was outside test scheduling tolerance')
    require(start < arm['source_repaint_while_gated_ns'] < first['issue_ns'] <= first['host_seen_ns']
            < observed <= grabs < end < arm['viewer_exited_ns'] and first['edge'] == 'held_down',
            'gate activity and cleanup observation times are inconsistent')
    require(arm['host_exit_status'] == arm['viewer_exit_status'] == 1
            and arm['host_max_outstanding'] == arm['viewer_read_ahead_queue_limit_seconds'] == 2,
            'unexpected endpoint fault outcome or granted credit/queue age')
    route = verify_stats(folder, arm['session_id'], arm['viewer_diagnostic'])
    statuses = arm['independent_keyboard_grab_status'], arm['independent_pointer_grab_status']
    if label == 'old':
        require(arm['keymap_while_gate_held'] == {'source_down': True, 'viewer_down': True}
                and statuses == (1, 1) and observed - start >= 2_200_000_000
                and second['edge'] == 'explicit_control_release'
                and grabs <= physical == second['issue_ns'] <= second['host_seen_ns'] < end,
                'old control did not retain authority until explicit release')
    else:
        require(arm['keymap_while_gate_held'] == {'source_down': False, 'viewer_down': True}
                and statuses == (0, 0) and second['edge'] == 'release_on_queue_expiry'
                and first['host_seen_ns'] < second['host_seen_ns'] <= observed <= grabs < physical < end
                and second['host_seen_ns'] - first['host_seen_ns'] < HOST_WATCHDOG_NS
                and held['physical_release_ns'] is None, 'candidate did not autonomously revoke before gate and watchdog')
    return {
        'arm': label, 'binary_sha256': arm['binary_sha256'], 'session_id': arm['session_id'],
        'actual_routes': route, 'actual_gate_hold_ms': (end - start) / 1e6,
        'observed_keymap_at_gate_offset_ms': (observed - start) / 1e6,
        'keymap_while_held': arm['keymap_while_gate_held'],
        'independent_keyboard_grab': 'success' if statuses[0] == 0 else 'already_grabbed',
        'independent_pointer_grab': 'success' if statuses[1] == 0 else 'already_grabbed',
        'grab_query_at_gate_offset_ms': (grabs - start) / 1e6,
        'source_key_up_at_gate_offset_ms': (second['host_seen_ns'] - start) / 1e6,
        'source_key_down_to_up_ms': (second['host_seen_ns'] - first['host_seen_ns']) / 1e6,
        'source_release': second['edge'], 'host_max_outstanding': arm['host_max_outstanding'],
        'viewer_exit_status': arm['viewer_exit_status'], 'host_exit_status': arm['host_exit_status'],
        'viewer_diagnostic': arm['viewer_diagnostic'],
    }


def replay(batch):
    require((batch / 'outcomes.tsv').read_text().splitlines() == ['old\t0', 'candidate\t0'],
            'paired controller outcomes absent or failed')
    arms = [verify_arm(batch / name, name) for name in PINS]
    require(arms[0]['session_id'] != arms[1]['session_id'], 'the two runs reused a session identity')
    spread = abs(arms[0]['actual_gate_hold_ms'] - arms[1]['actual_gate_hold_ms'])
    require(spread <= HOLD_TOLERANCE_NS / 1e6, 'pair did not hold the same scheduled duration')
    return {'fixture_status': 'pass', 'same_scheduled_hold_ms': CONTROL_NS / 1e6,
            'gate_hold_difference_ms': spread, 'arms': arms}


if __name__ == '__main__':
    folder = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent
    print(json.dumps(replay(folder), indent=2))
