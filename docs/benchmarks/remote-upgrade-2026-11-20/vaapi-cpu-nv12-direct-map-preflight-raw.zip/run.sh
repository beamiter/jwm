#!/usr/bin/env bash
set -euo pipefail
umask 077
base=$(cd "$(dirname "$0")" && pwd)
if [[ $# -lt 3 || $# -gt 4 || ( $# == 4 && "$4" != --map-first ) ]]; then
    printf '%s\n' 'Usage: bash run.sh FFMPEG_INCLUDE_DIR FFMPEG_LIB_DIR RENDER_NODE [--map-first]' >&2
    exit 2
fi
include=$1
lib=$2
node=$3
shift 3
pin=a8abec1aeb52fdd973e60b11704f6cbf58cf88ed85b026d1a780b44cb7f724d4
packet="$base/native-video-probe.h264"
[[ "$(sha256sum "$packet" | cut -d' ' -f1)" == "$pin" ]] || {
    printf '%s\n' 'Unexpected H.264 packet digest' >&2
    exit 2
}
if [[ -n ${JWM_VAAPI_PROBE_LOCK:-} ]]; then
    exec 9>>"$JWM_VAAPI_PROBE_LOCK"
    flock -x 9
fi
build=$(mktemp -d)
trap 'rm -f -- "$build/preflight"; rmdir -- "$build"' EXIT
cc -std=c11 -O2 -Wall -Wextra -Werror -I "$include" "$base/preflight.c" \
    -L "$lib" -Wl,-rpath-link,"$lib" -lavcodec -lavutil -lswscale -o "$build/preflight"
LD_LIBRARY_PATH="$lib" timeout --signal=TERM --kill-after=2s 20s \
    "$build/preflight" "$node" "$packet" "$@"
