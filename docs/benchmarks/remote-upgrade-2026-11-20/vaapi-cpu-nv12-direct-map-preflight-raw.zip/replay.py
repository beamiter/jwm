#!/usr/bin/env python3
"""Recheck completed VA-API result records without opening a GPU or decoding."""

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
EXPECTED = {
    'status': 'pass',
    'decoder': 'h264/vaapi',
    'map': 'cpu-nv12-read-direct',
    'decoded_size': [256, 256],
    'tested_crop': [251, 247],
    'nv12_active_bytes_equal': 256 * 256 * 3 // 2,
    'rgb_full_bytes_equal': 256 * 256 * 3,
    'rgb_crop_bytes_equal': 251 * 247 * 3,
    'mapped_strides': [256, 256],
    'downloaded_strides': [256, 256],
    'surface_colorspace': 2,
    'surface_color_range': 0,
    'performance_measured': False,
}
PACKET_SHA = 'a8abec1aeb52fdd973e60b11704f6cbf58cf88ed85b026d1a780b44cb7f724d4'
ABI = {'libavcodec': ('60.31.102', 'libavcodec.so.60'),
       'libavutil': ('58.29.100', 'libavutil.so.58'),
       'libswscale': ('7.5.100', 'libswscale.so.7')}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def verify(root):
    provenance = json.loads((root / 'provenance.json').read_bytes())
    packet = (root / 'native-video-probe.h264').read_bytes()
    require(len(packet) == 384 and digest(packet) == PACKET_SHA == provenance['packet']['sha256'],
            'pinned H.264 fixture mismatch')
    require(digest((root / 'preflight.c').read_bytes()) == provenance['source_sha256'],
            'the C source does not match the executed probe provenance')
    require(provenance['device']['pci_vendor'] == '0x8086' and provenance['device']['pci_device'] == '0x7d67'
            and provenance['device']['kernel_driver'] == 'i915', 'unexpected recorded Intel device')
    for name, (version, soname) in ABI.items():
        library = provenance['ffmpeg']['libraries'][name]
        require((library['version'], library['soname']) == (version, soname)
                and soname in provenance['executable_dynamic_dependencies'], f'ABI mismatch for {name}')
    results = []
    for name, order in (('transfer-first', 'download-first'), ('map-first', 'map-first')):
        completed = (root / 'raw' / f'{name}.exit').read_bytes()
        require(completed == b'0\n', f'{name} did not exit successfully')
        raw = (root / 'raw' / f'{name}.log').read_bytes()
        require(len(raw.splitlines()) == 1, f'{name} did not record one probe result')
        result = json.loads(raw)
        require(result == (EXPECTED | {'order': order}), f'{name} has unexpectedly different measured results')
        results.append({'order': order, 'exit_code': 0, 'result': result, 'raw_stdout_sha256': digest(raw)})
    return {'status': 'verified', 'provenance': provenance, 'runs': results, 'performance_measured': False}


if __name__ == '__main__':
    print(json.dumps(verify(ROOT), indent=2, sort_keys=True))
