/* Hardware H.264 VA-API CPU mapping correctness probe using one pinned IDR. */
#include <errno.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include <libavcodec/avcodec.h>
#include <libavcodec/version.h>
#include <libavutil/error.h>
#include <libavutil/frame.h>
#include <libavutil/hwcontext.h>
#include <libavutil/version.h>
#include <libswscale/swscale.h>
#include <libswscale/version.h>

#define WIDTH 256
#define HEIGHT 256
#define CROP_WIDTH 251
#define CROP_HEIGHT 247
#define PACKET_SIZE 384

enum ExitCode {
    SETUP_FAILED = 2,
    HARDWARE_DECODE_FAILED = 3,
    DIRECT_MAP_UNAVAILABLE = 4,
    CONTENT_CHECK_FAILED = 5,
};

static void report_error(const char *where, int error)
{
    char message[AV_ERROR_MAX_STRING_SIZE];
    if (av_strerror(error, message, sizeof(message)) < 0)
        snprintf(message, sizeof(message), "FFmpeg error %d", error);
    fprintf(stderr, "%s: %s (%d)\n", where, message, error);
}

static enum AVPixelFormat choose_vaapi(AVCodecContext *context,
                                       const enum AVPixelFormat *formats)
{
    (void)context;
    for (; *formats != AV_PIX_FMT_NONE; ++formats)
        if (*formats == AV_PIX_FMT_VAAPI)
            return *formats;
    return AV_PIX_FMT_NONE;
}

static bool has_vaapi(const AVCodec *codec)
{
    if (!codec)
        return false;
    for (int index = 0;; ++index) {
        const AVCodecHWConfig *config = avcodec_get_hw_config(codec, index);
        if (!config)
            return false;
        if (config->device_type == AV_HWDEVICE_TYPE_VAAPI &&
            config->pix_fmt == AV_PIX_FMT_VAAPI &&
            (config->methods & AV_CODEC_HW_CONFIG_METHOD_HW_DEVICE_CTX))
            return true;
    }
}

static int read_packet(AVPacket *packet, const char *path)
{
    FILE *source = fopen(path, "rb");
    if (!source)
        return AVERROR(errno);
    int result = av_new_packet(packet, PACKET_SIZE);
    if (result == 0 && (fread(packet->data, 1, PACKET_SIZE, source) != PACKET_SIZE ||
                        fgetc(source) != EOF || ferror(source)))
        result = AVERROR_INVALIDDATA;
    fclose(source);
    return result;
}

static void set_frame_layout(AVFrame *frame, enum AVPixelFormat format)
{
    frame->format = format;
    frame->width = WIDTH;
    frame->height = HEIGHT;
}

static bool valid_nv12(const AVFrame *frame)
{
    return frame->format == AV_PIX_FMT_NV12 && frame->width == WIDTH &&
           frame->height == HEIGHT && frame->data[0] && frame->data[1] &&
           frame->linesize[0] >= WIDTH && frame->linesize[1] >= WIDTH;
}

static int copy_active_nv12(AVFrame *destination, const AVFrame *source)
{
    if (!valid_nv12(source))
        return AVERROR_INVALIDDATA;
    set_frame_layout(destination, AV_PIX_FMT_NV12);
    int result = av_frame_get_buffer(destination, 32);
    if (result < 0)
        return result;
    for (int plane = 0; plane < AV_NUM_DATA_POINTERS; ++plane)
        if (destination->buf[plane])
            memset(destination->buf[plane]->data, 0, destination->buf[plane]->size);
    for (int plane = 0; plane < 2; ++plane) {
        int rows = plane == 0 ? HEIGHT : HEIGHT / 2;
        for (int y = 0; y < rows; ++y)
            memcpy(destination->data[plane] + (size_t)y * destination->linesize[plane],
                   source->data[plane] + (size_t)y * source->linesize[plane], WIDTH);
    }
    return 0;
}

static int compare_rows(const AVFrame *a, const AVFrame *b, int plane,
                        int width_bytes, int rows, const char *label)
{
    for (int y = 0; y < rows; ++y) {
        const uint8_t *pa = a->data[plane] + (size_t)y * a->linesize[plane];
        const uint8_t *pb = b->data[plane] + (size_t)y * b->linesize[plane];
        if (memcmp(pa, pb, (size_t)width_bytes) == 0)
            continue;
        for (int x = 0; x < width_bytes; ++x) {
            if (pa[x] == pb[x])
                continue;
            fprintf(stderr, "%s differs at row %d byte %d: %u vs %u\n",
                    label, y, x, (unsigned)pa[x], (unsigned)pb[x]);
            return AVERROR_INVALIDDATA;
        }
    }
    return 0;
}

static int color_matrix(enum AVColorSpace color)
{
    switch (color) {
    case AVCOL_SPC_BT709: return SWS_CS_ITU709;
    case AVCOL_SPC_FCC: return SWS_CS_FCC;
    case AVCOL_SPC_SMPTE240M: return SWS_CS_SMPTE240M;
    case AVCOL_SPC_BT2020_NCL: return SWS_CS_BT2020;
    default: return SWS_CS_DEFAULT;
    }
}

static int convert_rgb(const AVFrame *nv12, const AVFrame *surface, AVFrame *output)
{
    set_frame_layout(output, AV_PIX_FMT_RGB24);
    int result = av_frame_get_buffer(output, 32);
    if (result < 0)
        return result;
    struct SwsContext *scale = sws_getContext(WIDTH, HEIGHT, AV_PIX_FMT_NV12,
        WIDTH, HEIGHT, AV_PIX_FMT_RGB24, SWS_FAST_BILINEAR, NULL, NULL, NULL);
    if (!scale)
        return AVERROR(ENOMEM);
    const int *coefficients = sws_getCoefficients(color_matrix(surface->colorspace));
    if (!coefficients) {
        sws_freeContext(scale);
        return AVERROR_INVALIDDATA;
    }
    result = sws_setColorspaceDetails(scale, coefficients, surface->color_range == AVCOL_RANGE_JPEG,
                                     coefficients, 1, 0, 1 << 16, 1 << 16);
    if (result >= 0) {
        const uint8_t *planes[4] = {nv12->data[0], nv12->data[1], NULL, NULL};
        result = sws_scale(scale, planes, nv12->linesize, 0, HEIGHT, output->data, output->linesize);
        if (result >= 0 && result != HEIGHT)
            result = AVERROR_INVALIDDATA;
    }
    sws_freeContext(scale);
    return result < 0 ? result : 0;
}

static int map_snapshot(const AVFrame *surface, AVFrame *snapshot, int strides[2])
{
    AVFrame *mapped = av_frame_alloc();
    if (!mapped) {
        report_error("allocating direct map target", AVERROR(ENOMEM));
        return DIRECT_MAP_UNAVAILABLE;
    }
    mapped->format = AV_PIX_FMT_NV12;
    int result = av_hwframe_map(mapped, surface, AV_HWFRAME_MAP_READ | AV_HWFRAME_MAP_DIRECT);
    if (result < 0) {
        report_error("direct CPU NV12 mapping unavailable on this VA-API device", result);
        av_frame_free(&mapped);
        return DIRECT_MAP_UNAVAILABLE;
    }
    if (!valid_nv12(mapped)) {
        fputs("direct mapping did not return the expected CPU NV12 frame and plane strides\n", stderr);
        av_frame_free(&mapped);
        return DIRECT_MAP_UNAVAILABLE;
    }
    strides[0] = mapped->linesize[0];
    strides[1] = mapped->linesize[1];
    /* Keep only active bytes, then unmap before a second access to the same
     * driver surface. This correctness probe never passes unknown mapped
     * padding to libswscale's potentially overreading SIMD kernels. */
    result = copy_active_nv12(snapshot, mapped);
    av_frame_free(&mapped);
    if (result < 0) {
        report_error("copying active rows from mapped frame", result);
        return CONTENT_CHECK_FAILED;
    }
    return 0;
}

int main(int argc, char **argv)
{
    bool map_first = argc == 4 && strcmp(argv[3], "--map-first") == 0;
    if (argc != 3 && !map_first) {
        fprintf(stderr, "usage: %s DEVICE PINNED_PACKET [--map-first]\n", argv[0]);
        return SETUP_FAILED;
    }
    if (avcodec_version() != LIBAVCODEC_VERSION_INT || avutil_version() != LIBAVUTIL_VERSION_INT ||
        swscale_version() != LIBSWSCALE_VERSION_INT) {
        fputs("FFmpeg header/runtime version mismatch\n", stderr);
        return SETUP_FAILED;
    }
    int result = 0;
    int status = SETUP_FAILED;
    int strides[2] = {0, 0};
    AVCodecContext *context = NULL;
    AVPacket *packet = av_packet_alloc();
    AVFrame *surface = av_frame_alloc();
    AVFrame *extra = av_frame_alloc();
    AVFrame *download = av_frame_alloc();
    AVFrame *aligned_download = av_frame_alloc();
    AVFrame *aligned_map = av_frame_alloc();
    AVFrame *rgb_download = av_frame_alloc();
    AVFrame *rgb_map = av_frame_alloc();
    if (!(packet && surface && extra && download && aligned_download && aligned_map &&
          rgb_download && rgb_map)) {
        report_error("allocating probe frames", AVERROR(ENOMEM));
        goto done;
    }
    result = read_packet(packet, argv[2]);
    if (result < 0) {
        report_error("reading pinned Annex B H.264 packet", result);
        goto done;
    }
    status = HARDWARE_DECODE_FAILED;
    const AVCodec *codec = avcodec_find_decoder(AV_CODEC_ID_H264);
    if (!has_vaapi(codec)) {
        fputs("FFmpeg H.264 decoder has no VA-API device mode\n", stderr);
        goto done;
    }
    context = avcodec_alloc_context3(codec);
    if (!context) {
        report_error("allocating H.264 decoder", AVERROR(ENOMEM));
        goto done;
    }
    context->get_format = choose_vaapi;
    context->flags |= AV_CODEC_FLAG_LOW_DELAY;
    context->err_recognition = AV_EF_EXPLODE;
    context->thread_count = 1;
    context->max_pixels = WIDTH * HEIGHT;
    context->width = WIDTH;
    context->height = HEIGHT;
    result = av_hwdevice_ctx_create(&context->hw_device_ctx, AV_HWDEVICE_TYPE_VAAPI, argv[1], NULL, 0);
    if (result < 0) {
        report_error("opening the requested VA-API render node", result);
        goto done;
    }
    if ((result = avcodec_open2(context, codec, NULL)) < 0 ||
        (result = avcodec_send_packet(context, packet)) < 0 ||
        (result = avcodec_receive_frame(context, surface)) < 0) {
        report_error("decoding the pinned H.264 packet on VA-API", result);
        goto done;
    }
    if (surface->format != AV_PIX_FMT_VAAPI || !surface->hw_frames_ctx ||
        surface->width != WIDTH || surface->height != HEIGHT || !(surface->flags & AV_FRAME_FLAG_KEY) ||
        avcodec_receive_frame(context, extra) != AVERROR(EAGAIN)) {
        fputs("expected one 256x256 VA-API hardware keyframe and no queued second frame\n", stderr);
        goto done;
    }
    if (map_first && (status = map_snapshot(surface, aligned_map, strides)) != 0)
        goto done;
    status = HARDWARE_DECODE_FAILED;
    download->format = AV_PIX_FMT_NV12;
    result = av_hwframe_transfer_data(download, surface, 0);
    if (result < 0) {
        report_error("baseline VA-API NV12 download unavailable", result);
        goto done;
    }
    if (!valid_nv12(download)) {
        fputs("baseline download did not return valid 256x256 NV12 planes\n", stderr);
        goto done;
    }
    if (!map_first && (status = map_snapshot(surface, aligned_map, strides)) != 0)
        goto done;
    status = CONTENT_CHECK_FAILED;
    if (compare_rows(download, aligned_map, 0, WIDTH, HEIGHT, "active NV12 Y") < 0 ||
        compare_rows(download, aligned_map, 1, WIDTH, HEIGHT / 2, "active NV12 UV") < 0)
        goto done;
    if ((result = copy_active_nv12(aligned_download, download)) < 0 ||
        (result = convert_rgb(aligned_download, surface, rgb_download)) < 0 ||
        (result = convert_rgb(aligned_map, surface, rgb_map)) < 0) {
        report_error("producing RGB24 with the original surface's color metadata", result);
        goto done;
    }
    if (compare_rows(rgb_download, rgb_map, 0, WIDTH * 3, HEIGHT, "full visible RGB24") < 0 ||
        compare_rows(rgb_download, rgb_map, 0, CROP_WIDTH * 3, CROP_HEIGHT, "odd visible RGB24 crop") < 0)
        goto done;
    printf("{\"status\":\"pass\",\"decoder\":\"h264/vaapi\",\"map\":\"cpu-nv12-read-direct\","
           "\"order\":\"%s\",\"decoded_size\":[%d,%d],\"tested_crop\":[%d,%d],"
           "\"nv12_active_bytes_equal\":%d,\"rgb_full_bytes_equal\":%d,\"rgb_crop_bytes_equal\":%d,"
           "\"mapped_strides\":[%d,%d],\"downloaded_strides\":[%d,%d],"
           "\"surface_colorspace\":%d,\"surface_color_range\":%d,\"performance_measured\":false}\n",
           map_first ? "map-first" : "download-first", WIDTH, HEIGHT, CROP_WIDTH, CROP_HEIGHT,
           WIDTH * HEIGHT * 3 / 2, WIDTH * HEIGHT * 3, CROP_WIDTH * CROP_HEIGHT * 3,
           strides[0], strides[1], download->linesize[0], download->linesize[1],
           surface->colorspace, surface->color_range);
    status = 0;

done:
    av_frame_free(&rgb_map);
    av_frame_free(&rgb_download);
    av_frame_free(&aligned_map);
    av_frame_free(&aligned_download);
    av_frame_free(&download);
    av_frame_free(&extra);
    av_frame_free(&surface);
    av_packet_free(&packet);
    avcodec_free_context(&context);
    return status;
}
