# VA-API CPU NV12 direct-map preflight

The two completed runs decoded the pinned 384-byte H.264 IDR on the same Intel
VA-API device. Within each run, ordinary transfer and read-only direct map read
the same decoded surface. One run transferred first and one mapped first.

After extracting the archive, run `python3 -B replay.py` for offline evidence
validation. This reads only the retained result and provenance files. Both
orders reported equality of all 98,304 active NV12 bytes, all 196,608 full
RGB24 bytes, and all 185,991 visible RGB24 bytes in the 251×247 crop. Both
planes used a 256-byte stride on each path.

For an optional new hardware run, supply the FFmpeg headers, matching shared
libraries and render node explicitly. Set `JWM_VAAPI_PROBE_LOCK` to the lab's
existing lock file when applicable.

```sh
bash run.sh "$FFMPEG_INCLUDE_DIR" "$FFMPEG_LIB_DIR" /dev/dri/renderD128
bash run.sh "$FFMPEG_INCLUDE_DIR" "$FFMPEG_LIB_DIR" /dev/dri/renderD128 --map-first
```

The C probe rejects header/runtime version mismatches and distinguishes an
unsupported direct map with status 4. The replay needs Python's standard
library only. The optional live launcher needs a C compiler, the supplied
FFmpeg development files, and access to a VA-API render device.

The aligned RGB comparison does not call libswscale on mapped storage. The odd
crop is from the 256×256 picture. Same-surface access can pay hardware
synchronization and warm the surface for the second path, so these runs do not
measure performance or validate 4K. The recorded PCI device details are a
read-only sysfs snapshot after the two runs.
