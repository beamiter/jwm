# Slow decoder and input teardown on private X11

This fixture is staged and unexecuted. It uses the release viewer with read-ahead
enabled and holds one real H.264 RGB conversion in the decoder thread. It uses
the existing Xvfb launcher and the P07 actual XTEST and target input observer.
The codec gate lives in a private viewer-only loader shim. Production code
and protocol are unchanged.

Run after the shared timing work releases the local machine. Use a current
hardware-enabled release binary with NVENC host encode and H.264 hardware
decode on this machine. If the installed binary needs its pinned FFmpeg
libraries, keep the corresponding LD_LIBRARY_PATH.

    fixture=/tmp/jwm-slow-decoder.w7pf3iW6
    cc -O2 -Wall -Wextra -fPIC -shared "$fixture/sws-decode-gate.c" -o "$fixture/sws-decode-gate.so" -ldl -pthread
    python3 -B "$fixture/run.py" /tmp/jwm-p08-p09-release/jwm-remote --repo /home/yj/projects/jwm --shim "$fixture/sws-decode-gate.so" --out "$fixture/first-run"

The harness expects Python Xlib and Xvfb. It uses a gated Unix socket inherited
only by the viewer and two owned X displays. No external peer or live desktop
is needed. Xvfb provides the real viewer and target application windows. The
shim resolves the actual shared libswscale symbol, recognizes the Linux
decoder thread name, and waits at most one second on one armed invocation.
It calls the original codec function with the original arguments after the
gate. The gate entry, release and timeout are distinct socket messages. Missing
library interposition, an unexpected thread name or JPEG fallback gives a
failed fixture.

The positive initial XTEST tap establishes that input and the local grab
actually work. The observer then paints a new host image and waits for the
direct codec-entry marker. It issues a second tap and holds a separate modifier
while the decode thread is still gated. The host's real focused target window
must see these edges. The observer sends WM_DELETE_WINDOW to the viewer while
the modifier is down. It measures host key-up and verifies that its separate
local X client can obtain both grabs before releasing the decoder. The input
and close observations must occur before the independent host input-idle
release timer could explain this key-up. The viewer and host must then exit
successfully, and the same authenticated session must show actual decode queue
use in telemetry.

Acquired timestamps describe software issue, X11 target delivery, local grab
availability, gate release and process exit on one clock. The 550 ms fixture
window isolates this failure mechanism. The result does not imply the physical
interaction target, queue saturation, exact on-wire input retirement order,
host capture slowdown or a clean exit before an arbitrary codec call returns.

The existing owned-Xvfb test
`remote::client::cleanup_probe::transport_cleanup_returns_local_input_before_waiting_for_receiver`
can also be rerun independently in the existing owned Xvfb runner, with
`JWM_REMOTE_TEST_VIEWER_OWNED=1 JWM_TEST_X11_DISPLAY=<owned display>` and
`--ignored --exact`. Its gate is after receive_frames and provides
cleanup-order evidence. It does not hold the codec. A separate mid-capture
experiment must gate only the actual capture operation. Pausing the whole
host X server also pauses XTEST and does not isolate capture.
