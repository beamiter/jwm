#define _GNU_SOURCE
#include <dlfcn.h>
#include <errno.h>
#include <limits.h>
#include <poll.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <time.h>
#include <unistd.h>

/* Test-only loader shim. No dependency on the FFmpeg headers or build. */
struct SwsContext;
typedef int (*scale_fn)(struct SwsContext *, const uint8_t *const [],
                        const int [], int, int, uint8_t *const [], const int []);
static scale_fn real_scale;
static pthread_once_t init = PTHREAD_ONCE_INIT;
static atomic_flag entered = ATOMIC_FLAG_INIT;

static void find_scale(void)
{
    real_scale = (scale_fn)dlsym(RTLD_NEXT, "sws_scale");
    if (!real_scale)
        _exit(125);
}

static int64_t monotonic_ms(void)
{
    struct timespec ts;
    if (clock_gettime(CLOCK_MONOTONIC, &ts))
        _exit(126);
    return (int64_t)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
}

static void notify(int fd, char byte)
{
    if (send(fd, &byte, 1, MSG_NOSIGNAL | MSG_DONTWAIT) != 1)
        _exit(126);
}

static void gate_decoder(void)
{
    const char *value = getenv("JWM_FIXTURE_DECODER_FD");
    char name[16];
    if (!value || pthread_getname_np(pthread_self(), name, sizeof(name)) ||
        strcmp(name, "jwm-remote-vide"))
        return;

    char *end;
    long fd_value = strtol(value, &end, 10);
    if (!*value || *end || fd_value < 3 || fd_value > INT_MAX)
        _exit(126);
    int fd = (int)fd_value;
    char command;
    if (recv(fd, &command, 1, MSG_DONTWAIT) != 1 || command != 'A' ||
        atomic_flag_test_and_set(&entered))
        return;

    notify(fd, 'E');
    int64_t deadline = monotonic_ms() + 1000;
    do {
        int64_t remaining = deadline - monotonic_ms();
        if (remaining <= 0)
            break;
        struct pollfd request = {.fd = fd, .events = POLLIN};
        int status = poll(&request, 1, (int)remaining);
        if (status > 0) {
            if (recv(fd, &command, 1, MSG_DONTWAIT) == 1 && command == 'R') {
                notify(fd, 'L');
                return;
            }
            break;
        }
        if (status == 0 || errno != EINTR)
            break;
    } while (1);
    notify(fd, 'T');
}

int sws_scale(struct SwsContext *context, const uint8_t *const source[],
              const int source_stride[], int first, int height,
              uint8_t *const dest[], const int dest_stride[])
{
    int old_errno = errno;
    pthread_once(&init, find_scale);
    gate_decoder();
    errno = old_errno;
    return real_scale(context, source, source_stride, first, height, dest,
                      dest_stride);
}
