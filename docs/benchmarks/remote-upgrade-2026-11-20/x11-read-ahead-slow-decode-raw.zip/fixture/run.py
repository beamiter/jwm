#!/usr/bin/env python3
"""Owned-Xvfb input and close fixture, gated inside the actual H.264 worker."""
import argparse
from contextlib import ExitStack
import json
import os
from pathlib import Path
import re
import runpy
import select
import socket
import subprocess
import time

from Xlib import X, XK, display
from Xlib.protocol import event


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('binary', type=Path)
    cli.add_argument('--shim', type=Path, required=True)
    cli.add_argument('--repo', type=Path, required=True)
    cli.add_argument('--out', type=Path, required=True)
    cli.add_argument('--p07', type=Path, default=Path('/tmp/jwm-p07-lab/p07.py'))
    args = cli.parse_args()
    args.out.mkdir(mode=0o700)
    p07 = runpy.run_path(str(args.p07))
    launch = runpy.run_path(str(args.repo / 'scripts/test-remote-viewer-e2e.py'))['launch']
    env = {key: value for key, value in os.environ.items()
           if key not in ('DISPLAY', 'WAYLAND_DISPLAY', 'WAYLAND_SOCKET', 'XAUTHORITY', 'LD_PRELOAD')
           and not key.startswith('JWM_REMOTE_')}
    env.update(XDG_RUNTIME_DIR=str(args.out.resolve()),
               XDG_CACHE_HOME=str((args.out / 'cache').resolve()))
    with ExitStack() as cleanup:
        host_x, host_display = launch()
        cleanup.callback(p07['stop'], host_x)
        viewer_x, viewer_display = launch()
        cleanup.callback(p07['stop'], viewer_x)
        host_x11 = display.Display(host_display)
        cleanup.callback(host_x11.close)
        viewer_x11 = display.Display(viewer_display)
        cleanup.callback(viewer_x11.close)
        for connection in (host_x11, viewer_x11):
            assert connection.has_extension('XTEST')
            connection.change_keyboard_control(auto_repeat_mode=X.AutoRepeatModeOff)
            connection.sync()
        receiver = p07['owned_app'](host_x11, mask=p07['INPUT_MASK'])
        gc = receiver.create_gc(foreground=0xc05020)
        key = args.out / 'key'
        cleanup.callback(key.unlink, missing_ok=True)
        binary = args.binary.resolve()
        subprocess.run([binary, 'keygen', '--output', key], env=env, check=True, timeout=5)

        def start(name, argv, proc_env, *, fds=()):
            path = args.out / f'{name}.log'
            log = cleanup.enter_context(path.open('wb'))
            process = subprocess.Popen([binary, *argv], env=proc_env, stdin=subprocess.DEVNULL,
                                       stdout=log, stderr=subprocess.STDOUT, pass_fds=fds)
            cleanup.callback(p07['stop'], process)
            return process, path

        host, host_log = start(
            'host', ['host', '--display', host_display, '--capture-source', 'root', '--listen',
                     '127.0.0.1:0', '--once', '--allow-h264', '--allow-input', '--max-width', '0',
                     '--fps', '30', '--stats-json', '--key-file', key], env)
        port = p07['wait_for']('private host listener', lambda: re.search(
            r'listening on 127\.0\.0\.1:(\d+)', p07['read'](host_log)), host)[1]
        gate, child_gate = socket.socketpair()
        cleanup.callback(gate.close)
        cleanup.callback(child_gate.close)
        gate.settimeout(3)
        viewer_env = env | {'LD_PRELOAD': str(args.shim.resolve()), 'JWM_REMOTE_READ_AHEAD': '1',
                            'JWM_FIXTURE_DECODER_FD': str(child_gate.fileno())}
        viewer, viewer_log = start(
            'viewer', ['connect', f'127.0.0.1:{port}', '--display', viewer_display, '--window-size',
                       '640x400', '--grab-input', '--scaling', 'cpu', '--key-file', key,
                       '--diagnostics-json', '--stats-json'],
            viewer_env, fds=(child_gate.fileno(),))
        child_gate.close()
        p07['wait_for']('connected viewer', lambda: 'connected;' in p07['read'](viewer_log), host, viewer)
        log = p07['read'](viewer_log)
        assert 'authenticated reader and ordered decoder running independently' in log
        assert 'hardware H.264 decoding active (' in log and 'keyboard + pointer' in log
        window = p07['wait_for']('private viewer window', lambda: p07['viewer_window'](viewer_x11),
                                 host, viewer)
        window.set_input_focus(X.RevertToParent, X.CurrentTime)
        geometry = window.get_geometry()
        p07['inject'](viewer_x11, X.MotionNotify,
                      x=geometry.x + geometry.width // 2, y=geometry.y + geometry.height // 2)
        p07['inject'](viewer_x11, X.ButtonPress, 1)
        p07['inject'](viewer_x11, X.ButtonRelease, 1)
        name_atom = viewer_x11.intern_atom('_NET_WM_NAME')

        def grabbed():
            prop = window.get_full_property(name_atom, X.AnyPropertyType)
            return prop is not None and b'; grabbed -' in bytes(prop.value)

        p07['wait_for']('owned click-to-grab', grabbed, host, viewer)
        list(p07['pending_edges'](host_x11, receiver))
        preflight = p07['input_schedule'](viewer_x11, host_x11, receiver, 1, lambda: 0)

        gate.sendall(b'A')
        receiver.fill_rectangle(gc, 12, 12, 160, 120)
        host_x11.sync()
        assert gate.recv(1) == b'E', 'viewer never entered gated swscale'
        entered = time.monotonic_ns()
        results = []

        def wait_edge(kind, code, issued, label, limit_ns):
            while time.monotonic_ns() < limit_ns:
                for seen_kind, seen_code, when in p07['pending_edges'](host_x11, receiver):
                    if (seen_kind, seen_code) == (kind, code):
                        assert viewer.poll() is None, 'viewer exited before the observation'
                        assert not select.select([gate], [], [], 0)[0], 'codec gate already ended'
                        results.append({'edge': label, 'issue_ns': issued, 'host_seen_ns': when,
                                        'elapsed_ms': (when - issued) / 1_000_000})
                        return when
                ready, _, _ = select.select([host_x11.fileno(), gate], [], [], .005)
                assert gate not in ready, 'codec gate already ended'
            raise RuntimeError(f'missing host input edge: {label}')

        tap = viewer_x11.keysym_to_keycode(XK.XK_F8)
        shift = viewer_x11.keysym_to_keycode(XK.XK_Shift_L)
        limit_ns = entered + 550_000_000
        for kind, keycode, label in ((X.KeyPress, tap, 'tap_down'),
                                     (X.KeyRelease, tap, 'tap_up'),
                                     (X.KeyPress, shift, 'held_down')):
            sent = p07['inject'](viewer_x11, kind, keycode)
            down_seen = wait_edge(kind, keycode, sent, label, limit_ns)
        close_at = time.monotonic_ns()
        message = event.ClientMessage(
            window=window, client_type=viewer_x11.intern_atom('WM_PROTOCOLS'),
            data=(32, [viewer_x11.intern_atom('WM_DELETE_WINDOW'), 0, 0, 0, 0]))
        window.send_event(message)
        viewer_x11.flush()
        # Observe while the viewer process and decoder both remain live. The
        # upper bound precedes the independent host held-input idle timer.
        released = wait_edge(X.KeyRelease, shift, close_at, 'held_release_on_close', limit_ns)
        assert released - down_seen < 600_000_000
        root = viewer_x11.screen().root
        assert root.grab_keyboard(False, X.GrabModeAsync, X.GrabModeAsync,
                                  X.CurrentTime) == X.GrabSuccess
        viewer_x11.ungrab_keyboard(X.CurrentTime)
        assert root.grab_pointer(False, X.PointerMotionMask, X.GrabModeAsync,
                                 X.GrabModeAsync, X.NONE, X.NONE, X.CurrentTime) == X.GrabSuccess
        viewer_x11.ungrab_pointer(X.CurrentTime)
        viewer_x11.sync()
        ungrabbed = time.monotonic_ns()
        assert not select.select([gate], [], [], 0)[0], 'decoder exited before local ungrab check'
        assert viewer.poll() is None
        gate.sendall(b'R')
        assert gate.recv(1) == b'L'
        gate_released = time.monotonic_ns()
        p07['inject'](viewer_x11, X.KeyRelease, shift)
        assert viewer.wait(timeout=5) == 0
        viewer_exited = time.monotonic_ns()
        assert host.wait(timeout=5) == 0
        assert not host_x11.query_keymap()[shift // 8] & (1 << (shift % 8))

        def records(path, kind):
            rows = [json.loads(line) for line in p07['read'](path).splitlines() if line.startswith('{')]
            return [row for row in rows if row.get('type') == kind]

        viewers = records(viewer_log, 'jwm_remote_viewer_stats')
        hosts = records(host_log, 'jwm_remote_host_stats')
        sessions = {row['session_id'] for row in viewers}
        assert len(sessions) == 1 and sessions == {row['session_id'] for row in hosts}
        assert sum(row['stages']['decode_queue_ms']['observations'] for row in viewers) > 0
        [diagnostic] = records(viewer_log, 'jwm_remote_command_result')
        assert diagnostic['outcome'] == 'success', diagnostic
        report = {'session_id': sessions.pop(), 'codec': 'H.264', 'gate_entered_ns': entered,
                  'gate_released_ns': gate_released, 'local_grabs_reacquired_ns': ungrabbed,
                  'viewer_exited_ns': viewer_exited, 'initial_input': preflight, 'edges': results}
        (args.out / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
        print(json.dumps(report))


if __name__ == '__main__':
    main()
