# Private 4K X11 DRI3 prerequisite

Weston 13 and its headless, GL and kiosk modules are already staged under
`/tmp/jwm-aether-weston.xBLhos`. The installed Xwayland supports rootful
geometry and fullscreen. On the local PC, `/dev/dri/renderD128` is writable
by the current user and maps to Intel i915 PCI `0000:00:02.0`. Read-only DRM
connector state showed all Intel connectors disconnected and the connected
DP connector on the separate NVIDIA card. Headless Weston opens a render
device and takes no physical seat or output.

## Executed prerequisites

The first probe reached a private depth-24 3840×2160 X11 screen and advertised
DRI3. Weston reported NVIDIA EGL, RTX 5080 rendering and
`/dev/dri/renderD129`. The Intel gate stopped before querying the Xwayland
DRI3 descriptor or running the production doctor.

The single recovery probe ran under the shared benchmark lock. All child
processes saw only the installed Mesa EGL vendor manifest and the same
explicit Intel PCI selection. Weston reported Mesa Intel ARL rendering, yet
EGL still reported `/dev/dri/renderD129` as its rendering device. Xwayland
tried that NVIDIA device under Mesa and could not initialize EGL/glamor.
Its screen was still depth-24 3840×2160, with DAMAGE and MIT-SHM. It exposed
no DRI3 and the gate stopped. No Xwayland DRI3 FD exists from this probe.

    fixture=/tmp/jwm-private-dri3.ijJuCXWt
    flock /tmp/jwm-p08-p09-release/benchmark.lock python3 -B "$fixture/probe.py" /tmp/jwm-p08-p09-release/jwm-remote --out "$fixture/mesa-probe"

The outputs are preserved in `first-probe` and `mesa-probe`. No timed
measurement or production doctor ran. Weston 13's `--drm-device` is an
option of its DRM/KMS backend, so it cannot select the headless device in
this fixture. Starting a physical backend would change the isolation scope.

## Probe contract

The probe launches fresh headless Weston GL with a private runtime and
configuration and chooses an unused rootful Xwayland display by displayfd.
Only its own temporary Xauthority cookie is accepted. It does not inherit the
ambient X11 display, Wayland socket or session bus. It verifies exact
3840×2160 screen, a depth-24 DRI3 visual and Weston Intel GLES and runs
the real same-device VA-API/EGL/DRI3 doctor against that private display.
The production doctor independently compares the requested DRM device to
the exact display's DRI3 DRM FD and verifies four cropped hardware pixels.
Logs survive both successful and failed probes. The helper tears down its
own display processes and temporary credentials before returning.

The doctor allocates a small test surface. A positive result establishes the
private hardware DRI3 prerequisites at a 4K display size. It leaves actual
4K surface import, viewer frame completion and throughput for the next stage.

For sustained measurement, reuse the high-resolution P09 painter, existing
host settings, telemetry and matched-window observer. Replace only the
viewer Xvfb factory with this helper while preserving the private runtime,
cookie and exact eligible window. Validate one live stream at 3840×2160
before timing. Use `--view-only --scaling gpu --window-size 3840x2160
--window-position 0,0` for both arms with the same H.264 decoder. Set
`JWM_REMOTE_GPU_PRESENT=/dev/dri/renderD128` only for the native arm.
Require native X11 presentation count to match that arm's drawn count and
hardware downloads to stay at zero across each retained window. Sample actual
window pixels with the existing P09 96×96 marker crop at (16,16) and count only
valid new run/frame IDs. Retain raw source and viewer markers, duplicate or
invalid samples, and observer crop cost. Only use polling if XDamage proves
unavailable for the drawable, and use the same mode in both arms. A CPU or
physical scanout result from a different desktop cannot stand in for this
paired native-path measurement.

## Isolated native Wayland fallback

The existing acceptance command, on a hardware-capable build and outside
timed work, is `scripts/test-remote-wayland-cli.sh --gpu-viewer /dev/dri/renderD128`.
That test proved the smaller native path on Ubuntu's physical Intel GPU. Its
fixture opens that exact render node as GBM in `HeadlessSmithayGles::on_render_node`
and advertises the corresponding device in its private Wayland DMA-BUF
feedback, independently of Weston or any connected monitor. It rejects a
software GLES renderer.

To reuse the existing fixed-NVENC 4K source, start only the private viewer
compositor from that harness and connect the normal release viewer over the
same authenticated TCP forward. Configure the test toplevel to 3840×2160 at
scale 1 from its initial configure. Run the view-only Wayland viewer with
`JWM_REMOTE_GPU_PRESENT=/dev/dri/renderD128` for the native arm and unset it
for the CPU arm. Match each received viewer buffer to the current committed
role and its presentation feedback. At scale 1 the exact 96×96 marker crop
can be read from rendered surface pixels. Reuse the painter's complemented
run/frame ID and checksum and confirm orientation with the asymmetric source
before counting. A retained GPU render target plus a small Smithay
`ExportMem::copy_framebuffer` crop avoids the existing fixture's full-image
SHM capture and allocation on every frame. Keep that observer identical
between arms and record readback overhead.

An exact-size native stream still needs preflight on the selected local
Intel driver. The production GPU presenter accepts 3840×2160 in its software
limits. Enforce matching host/source/encoded and viewer buffer dimensions
and require native presented counts and zero viewer hardware downloads
throughout the scored native arm. Report it as a software observation of
the private Wayland compositor's hardware-rendered pixels. This route uses
a different viewer backend and presentation fence from the Xwayland comparison.
