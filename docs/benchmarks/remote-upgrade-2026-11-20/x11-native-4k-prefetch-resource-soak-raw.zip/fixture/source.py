#!/usr/bin/env python3
"""Owned Ubuntu endpoint for the exact-size native X11 prefetch soak."""
import argparse
from contextlib import ExitStack
import hashlib
import json
from pathlib import Path
import re
import select
import subprocess
import sys
import time

from prior_resources import TelemetryRelay, track
from remote_processes import clean_env, get_display, start_display, stop, wait_for
from sampler import BURN, MEASURE, capture, require

LAB = Path(__file__).resolve().parent
HOST = Path('/tmp/jwm-p09-resolution-candidate/jwm-remote')
HOST_SHA256 = '59572059a51aae67c91eff3013012352b932850806647cb81ccda2756522b47b'
PAINTER_SECONDS = BURN + MEASURE + 70


def digest(path):
    sha = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            sha.update(block)
    return sha.hexdigest()


def bridge(event, **details):
    print(json.dumps({'type':event, **details}), flush=True)


def main():
    args = argparse.ArgumentParser(description=__doc__)
    args.add_argument('trial')
    args.add_argument('--run-id', type=int, required=True)
    args.add_argument('--painter-sha256', required=True)
    opts = args.parse_args()
    require(re.fullmatch(r'[a-z0-9-]{1,54}',opts.trial) and 1 <= opts.run_id <= 255, 'invalid owned source identity')
    painter_bin = LAB / 'p09-workload'
    require(digest(HOST) == HOST_SHA256 and digest(painter_bin) == opts.painter_sha256, 'source pin differs')
    work = LAB / opts.trial
    work.mkdir(mode=0o700)
    key = sys.stdin.buffer.readline(4096)
    require(len(key) == 65 and key.endswith(b'\n'), 'expected one generated session key line')
    with ExitStack() as tear_down:
        def log(name, mode):
            return tear_down.enter_context((work / name).open(mode))

        xvfb = start_display(3840,2160,log('xvfb.log','xb'))
        tear_down.callback(stop, xvfb)
        display = get_display(xvfb)
        host_env = clean_env()
        host_env['JWM_REMOTE_PARALLEL_YUV420'] = '1'
        host = subprocess.Popen([HOST,'host','--display',display,'--capture-source','root','--scaling','auto',
                                 '--listen','127.0.0.1:0','--key-stdin','--once','--stats-json','--allow-h264','--fps','30'],
                                env=host_env, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        relay = TelemetryRelay(host,'host',log('host.log','xb'),log('host-clock.jsonl','x'))
        tear_down.callback(relay.finish)
        tear_down.callback(stop,host,natural=True)
        identity = track(host.pid, HOST)
        host.stdin.write(key)
        host.stdin.flush()
        port = int(wait_for(host, lambda: re.search(r'listening on 127\.0\.0\.1:(\d+)',
               (work/'host.log').read_text(errors='replace')),15)[1])
        painter = subprocess.Popen([painter_bin,'paint','--display',display,'--width','3840','--height','2160',
                                    '--seconds',str(PAINTER_SECONDS),'--fps','60','--run-id',str(opts.run_id),'--seed','7'],
                                    env=clean_env(), stdin=subprocess.DEVNULL, stdout=log('paint.jsonl','xb'),
                                    stderr=log('paint-stderr.log','xb'))
        tear_down.callback(stop,painter)
        wait_for(painter,lambda: re.search(r'"type":"p09_start"',(work/'paint.jsonl').read_text()),10)
        bridge('soak_ready',upstream_port=port)

        def healthy(check_host=True):
            relay.check(alive=check_host)
            if select.select([sys.stdin],[],[],0)[0]:
                raise RuntimeError('controller pipe closed or rewrote the one-line key grant')
            if xvfb.poll() is not None or painter.poll() is not None:
                raise RuntimeError('owned source Xvfb or painter ended before terminal scope')

        expiry=time.monotonic()+40
        while relay.anchor is None:
            healthy()
            require(time.monotonic()<expiry, 'no complete authenticated host video/ACK window')
            time.sleep(.05)
        capture(log('host-resources.jsonl','x'),'host',identity,relay.anchor,healthy)
        bridge('host_measured')
        expiry=time.monotonic()+45
        while host.poll() is None:
            healthy(check_host=False)
            require(time.monotonic()<expiry,'host did not exit following viewer disconnect')
            time.sleep(.05)
        require(host.returncode==0,'host exited unsuccessfully after measurement')
        relay.finish()
        relay.check(alive=False)
        require(not relay.worker.is_alive(),'host telemetry relay never drained')
        require(digest(HOST) == HOST_SHA256 and digest(painter_bin) == opts.painter_sha256, 'source pin changed')
        (work/'terminal.json').write_text(json.dumps({'host_exit':0,'owned_painter_live_at_host_exit':painter.poll() is None})+'\n')
        bridge('host_closed',exit=0)


if __name__ == '__main__':
    main()
