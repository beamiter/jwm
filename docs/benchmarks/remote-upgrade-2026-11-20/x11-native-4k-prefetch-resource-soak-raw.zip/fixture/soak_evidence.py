"""Replay the exact resource interval and observed hardware/marker evidence."""
import hashlib
import json
import math
import os
from pathlib import Path

from evidence import mark_score, observed, phase_stats, prove_host, prove_route, records, require, verify_prefetch
from sampler import BURN, INTERVAL, MEASURE, SECOND, summarize

SIZE = [3840,2160]
BUCKETS = MEASURE // BURN
EXPECTED_WATCHDOG = 1100
HOST_SHA256 = '59572059a51aae67c91eff3013012352b932850806647cb81ccda2756522b47b'


def read(path):
    return json.loads(path.read_text())


def telemetry(path, scope, counter):
    all_rows = records(path)
    start, end = scope['measurement_start_ns'], scope['measurement_end_ns']
    arrivals=[row['arrived_monotonic_ns'] for row in all_rows]
    require(all(type(stamp) is int for stamp in arrivals) and all(a<b for a,b in zip(arrivals,arrivals[1:])),
            'endpoint telemetry receipt clock is not strictly increasing')
    retained = []
    buckets = [0]*BUCKETS
    for row in all_rows:
        entry = row['record']
        stamp = row['arrived_monotonic_ns']
        window = entry['window_seconds']
        require(isinstance(window,(int,float)) and math.isfinite(window) and window>0,
                'invalid endpoint telemetry duration')
        if entry.get('final') or window < 4.9 or stamp > end or stamp-round(window*SECOND) < start:
            continue
        retained.append(row)
        bucket = min((stamp-start)//(BURN*SECOND), BUCKETS-1)
        buckets[bucket] += entry[counter]
    covered = sum(row['record']['window_seconds'] for row in retained)
    require(covered >= MEASURE - 2*INTERVAL and all(value>0 for value in buckets),
            'missing steady endpoint telemetry or sustained drawn ACK progress')
    return all_rows, retained, covered, buckets


def analyze(root):
    plan = read(root/'protocol.json')
    require(plan['burn_in_seconds']==BURN and plan['retained_seconds']==MEASURE
            and plan['resource_interval_seconds']==INTERVAL and plan['source_video_size']==SIZE,
            'the replay protocol differs from the declared soak')
    fixture=root/'fixture'
    require(all(hashlib.sha256((fixture/name).read_bytes()).hexdigest()==pin
                for name,pin in plan['fixture_sha256'].items()), 'fixture source digests differ')
    before=read(root/'remote-pins-before.json')
    after=read(root/'remote-pins-after.json')
    require(before==after and before['host']==HOST_SHA256, 'pinned host or source assets differ')
    require(read(root/'observer-pin.json').get('sha256'), 'local long observer identity is missing')
    source = root/'remote'
    host_resource = summarize(records(source/'host-resources.jsonl'),'host')
    view_resource = summarize(records(root/'viewer-resources.jsonl'),'viewer')
    host_all, host, host_cover, host_buckets = telemetry(source/'host-clock.jsonl',host_resource,'drawn_acks')
    view_all, view, view_cover, view_buckets = telemetry(root/'viewer-clock.jsonl',view_resource,'acked')
    host_rows = [row['record'] for row in host_all]
    viewer_rows = [row['record'] for row in view_all]
    retained_viewer = [row['record'] for row in view]
    obey_host = (source/'host.log').read_text()
    obey_view = (root/'viewer.log').read_text()
    prove_host(host_rows,obey_host)
    prove_route(viewer_rows,obey_view,'on')
    require(all(row['negotiated_codec']=='H.264' for row in viewer_rows), 'wrong native stream codec')
    require(all(not row['png_atlases'] for row in host_rows), 'host left H.264 for PNG')
    sessions = {row['session_id'] for row in host_rows+viewer_rows}
    require(len(sessions)==1 and next(iter(sessions),None), 'actual endpoints used differing authenticated sessions')
    frames = [row['last_sent_frame'] for row in host_rows if row.get('last_sent_frame')]+[
        row['last_frame'] for row in viewer_rows if row.get('last_frame')]
    require(frames and all(row['source_dimensions']==row['encoded_dimensions']==SIZE and row['codec']=='H.264'
                           for row in frames),'resolution or codec changed during the soak')
    scopes = {(row['source_epoch'],row['geometry_epoch']) for row in frames}
    require(len(scopes)==1,'fixed-size video source or geometry epoch changed')
    require(all(row['source_dimensions']==row['encoded_dimensions']==SIZE
                for row in host_rows if row['captured']), 'host capture left exact resolution')
    require(all(observed(row,'stages','hardware_download_ms')==0 for row in viewer_rows), 'D3 playback downloaded on the CPU')
    imports = verify_prefetch(retained_viewer,viewer_rows,'on')
    host_credit=max(row['max_outstanding'] for row in host_rows)
    require(0<=host_credit<=2,'reported host credits exceeded its fixed limit')
    windows = plan['trial']
    [observer_start] = [row for row in records(root/'observed.jsonl') if row['type']=='p09_start']
    require([observer_start['width'],observer_start['height']]==SIZE and
            observer_start['seconds']==windows['observer_seconds'], 'independent observer left exact 4K')
    marker, markers = mark_score(windows,root/'observed.jsonl',source/'paint.jsonl')
    require(marker['score_start_ns']==view_resource['measurement_start_ns'] and
            marker['score_end_ns']==view_resource['measurement_end_ns'], 'viewer resources and marker interval differ')
    marker_buckets = [0]*BUCKETS
    for point in markers:
        marker_buckets[(point['monotonic_ns']-marker['score_start_ns'])//(BURN*SECOND)] += 1
    require(all(marker_buckets),'at least one full retained minute showed no new marker')
    first, last = records(source/'paint.jsonl')
    require(first['type']=='p09_start' and last['type']=='p09_end' and first['fps']==60 and
            [first['width'],first['height']]==SIZE and
            (last['last_submit_ns']-last['first_submit_ns']) >= (BURN+MEASURE)*SECOND,
            'actual source motion was not sustained through burn-in and scoring')
    display = read(root/'display/result.json')
    require(display['screen_size']==SIZE and display['render_node']==plan['renderer']['render_node']
            and display['dri3']['path']==plan['renderer']['render_node']
            and os.makedev(display['dri3']['major'],display['dri3']['minor'])==plan['renderer']['render_node_rdev']
            and display['pci_device']==plan['renderer']['render_pci_device']
            and display['binary_sha256']['doctor']==plan['viewer_sha256']
            and display['binary_sha256']['harness']==plan['harness_sha256']
            and display['owned_output_final']['watchdog_seconds']==EXPECTED_WATCHDOG
            and display['production_doctor_passed'] and display['compositor_exit']==0
            and display['owned_output_final']['dmabuf_draws'] > 0,'incomplete owned native display lifecycle')
    proc= read(root/'terminal.json')
    require(all(value==0 for value in proc.values()) and set(proc)=={'observer','viewer','source','launcher'}
            and read(source/'terminal.json')['host_exit']==0,'missing normal process shutdown')
    for role, samples in (('host',host),('viewer',view),('markers',markers)):
        path=root/f'retained-{role}.jsonl'
        rendered=''.join(json.dumps(row,allow_nan=False)+'\n' for row in samples)
        if path.exists():
            require(path.read_text()==rendered,f'retained {role} evidence changed')
        else:
            path.write_text(rendered)
    return {'status':'complete','plan':plan,'same_authenticated_session':True,
            'scope':{'source_epoch':next(iter(scopes))[0],'geometry_epoch':next(iter(scopes))[1]},
            'host':host_resource | {'whole_windows':len(host),'telemetry_covered_seconds':host_cover,
                                     'drawn_ack_progress_each_minute':host_buckets,'peak_outstanding_credits':host_credit},
            'viewer':view_resource | {'whole_windows':len(view),'telemetry_covered_seconds':view_cover,
                                      'drawn_ack_progress_each_minute':view_buckets,'native_prefetch':imports,
                                      'native_stages':phase_stats(retained_viewer,'native_x11_stages'),'cpu_downloads':0},
            'marker':marker | {'observed_unique_each_minute':marker_buckets,'meets_27_fps_gate':marker['visible_fps']>=27},
            'terminal':proc,'clocks':'Endpoint monotonic clocks independently. No cross-machine timestamp subtraction.'}


if __name__ == '__main__':
    import sys
    print(json.dumps(analyze(Path(sys.argv[1])),indent=2,allow_nan=False))
