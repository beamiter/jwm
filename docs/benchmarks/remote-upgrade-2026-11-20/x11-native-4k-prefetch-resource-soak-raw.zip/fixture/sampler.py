"""Absolute scheduled samples for one owned Linux endpoint process."""
from collections import Counter, defaultdict
from dataclasses import asdict
import os
from pathlib import Path
import re
from statistics import median
import time

from prior_resources import RESOURCE_FIELDS, SECOND, describe, read_identity, resources, sleep_until, write_row

BURN = 60
MEASURE = 900
INTERVAL = 5
BURN_SLOTS = BURN // INTERVAL
MEASURE_SLOTS = MEASURE // INTERVAL
SLOTS = BURN_SLOTS + MEASURE_SLOTS
DRM_MAX_FDS = 512
DRM_MAX_BYTES = 16384
MEMORY_KEY = re.compile(r'drm-(?:total|shared|resident|memory|purgeable|active)-[\w.-]+\Z', re.ASCII)
COUNTER = re.compile(r'([0-9]+)(?:\s+(B|KiB|MiB))?\Z')
UNITS = {None: 1, 'B': 1, 'KiB': 1024, 'MiB': 1048576}


def require(condition, why):
    if not condition:
        raise ValueError(why)


def parse_drm(text):
    fields = {}
    for line in text.splitlines():
        key, separator, value = line.partition(':')
        if separator and key.startswith('drm-'):
            fields[key] = value.strip()
    driver = fields.get('drm-driver')
    if not driver or not re.fullmatch(r'[\w.-]+', driver, re.ASCII):
        return None
    raw_id = fields.get('drm-client-id', '')
    client_id = int(raw_id) if re.fullmatch(r'[0-9]+', raw_id) else None
    device = fields.get('drm-pdev')
    require(device is None or re.fullmatch(r'[0-9a-fA-F:.]+', device), 'unexpected DRM device identifier')
    counters, unknown = {}, []
    for key, value in fields.items():
        if not MEMORY_KEY.fullmatch(key) or key.startswith('drm-total-cycles-'):
            continue
        if found := COUNTER.fullmatch(value):
            counters[key] = int(found[1]) * UNITS[found[2]]
        else:
            unknown.append(key)
    return {'driver': driver, 'device': device, 'client_id': client_id,
            'memory_bytes_by_key': counters, 'unrecognized_memory_keys': sorted(unknown)}


def collect_drm(base):
    grouped = {}
    anonymous = []
    skipped = Counter()
    try:
        descriptors = [entry for entry in (base / 'fdinfo').iterdir() if entry.name.isdecimal()]
    except PermissionError:
        return {'status': 'permission_denied', 'clients': [], 'unlinked': [], 'scan_issues': {}}
    except OSError as problem:
        return {'status': 'fdinfo_read_error', 'clients': [], 'unlinked': [],
                'scan_issues': {type(problem).__name__: 1}}
    if len(descriptors) > DRM_MAX_FDS:
        return {'status': 'fdinfo_descriptor_limit', 'clients': [], 'unlinked': [],
                'scan_issues': {'descriptor_limit': len(descriptors)}}
    for path in sorted(descriptors, key=lambda entry: int(entry.name)):
        try:
            with path.open('rb') as stream:
                data = stream.read(DRM_MAX_BYTES + 1)
            if len(data) > DRM_MAX_BYTES:
                skipped['entry_limit'] += 1
                continue
            client = parse_drm(data.decode('utf-8', errors='replace'))
        except (OSError, ValueError) as problem:
            skipped[type(problem).__name__] += 1
            continue
        if client is None:
            continue
        if client['client_id'] is None:
            anonymous.append(client)
            continue
        identity = (client['driver'], client['device'], client['client_id'])
        if identity not in grouped:
            grouped[identity] = client
        elif client != grouped[identity]:
            # Each duplicated FD can observe currently changing counters at a
            # different instant. Keep the first reading in the slot and say so.
            skipped['duplicate_client_values_changed'] += 1
    identified = list(grouped.values())
    observed = any(client['memory_bytes_by_key'] for client in identified + anonymous)
    if observed:
        status = 'partial_counters' if skipped else 'counters_reported'
    elif skipped:
        status = 'read_incomplete'
    elif identified or anonymous:
        status = 'drm_client_without_memory_counters'
    else:
        status = 'no_standard_drm_client_export'
    return {'status': status, 'clients': identified, 'unlinked': anonymous, 'scan_issues': dict(skipped)}


def sample(identity, proc=Path('/proc')):
    ordinary = resources(identity, proc)
    base = proc / str(identity.pid)
    fields = (base / 'stat').read_text().rpartition(') ')[2].split()
    # Tokens start at stat field 3. Save only the endpoint's user/system ticks.
    ordinary['cpu_user_ticks'] = int(fields[11])
    ordinary['cpu_system_ticks'] = int(fields[12])
    ordinary['drm'] = collect_drm(base)
    if read_identity(identity.pid, proc) != identity:
        raise RuntimeError('owned endpoint identity changed during resource collection')
    return ordinary


def capture(output, role, identity, anchor, health, *, clock=time.monotonic_ns, sleep=time.sleep,
            read_sample=sample, clock_ticks=os.sysconf('SC_CLK_TCK')):
    start = anchor + BURN * SECOND
    end = start + MEASURE * SECOND
    write_row(output, {'type':'resource_start', 'role':role, 'identity':asdict(identity), 'anchor_ns':anchor,
                       'measurement_start_ns':start, 'measurement_end_ns':end,
                       'interval_seconds':INTERVAL, 'process_clock_ticks_per_second':clock_ticks})
    status = Counter()
    next_slot = 0
    try:
        while next_slot < SLOTS:
            due = anchor + next_slot * INTERVAL * SECOND
            sleep_until(due, health, clock, sleep)
            before = clock()
            row = {'type':'resource_sample', 'role':role, 'slot':next_slot, 'scheduled_ns':due,
                   'phase':'burn_in' if next_slot < BURN_SLOTS else 'measured'}
            if before >= due + INTERVAL * SECOND:
                row |= {'status':'missed', 'observed_ns':before}
            else:
                try:
                    values = read_sample(identity)
                    after = clock()
                    row |= {'status':'valid' if after < due + INTERVAL * SECOND else 'late',
                            'sample_start_ns':before, 'sample_ns':after, **values}
                except (OSError, RuntimeError, ValueError, IndexError) as problem:
                    row |= {'status':'error', 'sample_start_ns':before, 'sample_ns':clock(),
                            'failure_type':type(problem).__name__, 'failure':str(problem)}
            status[row['status']] += 1
            write_row(output, row)
            next_slot += 1
        # A last sample at start+895s proves the scheduled slot, while observed
        # process health through start+900s proves the actual full interval.
        sleep_until(end, health, clock, sleep)
    except BaseException as problem:
        while next_slot < SLOTS:
            status['unreached'] += 1
            write_row(output, {'type':'resource_sample', 'role':role, 'slot':next_slot,
                               'scheduled_ns':anchor+next_slot*INTERVAL*SECOND,
                               'phase':'burn_in' if next_slot < BURN_SLOTS else 'measured',
                               'status':'unreached'})
            next_slot += 1
        write_row(output, {'type':'resource_end', 'role':role, 'observed_ns':clock(), 'complete':False,
                           'status_counts':dict(status), 'failure_type':type(problem).__name__,
                           'failure':str(problem)})
        raise
    write_row(output, {'type':'resource_end', 'role':role, 'observed_ns':clock(), 'complete':True,
                       'status_counts':dict(status)})


def metric(values, start_values, end_values):
    first, last = median(start_values), median(end_values)
    return describe(values) | {'first_minute_median':first, 'last_minute_median':last, 'median_delta':last-first}


def summarize(rows, role):
    start, *samples, end = rows
    require(start['type'] == 'resource_start' and end['type'] == 'resource_end', 'missing terminal resource evidence')
    require(all(row['role'] == role for row in rows), 'unexpected resource trace role')
    anchor = start['anchor_ns']
    score_start = start['measurement_start_ns']
    score_end = start['measurement_end_ns']
    require((score_start-anchor, score_end-score_start, start['interval_seconds']) ==
            (BURN*SECOND, MEASURE*SECOND, INTERVAL), 'resource interval differs from declared workload')
    require(end['complete'] and end['observed_ns'] >= score_end and len(samples) == SLOTS,
            'did not observe a complete resource interval')
    counts = Counter(row['status'] for row in samples)
    require(counts == Counter(end['status_counts']), 'recorded resource status counts differ')
    for index, row in enumerate(samples):
        due = anchor + index*INTERVAL*SECOND
        require(row['slot'] == index and row['scheduled_ns'] == due and
                row['phase'] == ('burn_in' if index < BURN_SLOTS else 'measured'),
                'invalid resource sample phase or schedule')
        if row['status'] == 'valid':
            require(due <= row['sample_start_ns'] <= row['sample_ns'] < due+INTERVAL*SECOND and
                    all(type(row[field]) is int and row[field] > 0 for field in RESOURCE_FIELDS),
                    'invalid valid-sample accounting')
    measured = [row for row in samples[BURN_SLOTS:] if row['status'] == 'valid']
    require(len(measured) == MEASURE_SLOTS, f'{role} lost measured resource samples: {dict(counts)}')
    first, last = measured[:BURN_SLOTS], measured[-BURN_SLOTS:]
    resource = {}
    for field in RESOURCE_FIELDS:
        resource[field] = metric([r[field] for r in measured], [r[field] for r in first], [r[field] for r in last])
    cpu = []
    tick_rate = start['process_clock_ticks_per_second']
    require(type(tick_rate) is int and tick_rate > 0, 'unsupported process CPU tick rate')
    for a,b in zip(measured, measured[1:]):
        delta = b['cpu_user_ticks']+b['cpu_system_ticks']-a['cpu_user_ticks']-a['cpu_system_ticks']
        require(delta >= 0, 'process CPU ticks moved backwards')
        cpu.append(delta / tick_rate * SECOND / (b['sample_ns']-a['sample_ns']))
    gpu = Counter(row['drm']['status'] for row in measured)
    stable_gpu = defaultdict(list)
    for row in measured:
        for client in row['drm']['clients']:
            key = (client['driver'], client['device'], client['client_id'])
            stable_gpu[key].append((row['slot'], client['memory_bytes_by_key']))
    clients = []
    for key, snapshots in stable_gpu.items():
        counters = {}
        for name in sorted({name for _, data in snapshots for name in data}):
            values = [(slot, data[name]) for slot, data in snapshots if name in data]
            early = [value for slot,value in values if slot < 2*BURN_SLOTS]
            late = [value for slot,value in values if slot >= SLOTS-BURN_SLOTS]
            counters[name] = {'samples':len(values)} | (metric([v for _,v in values],early,late)
                                                      if early and late else describe([v for _,v in values]))
        clients.append({'driver':key[0], 'device':key[1], 'client_id':key[2], 'observed_slots':len(snapshots),
                        'memory_bytes_by_key':counters})
    timestamps = [score_start, *[row['sample_ns'] for row in measured], score_end]
    return {'measurement_start_ns':score_start, 'measurement_end_ns':score_end,
            'measurement_seconds':MEASURE, 'status_counts':dict(counts), 'valid_measured_samples':len(measured),
            'max_sample_gap_seconds':max(b-a for a,b in zip(timestamps,timestamps[1:])) / SECOND,
            'process_resources':resource, 'cpu_cores_in_use_between_samples':describe(cpu),
            'drm_samples_by_status':dict(gpu), 'drm_clients':clients,
            'samples_with_unlinked_drm_fds':sum(bool(row['drm']['unlinked']) for row in measured)}
