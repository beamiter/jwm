"""Reproduce the recorded gate from raw X11 2560×1440 viewport evidence."""

import argparse
import json
from pathlib import Path

from evidence import NATIVE_ROOT, SIZE, analyze, records, require
from processes import sha256
from run import (CANDIDATE, HARNESS_PIN, OBSERVER_PHASE_MAX_NS, OBSERVER_PHASE_MIN_NS, REMOTE_PINS,
                 prove_display_report, summarize)


def load(path):
    return json.loads(path.read_text())


def replay(run):
    protocol = load(run / 'protocol.json')
    require(protocol['remote_pins'] == REMOTE_PINS, 'unexpected remote source manifest')
    native = protocol['study'] != 'rgb-comparator'
    require(protocol['schema'] == 2 and protocol['dimensions'] == SIZE
            and protocol['viewport_position'] == [0, 0]
            and protocol['native_root_dimensions'] == (NATIVE_ROOT if native else None)
            and protocol['native_harness_sha256'] == (HARNESS_PIN if native else None),
            'source, viewport or owned root dimensions differ from protocol')
    require(protocol['candidate_flag'] == CANDIDATE and protocol['lazy_picture_env'] is None,
            'live protocol makes another picture preparation change')
    phase_scope = protocol.get('formal_observer_phase')
    if phase_scope is not None:
        require(protocol['study'] in ('pair', 'abba')
                and phase_scope['spawn_target_delay_ns'] == [OBSERVER_PHASE_MIN_NS, OBSERVER_PHASE_MAX_NS]
                and phase_scope['viewer_readiness_timeout_seconds'] == 20,
                'observer launch phase differs from the recorded protocol')
    require(all(sha256(Path(__file__).with_name(name)) == digest
                for name, digest in protocol['fixture_sha256'].items()),
            'live benchmark and replay source pins differ')
    rows = []
    for trial in protocol['schedule']:
        case = run / trial['name']
        result = load(case / 'result.json')
        require(all(result[key] == value for key, value in trial.items()), 'slot differs from schedule')
        if result['status'] == 'valid':
            require(load(case / 'source-pins-before.json') == load(case / 'source-pins-after.json')
                    == REMOTE_PINS, 'source pins changed between trial boundaries')
            control = load(case / 'viewer-control.json')
            require(control['viewer_sha256'] == protocol['viewer_sha256'] and control['mode'] == trial['mode']
                    and control['prefetch_env'] == ('1' if trial['mode'] == 'on' else None)
                    and control['lazy_picture_env'] is None
                    and control['viewport_position'] == [0, 0] and control['viewport_dimensions'] == SIZE
                    and control['root_dimensions'] == (NATIVE_ROOT if native else SIZE)
                    and control['scaling'] == ('gpu' if native else 'cpu')
                    and control['gpu_render_node'] == (protocol['renderer']['render_node'] if native else None),
                    'viewer launch controls differ from protocol')
            if native:
                display = load(case / 'display' / 'result.json')
                prove_display_report(display, protocol['viewer_sha256'], protocol['renderer'], closed=True)
            if phase_scope is not None:
                audit = load(case / 'observer-phase.json')
                receipts = {item['end_ns'] for item in records(case / 'viewer-clock.jsonl')}
                start, = [row['monotonic_ns'] for row in records(case / 'observed.jsonl')
                          if row['type'] == 'p09_start']
                require(audit['target_delay_ns'] == phase_scope['spawn_target_delay_ns']
                        and audit['receipt_clock_ns'] in receipts
                        and audit['receipt_clock_ns'] <= audit['spawn_requested_ns'] <= start,
                        'observer launch audit does not agree with actual monotonic receipts')
            actual, host, viewer, markers = analyze(case, trial)
            actual['status'] = 'valid'
            require(actual == result, f'{trial["name"]} does not reproduce recorded statistics')
            for lane, kept in (('host', host), ('viewer', viewer), ('markers', markers)):
                require(records(case / f'retained-{lane}.jsonl') == kept, f'{lane} retention differs')
        else:
            require(result.get('marker') is None and result.get('meets_27_fps_gate') is None,
                    'unsuccessful or preflight-only attempt claimed scored evidence')
        rows.append(result)
    summary = summarize(protocol['study'], rows)
    require(summary == load(run / 'summary.json'), 'comparison summary does not replay')
    return summary


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('run', type=Path)
    args = parser.parse_args()
    print(json.dumps(replay(args.run), indent=2, allow_nan=False))
