"""Validate actual RGB backing reuse in the native Wayland phase smoke."""
import argparse
import json
from pathlib import Path

from validate_phases import require, stage_summary, write_diagnostic as validate_native


ALLOCATION = 'rgb_target_allocation_ms'
FENCE = 'egl_fence_wait_ms'
IMPORT = 'wayland_dmabuf_import_ms'
ACTIVE = 'jwm-remote: native Wayland XRGB DMA-BUF backing reuse active'


def counters(rows):
    phase_observations = {name: 0 for name in (ALLOCATION, FENCE, IMPORT)}
    preparation = 0
    for row in rows:
        record = row['record']
        preparation += record['stages']['native_preparation_and_submit_ms']['observations']
        measured = record.get('native_wayland_stages', {})
        for name in phase_observations:
            if name in measured:
                phase_observations[name] += measured[name]['observations']
    return {'native_preparations': preparation,
            'rgb_target_allocations': phase_observations[ALLOCATION],
            'egl_fence_waits': phase_observations[FENCE],
            'fresh_wayland_dmabuf_imports': phase_observations[IMPORT]}


def validate_reuse(run, result, raw_rows, retained):
    arm = result['rgb_backing_reuse_arm']
    log = run / 'viewer' / 'viewer-complete-stderr.log'
    activations = sum(line == ACTIVE for line in log.read_text().splitlines())
    stage_summary(raw_rows)  # The whole session must prove real allocation measurements.
    whole = counters(raw_rows)
    steady = counters(retained)
    require(whole['rgb_target_allocations'] > 0, 'no actual RGB target allocation in the entire viewer session')
    preparations = steady['native_preparations']
    allocations = steady['rgb_target_allocations']
    require(preparations > 0 and steady['egl_fence_waits'] == preparations
            and steady['fresh_wayland_dmabuf_imports'] == preparations,
            'steady native preparation, fence wait, and fresh wl_buffer import counts differ')
    if arm == 'A':
        require(activations == 0, 'control unexpectedly activated the reuse path')
        require(allocations == preparations, 'control did not allocate per native preparation')
    else:
        require(arm == 'B' and activations == 1, 'candidate never reported one successful backing reuse activation')
        require(0 <= allocations < preparations,
                'candidate allocations did not decline against steady native preparations')
    return {'arm': arm, 'successful_reuse_activation_log_lines': activations,
            'confirmed_activation': activations == 1,
            'whole_session': whole, 'matched_steady_windows': steady,
            'allocations_outside_matched_steady_windows': whole['rgb_target_allocations'] - allocations,
            'steady_allocations_per_native_preparation': allocations / preparations,
            'scope': ('Counts are actual GBM backing allocations and separate native preparation, fence, '
                      'and fresh Wayland DMA-BUF import observations. Missing allocation phase in a matched '
                      'steady window contributes zero only after the same session proves allocations elsewhere.')}


def write_diagnostic(run):
    result = json.loads((run / 'result.json').read_text())
    arm = result['rgb_backing_reuse_arm']
    require(arm in ('A', 'B'), 'unrecognized backing reuse mode')
    return validate_native(run, optional_stages=(ALLOCATION,) if arm == 'B' else (),
                           additional_check=validate_reuse)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('run', type=Path)
    write_diagnostic(parser.parse_args().run)
