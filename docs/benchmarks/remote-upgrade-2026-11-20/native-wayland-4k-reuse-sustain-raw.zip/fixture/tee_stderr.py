"""Timestamp whole viewer JSON records and preserve the test's original stderr pipe."""
import json
from pathlib import Path
import sys
import threading
import time

from viewer_resources import sample_process


def relay(incoming, forwarded, complete, windows, clock=time.monotonic_ns):
    for line in incoming:
        arrived = clock()
        complete.write(line)
        complete.flush()
        if line.startswith(b'{') and b'jwm_remote_viewer_stats' in line:
            record = json.loads(line)
            if record.get('type') == 'jwm_remote_viewer_stats':
                print(json.dumps({'arrival_monotonic_ns': arrived, 'record': record},
                                 separators=(',', ':')), file=windows, flush=True)
        if forwarded is not None:
            try:
                forwarded.write(line)
                forwarded.flush()
            except BrokenPipeError:
                forwarded = None


def main(evidence, pid, start_ticks, viewer, sha256):
    done = threading.Event()
    sampler = threading.Thread(target=sample_process, args=(evidence / 'viewer-resources.jsonl',
                              done, pid, start_ticks, viewer, sha256))
    sampler.start()
    try:
        with (evidence / 'viewer-complete-stderr.log').open('xb') as complete, \
                (evidence / 'viewer-stage-windows.jsonl').open('x') as windows:
            relay(sys.stdin.buffer, sys.stdout.buffer, complete, windows)
    finally:
        done.set()
        sampler.join()
    (evidence / 'viewer-stderr-relay-complete').touch(exist_ok=False)


if __name__ == '__main__':
    evidence, pid, start_ticks, viewer, sha256 = sys.argv[1:]
    main(Path(evidence), int(pid), int(start_ticks), Path(viewer), sha256)
