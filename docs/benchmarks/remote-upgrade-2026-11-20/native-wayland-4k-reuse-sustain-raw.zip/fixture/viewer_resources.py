"""Sample one exact owned exec through procfs and replay resource diagnostics."""
import json
from pathlib import Path
import re
import stat
from statistics import median
import time
import os

SECOND = 10**9
DRM_MAJOR = 226
MEMORY_NAME = re.compile(r'drm-(?:memory|total|resident|shared|active|purgeable)-[a-zA-Z0-9_-]+')
MEMORY_VALUE = re.compile(r'(\d+) (B|KiB|MiB|GiB)')
UNIT_BYTES = {'B': 1, 'KiB': 1024, 'MiB': 1024**2, 'GiB': 1024**3}


def jsonl(writer, row):
    print(json.dumps(row, separators=(',', ':')), file=writer, flush=True)


def proc_start(path):
    suffix = (path / 'stat').read_text().rsplit(') ', 1)[1].split()
    if suffix[0] in ('Z', 'X'):
        raise ProcessLookupError
    return int(suffix[19])


def read_status(path):
    fields = dict(line.split(':', 1) for line in (path / 'status').read_text().splitlines() if ':' in line)
    rss, units = fields['VmRSS'].split()
    if units != 'kB':
        raise ValueError('unexpected procfs RSS unit')
    return {'rss_kib': int(rss), 'threads': int(fields['Threads'])}


def drm_counters(text):
    fields = dict(line.split(':', 1) for line in text.splitlines() if ':' in line)
    client_id = fields.get('drm-client-id', '').strip()
    if not client_id.isdecimal():
        return None, {}
    counters = {}
    for name, raw in fields.items():
        if MEMORY_NAME.fullmatch(name) and (parsed := MEMORY_VALUE.fullmatch(raw.strip())):
            count, unit = parsed.groups()
            counters[name] = int(count) * UNIT_BYTES[unit]
    return int(client_id), counters


def read_drm(path, fds, aliases):
    drm_fds = accessible = 0
    clients = {}
    for fd in fds:
        try:
            info = fd.stat()
        except OSError:
            continue  # Descriptor closed during this sample, or procfs access denied.
        if not stat.S_ISCHR(info.st_mode) or os.major(info.st_rdev) != DRM_MAJOR:
            continue
        drm_fds += 1
        try:
            text = (path / 'fdinfo' / fd.name).read_text()
        except OSError:
            continue
        accessible += 1
        client_id, counters = drm_counters(text)
        if client_id is not None:
            key = (info.st_rdev, client_id)
            alias = aliases.setdefault(key, f'drm-client-{len(aliases) + 1}')
            client = clients.setdefault(alias, {})
            for name, value in counters.items():
                client.setdefault(name, value)
    return {'drm_fds': drm_fds, 'fdinfo_readable': accessible, 'client_memory_bytes': clients}


def exe_identity(path):
    info = path.stat()
    return info.st_dev, info.st_ino


def sample_process(destination, quit_event, pid, start_ticks, exe, binary_sha256):
    proc = Path('/proc') / str(pid)
    aliases = {}
    end_reason = 'relay_closed'
    with destination.open('x') as out:
        try:
            expected = exe_identity(exe)
            launch_deadline = time.monotonic_ns() + 5 * SECOND
            while not quit_event.is_set():
                if proc_start(proc) != start_ticks:
                    raise ValueError('process start ticks changed')
                if exe_identity(proc / 'exe') == expected:
                    break
                if time.monotonic_ns() >= launch_deadline:
                    raise ValueError('expected viewer exec not reached')
                quit_event.wait(.02)
            if quit_event.is_set():
                return
            jsonl(out, {'type': 'identity', 'monotonic_ns': time.monotonic_ns(), 'pid': pid,
                        'start_ticks': start_ticks, 'exe_device': expected[0], 'exe_inode': expected[1],
                        'viewer_binary_sha256': binary_sha256})
            next_at = time.monotonic_ns()
            while not quit_event.is_set():
                began_at = time.monotonic_ns()
                if proc_start(proc) != start_ticks or exe_identity(proc / 'exe') != expected:
                    raise ValueError('viewer identity changed')
                core = read_status(proc)
                fds = list((proc / 'fd').iterdir())
                drm = read_drm(proc, fds, aliases)
                if proc_start(proc) != start_ticks or exe_identity(proc / 'exe') != expected:
                    raise ValueError('viewer identity changed during sample')
                ended_at = time.monotonic_ns()
                jsonl(out, {'type': 'sample', 'monotonic_ns': ended_at, 'acquisition_ns': ended_at - began_at,
                            **core, 'fds': len(fds), 'drm': drm})
                next_at += SECOND
                if next_at <= ended_at:
                    next_at += ((ended_at - next_at) // SECOND + 1) * SECOND
                quit_event.wait(max(0, (next_at - time.monotonic_ns()) / SECOND))
        except (FileNotFoundError, ProcessLookupError):
            end_reason = 'viewer_exited'
        except PermissionError:
            end_reason = 'procfs_inaccessible'
        except (ValueError, KeyError, IndexError):
            end_reason = 'identity_or_fields_invalid'
        except OSError:
            end_reason = 'procfs_error'
        finally:
            jsonl(out, {'type': 'end', 'monotonic_ns': time.monotonic_ns(), 'reason': end_reason})


def describe(samples):
    if not samples:
        return None
    ticks, values = zip(*samples)
    elapsed = [(tick - ticks[0]) / (60 * SECOND) for tick in ticks]
    avg_time = sum(elapsed) / len(elapsed)
    avg_value = sum(values) / len(values)
    squares = sum((tick - avg_time)**2 for tick in elapsed)
    slope = (sum((tick - avg_time) * (value - avg_value) for tick, value in zip(elapsed, values))
             / squares if squares else None)
    return {'samples': len(values), 'first': values[0], 'last': values[-1],
            'minimum': min(values), 'median': median(values), 'maximum': max(values),
            'last_minus_first': values[-1] - values[0],
            'least_squares_units_per_minute': round(slope, 5) if slope is not None else None}


def summarize(rows, start, end):
    retained = [row for row in rows if row['type'] == 'sample' and start <= row['monotonic_ns'] < end]
    ticks = [row['monotonic_ns'] for row in retained]
    gap_seconds = (max(b - a for a, b in zip([start, *ticks], [*ticks, end])) / SECOND)
    bins = len({(tick - start) // SECOND for tick in ticks})
    seconds = (end - start) // SECOND
    drm = {}
    for row in retained:
        for alias, counters in row['drm']['client_memory_bytes'].items():
            for key, value in counters.items():
                drm.setdefault(alias, {}).setdefault(key, []).append((row['monotonic_ns'], value))
    report = {
        'samples': len(retained), 'one_second_bins_with_a_sample': bins,
        'maximum_sample_gap_seconds_including_boundaries': gap_seconds,
        'coverage_sufficient': bins >= seconds - 2 and gap_seconds <= 3,
        'drm_clients_reported': {alias: {key: describe(samples) for key, samples in values.items()}
                                 for alias, values in drm.items() if values},
        'fdinfo_observable_samples': sum(row['drm']['fdinfo_readable'] > 0 for row in retained),
    }
    for key in ('rss_kib', 'threads', 'fds', 'acquisition_ns'):
        report[key] = describe([(row['monotonic_ns'], row[key]) for row in retained])
    for key in ('drm_fds', 'fdinfo_readable'):
        report[key] = describe([(row['monotonic_ns'], row['drm'][key]) for row in retained])
    return report


def write_report(run, phase):
    result = json.loads((run / 'result.json').read_text())
    rows = [json.loads(line) for line in (run / 'viewer/viewer-resources.jsonl').read_text().splitlines()]
    start = result['observer_start']
    warmup_start, interval_start, interval_end = (start[key] for key in
        ('monotonic_ns', 'score_start_ns', 'score_end_ns'))
    if interval_start - warmup_start != 30 * SECOND or interval_end - interval_start != 120 * SECOND:
        raise ValueError('resource run must have 30 s warmup followed by 120 s')
    identity = rows[0] if rows and rows[0]['type'] == 'identity' else None
    if any(a['monotonic_ns'] >= b['monotonic_ns'] for a, b in zip(rows, rows[1:])):
        raise ValueError('resource sample times were not strictly ordered')
    same_exec = bool(identity and identity['monotonic_ns'] < interval_start
                     and identity['viewer_binary_sha256'] == result['viewer_binary_sha256'])
    reuse = phase['rgb_backing_reuse']
    if result['run_id'] != 104 or reuse['arm'] != 'B' or not reuse['confirmed_activation']:
        raise ValueError('expected run 104 with operational RGB backing reuse')
    warmup = summarize(rows, warmup_start, interval_start)
    observed = summarize(rows, interval_start, interval_end)
    end_reason = rows[-1]['reason'] if rows and rows[-1]['type'] == 'end' else 'missing_end'
    report = {
        'schema_version': 1, 'run_id': result['run_id'], 'diagnostic_only': True,
        'warmup_seconds': 30, 'observation_seconds': 120,
        'identity_verified_before_observation': same_exec, 'viewer_identity': identity,
        'viewer_binary_sha256': result['viewer_binary_sha256'],
        'observer_binary_sha256': result['viewer_test_binary_sha256'],
        'host_binary_sha256': result['host_binary_sha256'],
        'complete': same_exec and observed['coverage_sufficient']
                    and end_reason in ('relay_closed', 'viewer_exited'),
        'sampler_end_reason': end_reason,
        'warmup': warmup, 'observation': observed,
        'rgb_backing_reuse': reuse,
        'scope': ('Owned local viewer process only. Linux procfs VmRSS and FD link counts are snapshots. '
                  'DRM fdinfo rows are optional driver counters, observed per distinct client and metric. '
                  'Memory shared across clients may overlap. Missing counters are not zero. No hierarchy '
                  'or total GPU allocation is inferred. Slopes are descriptive for this interval.'),
    }
    (run / 'resource-diagnostic.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2), flush=True)
    if not report['complete']:
        raise RuntimeError('resource identity or observation coverage incomplete; inspect the saved diagnostic')
