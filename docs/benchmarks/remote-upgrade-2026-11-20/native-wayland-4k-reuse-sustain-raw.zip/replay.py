"""Replay the completed 30+120 s owned viewer resource diagnostic."""
import contextlib
import io
import json
from pathlib import Path
from statistics import linear_regression, median
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent / 'fixture'))
from validate_reuse import write_diagnostic
from viewer_resources import write_report

SECOND = 10**9


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def load(path):
    return json.loads(path.read_text())


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line]


def metrics(values):
    ticks, measurements = zip(*values)
    trend = (linear_regression([(t - ticks[0]) / (60 * SECOND) for t in ticks], measurements).slope
             if len(values) > 1 else None)
    return {'samples': len(values), 'first': measurements[0], 'last': measurements[-1],
            'minimum': min(measurements), 'median': median(measurements), 'maximum': max(measurements),
            'last_minus_first': measurements[-1] - measurements[0],
            'least_squares_units_per_minute': round(trend, 5) if trend is not None else None}


def check_interval(resource_rows, start, end, declared):
    selected = [row for row in resource_rows if start <= row['monotonic_ns'] < end]
    ticks = [row['monotonic_ns'] for row in selected]
    gaps = [y - x for x,y in zip([start, *ticks], [*ticks, end])]
    bins = {(tick - start) // SECOND for tick in ticks}
    require(len(bins) >= (end - start) // SECOND - 2 and max(gaps) <= 3 * SECOND,
            'resource observation has insufficient sample coverage')
    require(declared['samples'] == len(selected)
            and declared['one_second_bins_with_a_sample'] == len(bins)
            and declared['maximum_sample_gap_seconds_including_boundaries'] == max(gaps) / SECOND
            and declared['coverage_sufficient'], 'resource coverage does not replay')
    measurements = {}
    for name in ('rss_kib', 'threads', 'fds', 'acquisition_ns'):
        series = [(row['monotonic_ns'], row[name]) for row in selected]
        require(all(type(value) is int and value > 0 for _, value in series),
                f'invalid {name} values')
        measurements[name] = metrics(series)
    for name in ('drm_fds', 'fdinfo_readable'):
        measurements[name] = metrics([(row['monotonic_ns'], row['drm'][name]) for row in selected])
    drm = {}
    for row in selected:
        data = row['drm']
        require(0 <= data['fdinfo_readable'] <= data['drm_fds'] <= row['fds'],
                'DRM sample counts differ from viewer FD extent')
        for client, counters in data['client_memory_bytes'].items():
            require(client.startswith('drm-client-'), 'DRM client ID was not anonymized')
            for counter, value in counters.items():
                require(type(value) is int and value >= 0, 'invalid DRM memory counter')
                drm.setdefault(client, {}).setdefault(counter, []).append((row['monotonic_ns'], value))
    measurements['drm_clients_reported'] = {client: {name: metrics(series) for name, series in counters.items()}
                                             for client, counters in drm.items()}
    for name, value in measurements.items():
        require(declared[name] == value, f'{name} does not replay')
    require(declared['fdinfo_observable_samples'] == sum(row['drm']['fdinfo_readable'] > 0 for row in selected),
            'fdinfo coverage differs')


def replay(root):
    evidence = root / 'evidence'
    phase = load(evidence / 'phase-diagnostic.json')
    resource = load(evidence / 'resource-diagnostic.json')
    result = load(evidence / 'result.json')
    terminal = load(evidence / 'terminal-proof.json')
    require(terminal['controller_pid_ended'] and terminal['terminal_viewer_state'] == 'closed'
            and terminal['temporary_key_absent'] and terminal['observer_test_passed']
            and terminal['viewer_stderr_relay_drained'], 'missing actual run completion')
    events = rows(evidence / 'viewer/viewer-events.jsonl')
    require(events[-1]['state'] == 'closed' and not any(row.get('state') == 'failed' for row in events),
            'managed viewer did not close cleanly')

    with contextlib.redirect_stdout(io.StringIO()):
        replayed_phase = write_diagnostic(evidence)
        write_report(evidence, replayed_phase)
    replayed_resource = load(evidence / 'resource-diagnostic.json')
    require(phase == replayed_phase and resource == replayed_resource,
            'phase or resource validator did not reproduce the original diagnostic')
    require(phase['hardware_rgb_download_observations_all_raw_windows'] == 0
            and phase['rgb_backing_reuse']['confirmed_activation']
            and resource['complete'] and resource['diagnostic_only'], 'missing reuse or no-download proof')
    pins = load(evidence / 'binary-pins.json')
    require(all(pins[role] == phase[f'{role}_binary_sha256'] == resource[f'{role}_binary_sha256']
                for role in ('host', 'viewer', 'observer')), 'pinned binaries differ across evidence')

    resources = rows(evidence / 'viewer/viewer-resources.jsonl')
    require(resources[0]['type'] == 'identity' and resources[-1]['type'] == 'end'
            and all(row['type'] == 'sample' for row in resources[1:-1])
            and all(x['monotonic_ns'] < y['monotonic_ns'] for x,y in zip(resources, resources[1:])),
            'unexpected resource sampler lifecycle')
    warm, start, end = (result['observer_start'][key] for key in
                        ('monotonic_ns','score_start_ns','score_end_ns'))
    require(start - warm == 30 * SECOND and end - start == 120 * SECOND
            and resources[0]['monotonic_ns'] < warm and end <= resources[-1]['monotonic_ns'],
            'owned sampler did not span the observer interval')
    check_interval(resources[1:-1], warm, start, resource['warmup'])
    check_interval(resources[1:-1], start, end, resource['observation'])

    live = load(evidence / 'live-process-witness.json')
    lineage = live['process_lineage']
    require(live['viewer_identity'] == resources[0] == resource['viewer_identity']
            and start <= live['monotonic_ns'] < end
            and live['viewer_exec_matches_pinned_file_device_inode']
            and live['observer_exec_matches_pinned_file_device_inode']
            and lineage[0]['pid'] == resources[0]['pid']
            and lineage[0]['start_ticks'] == resources[0]['start_ticks']
            and lineage[-1]['pid'] == live['controller_pid'] == terminal['controller_pid']
            and all(a['parent_pid'] == b['pid'] for a,b in zip(lineage,lineage[1:])),
            'independent live procfs witness did not match the owned viewer/controller')
    return {
        'complete': True, 'warmup_seconds': 30, 'observation_seconds': 120,
        'runtime_identity': resource['viewer_identity'], 'controller': terminal,
        'warmup': resource['warmup'], 'observation': resource['observation'],
        'native_evidence': {
            'codec': phase['codec'], 'presentation': phase['presentation'], 'extent': phase['extent'],
            'host_binary_sha256': phase['host_binary_sha256'], 'viewer_binary_sha256': phase['viewer_binary_sha256'],
            'observer_binary_sha256': phase['observer_binary_sha256'],
            'matching_roi_markers_in_observation': phase['matching_scored_roi_markers'],
            'matched_whole_observer_windows': phase['matched_whole_observer_windows'],
            'hardware_rgb_download_observations': phase['hardware_rgb_download_observations_all_raw_windows'],
            'reuse': phase['rgb_backing_reuse'],
        },
    }


if __name__ == '__main__':
    print(json.dumps(replay(Path(sys.argv[1])), indent=2))
