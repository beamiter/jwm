# Owned native Wayland resource diagnostic

Extract this archive and run `python3 -B replay.py .` offline. The replay
validates the camera-free 4K ROI, same-session raw and managed telemetry,
candidate backing reuse, zero RGB downloads and resource sample coverage.
It replays both reported resource intervals and checks the pinned executable
identity independently witnessed while the controller and viewer were active.

The raw evidence keeps the 30 s warmup and 120 s observation with its original
viewer-machine monotonic clock. Source records use their local clock. The
opaque authenticated session ID is aliased consistently. The host log includes
typed rows, and the stderr excerpt includes the exact one-time reuse line.
The complete structured stderr windows are a separate file. Viewer process
identity metadata and measurements contain no command lines, environment, FD
targets or raw fdinfo. DRM fdinfo counters are per-client; memory may overlap
between clients, and missing metrics are unobserved. This sample describes one
viewer process in the private native Wayland configuration.
