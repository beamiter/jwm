#!/usr/bin/env python3
"""Publish and replay the normal-network P07 ReleaseAll software measurement."""

import argparse
import hashlib
import json
from pathlib import Path
import re
from zipfile import ZIP_DEFLATED, ZipFile

from release_metrics import (
    CLOCKS, METRICS, PROBE_KEYS, SAMPLES, SESSIONS, distribution, observation, reconcile_ledger, require, trial_replay,
    verify_phase_slots,
)


STEM = "x11-release-all-software-latency"
MAX_FILE_BYTES = 15_000_000
SHA = re.compile(r"[0-9a-f]{64}")
PUBLIC_NAME = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,79}")
LABEL = re.compile(r"[a-z][a-z0-9_-]{0,63}")
PEER = re.compile(rb"(?<![0-9.])(?:192\.168|10\.\d{1,3}|172\.(?:1[6-9]|2\d|3[01]))\.\d{1,3}\.\d{1,3}(?![0-9.])")
TOP = (
    "schema_version", "profile", "metric", "pilot", "samples_requested_per_session", "sessions_requested",
    "deadline_ms", "warmup_seconds", "score_seconds", "warmup_samples_requested",
    "viewer_binary_sha256", "local_binary_sha256", "host_binary_sha256", "fixture_sha256", "qualified_population",
)
SESSION = (
    "session_index", "requested", "attempted", "not_attempted", "shortcut_issued",
    "warmup_start_ns", "score_start_ns", "score_end_ns",
)
SAMPLE = (
    "phase", "slot", "planned_slot_ns", "started_ns", "observations_finished_locally_ns",
    "seq", "held_keycode", "viewer_issue_ns", "host_edge_ns", "viewer_receipt_ns",
    "viewer_local_key_up_ns", "latency_ns", "grab_before", "grab_after", "host_held_before",
    "host_held_after", "viewer_held_before", "viewer_held_before_cleanup", "viewer_held_after_cleanup",
)
EDGE = ("event", "seq", "index", "type", "detail", "host_ns", "viewer_receipt_ns")
ACTION = ("event", "at_ns", "type", "detail")
ENDPOINT = (
    "authenticated_scope_equal", "host_auth_starts", "viewer_auth_starts", "final_viewer_stats",
    "host_exit", "viewer_exit", "observer_exit", "host_held_when_finished", "host_stat_windows",
    "host_interface", "viewer_interface", "viewer_dimensions", "viewer_dimensions_at_close",
)
ROUTE = ("source_dimensions", "capture_fps", "clipboard")
TRIAL_FRAME = ("source_dimensions", "encoded_dimensions", "sequence", "source_epoch", "geometry_epoch")
NORMAL_PATHS = {
    "loopback": ("unshaped IPv4 loopback", "same-device stdio"),
    "dual": ("unshaped SSH IPv4 local forward over an ordinary link with an Ubuntu Wi-Fi segment",
             "independent SSH TCP stdio control and observer connection, no multiplexing with data forward"),
}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, allow_nan=False) + "\n").encode()


def read(path):
    with path.open("rb") as source:
        result = source.read(MAX_FILE_BYTES + 1)
    require(len(result) <= MAX_FILE_BYTES, "release evidence exceeds the bounded file size")
    return result


def strict_value(value):
    if value is None or type(value) in {int, bool}:
        return value
    if type(value) is list:
        return [strict_value(item) for item in value]
    if type(value) is str and (LABEL.fullmatch(value) or SHA.fullmatch(value)):
        return value
    # Keep malformed field presence explicit and omit arbitrarily supplied data.
    return {"unexpected_value_type": type(value).__name__}


def fields(obj, names):
    if type(obj) is not dict:
        return {"unexpected_record_type": type(obj).__name__}
    return {key: strict_value(obj[key]) for key in names if key in obj}


def array(obj, key, sanitize):
    items = obj.get(key)
    return [sanitize(item) for item in items] if type(items) is list else strict_value(items)


def event_status(obj, key):
    value = obj.get(key)
    return value if type(value) is str and LABEL.fullmatch(value) else None


def sanitize_sample(sample):
    row = fields(sample, SAMPLE)
    if type(sample) is not dict:
        return row
    row["status"] = event_status(sample, "status")
    row["source_edges"] = array(sample, "source_edges", lambda edge: fields(edge, EDGE))
    if "viewer_actions" in sample:
        row["viewer_actions"] = array(sample, "viewer_actions", lambda action: fields(action, ACTION))
    if "stage" in sample:
        row["stage"] = event_status(sample, "stage")
    if sample.get("error"):
        row["error_class"] = safe_error(sample["error"])
    return row


def sanitize_session(session):
    row = fields(session, SESSION)
    if type(session) is not dict:
        return row
    row["status"] = event_status(session, "status")
    row["setup_status"] = event_status(session, "setup_status")
    row["samples"] = array(session, "samples", sanitize_sample)
    row["warmup_samples"] = array(session, "warmup_samples", sanitize_sample)
    row["probe_keycodes"] = fields(session.get("probe_keycodes"), PROBE_KEYS)
    row["endpoint_witness"] = sanitize_endpoint(session.get("endpoint_witness"))
    if session.get("error"):
        row["error_class"] = safe_error(session["error"])
    if session.get("detail") == "unexpected source reply type":
        row["failure_code"] = "unexpected_source_reply_during_teardown"
    return row


def safe_error(value):
    return value if type(value) is str and re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,63}", value) else "omitted"


def sanitize_endpoint(endpoint):
    row = fields(endpoint, ENDPOINT)
    if type(endpoint) is not dict:
        return row
    for party in ("viewer", "host"):
        ids = endpoint.get(party + "_session_ids", [])
        row[party + "_session_aliases"] = [
            digest(b"P07 release session alias " + value.encode()) for value in ids
            if type(value) is str and re.fullmatch(r"[0-9a-f]{32,128}", value)
        ] if type(ids) is list else []
    def frame_line(frame):
        jpeg = type(frame) is dict and frame.get("codec") == "JPEG"
        return fields(frame, TRIAL_FRAME) | {"codec": "JPEG" if jpeg else "other"}
    row["observed_route"] = array(endpoint, "observed_route", frame_line)
    if "viewer_authenticated_grant" in endpoint:
        row["viewer_keyboard_and_pointer_granted"] = (
            endpoint["viewer_authenticated_grant"] == "jwm-remote: connected; keyboard + pointer; clipboard off"
        )
    if "host_authenticated_grant" in endpoint:
        row["host_keyboard_and_pointer_granted"] = endpoint["host_authenticated_grant"] == [
            "jwm-remote: authenticated session started (screen + pointer + keyboard)"
        ]
    if type(endpoint.get("host_keymap_diagnostic")) is list:
        row["host_keymap_diagnostic_lines"] = len(endpoint["host_keymap_diagnostic"])
    if type(endpoint.get("keymap_alignment")) is dict:
        align = endpoint["keymap_alignment"]
        state_fields = ("common_bound", "differing_keycodes", "modifiers_equal", "compatible")
        row["keymap_alignment"] = fields(align, ("source_xkb_sha256", "viewer_map_loaded")) | {
            "authority_matches": align.get("authority") == "private Ubuntu source Xvfb",
            "before": fields(align.get("before"), state_fields),
            "after": fields(align.get("after"), state_fields),
        }
    return row


def sanitize_ledger(path):
    if not path.is_file():
        return {"status": "missing", "rows": 0}, []
    data = read(path)
    rows = []
    ended = data.endswith(b"\n") or not data
    malformed = 0
    for raw in data.splitlines():
        try:
            row = json.loads(raw)
        except (ValueError, UnicodeError):
            malformed += 1
        else:
            if type(row) is not dict:
                malformed += 1
                continue
            rows.append(sanitize_sample(row))
    return {
        "status": "captured" if not malformed and ended else "truncated_or_invalid_jsonl",
        "rows": len(rows), "malformed_rows": malformed, "bytes": len(data),
        "original_sha256": digest(data),
    }, rows


def capture_json(result, sanitizer):
    if not result.is_file():
        return {"status": "missing"}, None
    raw = read(result)
    capture = {"bytes": len(raw), "original_sha256": digest(raw)}
    try:
        data = json.loads(raw)
    except (ValueError, UnicodeError):
        return capture | {"status": "truncated_or_invalid_json"}, None
    if type(data) is not dict:
        return capture | {"status": "invalid_top_level"}, None
    return capture | {"status": "captured"}, sanitizer(data)


def sanitized_result(result):
    row = fields(result, TOP) | {"sessions": array(result, "sessions", sanitize_session)}
    profile = result.get("profile") if type(result.get("profile")) is str else None
    row["clock"] = CLOCKS.get(profile) if result.get("clock") == CLOCKS.get(profile) else None
    route = result.get("route")
    row["route"] = fields(route, ROUTE)
    if type(route) is dict and profile in NORMAL_PATHS:
        for key, expected in zip(("application_path", "observer_path"), NORMAL_PATHS[profile]):
            row["route"][key] = expected if route.get(key) == expected else None
        row["route"]["codec"] = "JPEG" if route.get("codec") == "JPEG" else "other"
    return row


def collect(profiles, fixture_files, fixture_manifest=None, *, profile_fixtures=None,
            initial_dual_pilot=None, calibrated_dual_pilot=None, build_provenance=None, dual_link_dir=None):
    entries = {}
    for profile, result in profiles.items():
        prefix = "run/" + profile
        if result is None:
            entries[prefix + "/capture.json"] = encoded({"status": "missing", "checkpoints": {}, "ledgers": {}})
            continue
        if result.is_dir():
            result = result / ("raw/result.json" if (result / "raw").is_dir() else "result.json")
        capture, data = capture_json(result, sanitized_result)
        if data is not None:
            entries[prefix + "/result.json"] = encoded(data)
        capture["checkpoints"] = {}
        capture["ledgers"] = {}
        for index in range(1, SESSIONS + 1):
            folder = result.parent / f"session-{index}"
            checkpoint, session = capture_json(folder / "session.json", sanitize_session)
            if checkpoint["status"] != "missing":
                capture["checkpoints"][str(index)] = checkpoint
            if session is not None:
                entries[prefix + f"/session-{index}/session.json"] = encoded(session)
            ledger, rows = sanitize_ledger(folder / "samples.jsonl")
            source_keymap = folder / "host-authority.xkb"
            if source_keymap.is_file():
                ledger["source_xkb_retained_sha256"] = digest(read(source_keymap))
            capture["ledgers"][str(index)] = ledger
            if ledger["status"] != "missing":
                entries[prefix + f"/session-{index}/samples.jsonl"] = b"".join(
                    json.dumps(row, separators=(",", ":")).encode() + b"\n" for row in rows
                )
        exit_file = terminal_marker(result)
        if exit_file is not None:
            data = read(exit_file).decode(errors="replace").strip()
            capture["controller_exit"] = int(data) if re.fullmatch(r"-?[0-9]+", data) else None
        entries[prefix + "/capture.json"] = encoded(capture)

    fixtures = {}
    for source in fixture_files:
        source_member(entries, fixtures, source.name, source)
    for profile, source in (profile_fixtures or {}).items():
        if source is not None:
            require(profile in METRICS, "unrecognized profile fixture")
            source_member(entries, fixtures, profile + "/" + source.name, source)
    if initial_dual_pilot is not None:
        attach_pilot(entries, initial_dual_pilot, "initial")
    if calibrated_dual_pilot is not None:
        attach_pilot(entries, calibrated_dual_pilot, "calibrated")
    if dual_link_dir is not None:
        for phase in ("before", "after"):
            path = dual_link_dir / f"link-{phase}.log"
            if path.is_file():
                entries[f"run/dual/link-{phase}.json"] = encoded(link_snapshot(read(path)))
    if build_provenance is not None:
        data = read(build_provenance)
        entries["build/provenance.json"] = encoded(normalize_build(json.loads(data)) |
                                                    {"input_sha256": digest(data)})
    if fixture_manifest is not None:
        known = {}
        for line in read(fixture_manifest).decode().splitlines():
            pin = re.fullmatch(r"([0-9a-f]{64})  ([A-Za-z0-9_.-]+)", line)
            require(pin is not None and pin[2] not in known, "invalid fixture sha256 manifest")
            known[pin[2]] = pin[1]
        require(known and all(name in fixtures and checksum == fixtures[name]["source_sha256"]
                              for name, checksum in known.items()), "supplied fixture pins differ from the copied fixture")
        entries["fixture/recorded-sha256.json"] = encoded(known)
    for name in ("publish_release.py", "release_metrics.py"):
        entries["replay/" + name] = read(Path(__file__).with_name(name))
    entries["fixture/index.json"] = encoded(fixtures)
    return entries


def source_member(entries, fixtures, name, source):
    require(all(PUBLIC_NAME.fullmatch(piece) for piece in name.split("/")) and name not in fixtures,
            "invalid or repeated fixture artifact name")
    data = read(source)
    packaged = PEER.sub(b"<private-peer>", data)
    entries["fixture/" + name] = packaged
    fixtures[name] = {
        "source_sha256": digest(data), "archived_sha256": digest(packaged), "private_peer_redacted": data != packaged,
    }


def terminal_marker(result):
    adjacent = (result.with_name("live.exit"), result.with_name("controller.exit"))
    siblings = (result.parent.parent / "controller.exit", result.parent.parent / "live.exit")
    paths = adjacent + siblings if result.parent.name == "raw" else adjacent
    return next((file for file in paths if file.is_file()), None)


def attach_pilot(entries, root, kind):
    result = root / "raw/result.json" if root.is_dir() and (root / "raw").is_dir() else (
        root / "result.json" if root.is_dir() else root)
    capture, sanitized = capture_json(result, sanitized_result)
    require(sanitized is not None and sanitized["profile"] == "dual" and sanitized["pilot"] is True,
            "dual pilot must have a distinct unscored result")
    marker = terminal_marker(result)
    require(marker is not None, "dual pilot controller terminal status missing")
    controller = int(read(marker).strip())
    require(controller != 0, "dual pilot lacks a failed terminal status")
    viewer = read(result.parent / "session-1/viewer.log")
    phrases = {
        "x11_keymaps_differ": b"X11 keymaps differ",
        "keyboard_disabled": b"keyboard is disabled",
        "pointer_only_diagnostic": b"pointer only; keyboard disabled",
    }
    report = {
        "capture": capture, "controller_exit": controller, "result": sanitized,
        "log_diagnostics": {field: viewer.lower().count(phrase.lower()) for field, phrase in phrases.items()} |
                           {"viewer_log_sha256_before_omission": digest(viewer)},
    }
    if kind == "calibrated":
        folder = result.parent / "session-1"
        checkpoint, session = capture_json(folder / "session.json", sanitize_session)
        ledger, rows = sanitize_ledger(folder / "samples.jsonl")
        report["checkpoint"] = checkpoint
        report["session"] = session
        report["ledger"] = ledger
        report["append_only_actions"] = rows
        keymap = folder / "host-authority.xkb"
        report["owned_source_xkb_sha256"] = digest(read(keymap)) if keymap.is_file() else None
    entries[f"run/pilot/{kind}-dual.json"] = encoded(report)


def link_snapshot(raw):
    text = raw.decode(errors="replace")
    packet = re.search(r"([0-9]+) packets transmitted, ([0-9]+)(?: packets)? received", text)
    timing = re.search(r"(?:rtt|round-trip) min/avg/max/(?:mdev|stddev) = ([0-9.]+)/([0-9.]+)/([0-9.]+)/([0-9.]+) ms", text)
    return {
        "original_sha256": digest(raw), "bytes": len(raw),
        "packets": dict(zip(("transmitted", "received"), map(int, packet.groups()))) if packet else None,
        "rtt_ms": dict(zip(("min", "avg", "max", "mdev"), map(float, timing.groups()))) if timing else None,
    }


def normalize_build(record):
    require(record["schema_version"] == 1 and record["profile"] == "release" and
            record["cargo_default_features"] is False and record["cargo_features"] == ["remote-h264"],
            "unexpected recorded build profile")
    expected_files = {"Cargo.lock", "Cargo.toml", "src/remote/client.rs", "src/remote/h264.rs", "src/remote/host.rs"}
    sources = record["tracked_source_sha256"]
    require(sources.keys() == expected_files and all(SHA.fullmatch(value) for value in sources.values()),
            "release build source pins invalid")
    result = {
        "schema_version": 1, "profile": "release", "cargo_default_features": False,
        "cargo_features": ["remote-h264"], "tracked_source_sha256": sources,
    }
    sonames = {
        "mint": ["libavcodec.so.60", "libavutil.so.58", "libswscale.so.7"],
        "ubuntu": ["libavcodec.so.58", "libavutil.so.56", "libswscale.so.5"],
    }
    for name, expected in sonames.items():
        toolchain = record[name]
        require(SHA.fullmatch(toolchain["binary_sha256"]) and toolchain["build_exit"] == 0 and
                re.fullmatch(r"rustc [0-9]+\.[0-9]+\.[0-9]+ \([a-f0-9]+ [0-9-]+\)", toolchain["compiler"]) and
                toolchain["ffmpeg_link_sonames"] == expected, "release build binary or FFmpeg pins invalid")
        result[name] = {key: toolchain[key] for key in ("binary_sha256", "build_exit", "compiler", "ffmpeg_link_sonames")}
    tools = ("mapped_nv12_layout_unit_test_exit", "vaapi_same_surface_fallback_test_exit")
    require(all(type(record["mint"][key]) is int for key in tools) and record["ubuntu"]["source_manifest_matches_mint"] is True,
            "release source comparison or focused test exit missing")
    result["mint"].update({key: record["mint"][key] for key in tools})
    result["ubuntu"]["source_manifest_matches_mint"] = True
    before = record["ubuntu_pre_fix"]
    require(before == {"build_exit": 101, "compiler_error": "av_image_copy_plane_uc_from unavailable"},
            "unexpected Ubuntu pre-fix build outcome")
    result["ubuntu_pre_fix"] = before
    return result


def attach_build_to_report(entries, profiles):
    record = json.loads(entries["build/provenance.json"])
    sha = record.pop("input_sha256")
    require(SHA.fullmatch(sha), "build provenance record lacks original digest")
    build = normalize_build(record)
    associations = {}
    for profile, role in (("loopback", "mint"), ("dual", "ubuntu")):
        pins = profiles[profile]["binary_pins"]
        if pins is None:
            associations[profile] = None
            continue
        associated = (pins["viewer_binary_sha256"] == build["mint"]["binary_sha256"] and
                      pins["host_binary_sha256"] == build[role]["binary_sha256"])
        require(associated, "release build provenance differs from the actual " + profile + " binary pins")
        associations[profile] = "both_endpoint_pins_matched"
    return build | {"input_sha256": sha, "profile_associations": associations}


def pilot_report(entries):
    pilot = json.loads(entries["run/pilot/initial-dual.json"])
    raw = pilot["result"]
    require(raw["profile"] == "dual" and raw["pilot"] is True and pilot["controller_exit"] != 0,
            "diagnostic pilot must be independently failed and unscored")
    samples = [row for trial in raw["sessions"] for row in trial["warmup_samples"] + trial["samples"]]
    log = pilot["log_diagnostics"]
    return {
        "status": "failed", "controller_exit": pilot["controller_exit"], "scored": False,
        "fixture_sha256": raw["fixture_sha256"],
        "endpoint_binary_sha256": {"viewer": raw["viewer_binary_sha256"], "host": raw["host_binary_sha256"]},
        "reason": "x11_keymaps_differ_keyboard_disabled" if log["x11_keymaps_differ"] and log["keyboard_disabled"] else None,
        "log_diagnostics": log,
        "sessions": [{"session_index": trial["session_index"], "setup_status": trial["setup_status"],
                      "status": trial["status"], "scored_samples_attempted": trial["attempted"],
                      "scored_samples_not_attempted": trial["not_attempted"], "error_class": trial.get("error_class")}
                     for trial in raw["sessions"]],
        "observed_attempt_statuses": [row["status"] for row in samples],
    }


def calibrated_pilot_report(entries):
    pilot = json.loads(entries["run/pilot/calibrated-dual.json"])
    raw = pilot["result"]
    require(raw["profile"] == "dual" and raw["pilot"] is True and pilot["controller_exit"] != 0 and
            raw["metric"] == METRICS["dual"] and raw["clock"] == CLOCKS["dual"],
            "calibrated dual pilot failed scope or terminal verification")
    session, = raw["sessions"]
    require(pilot["checkpoint"]["status"] == pilot["ledger"]["status"] == "captured" and pilot["session"] == session,
            "calibrated dual pilot result differs from recorded checkpoint")
    samples = session["warmup_samples"] + session["samples"]
    late_edges = reconcile_ledger(pilot["append_only_actions"], samples)
    original_by_slot = {(row["phase"], row["slot"]): row for row in pilot["append_only_actions"]}
    endpoint = session["endpoint_witness"]
    alignment = endpoint["keymap_alignment"]
    keys = session["probe_keycodes"]
    require(alignment["authority_matches"] is True and alignment["after"]["compatible"] is True and
            alignment["source_xkb_sha256"] == pilot["owned_source_xkb_sha256"] and
            endpoint["viewer_keyboard_and_pointer_granted"] is True and
            endpoint["host_keyboard_and_pointer_granted"] is True and endpoint["host_keymap_diagnostic_lines"] == 0,
            "calibrated pilot does not prove negotiated keyboard and pointer")
    requested = raw["samples_requested_per_session"]
    start, end = session["score_start_ns"], session["score_end_ns"]
    require(end - start == raw["score_seconds"] * 1_000_000_000, "calibrated pilot schedule differs")
    verify_phase_slots(session["samples"], "scored", start, end, requested)
    extended = []
    for original in session["samples"]:
        observed = observation(original, "dual", raw["deadline_ms"] * 1_000_000, keys)
        if observed["status"] != "passed":
            observed["phase_offset_ns"] = original["planned_slot_ns"] - start
            observed["ended_after_scoring_window_ns"] = original["observations_finished_locally_ns"] - end
            observed["stage"] = original.get("stage")
            observed["error_class"] = original.get("error_class")
            observed["shortcut_issued"] = "viewer_issue_ns" in original
            identity = (original["phase"], original["slot"])
            observed["source_edges_observed_before_timeout"] = len(original_by_slot[identity]["source_edges"])
            observed["late_source_edges_after_observation"] = late_edges.get(identity, [])
        extended.append(observed)
    attempted = sum("seq" in row for row in session["samples"])
    issued = sum("viewer_issue_ns" in row for row in session["samples"])
    require(session["attempted"] == attempted and session["not_attempted"] == requested - attempted and
            session["shortcut_issued"] == issued, "calibrated pilot request and outcome counts differ")
    return {
        "status": "failed", "controller_exit": pilot["controller_exit"], "scored": False,
        "reason": ("reacquire_deadline_before_release_shortcut" if any(
            row["status"] == "timeout" and row["stage"] == "reacquire" and not row["shortcut_issued"]
            for row in extended) else "calibrated_pilot_attempt_failed"),
        "metric": METRICS["dual"],
        "fixture_sha256": raw["fixture_sha256"],
        "endpoint_binary_sha256": {"viewer": raw["viewer_binary_sha256"], "host": raw["host_binary_sha256"]},
        "timing": {key: raw[key] for key in ("deadline_ms", "warmup_seconds", "score_seconds")},
        "warmup_observed": len(session["warmup_samples"]),
        "scored_slot_records": len(extended), "attempted": attempted, "shortcut_issued": issued,
        "not_attempted": requested - attempted, "keymap_alignment": alignment,
        "diagnostic_only_distribution": distribution(extended, requested),
        "samples": extended,
    }


def expected_result(result, profile, fixture_sha):
    require(result["schema_version"] == 1 and result["pilot"] is False and
            result["profile"] == profile and result["metric"] == METRICS[profile] and
            result["clock"] == CLOCKS[profile] and result["samples_requested_per_session"] == SAMPLES and
            result["sessions_requested"] == SESSIONS, "requested formal profile, samples or clock contract differs")
    timings = {
        "deadline_ms": result["deadline_ms"], "warmup_seconds": result["warmup_seconds"],
        "score_seconds": result["score_seconds"], "warmup_samples": result["warmup_samples_requested"],
    }
    require(all(type(val) is int for val in timings.values()) and timings["deadline_ms"] >= 50 and
            timings["warmup_seconds"] >= 30 and timings["score_seconds"] == 60 and timings["warmup_samples"] > 0,
            "requested warmup, scoring duration or deadline differs")
    pins = {key: result[key] for key in ("viewer_binary_sha256", "host_binary_sha256", "fixture_sha256")}
    require(all(type(value) is str and SHA.fullmatch(value) for value in pins.values()), "binary or fixture SHA pins missing")
    require(fixture_sha is None or pins["fixture_sha256"] == fixture_sha, "supplied fixture differs from runtime hash")
    if "local_binary_sha256" in result:
        require(result["local_binary_sha256"] == pins["viewer_binary_sha256"], "viewer binary digest aliases differ")
    if profile == "loopback":
        require(pins["viewer_binary_sha256"] == pins["host_binary_sha256"], "loopback artifacts used different binary pins")
    application, observer = NORMAL_PATHS[profile]
    require(result["route"] == {"application_path": application, "observer_path": observer, "source_dimensions": [1920, 1080],
                                "capture_fps": 15, "codec": "JPEG", "clipboard": "disabled"}, "normal test route changed")
    require(type(result["sessions"]) is list, "session result list is missing or truncated")
    return pins, timings


def report_profile(entries, profile, fixture_sha):
    prefix = "run/" + profile
    capture = json.loads(entries[prefix + "/capture.json"])
    pinned = None
    timings = None
    issues = []
    sessions = []
    present = prefix + "/result.json" in entries
    received = json.loads(entries[prefix + "/result.json"]) if present else None
    if present:
        try:
            pinned, timings = expected_result(received, profile, fixture_sha)
            sessions = received["sessions"]
        except (AttributeError, KeyError, TypeError, ValueError) as error:
            issues.append(str(error) if type(error) is ValueError else type(error).__name__)
    else:
        issues.append("profile result missing or incomplete")
    if capture.get("controller_exit") not in {None, 0}:
        issues.append("controller returned nonzero")
    counts = {}
    for row in sessions:
        index = row.get("session_index")
        if type(index) is not int or not 1 <= index <= SESSIONS:
            issues.append("unexpected session index")
        else:
            counts.setdefault(index, []).append(row)
    trials = []
    aliases = set()
    for index in range(1, SESSIONS + 1):
        rows = counts.get(index, [])
        folder = prefix + f"/session-{index}/"
        checkpoint_path = folder + "session.json"
        checkpoint = json.loads(entries[checkpoint_path]) if checkpoint_path in entries else None
        if len(rows) > 1:
            trials.append({"session_index": index, "status": "duplicate_slot", "complete_trace": False})
            continue
        origin = "result"
        if rows:
            row = rows[0]
            if capture["checkpoints"].get(str(index), {}).get("status") != "captured" or checkpoint != row:
                trials.append({"session_index": index, "status": "checkpoint_missing_invalid_or_mismatched",
                               "complete_trace": False})
                continue
        elif checkpoint is not None:
            row = checkpoint
            origin = "checkpoint"
        else:
            trials.append({"session_index": index, "status": "missing_trial", "complete_trace": False})
            continue
        if timings is None:
            trials.append({"session_index": index, "status": "profile_metadata_unavailable",
                           "complete_trace": False, "retained_source": origin,
                           "retained_samples": len(row["samples"]) if type(row.get("samples")) is list else None})
            continue
        ledger = capture["ledgers"].get(str(index), {})
        try:
            require(ledger.get("status") == "captured", "raw append-only action ledger is missing or truncated")
            action_records = [json.loads(data) for data in entries[folder + "samples.jsonl"].splitlines()]
            alignment = row["endpoint_witness"].get("keymap_alignment")
            if alignment and row.get("status") == "passed":
                require(ledger.get("source_xkb_retained_sha256") == alignment["source_xkb_sha256"] and
                        SHA.fullmatch(alignment["source_xkb_sha256"]),
                        "retained owned source XKB export differs from its recorded SHA")
            stats = trial_replay(row, profile, timings, index, action_records)
            scoped = row["endpoint_witness"].get("host_session_aliases", [])
            require(not any(alias in aliases for alias in scoped), "authenticated session repeated in separate trial")
            aliases.update(scoped)
        except (AttributeError, KeyError, TypeError, ValueError) as error:
            trials.append({"session_index": index, "status": "invalid_trial", "complete_trace": False,
                           "error": str(error) if type(error) is ValueError else type(error).__name__})
        else:
            stats["retained_source"] = origin
            stats["status"] = "complete" if stats["complete_trace"] else "incomplete"
            trials.append(stats)
    complete = not issues and all(trial["complete_trace"] for trial in trials)
    answered = complete and received.get("qualified_population") is True and all(
        t["all_attempts_responded"] and t["fixture_session_status"] == "passed" for t in trials)
    return {
        "profile": profile, "metric": METRICS[profile], "capture": capture, "binary_pins": pinned,
        "software_timings": timings, "profile_findings": issues, "trials": trials,
        "all_three_trials_complete": complete,
        "all_three_trials_replied_to_every_attempt": answered,
        "all_three_software_p95_at_most_50_ms": answered and
            all(t["replayed_software_p95_meets_50_ms"] for t in trials),
    }


def reconstruct(entries):
    fixtures = json.loads(entries["fixture/index.json"])
    for name, spec in fixtures.items():
        require(digest(entries["fixture/" + name]) == spec["archived_sha256"], "archived fixture digest differs")
    if "fixture/recorded-sha256.json" in entries:
        manifest = json.loads(entries["fixture/recorded-sha256.json"])
        require(all(fixtures[name]["source_sha256"] == value for name, value in manifest.items()),
                "staged fixture manifest differs from archived source pins")
    else:
        manifest = None
    common = fixtures.get("normal-release.py", {}).get("source_sha256")
    references = {profile: next((spec["source_sha256"] for name, spec in fixtures.items()
                                if name.startswith(profile + "/")), common) for profile in METRICS}
    profiles = {profile: report_profile(entries, profile, references[profile]) for profile in METRICS}
    valid_viewers = {profile["binary_pins"]["viewer_binary_sha256"] for profile in profiles.values()
                     if profile["binary_pins"] is not None}
    report = {
        "schema_version": 1,
        "experiment": "X11 ReleaseAll normal-software timing",
        "status": "complete" if all(p["all_three_trials_complete"] for p in profiles.values()) else "partial",
        "profiles": profiles,
        "same_viewer_binary_across_both_profiles": len(valid_viewers) == 1 and
            all(profile["binary_pins"] is not None for profile in profiles.values()),
        "source_pins": fixtures, "recorded_fixture_source_manifest": manifest,
        "planned_sessions_per_profile": SESSIONS, "planned_attempts_per_session": SAMPLES,
        "software_p95_target_ms": 50,
        "method": (
            "The loopback metric is the observed host X11 held-key release edge minus viewer F12 issuance on one "
            "monotonic clock. The two-machine metric is viewer issuance to viewer receipt of the matching "
            "host observer reply using the viewer clock at both endpoints of the interval. It is an upper bound "
            "on host edge latency and includes observer delivery back to the viewer. Host monotonic timestamps "
            "are retained independently as causal evidence. Per-session nearest-rank p95 uses the full planned "
            "sample budget and gives unverified samples infinite rank; it is unbounded unless the p95 rank is "
            "reachable with verified observations. Successful-only summaries are descriptive. The physical "
            "input-to-pixel target is outside the measurement scope."
        ),
    }
    if "run/pilot/initial-dual.json" in entries:
        report["unscored_initial_dual_pilot"] = pilot_report(entries)
    if "run/pilot/calibrated-dual.json" in entries:
        report["unscored_calibrated_dual_pilot"] = calibrated_pilot_report(entries)
    report["dual_adjacent_link_probes"] = {phase: json.loads(entries[f"run/dual/link-{phase}.json"])
                                           for phase in ("before", "after")
                                           if f"run/dual/link-{phase}.json" in entries}
    if "build/provenance.json" in entries:
        report["build_provenance"] = attach_build_to_report(entries, profiles)
    return report


def publish(entries, output):
    report = reconstruct(entries)
    output.mkdir(parents=True, exist_ok=True)
    summary = output / (STEM + ".json")
    archive = output / (STEM + "-raw.zip")
    require(not summary.exists() and not archive.exists(), "select fresh scratch output")
    with ZipFile(archive, "x", compression=ZIP_DEFLATED, compresslevel=7) as file:
        for path, data in sorted(entries.items()):
            file.writestr(path, data)
    report["archive"] = {
        "name": archive.name, "sha256": digest(archive.read_bytes()),
        "members_sha256": {name: digest(data) for name, data in entries.items()},
    }
    with summary.open("xb") as file:
        file.write(encoded(report))
    replay(summary, archive)
    print(report["status"], summary, archive)


def replay(summary, archive):
    expected = json.loads(read(summary))
    meta = expected.pop("archive")
    require(meta["name"] == archive.name and meta["sha256"] == digest(archive.read_bytes()),
            "release archive digest differs")
    with ZipFile(archive) as file:
        names = file.namelist()
        require(len(set(names)) == len(names) and set(names) == set(meta["members_sha256"]),
                "release archive member list differs")
        entries = {name: file.read(name) for name in names}
    require({name: digest(data) for name, data in entries.items()} == meta["members_sha256"],
            "release archive member digest differs")
    require(reconstruct(entries) == expected, "replay does not reproduce the release measurement")
    return expected


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    commands = cli.add_subparsers(dest="cmd", required=True)
    pack = commands.add_parser("publish")
    pack.add_argument("--loopback", type=Path)
    pack.add_argument("--dual", type=Path)
    pack.add_argument("--fixture", action="append", default=[], type=Path)
    pack.add_argument("--fixture-sha256", type=Path)
    pack.add_argument("--loopback-fixture", type=Path)
    pack.add_argument("--dual-fixture", type=Path)
    pack.add_argument("--failed-dual-pilot", type=Path)
    pack.add_argument("--failed-calibrated-dual-pilot", type=Path)
    pack.add_argument("--dual-link-dir", type=Path)
    pack.add_argument("--build-provenance", type=Path)
    pack.add_argument("--out", type=Path, required=True)
    verify = commands.add_parser("replay")
    verify.add_argument("summary", type=Path)
    verify.add_argument("archive", type=Path)
    args = cli.parse_args()
    if args.cmd == "publish":
        require(args.loopback is not None or args.dual is not None, "supply at least one terminal trial profile")
        entries = collect({"loopback": args.loopback, "dual": args.dual}, args.fixture, args.fixture_sha256,
                          profile_fixtures={"loopback": args.loopback_fixture, "dual": args.dual_fixture},
                          initial_dual_pilot=args.failed_dual_pilot,
                          calibrated_dual_pilot=args.failed_calibrated_dual_pilot,
                          build_provenance=args.build_provenance, dual_link_dir=args.dual_link_dir)
        publish(entries, args.out)
    else:
        print(replay(args.summary, args.archive)["status"], "reproduced from", args.archive)


if __name__ == "__main__":
    main()
