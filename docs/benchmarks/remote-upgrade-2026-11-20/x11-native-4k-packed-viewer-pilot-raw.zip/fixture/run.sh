#!/usr/bin/env bash
set -euo pipefail
lab=$(cd "$(dirname "$0")" && pwd)
export LD_LIBRARY_PATH=/tmp/jwm-remote-ffmpeg/usr/lib/x86_64-linux-gnu
peer=ubuntu@192.168.0.78
expected_host=59572059a51aae67c91eff3013012352b932850806647cb81ccda2756522b47b
actual_host=$(ssh -n -o BatchMode=yes -o ConnectTimeout=5 "$peer" \
    'sha256sum /tmp/jwm-p09-resolution-candidate/jwm-remote' | cut -d' ' -f1)
if [[ "$actual_host" != "$expected_host" ]]; then
    printf '%s\n' 'Ubuntu host binary differs from the pinned candidate' >&2
    exit 1
fi
printf '%s\n' "$actual_host" > "$lab/host-binary-sha256"
remote=$(cat "$lab/remote-dir")
common=(--remote-dir "$remote" --pilot --seconds 36 --arms treatment --width 3840 --height 2160
        --fps 30 --paint-fps 60 --capture-scaling auto --feature-flag JWM_REMOTE_PARALLEL_YUV420 --enable-at both)
status=0
if ! python3 -B -u "$lab/benchmark.py" "${common[@]}" --label packing-v2-control \
    --viewer-binary /tmp/jwm-p09-resolution-candidate/jwm-remote \
    --viewer-sha256 b51bdd70ece747a3f535a261086a873d0ace3388acb067a7a099347f58a5cdd6; then status=1; fi
if ! python3 -B -u "$lab/benchmark.py" "${common[@]}" --label packing-v2-new \
    --viewer-binary /tmp/jwm-p09-packed-viewer-v2/jwm-remote \
    --viewer-sha256 0bcbd715b559b540b20281b7b5f35ca6912b42eee0714ca74f0ba4b8def971b2 \
    --expected-packed-rgb; then status=1; fi
exit "$status"
