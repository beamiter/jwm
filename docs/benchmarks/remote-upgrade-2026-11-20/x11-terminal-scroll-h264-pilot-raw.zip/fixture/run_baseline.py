"""Owned X11 readback and exact telemetry windows for the terminal trial."""

import ctypes as C
import json
import os
import re
import signal
import subprocess
from contextlib import suppress
import threading
import time

from score import MEASURE_SECONDS, SECOND, TAIL_SECONDS, WARM_SECONDS, score_pixels, write_json
from processes import wait_for
from terminal_scroll import sample



class Image(C.Structure):
    _fields_ = [(name, C.c_int) for name in ('width', 'height', 'xoffset', 'format')]
    _fields_ += [('data', C.c_void_p)]
    _fields_ += [(name, C.c_int) for name in (
        'byte_order', 'bitmap_unit', 'bitmap_bit_order', 'bitmap_pad', 'depth',
        'bytes_per_line', 'bits_per_pixel')]
    _fields_ += [(name, C.c_ulong) for name in ('red_mask', 'green_mask', 'blue_mask')]


class Pixels:
    def __init__(self, display):
        self.xlib = C.CDLL('libX11.so.6')
        for name, inputs, result in (
            ('XOpenDisplay', [C.c_char_p], C.c_void_p),
            ('XCloseDisplay', [C.c_void_p], C.c_int),
            ('XDefaultRootWindow', [C.c_void_p], C.c_ulong),
            ('XGetImage', [C.c_void_p, C.c_ulong, C.c_int, C.c_int, C.c_uint,
                           C.c_uint, C.c_ulong, C.c_int], C.POINTER(Image)),
            ('XDestroyImage', [C.POINTER(Image)], C.c_int),
        ):
            fn = getattr(self.xlib, name)
            fn.argtypes, fn.restype = inputs, result
        self.display = self.xlib.XOpenDisplay(display.encode())
        if not self.display:
            raise RuntimeError(f'could not open owned X display {display}')
        self.root = self.xlib.XDefaultRootWindow(self.display)

    def close(self):
        self.xlib.XCloseDisplay(self.display)

    def crop(self, xid, x, y, width, height):
        ptr = self.xlib.XGetImage(self.display, xid, x, y, width, height, C.c_ulong(-1), 2)
        if not ptr:
            raise RuntimeError('owned drawable did not return pixels')
        try:
            info = ptr.contents
            layout = (info.width, info.height, info.byte_order, info.bits_per_pixel,
                      info.red_mask, info.green_mask, info.blue_mask)
            if layout != (width, height, 0, 32, 0xff0000, 0xff00, 0xff):
                raise RuntimeError(f'unexpected owned Xvfb pixel format {layout}')
            packed = C.string_at(info.data, info.bytes_per_line * height)
            return tuple(packed[y:y + width * 4]
                         for y in range(0, len(packed), info.bytes_per_line))
        finally:
            self.xlib.XDestroyImage(ptr)


def write_capture(path, rows):
    with path.open('wb') as image:
        image.write(f'P6\n{len(rows[0]) // 4} {len(rows)}\n255\n'.encode())
        for row in rows:
            rgb = bytearray(len(row) // 4 * 3)
            rgb[0::3], rgb[1::3], rgb[2::3] = row[2::4], row[1::4], row[0::4]
            image.write(rgb)


def wait_for_window(process, display, title, env, tree_log, seconds, geometry=None):
    pattern = rf'^ +(0x[0-9a-f]+) "[^"\n]*{re.escape(title)}[^"\n]*":'
    if geometry is not None:
        size = f'{geometry[0]}x{geometry[1]}+0+0'
        pattern += rf' [^\n]* {re.escape(size)}(?= |$)'
    tree = ''

    def inspect():
        nonlocal tree
        tree = subprocess.check_output(['xwininfo', '-display', display, '-root', '-tree'],
                                       env=env, text=True, timeout=4)
        matches = re.findall(pattern, tree, re.MULTILINE | re.IGNORECASE)
        if len(matches) > 1:
            raise RuntimeError(f'more than one owned drawable for {title!r}')
        return int(matches[0], 16) if matches else None

    try:
        return wait_for(process, inspect, seconds)
    finally:
        tree_log.write_text(tree)


def stop_group(process):
    with suppress(ProcessLookupError):
        os.killpg(process.pid, signal.SIGTERM)
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        with suppress(ProcessLookupError):
            os.killpg(process.pid, signal.SIGKILL)
        process.wait(timeout=5)
    with suppress(ProcessLookupError):
        os.killpg(process.pid, signal.SIGKILL)


def collect_phase(name, run_dir, lanes, processes, width, top):
    phase_start = time.monotonic_ns()
    start = phase_start + WARM_SECONDS * SECOND
    end = start + MEASURE_SECONDS * SECOND
    deadline = end + TAIL_SECONDS * SECOND
    phase = {'phase': name, 'phase_start_monotonic_ns': phase_start,
             'score_start_monotonic_ns': start, 'score_end_monotonic_ns': end,
             'telemetry_phase_end_monotonic_ns': deadline}
    write_json(run_dir / f'{name}-scope.json', phase)
    samples = {side: [] for side in lanes}
    slot, last_health_check = 0, 0
    with (run_dir / f'{name}-pixels.jsonl').open('w') as observer:
        while (now := time.monotonic_ns()) < deadline:
            if now - last_health_check >= SECOND:
                dead = [proc.args[0] for proc in processes if proc.poll() is not None]
                if dead:
                    raise RuntimeError(f'{name} ended before the full observation period: {dead}')
                last_health_check = now
            for side, (pixels, xid) in lanes.items():
                began = time.monotonic_ns()
                tile, scroll = sample(pixels, xid, width, top)
                row = {'side': side, 'start_monotonic_ns': began,
                       'end_monotonic_ns': time.monotonic_ns(),
                       'marker': tile, 'scroll_signature': scroll}
                samples[side].append(row)
                print(json.dumps(row, separators=(',', ':')), file=observer)
            slot = max(slot + 1, (time.monotonic_ns() - phase_start) * 90 // SECOND + 1)
            next_tick = min(deadline, phase_start + slot * SECOND // 90)
            time.sleep(max(0, (next_tick - time.monotonic_ns()) / SECOND))
    phase['observer_end_monotonic_ns'] = time.monotonic_ns()
    phase['samples'] = {side: score_pixels(rows, start, end) for side, rows in samples.items()}
    write_json(run_dir / f'{name}-scope.json', phase)
    return phase


def monitor_stderr(process, role, run_dir):
    trace = run_dir / f'{role}-clocked-telemetry.jsonl'
    log = run_dir / f'{role}.log'
    failures = []

    def relay():
        try:
            with log.open('wb') as raw, trace.open('w') as typed:
                for line in iter(process.stderr.readline, b''):
                    arrived = time.monotonic_ns()
                    raw.write(line)
                    raw.flush()
                    if not line.startswith(b'{'):
                        continue
                    payload = json.loads(line)
                    if payload.get('type') != f'jwm_remote_{role}_stats' or payload.get('final'):
                        continue
                    print(json.dumps({'end_monotonic_ns': arrived, 'record': payload},
                                     separators=(',', ':')), file=typed, flush=True)
        except (OSError, ValueError) as error:
            failures.append(str(error))

    worker = threading.Thread(target=relay, daemon=True)
    worker.start()
    return worker, failures


def select_telemetry(run_dir, phase, role, dimensions=(960, 640)):
    start = phase['score_start_monotonic_ns']
    last = phase['telemetry_phase_end_monotonic_ns']
    retained = []
    for line in (run_dir / f'{role}-clocked-telemetry.jsonl').read_text().splitlines():
        row = json.loads(line)
        window = row['record']
        end = row['end_monotonic_ns']
        duration = round(window['window_seconds'] * SECOND)
        if duration > 0 and start <= end - duration and end <= last:
            retained.append(row)
    with (run_dir / f"{phase['phase']}-{role}.jsonl").open('w') as selected:
        for row in retained:
            print(json.dumps(row['record'], separators=(',', ':')), file=selected)
    scope_field = 'last_sent_frame' if role == 'host' else 'last_frame'
    scopes = [row['record'][scope_field] for row in retained if row['record'].get(scope_field)]
    routes = sorted({route for row in retained for route in (
        row['record'].get('mode' if role == 'host' else 'last_presentation_path'),) if route})
    return {'whole_windows': len(retained),
            'window_seconds': sum(row['record']['window_seconds'] for row in retained),
            'session_ids': sorted({row['record']['session_id'] for row in retained if row['record'].get('session_id')}),
            'routes': routes, 'frame_scopes_observed': len(scopes),
            'viewer_backends': sorted({row['record']['viewer_backend'] for row in retained
                                       if row['record'].get('viewer_backend')}),
            'frame_scopes_match_requested_codec': all(
                scope.get('codec') == 'H.264' and scope.get('source_dimensions') == list(dimensions)
                and scope.get('encoded_dimensions') == list(dimensions) for scope in scopes),
            'first_window_end_monotonic_ns': retained[0]['end_monotonic_ns'] if retained else None,
            'last_window_end_monotonic_ns': retained[-1]['end_monotonic_ns'] if retained else None}
