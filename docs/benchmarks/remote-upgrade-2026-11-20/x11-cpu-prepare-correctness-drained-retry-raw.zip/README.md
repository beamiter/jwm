# X11 CPU preparation with a restored native-size credit fence

Extract the archive and run `python3 -I -B replay.py`. The replay checks
member hashes, independent endpoint telemetry, the drained-credit condition,
source input ordering and every synthetic X11 capture. The original fixture
sources and their digests are under `fixture`.

This independent ON/OFF retry used one H.264 release and distinct native
source grants. Each arm waited for evidence of a fresh 1393×785 H.264 viewer
scope, matching host scope and zero host outstanding frame credits before
sending the restored-window click. Both lifecycle arms passed. The controller
exited 1 because the first independent lossy H.264 capture differed between
arms. The opposite letterbox, restored source and switched source captured
rasters matched byte for byte. All captures have exact black bars and the
expected color and crop probes.

This replay checks cumulative evidence from endpoint telemetry windows. It
cannot reconstruct individual ACK records or attribute differences between
independent H.264 encode/decode instances. It does not replace the separate
same-decoded-frame X11 presentation regression. The earlier A/B/A attempt is
referenced by digest and remains a separate artifact.
