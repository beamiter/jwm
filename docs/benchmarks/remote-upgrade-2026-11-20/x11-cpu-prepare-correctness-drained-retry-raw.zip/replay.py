#!/usr/bin/env python3
"""Replay raw synthetic X11 drawable crops and scoped evidence offline."""
import argparse
from hashlib import sha256
from itertools import combinations
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
MARKERS = ('upper_left', 'upper_right', 'lower_left', 'lower_right', 'last_column', 'last_row',
           'gray_low', 'gray_high', 'origin')


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def file_hash(path):
    result = sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(1 << 20), b''):
            result.update(data)
    return result.hexdigest()


def rectangle(viewport, source):
    width, height = viewport
    iw, ih = source
    if width * ih <= height * iw:
        cw, ch = width, max(1, width * ih // iw)
    else:
        cw, ch = max(1, height * iw // ih), height
    return [(width - cw) // 2, (height - ch) // 2, cw, ch]


def parse_ppm(path, witness):
    with path.open('rb') as stream:
        require(stream.readline() == b'P6\n', 'expected binary RGB PPM')
        dims = tuple(map(int, stream.readline().split()))
        require(stream.readline() == b'255\n' and list(dims) == witness['viewport'], 'invalid PPM dimensions or range')
        rgb = stream.read()
    require(len(rgb) == dims[0] * dims[1] * 3 and file_hash(path) == witness['sha256'], 'capture bytes differ from the pins')
    return rgb


def color_class(rgb):
    r, g, b = rgb
    if max(rgb) <= 12:
        return 'black'
    if r > g + 32 and r > b + 22:
        return 'A'
    if g > r + 34 or b > r + 48:
        return 'B'
    return 'other'


def read_capture(path, witness):
    rgb = parse_ppm(path, witness)
    width, height = witness['viewport']
    left, top, w, h = witness['content']
    require(witness['content'] == rectangle((width, height), (1393, 785)), 'bad letterbox placement')
    stride = width * 3
    for row in range(height):
        start = row * stride
        bars = (rgb[start:start + stride] if row < top or row >= top + h else
                rgb[start:start + left * 3] + rgb[start + (left + w) * 3:start + stride])
        require(not bars.strip(b'\x00'), f'non-black RGB in expected black bars at row {row}')
    sites = [(left + w // 4, top + h // 4), (left + w * 3 // 4, top + h // 4),
             (left + w // 4, top + h * 3 // 4), (left + w * 3 // 4, top + h * 3 // 4),
             (left + w - 1, top + h // 4), (left + w // 4, top + h - 1),
             (left + 108, top + h - 65), (left + 276, top + h - 65), (0, 0)]
    markers = {label: list(rgb[(y * width + x) * 3:(y * width + x + 1) * 3]) for label, (x, y) in zip(MARKERS, sites)}
    require(all(color_class(markers[region]) == witness['source'] for region in MARKERS[:4]), 'wrong source at a quadrant')
    require(markers['last_column'] != [0, 0, 0] and markers['last_row'] != [0, 0, 0], 'visible odd crop edges lost')
    require(all(len(set(markers[name])) == 1 for name in ('gray_low', 'gray_high'))
            and markers['gray_low'][0] >= 10 and markers['gray_high'][0] >= 220, 'range ramp endpoints differ')
    active = [rgb[((top + y) * width + left) * 3:((top + y) * width + left + w) * 3] for y in range(h)]
    return active, markers


def pixel_distance(a, b):
    require(len(a) == len(b) and a and len(a[0]) == len(b[0]) and len(a[0]) % 3 == 0, 'noncomparable raster')
    pixels = len(a) * (len(a[0]) // 3)
    differences = sumdelta = 0
    absmax = [0, 0, 0]
    bins = {2: 0, 8: 0, 16: 0, 32: 0}
    bbox = None
    for y, (left, right) in enumerate(zip(a, b)):
        if left == right:
            continue
        for i in range(0, len(left), 3):
            if left[i:i + 3] == right[i:i + 3]:
                continue
            delta = [abs(left[i + k] - right[i + k]) for k in range(3)]
            differences += 1
            sumdelta += sum(delta)
            for k, value in enumerate(delta):
                if value > absmax[k]:
                    absmax[k] = value
            for threshold in bins:
                if max(delta) > threshold:
                    bins[threshold] += 1
            x = i // 3
            bbox = [x, y, x, y] if bbox is None else [min(bbox[0], x), bbox[1], max(bbox[2], x), y]
    return {'compared_content_pixels': pixels, 'differing_pixels': differences,
            'max_absolute_rgb_delta': absmax, 'total_absolute_channel_delta': sumdelta,
            'mean_absolute_channel_delta': sumdelta / (pixels * 3),
            'pixels_over_absolute_delta': {str(threshold): count for threshold, count in bins.items()},
            'difference_content_bbox_inclusive': bbox}


def analyze(root, trace):
    captures, aligned = {}, {}
    for lane in trace['arms']:
        selected = {}
        for label, witness in lane['captures'].items():
            active, markers = read_capture(root / lane['case'] / witness['file'], witness)
            selected[label] = active
            captures.setdefault(label, {})[lane['case']] = {'markers_rgb': markers, 'bars_exact_black': True,
                 'full_ppm_sha256': witness['sha256'], 'content_rgb_sha256': sha256(b''.join(active)).hexdigest(),
                 'content': witness['content'], 'viewport': witness['viewport']}
        aligned[lane['case']] = selected
    phases = {}
    for label, rows in captures.items():
        pairs = []
        for first, second in combinations(rows, 2):
            pairs.append({'arms': [first, second], **pixel_distance(aligned[first][label], aligned[second][label])})
        phases[label] = pairs
    reorientation = {case: pixel_distance(images['a_initial'], images['a_other']) for case, images in aligned.items()}
    return {'capture_witnesses': captures, 'same_phase_comparisons': phases,
            'per_arm_initial_to_opposite_letterbox_content_comparison': reorientation}


def frame_scope(frame):
    return tuple(frame[key] for key in ('source_epoch', 'geometry_epoch', 'codec',
                                        'source_dimensions', 'encoded_dimensions'))


def native_scope(frame, epoch):
    return (frame['source_epoch'] == epoch and frame['codec'] == 'H.264'
            and frame['source_dimensions'] == frame['encoded_dimensions'] == [1393, 785])


def read_endpoint(root, case):
    return json.loads((root / case / 'endpoint-evidence.json').read_bytes())


def check_protocol(trace, root):
    require(trace['controller_exit'] == 1 and [lane['arm'] for lane in trace['arms']] == ['on', 'off'],
            'unexpected terminal outcome or arm order')
    require(trace['visible_rgb_parity'] == {'a_initial': False, 'a_other': True,
            'a_restored': True, 'b_final': True}, 'the controller parity outcome differs')
    require(len({tuple(row['source_content_sha256']) for row in trace['arms']}) == 1,
            'source rasters did not match')
    names = ('scheduled', 'prepared', 'submitted', 'fallbacks', 'stale')
    for number, lane in enumerate(trace['arms'], 1):
        arm, case = lane['arm'], lane['case']
        require(case == f'{number}-{arm}' and lane['status'] == 'passed'
                and lane['viewer_exit'] == lane['host_exit'] == 0,
                f'{case} lifecycle did not finish cleanly')
        endpoint = read_endpoint(root, case)
        host, viewer = endpoint['host_payload'], endpoint['viewer_payload']
        require(lane['host_and_viewer_scope_equal'] and endpoint['authenticated_scope_equal']
                and host and viewer[-1]['final'] is True and lane['viewer_terminal_final']
                and {row['session_alias'] for row in host + viewer} == {f'case-{number}'},
                f'{case} authenticated lifecycle evidence is missing')
        require('jwm-remote: hardware H.264 encoding active (NVENC)' in endpoint['host_markers']
                and 'jwm-remote: H.264 hardware decoder active (VAAPI)' in endpoint['viewer_markers']
                and 'jwm-remote: session ended' in endpoint['viewer_markers']
                and sum(row['h264_frames'] for row in host) > 0
                and all(row.get('last_presentation_path') in (None, 'rgb') for row in viewer),
                f'{case} did not establish hardware stream and CPU presentation')
        require(sum(row['drawn_acks'] for row in host) == sum(row['acked'] for row in viewer)
                == lane['authenticated_host_drawn_ack_count'] == lane['authenticated_viewer_ack_count']
                == (800 if arm == 'on' else 1119), f'{case} endpoint ACK totals disagree')
        require(native_scope(lane['source_a_ack'], 1) and native_scope(lane['source_b_ack'], 2),
                f'{case} odd native-size source ACK scope failed')
        floor = lane['post_restore_ack_floor']
        decoded = floor['presented_frame']
        sent = floor['host_sent_frame_at_ack_floor']
        require(floor['host_and_viewer_authenticated_scope_equal']
                and floor['host_outstanding'] == 0 and floor['host_drawn_acks_in_window'] > 0
                and floor['received_ack_observation'] == 'cumulative_at_or_beyond_fresh_scope'
                and native_scope(decoded, 1) and frame_scope(decoded) == frame_scope(sent)
                and decoded['geometry_epoch'] >= lane['source_a_ack']['geometry_epoch']
                and decoded['sequence'] > lane['source_a_ack']['sequence']
                and sent['sequence'] >= decoded['sequence']
                and lane['source_b_ack']['sequence'] > sent['sequence'], f'{case} drained-credit scope is wrong')
        require(any(row.get('last_frame') == decoded and row['acked'] > 0 for row in viewer)
                and any(row.get('last_sent_frame') == sent and row['outstanding'] == 0
                        and row['drawn_acks'] == floor['host_drawn_acks_in_window'] for row in host),
                f'{case} drained-credit witnesses cannot be reproduced from endpoint windows')
        edges = lane['source_edges']
        require([(row['type'], row['detail'], row['target']) for row in edges]
                == [(4, 1, 'A'), (5, 1, 'A'), (2, 74, 'A'), (3, 74, 'A'),
                    (4, 1, 'B'), (5, 1, 'B'), (2, 75, 'B'), (3, 75, 'B')],
                f'{case} actual source edges differ')
        require([(edge['root_x'], edge['root_y']) for edge in edges if edge['type'] == 4]
                == [(481, 554), (2025, 590)]
                and lane['captures']['a_restored']['recorded_ns'] < edges[0]['observed_ns']
                and edges[3]['observed_ns'] < lane['local_old_physical_up_ns']
                < lane['captures']['b_final']['recorded_ns'] < edges[4]['observed_ns'],
                f'{case} edge coordinates or ordering differs')
        require([row['viewport'] for row in lane['resize_window_trace']]
                == [[1651,785], [1393,925], [1241,721], [1651,785], [1393,925], [1651,785], [1393,925]],
                f'{case} resize sequence differs')
        counts = {key: sum(int((row.get('x11_cpu_preparation') or {}).get(key) or 0)
                           for row in viewer) for key in names}
        counts['stage_observations'] = sum(int(row['stages'].get('x11_cpu_prepare_ms', {}).get('observations', 0))
                                           for row in viewer)
        active = 797 if arm == 'on' else 0
        require(counts == lane['viewer_preparation'] == {'scheduled': active, 'prepared': active,
                'submitted': active, 'stage_observations': active, 'fallbacks': 0, 'stale': 0},
                f'{case} worker scope differs')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--metadata-only', action='store_true')
    args = parser.parse_args()
    trace = json.loads((args.root / 'trace.json').read_text())
    check_protocol(trace, args.root)
    if args.metadata_only:
        print('paired ON/OFF lifecycle, drained native-size credit and endpoint windows replayed')
        return
    expected_members = json.loads((args.root / 'members.sha256.json').read_text())
    for rel, digest in expected_members.items():
        require(not Path(rel).is_absolute() and '..' not in Path(rel).parts, f'invalid member path: {rel}')
        require(file_hash(args.root / rel) == digest, f'archive member changed: {rel}')
    observed = analyze(args.root, trace)
    original = json.loads((args.root / 'image-evidence.json').read_text())
    require(observed == original, 'pixel comparison no longer reproduces the committed evidence')
    require({label: records[0]['differing_pixels'] == 0 for label, records in
             observed['same_phase_comparisons'].items()} == trace['visible_rgb_parity'], 'raw captures differ from controller parity')
    print(json.dumps(observed, indent=2))


if __name__ == '__main__':
    main()
