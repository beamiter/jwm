#!/usr/bin/env python3
"""Owned actual X11, authenticated TCP and full RGB bytes for CPU prepare parity."""
import argparse
from contextlib import ExitStack
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time

from Xlib import X, XK, display
from Xlib.ext import xtest
from Xlib.protocol import event

from pixels import Pixels, write_capture
from processes import clean_env, get_display, sha256, start_display, stop

SIZE = (1393, 785)
POSITIONS = ((17, 31), (1561, 67))
INITIAL = (1393, 925)
OTHER = (1651, 785)
CLIPPED = (1241, 721)
RGB = ((0xdb2722, 0xa01842, 0xee6e39, 0xaf3b40), (0x11bb69, 0x239bd0, 0x27ce91, 0x077292))
PROBE_MASK = X.KeyPressMask | X.KeyReleaseMask | X.ButtonPressMask | X.ButtonReleaseMask
TOGGLE = 'JWM_REMOTE_X11_PREPARE'


def require(condition, detail):
    if not condition:
        raise RuntimeError(detail)


def eventually(label, children, check, timeout=14):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        for child in children:
            require(child.poll() is None, f'{label}: owned child ended ({child.returncode})')
        result = check()
        if result:
            return result
        time.sleep(.01)
    raise TimeoutError(label)


def summaries(path, endpoint):
    rows = []
    for line in path.read_text(errors='replace').splitlines():
        if line.startswith('{') and line.endswith('}'):
            item = json.loads(line)
            if item.get('type') == f'jwm_remote_{endpoint}_stats':
                rows.append(item)
    return rows


def bounds(view, frame=SIZE):
    w, h = view
    sw, sh = frame
    if w * sh <= h * sw:
        dw, dh = w, max(1, w * sh // sw)
    else:
        dw, dh = max(1, h * sw // sh), h
    return ((w - dw) // 2, (h - dh) // 2, dw, dh)


def expected_source_pixel(view, point):
    x, y, w, h = bounds(view)
    return ((point[0] - x) * (SIZE[0] - 1) // max(w - 1, 1),
            (point[1] - y) * (SIZE[1] - 1) // max(h - 1, 1))


def rgb_at(pixels, xid, x, y):
    b, g, r, _ = pixels.crop(xid, x, y, 1, 1)[0]
    return (r, g, b)


def color_class(rgb):
    r, g, b = rgb
    if max(rgb) <= 12:
        return 'black'
    if r > g + 32 and r > b + 22:
        return 'A'
    if g > r + 34 or b > r + 48:
        return 'B'
    return 'other'


def assert_bars(image, view):
    w, h = view
    left, top, bw, bh = bounds(view)
    require(len(image) == h and all(len(row) == w * 4 for row in image), 'incomplete XGetImage row or stride')
    for y, row in enumerate(image):
        omitted = row if y < top or y >= top + bh else row[:left * 4] + row[(left + bw) * 4:]
        if any(omitted[0::4]) or any(omitted[1::4]) or any(omitted[2::4]):
            raise RuntimeError(f'non-black RGB in letterbox at visible row {y}')


def capture(directory, label, view, pixels, xid, source):
    rows = pixels.crop(xid, 0, 0, *view)
    assert_bars(rows, view)
    left, top, width, height = bounds(view)
    for x, y in ((width // 4, height // 4), (width * 3 // 4, height // 4),
                 (width // 4, height * 3 // 4), (width * 3 // 4, height * 3 // 4)):
        b, g, r, _ = rows[top + y][(left + x) * 4:(left + x + 1) * 4]
        require(color_class((r, g, b)) == source, 'unexpected source quadrant in actual viewer drawable')
    image = directory / f'{label}.ppm'
    write_capture(image, rows)
    return {'file': image.name, 'sha256': sha256(image), 'viewport': view, 'content': [left, top, width, height],
            'recorded_ns': time.monotonic_ns(), 'source': source}


def create_sources(conn):
    screen = conn.screen()
    root = screen.root
    root.change_attributes(background_pixel=0xcc28cc)
    root.clear_area(0, 0, 0, 0)
    cursor_mask = root.create_pixmap(1, 1, 1)
    mask_gc = cursor_mask.create_gc(foreground=0)
    cursor_mask.fill_rectangle(mask_gc, 0, 0, 1, 1)
    cursor = cursor_mask.create_cursor(cursor_mask, (0, 0, 0), (0, 0, 0), 0, 0)
    root.change_attributes(cursor=cursor)
    windows = []
    for index, (x, y) in enumerate(POSITIONS):
        win = root.create_window(x, y, *SIZE, 0, screen.root_depth, X.InputOutput, X.CopyFromParent,
                                 event_mask=PROBE_MASK, background_pixel=RGB[index][0], cursor=cursor)
        win.set_wm_name(f'P06 owned source {index}')
        win.map()
        windows.append(win)
    root.warp_pointer(3050, 1050)
    conn.sync()
    return windows


def paint(conn, win, idx, phase=0):
    w, h = SIZE
    gc = win.create_gc()
    palettes = RGB[idx]
    for i, (x, y, width, height) in enumerate(((0, 0, w // 2, h // 2), (w // 2, 0, w - w // 2, h // 2),
                     (0, h // 2, w // 2, h - h // 2), (w // 2, h // 2, w - w // 2, h - h // 2))):
        gc.change(foreground=palettes[(i + phase) % len(palettes)])
        win.fill_rectangle(gc, x, y, width, height)
    # Keep actual one-pixel chromatic and gray edge samples in the crop.
    for i, value in enumerate((0xe85d32, 0x20a778, 0xc0c0c0, 0x626262, 0x32a4c5, 0xd15c92, 0xededed, 0x8b8b8b)):
        gc.change(foreground=value)
        win.fill_rectangle(gc, w - len(palettes) * 2 + i, 0, 1, h)
        win.fill_rectangle(gc, 0, h - len(palettes) * 2 + i, w, 1)
    # Make luma/range errors observable away from subsampling at the crop edge.
    for i, level in enumerate((24, 48, 96, 128, 180, 216, 235)):
        gc.change(foreground=level * 0x010101)
        win.fill_rectangle(gc, 96 + 28 * i, h - 82, 24, 40)
    gc.free()
    conn.sync()


def current_window(conn):
    label = conn.intern_atom('_NET_WM_NAME')
    for window in conn.screen().root.query_tree().children:
        prop = window.get_full_property(label, X.AnyPropertyType)
        title = prop.value.decode(errors='replace') if prop and isinstance(prop.value, bytes) else window.get_wm_name()
        if isinstance(title, str) and ' - JWM Remote' in title:
            return window
    return None


def geometry(window):
    g = window.get_geometry()
    return (g.width, g.height)


def fake(conn, kind, detail=0, x=0, y=0):
    xtest.fake_input(conn, kind, detail, x=x, y=y)
    conn.flush()


def key_is_held(conn, code):
    return bool(conn.query_keymap()[code // 8] & (1 << code % 8))


def drain_edges(rows, conn):
    while conn.pending_events():
        received = conn.next_event()
        if received.type not in (X.KeyPress, X.KeyRelease, X.ButtonPress, X.ButtonRelease):
            continue
        require(not received.send_event, 'host must observe real XTEST events')
        trace = {'type': received.type, 'detail': received.detail, 'target': received.window.id,
                 'root_x': received.root_x, 'root_y': received.root_y, 'observed_ns': time.monotonic_ns()}
        rows.append(trace)
        yield trace


def wait_edge(rows, conn, child, kind, code, xid):
    def received():
        for item in drain_edges(rows, conn):
            if (item['type'], item['detail']) == (kind, code):
                require(item['target'] == xid, 'probe edge went to wrong original recipient')
                return item
    return eventually(f'owned actual X11 edge {kind}/{code}', (child,), received, timeout=7)


def close_viewer(conn, window, proc):
    close = event.ClientMessage(window=window, client_type=conn.intern_atom('WM_PROTOCOLS'),
                                data=(32, [conn.intern_atom('WM_DELETE_WINDOW'), 0, 0, 0, 0]))
    window.send_event(close)
    conn.flush()
    return proc.wait(timeout=12)


def prep_counters(viewer_stats):
    counts = dict(scheduled=0, submitted=0, prepared=0, stale=0, fallbacks=0, stage_observations=0)
    for row in viewer_stats:
        stats = row.get('x11_cpu_preparation') or {}
        for name in ('scheduled', 'submitted', 'prepared', 'stale', 'fallbacks'):
            value = stats.get(name, 0)
            counts[name] += int(value or 0)
        counts['stage_observations'] += int(row.get('stages', {}).get('x11_cpu_prepare_ms', {}).get('observations', 0))
    return counts


def restored_ack_floor(host_rows, viewer_rows, previous, codec):
    """Fresh stable scope drawn by viewer and cumulatively retired by host."""
    def scope(frame):
        return (frame['source_epoch'], frame['geometry_epoch'], frame['codec'],
                frame['source_dimensions'], frame['encoded_dimensions'])

    for viewer in viewer_rows:
        drawn = viewer.get('last_frame')
        if (not viewer.get('acked') or not drawn or drawn['source_epoch'] != previous['source_epoch']
                or drawn['geometry_epoch'] < previous['geometry_epoch'] or drawn['sequence'] <= previous['sequence']
                or drawn['codec'] != codec or drawn['source_dimensions'] != list(SIZE)
                or drawn['encoded_dimensions'] != list(SIZE)):
            continue
        for host in host_rows:
            sent = host.get('last_sent_frame')
            if (host.get('drawn_acks', 0) > 0 and host.get('outstanding') == 0 and sent
                    and host['session_id'] is not None and host['session_id'] == viewer['session_id']
                    and scope(sent) == scope(drawn) and sent['sequence'] >= drawn['sequence']):
                return {'presented_frame': drawn, 'host_sent_frame_at_ack_floor': sent,
                        'host_outstanding': host['outstanding'], 'host_drawn_acks_in_window': host['drawn_acks'],
                        'host_and_viewer_authenticated_scope_equal': True,
                        'received_ack_observation': 'cumulative_at_or_beyond_fresh_scope'}
    return None


def run_arm(args, directory, arm, result):
    with ExitStack() as clean:
        def log(name):
            return clean.enter_context((directory / name).open('wb'))
        source_x = start_display(3073, 1117, log('source-xvfb.log'))
        clean.callback(stop, source_x)
        local_x = start_display(1921, 1081, log('viewer-xvfb.log'))
        clean.callback(stop, local_x)
        host_display, viewer_display = get_display(source_x), get_display(local_x)
        hosts, local = display.Display(host_display), display.Display(viewer_display)
        clean.callback(hosts.close)
        clean.callback(local.close)
        for conn in (hosts, local):
            require(conn.has_extension('XTEST'), 'fixture requires XTEST on both owned screens')
            conn.change_keyboard_control(auto_repeat_mode=X.AutoRepeatModeOff)
            conn.sync()
        sources = create_sources(hosts)
        for i, target in enumerate(sources):
            paint(hosts, target, i)
        receiver = Pixels(viewer_display)
        clean.callback(receiver.close)
        raw_source = Pixels(host_display)
        clean.callback(raw_source.close)
        result['source_content_sha256'] = [hashlib.sha256(b''.join(raw_source.crop(win.id, 0, 0, *SIZE))).hexdigest()
                                           for win in sources]
        sources[0].set_input_focus(X.RevertToParent, X.CurrentTime)
        hosts.sync()
        env = clean_env()
        env.pop('XAUTHORITY', None)
        env['XDG_CACHE_HOME'] = str(directory / 'cache')
        if args.lib:
            env['LD_LIBRARY_PATH'] = args.lib
        key = directory / 'private.key'
        clean.callback(key.unlink, missing_ok=True)
        subprocess.run([args.viewer, 'keygen', '--output', key], check=True, stdin=subprocess.DEVNULL,
                       stdout=subprocess.DEVNULL, timeout=8, env=env)
        host_log, viewer_log = directory / 'host.log', directory / 'viewer.log'
        area = [f'{SIZE[0]}x{SIZE[1]}+{x}+{y}' for x, y in POSITIONS]
        host_args = [args.host, 'host', '--display', host_display, '--once', '--key-file', key, '--listen', '127.0.0.1:0',
                     '--capture-source', 'root', '--stats-json', '--allow-input', '--max-width', '0', '--fps', '30',
                     '--region', area[0], '--share-region', area[1], '--scaling', 'auto']
        host_args += ['--allow-h264'] if args.codec == 'h264' else ['--fixed-jpeg-quality', '--jpeg-quality', '92']
        host = subprocess.Popen(host_args, env=env, stdin=subprocess.DEVNULL, stdout=log(host_log.name), stderr=subprocess.STDOUT)
        clean.callback(stop, host)
        listener = eventually('owned host listener', [host], lambda: re.search(r'listening on 127\.0\.0\.1:(\d+)', host_log.read_text()))
        viewer_env = env | ({TOGGLE: '1'} if arm == 'on' else {})
        viewer_args = [args.viewer, 'connect', f'127.0.0.1:{listener[1]}', '--key-file', key, '--display', viewer_display,
                       '--window-size', f'{INITIAL[0]}x{INITIAL[1]}', '--window-position', '0,0',
                       '--scaling', 'cpu', '--grab-input', '--escape-key', 'F12', '--stats-json']
        if args.codec == 'jpeg':
            viewer_args += ['--jpeg']
        viewer = subprocess.Popen(viewer_args, env=viewer_env, stdin=subprocess.DEVNULL, stdout=log(viewer_log.name), stderr=subprocess.STDOUT)
        clean.callback(stop, viewer)
        pair = [host, viewer]
        window = eventually('unique viewer drawable', pair, lambda: current_window(local))
        xid = window.id
        require(geometry(window) == INITIAL, 'unexpected initial viewer geometry')
        eventually('full negotiated input grant', pair, lambda: 'connected; keyboard + pointer; clipboard off' in viewer_log.read_text())
        label = 'H.264' if args.codec == 'h264' else 'JPEG'
        captures, edges, changes = result['captures'], result['source_edges'], result['resize_window_trace']

        def color():
            w, h = geometry(window)
            return color_class(rgb_at(receiver, xid, w * 3 // 8, h * 3 // 8))

        def ack_epoch(epoch, after_sequence=-1):
            matching = [row for row in summaries(viewer_log, 'viewer') if row['acked'] and row.get('last_frame')
                        and row['last_frame']['source_epoch'] == epoch
                        and row['last_frame']['sequence'] > after_sequence]
            if not matching:
                return None
            frame = matching[-1]['last_frame']
            require(frame['codec'] == label, f'wrong granted video codec {frame}')
            return frame if frame['encoded_dimensions'] == frame['source_dimensions'] == list(SIZE) else None

        def palette_visible(index, phase):
            x, y, w, h = bounds(geometry(window))
            rgb = rgb_at(receiver, xid, x + w // 4, y + h // 4)
            value = RGB[index][phase]
            expected = (value >> 16, (value >> 8) & 255, value & 255)
            return max(abs(a - b) for a, b in zip(rgb, expected)) <= 17

        def steady_full_update(index, prior):
            # Drive a full decoded RGB update even for a static source whose
            # startup keyframe deliberately uses synchronous preparation.
            paint(hosts, sources[index], index, phase=1)
            eventually('source palette pulse actually visible', pair, lambda: palette_visible(index, 1))
            painted = eventually('drawn ACK for full palette update', pair,
                                 lambda: ack_epoch(index + 1, prior['sequence']))
            paint(hosts, sources[index], index)
            eventually('canonical RGB source restored', pair, lambda: palette_visible(index, 0))
            return eventually('canonical source drawn ACK', pair,
                              lambda: ack_epoch(index + 1, painted['sequence']))

        def configure(view):
            window.configure(width=view[0], height=view[1])
            local.sync()
            require(geometry(window) == view, 'owned Xvfb did not apply tested local geometry')
            changes.append({'viewport': view, 'observed_ns': time.monotonic_ns()})

        def click(index, view):
            left, top, w, h = bounds(view)
            position = (left + w // 3, top + h * 2 // 3)
            expected = tuple(a + b for a, b in zip(POSITIONS[index], expected_source_pixel(view, position)))
            window.set_input_focus(X.RevertToParent, X.CurrentTime)
            fake(local, X.MotionNotify, x=position[0], y=position[1])
            fake(local, X.ButtonPress, 1)
            arrived = wait_edge(edges, hosts, host, X.ButtonPress, 1, sources[index].id)
            fake(local, X.ButtonRelease, 1)
            wait_edge(edges, hosts, host, X.ButtonRelease, 1, sources[index].id)
            actual = (arrived['root_x'], arrived['root_y'])
            require(max(abs(a-b) for a, b in zip(expected, actual)) <= 2, f'input used wrong viewport/source: {actual} != {expected}')

        eventually('source A actual painted', pair, lambda: color() == 'A')
        first_a = eventually('source A drawn ACK window', pair, lambda: ack_epoch(1))
        result['source_a_ack'] = steady_full_update(0, first_a)
        captures['a_initial'] = capture(directory, 'a_initial', INITIAL, receiver, xid, 'A')
        configure(OTHER)
        eventually('A redirected on opposite-letterbox geometry', pair, lambda: color() == 'A')
        eventually('left letterbox black at opposite orientation', pair,
                   lambda: rgb_at(receiver, xid, 0, OTHER[1] // 2) == (0, 0, 0))
        time.sleep(.10)
        captures['a_other'] = capture(directory, 'a_other', OTHER, receiver, xid, 'A')
        configure(INITIAL)
        # Exercise viewport ABA separately from the held-key source barrier.
        # The smaller intermediate viewport can also elicit a host geometry
        # update, so no held input is used as evidence across this burst.
        paint(hosts, sources[0], 0, phase=1)
        for view in (CLIPPED, OTHER, INITIAL, OTHER, INITIAL):
            configure(view)
        paint(hosts, sources[0], 0)
        eventually('A after local viewport restore', pair, lambda: color() == 'A'
                   and palette_visible(0, 0)
                   and rgb_at(receiver, xid, INITIAL[0] // 2, 0) == (0, 0, 0))
        # Old output can already have the expected bars and palette. Ignore
        # pre-restore endpoint windows and require actual presentation progress
        # in the restored native crop before attempting a coordinate edge.
        host_floor = len(summaries(host_log, 'host'))
        viewer_floor = len(summaries(viewer_log, 'viewer'))
        result['post_restore_ack_floor'] = eventually('new native-size drawn scope and drained host ACK credit', pair,
            lambda: restored_ack_floor(summaries(host_log, 'host')[host_floor:],
                                       summaries(viewer_log, 'viewer')[viewer_floor:], result['source_a_ack'], label),
            timeout=25)
        require(geometry(window) == INITIAL and palette_visible(0, 0), 'restored native drawable changed before click')
        captures['a_restored'] = capture(directory, 'a_restored', INITIAL, receiver, xid, 'A')
        click(0, INITIAL)
        old, fresh, control, super_key, shift, f12 = [local.keysym_to_keycode(XK.string_to_keysym(name))
                  for name in ('F8', 'F9', 'Control_L', 'Super_L', 'Shift_L', 'F12')]
        require(0 not in (old, fresh, control, super_key, shift, f12), 'probe shortcut key missing')
        fake(local, X.KeyPress, old)
        wait_edge(edges, hosts, host, X.KeyPress, old, sources[0].id)
        require(key_is_held(hosts, old) and key_is_held(local, old), 'source must hold old key before barrier')
        paint(hosts, sources[0], 0, phase=1)
        for code in (control, super_key, shift, f12):
            fake(local, X.KeyPress, code)
        old_up = wait_edge(edges, hosts, host, X.KeyRelease, old, sources[0].id)
        require(not key_is_held(hosts, old) and key_is_held(local, old), 'source barrier released the wrong key generation')
        for code in (f12, shift, super_key, control, old):
            fake(local, X.KeyRelease, code)
        local.sync()
        result['local_old_physical_up_ns'] = time.monotonic_ns()
        require(old_up['observed_ns'] < result['local_old_physical_up_ns'], 'old scope release did not precede local key-up')
        eventually('new-source B actual pixels', pair, lambda: color() == 'B', timeout=18)
        first_b = eventually('new-source B drawn ACK window', pair, lambda: ack_epoch(2), timeout=18)
        result['source_b_ack'] = steady_full_update(1, first_b)
        captures['b_final'] = capture(directory, 'b_final', INITIAL, receiver, xid, 'B')
        require(current_window(local).id == xid and geometry(window) == INITIAL, 'viewer role or restored geometry changed')
        sources[1].set_input_focus(X.RevertToParent, X.CurrentTime)
        hosts.sync()
        click(1, INITIAL)
        fake(local, X.KeyPress, fresh)
        wait_edge(edges, hosts, host, X.KeyPress, fresh, sources[1].id)
        fake(local, X.KeyRelease, fresh)
        wait_edge(edges, hosts, host, X.KeyRelease, fresh, sources[1].id)
        require(not key_is_held(hosts, fresh), 'new host key remained held')
        for _ in range(15):
            require(color() == 'B', 'old-source pixel reappeared after observed and acknowledged B')
            time.sleep(.008)
        result['viewer_exit'] = close_viewer(local, window, viewer)
        result['host_exit'] = host.wait(timeout=12)
        require(result['viewer_exit'] == result['host_exit'] == 0, 'owned host/viewer did not exit cleanly')
        list(drain_edges(edges, hosts))
        real_probe = [(item['type'], item['detail'], item['target']) for item in edges
                      if item['type'] in (X.KeyPress, X.KeyRelease) and item['detail'] in (old, fresh, f12)]
        require(real_probe == [(X.KeyPress, old, sources[0].id), (X.KeyRelease, old, sources[0].id),
                               (X.KeyPress, fresh, sources[1].id), (X.KeyRelease, fresh, sources[1].id)],
                'stale, shortcut or misordered key edges reached a source')
        viewer_stats, host_stats = summaries(viewer_log, 'viewer'), summaries(host_log, 'host')
        ids = {item['session_id'] for item in viewer_stats}
        require(len(ids) == 1 and ids == {item['session_id'] for item in host_stats}, 'host and viewer did not retain one authenticated session')
        require(viewer_stats[-1]['final'] and sum(row['drawn_acks'] for row in host_stats) >= 2, 'actual host drawn ACK route missing')
        if args.codec == 'h264':
            require(all(row.get('last_presentation_path') in (None, 'rgb') for row in viewer_stats),
                    'a presentation path left viewer CPU RGB')
            require(sum(row['h264_frames'] for row in host_stats) > 0, 'host did not actually encode H.264')
            require('host switched to JPEG' not in viewer_log.read_text(), 'unexpected video fallback during test')
        result['viewer_preparation'] = counts = prep_counters(viewer_stats)
        if arm == 'on' and args.codec == 'h264':
            require(counts['prepared'] > 0 and counts['submitted'] > 0 and counts['stage_observations'] > 0, 'treatment did not exercise CPU preparation')
        elif arm == 'off' or args.codec == 'jpeg':
            require(counts['prepared'] == 0, 'baseline or excluded JPEG path unexpectedly exercised preparation')
        result['authenticated_viewer_ack_count'] = sum(row['acked'] for row in viewer_stats)
        result['authenticated_host_drawn_ack_count'] = sum(row['drawn_acks'] for row in host_stats)


def terminate(signum, _frame):
    raise KeyboardInterrupt(f'fixture interrupted by signal {signum}')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host', type=Path)
    parser.add_argument('--viewer', type=Path)
    parser.add_argument('--host-sha256')
    parser.add_argument('--viewer-sha256')
    parser.add_argument('--lib', default='')
    parser.add_argument('--codec', choices=('h264', 'jpeg'), default='h264')
    parser.add_argument('--order', default='off,on,off')
    parser.add_argument('--out', type=Path)
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test:
        assert bounds(INITIAL) == (0, 70, 1393, 785)
        assert bounds(OTHER) == (129, 0, 1393, 785)
        assert expected_source_pixel(INITIAL, (0, 70)) == (0, 0)
        assert expected_source_pixel(OTHER, (129 + 1392, 784)) == (1392, 784)
        assert color_class((219, 39, 34)) == 'A' and color_class((17, 187, 105)) == 'B'
        old = {'source_epoch': 1, 'geometry_epoch': 3, 'sequence': 225, 'codec': 'H.264',
               'source_dimensions': list(SIZE), 'encoded_dimensions': list(SIZE)}
        actual = old | {'geometry_epoch': 6, 'sequence': 290}
        host = {'session_id': 'test', 'outstanding': 0, 'drawn_acks': 66,
                'last_sent_frame': actual | {'sequence': 291}}
        viewer = {'session_id': 'test', 'acked': 66, 'last_frame': actual}
        assert restored_ack_floor([host], [viewer], old, 'H.264')['presented_frame'] == actual
        assert not restored_ack_floor([host | {'outstanding': 1}], [viewer], old, 'H.264')
        assert not restored_ack_floor([host | {'session_id': 'other'}], [viewer], old, 'H.264')
        assert not restored_ack_floor([host | {'last_sent_frame': old}], [viewer], old, 'H.264')
        assert not restored_ack_floor([host], [viewer | {'last_frame': old}], old, 'H.264')
        print('offline RGB classification, odd letterbox, relative input geometry and restored ACK floor passed')
        return 0
    if not all((args.host, args.viewer, args.host_sha256, args.viewer_sha256, args.out)):
        parser.error('real run requires both explicit binary paths/pins and fresh output directory')
    require(sha256(args.host) == args.host_sha256 and sha256(args.viewer) == args.viewer_sha256, 'release pin mismatch')
    arms = args.order.split(',')
    require(set(arms) == {'on', 'off'}, 'parity requires both treatment and control')
    args.out.mkdir(mode=0o700)
    result = {'codec': args.codec, 'host_sha256': args.host_sha256, 'viewer_sha256': args.viewer_sha256,
              'arms': [], 'limitations': ['CPU worker overlap is opportunistic without a per-job test gate',
                                         'real drawn ACK progress counted by endpoint windows; exact per-sequence ACK history unavailable']}
    signal.signal(signal.SIGTERM, terminate)
    for i, arm in enumerate(arms, 1):
        directory = args.out / f'{i}-{arm}'
        directory.mkdir(mode=0o700)
        lane = {'arm': arm, 'status': 'failed', 'captures': {}, 'source_edges': [], 'resize_window_trace': []}
        try:
            run_arm(args, directory, arm, lane)
            lane['status'] = 'passed'
        except (Exception, KeyboardInterrupt) as error:
            lane['error'] = f'{type(error).__name__}: {error}'
            if isinstance(error, KeyboardInterrupt):
                raise
        finally:
            result['arms'].append(lane)
            (args.out / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    if all(lane['status'] == 'passed' for lane in result['arms']):
        sources = [lane['source_content_sha256'] for lane in result['arms']]
        require(all(row == sources[0] for row in sources), 'test source RGB differed across arms')
        result['visible_rgb_parity'] = {name: len({lane['captures'][name]['sha256'] for lane in result['arms']}) == 1
                                        for name in result['arms'][0]['captures']}
        (args.out / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
        return 0 if all(result['visible_rgb_parity'].values()) else 1
    return 1


if __name__ == '__main__':
    raise SystemExit(main())
