"""Recompute the HEVC XTerm comparison from owned drawable observations."""

from collections import Counter
import hashlib
import json
from math import isclose
from pathlib import Path
import re
import sys
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile

from run_baseline import select_telemetry
from score import MEASURE_SECONDS, TAIL_SECONDS, WARM_SECONDS, score_pixels
from settling import FINAL_MARKER, measure_settling
from terminal_scroll import SIZE, sample


LAB = Path(__file__).resolve().parent
REPORT_NAME = 'x11-terminal-scroll-hevc444-lossless-option-pair'
SECOND = 1_000_000_000
EXPECTED_HOST = 'a62902b410c2672b27103c235cdebbc67f85b986e52bc504f5b8f952383d9155'
EXPECTED_VIEWER = 'aaa1ed44223181963b3463fb169d56c9a76b31a514f29915f7ad5d47002690a3'
HOST_MODE = {'cbr': 'NVENC', 'lossless': 'NVENC, lossless constant QP 0'}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(path.read_bytes())


def jsonl(path):
    return [json.loads(line) for line in path.read_bytes().splitlines()]


class Photo:
    """Use the original pixel classifier on an unmodified captured raster."""

    def __init__(self, path):
        header = f'P6\n{SIZE[0]} {SIZE[1]}\n255\n'.encode()
        payload = path.read_bytes()
        assert payload.startswith(header)
        self.rgb = payload[len(header):]
        assert len(self.rgb) == SIZE[0] * SIZE[1] * 3

    def crop(self, _xid, x, y, w, h):
        rows = []
        for scan in range(y, y+h):
            start = (scan * SIZE[0] + x) * 3
            row = self.rgb[start:start + w*3]
            raw = bytearray(w*4)
            raw[0::4], raw[1::4], raw[2::4] = row[2::3], row[1::3], row[0::3]
            rows.append(raw)
        return rows


def measure_static_text(source, viewer):
    rectangle = [0, 20, 1200, 200]
    reference = b''.join(row[1::4] for row in source.crop(0, *rectangle))
    rendered = b''.join(row[1::4] for row in viewer.crop(0, *rectangle))
    expected_foreground = sum(value >= 128 for value in reference)
    reported_foreground = sum(value >= 128 for value in rendered)
    matching_foreground = sum(a >= 128 and b >= 128 for a,b in zip(reference,rendered,strict=True))
    return {'rectangle': rectangle, 'examined_pixels': len(reference), 'green_channel_threshold': 128,
            'foreground_recall': matching_foreground / expected_foreground,
            'foreground_precision': matching_foreground / reported_foreground,
            'mean_absolute_green_difference': sum(abs(a-b) for a,b in zip(reference,rendered,strict=True))
                                              / len(reference)}


def static_signature_population(directory):
    scope = read_json(directory / 'static-scope.json')
    start, end = (scope[f'score_{bound}_monotonic_ns'] for bound in ('start', 'end'))
    counts = Counter(row['scroll_signature'] for row in jsonl(directory / 'static-pixels.jsonl')
                     if start <= row['end_monotonic_ns'] < end and row['scroll_signature'] is not None)
    return dict(sorted(counts.items()))


def settling_observation(host, viewer, case):
    marker, signature = sample(Photo(host/'source-settle-end.ppm'), 0, SIZE[0], case)
    reference = signature if marker == FINAL_MARKER else None
    return {role: measure_settling(jsonl(directory/'settle-pixels.jsonl'),
                                   read_json(directory/'settle-scope.json'), reference)
            for role, directory in (('host', host), ('viewer', viewer))}


def measure(phase, endpoint, actual, translated, run):
    raw = read_json(actual / f'{phase}-scope.json')
    begin, end = (raw[f'score_{part}_monotonic_ns'] for part in ('start', 'end'))
    assert begin - raw['phase_start_monotonic_ns'] == WARM_SECONDS * SECOND
    assert end - begin == MEASURE_SECONDS * SECOND
    assert raw['telemetry_phase_end_monotonic_ns'] - end == TAIL_SECONDS * SECOND
    assert raw['observer_end_monotonic_ns'] >= end
    samples = jsonl(actual / f'{phase}-pixels.jsonl')
    lane = 'source' if endpoint == 'host' else 'viewer'
    assert all(item['side'] == lane and item['start_monotonic_ns'] <= item['end_monotonic_ns']
               for item in samples)
    assert all(a['end_monotonic_ns'] <= b['start_monotonic_ns']
               for a, b in zip(samples, samples[1:]))
    observation = score_pixels(samples, begin, end)
    assert observation == raw['samples'][lane]
    telemetry = select_telemetry(translated, raw, endpoint, SIZE)
    exact = set(telemetry) - {'window_seconds'}
    assert all(telemetry[key] == raw['telemetry'][key] for key in exact)
    assert isclose(telemetry['window_seconds'], raw['telemetry']['window_seconds'])
    assert len(telemetry['session_ids']) == 1 and telemetry['frame_scopes_match_requested_codec']
    if phase == 'motion':
        assert telemetry['frame_scopes_observed'] > 0
    records = jsonl(translated / f'{phase}-{endpoint}.jsonl')
    observed_frame_field = 'last_sent_frame' if endpoint == 'host' else 'last_frame'
    for key in ('source_epoch', 'geometry_epoch'):
        values = sorted({row[observed_frame_field][key] for row in records if row.get(observed_frame_field)})
        run.add((key, tuple(values)))
    stages = ('capture_ms', 'hevc444_ms', 'socket_write_ms', 'send_to_ack_ms') if endpoint == 'host' else (
        'decode_ms', 'presentation_completion_ms'
    )
    for stage in stages:
        percentiles = [row['stages'][stage]['quantiles']['p95_ms'] for row in records
                       if row.get('stages', {}).get(stage, {}).get('quantiles', {}).get('samples')]
        telemetry.setdefault('max_recent_window_p95_ms', {})[stage] = max(percentiles) if percentiles else None
    if endpoint == 'host':
        telemetry['payload_mbit_per_second'] = sum(row['bytes'] for row in records)*8e-6/telemetry['window_seconds']
        telemetry['sampled_backpressure_skips'] = sum(row['backpressure_skipped'] for row in records)
    return observation, telemetry


def sanitized_identity(identity):
    keys = ('role', 'kernel', 'cpu', 'drawable_size', 'clock', 'release_sha256')
    result = {key: identity[key] for key in keys}
    result['boot_id_sha256'] = digest(identity['boot_id'].encode())
    if identity['role'] == 'host':
        result['xterm'] = {key: identity['xterm'][key] for key in ('sha256', 'version', 'font', 'grid')}
    return result


def archive_component(entries, run, name, paths):
    for path in paths:
        if (run / path).is_file():
            entries[name + '/' + path] = (run / path).read_bytes()


def codec_activation(run):
    expected = {'host': r'jwm-remote: hardware (HEVC 4:4:4|H\.264) encoding active \((NVENC(?:, lossless constant QP 0)?)\)',
                'viewer': r'jwm-remote: (HEVC 4:4:4|H\.264) hardware decoder active \(([A-Za-z0-9-]+)\)'}
    results = {}
    for role, folder in (('host', run), ('viewer', run / 'viewer')):
        path = folder / f'{role}.log'
        matches = []
        if path.is_file():
            for line in path.read_text().splitlines():
                if match := re.fullmatch(expected[role], line):
                    matches.append({'codec': match[1], 'backend': match[2]})
        results[role] = matches
    return results


def verify_trial(batch, outcome, entries):
    name = f"trial-{outcome['trial']:02}"
    run = batch / name
    host_name, viewer_name = f'{name}/host', f'{name}/viewer'
    for endpoint, directory, member in (('host', run, host_name), ('viewer', run / 'viewer', viewer_name)):
        names = tuple(f'{phase}-{suffix}'
                      for phase in ('static', 'motion', 'settle')
                      for suffix in ('scope.json', 'pixels.jsonl')) + (f'{endpoint}-clocked-telemetry.jsonl',)
        archive_component(entries, directory, member, names)
    archive_component(entries, run, host_name, ('terminal-progress.jsonl', 'source-static.ppm',
                                                  'source-static-end.ppm', 'source-motion-end.ppm',
                                                  'source-settle-end.ppm'))
    archive_component(entries, run/'viewer', viewer_name, ('viewer-static.ppm', 'viewer-motion-end.ppm',
                                                           'viewer-settle-end.ppm'))
    archive_component(entries, run, name, ('session-route.json',))
    activation = codec_activation(run)
    entries[f'{name}/codec-active.json'] = (json.dumps(activation, indent=2)+'\n').encode()
    if outcome['status'] != 'completed':
        failures = {
            name: (run / name).read_text().splitlines()[-1][:256]
            for name in ('failure.log', 'artifact-fetch-failure.log') if (run / name).exists()
        }
        # Do not archive complete tracebacks or SSH logs from private paths.
        return {'trial': outcome['trial'], 'status': 'failed', 'host_rate_control': outcome['host_rate_control'],
                'failure_types': [entry.partition(':')[0] for entry in failures.values()],
                'failure': outcome['error'].split(':', 1)[0], 'codec_activation': activation}

    ident = read_json(run / 'identity.json')
    endpoints = {role: sanitized_identity(ident[role]) for role in ('host', 'viewer')}
    assert endpoints['host']['boot_id_sha256'] != endpoints['viewer']['boot_id_sha256']
    assert endpoints['host']['release_sha256'] == EXPECTED_HOST
    assert endpoints['viewer']['release_sha256'] == EXPECTED_VIEWER
    assert all(info['drawable_size'] == list(SIZE) for info in endpoints.values())
    assert endpoints['host']['xterm']['grid'] == [192,54]
    entries[f'{name}/endpoints.json'] = (json.dumps(endpoints, indent=2)+'\n').encode()
    case = ident['marker_case']
    rate = outcome['host_rate_control']
    assert rate == ident['rate_control']
    phases = {}
    scopes = set()
    with TemporaryDirectory(prefix='jwm-terminal-replay.') as temp:
        isolated = Path(temp)
        for endpoint, seen in (('host',run), ('viewer',run/'viewer')):
            trace = f'{endpoint}-clocked-telemetry.jsonl'
            (isolated / trace).symlink_to((seen / trace).resolve())
            for phase in ('static','motion'):
                obs, stats = measure(phase, endpoint, seen, isolated, scopes)
                phases.setdefault(phase, {})[endpoint] = {'raster': obs, 'telemetry': stats}
    for field in ('source_epoch', 'geometry_epoch'):
        nonempty = {values for key, values in scopes if key == field and values}
        assert len(nonempty) == 1 and len(next(iter(nonempty))) == 1
    session_ids = {session for endpoints in phases.values() for phase in endpoints.values()
                   for session in phase['telemetry']['session_ids']}
    assert len(session_ids) == 1
    route = read_json(run/'session-route.json')
    assert all(set(role['sessions']) == session_ids for role in route.values())
    assert route['host']['alternate_codec_frames_or_atlases'] == 0
    for directory, path in ((run,'source-static.ppm'),(run,'source-static-end.ppm'),
                            (run/'viewer','viewer-static.ppm')):
        sequence, glyphs = sample(Photo(directory/path),0,SIZE[0],case)
        assert sequence == 0 and glyphs
    photos = {}
    for endpoint, directory, path in (('host',run,'source-motion-end.ppm'),
                                     ('viewer',run/'viewer','viewer-motion-end.ppm')):
        sequence, glyphs = sample(Photo(directory/path),0,SIZE[0],case)
        photos[endpoint] = {'marker': sequence, 'glyph_signature': glyphs}
    raw = read_json(run/'result.json')
    assert raw['codec'] == 'HEVC 4:4:4'
    assert activation['host'] == [{'codec': 'HEVC 4:4:4', 'backend': HOST_MODE[rate]}]
    assert {'codec': 'HEVC 4:4:4', 'backend': 'NVDEC'} in activation['viewer']
    events = jsonl(run/'peer-events.jsonl')
    assert [entry['event'] for entry in events] == [
        'viewer_ready','viewer_static_started','viewer_static_done',
        'viewer_motion_armed','viewer_motion_done','viewer_settle_done','viewer_disconnected']
    assert all(event['run_id'] == ident['run_id'] for event in events)
    assert events[0]['hevc444_decoder_active'] is True
    entries[f'{name}/control-events.json'] = (json.dumps(
        [{'event':entry['event'],'run_id':ident['run_id']} for entry in events],indent=2)+'\n').encode()
    for role in ('host','viewer'):
        stats = phases['motion'][role]['raster']
        assert stats['unique_content_fps'] == raw[f'{"source" if role=="host" else "viewer"}_motion_fps']
    static_populations = {role: static_signature_population(directory)
                          for role, directory in (('host', run), ('viewer', run/'viewer'))}
    source_match = next(iter(static_populations['host'])) if len(static_populations['host']) == 1 else None
    viewer_static = phases['static']['viewer']['raster']
    exact_reads = static_populations['viewer'].get(source_match, 0)
    cadence_gate = (phases['motion']['viewer']['raster']['unique_content_fps'] >= 27
                    and raw['source_qualified'] and raw['telemetry_complete'])
    return {'trial': outcome['trial'], 'status': 'completed', 'scope': outcome['result']['scope'],
            'host_rate_control': rate, 'marker_case': case,
            'codec_activation': activation,
            'session_route': route,
            'endpoints': {role:sanitized_identity(ident[role]) for role in ('host','viewer')},
            'authenticated_session': session_ids.pop(), 'phases': phases,
            'motion_snapshot_evidence': photos,
            'static_unchanged': raw['static_unchanged'],
            'static_glyph_signature_sample_counts': static_populations,
            'viewer_static_exact_glyph_reads': exact_reads,
            'viewer_static_glyph_reads': viewer_static['valid_and_invalid_sample_reads'],
            'viewer_static_exact_gate_met': exact_reads == viewer_static['valid_and_invalid_sample_reads'] > 0,
            'settling': settling_observation(run, run/'viewer', case),
            'source_static_sha256': digest((run/'source-static.ppm').read_bytes()),
            'static_text': measure_static_text(Photo(run/'source-static.ppm'),
                                               Photo(run/'viewer/viewer-static.ppm')),
            'source_qualified': raw['source_qualified'],
            'telemetry_complete': raw['telemetry_complete'],
            'viewer_motion_gate_met': cadence_gate}


def publish(batch, output):
    outcomes = read_json(batch/'outcomes.json')
    manifest = read_json(batch/'manifest.json')
    assert len(outcomes) == manifest['requested_trials'] == 2
    assert [outcome['trial'] for outcome in outcomes] == [1, 2]
    assert [outcome['host_rate_control'] for outcome in outcomes] == ['cbr', 'lossless']
    entries = {}
    for filename, expected in manifest['workload']['files'].items():
        payload = (LAB / filename).read_bytes()
        assert digest(payload) == expected
        entries['fixture/'+filename] = payload
    entries['fixture/publish.py'] = Path(__file__).read_bytes()
    entries['trial-manifest.json'] = (batch/'manifest.json').read_bytes()
    trials = [verify_trial(batch,outcome,entries) for outcome in outcomes]
    valid = [trial for trial in trials if trial['status']=='completed']
    assert len({trial['authenticated_session'] for trial in valid}) == len(valid)
    matched = len(valid) == 2 and all(
        len({tuple(trial['phases']['motion'][role]['telemetry']['routes']) for trial in valid}) == 1
        for role in ('host', 'viewer'))
    matched = matched and len({trial['source_static_sha256'] for trial in valid}) == 1
    matched = matched and len({trial['endpoints']['host']['xterm']['sha256'] for trial in valid}) == 1
    archive = output/(REPORT_NAME+'-raw.zip')
    with ZipFile(archive,'w',compression=ZIP_DEFLATED,compresslevel=5) as bundle:
        for name,content in sorted(entries.items()):
            bundle.writestr(name,content)
    with ZipFile(archive) as bundle:
        assert bundle.testzip() is None
        assert set(bundle.namelist()) == set(entries)
        assert all(bundle.read(name)==item for name,item in entries.items())
    report = {'schema_version':1,
              'scope':'One matched real XTerm 1080p scroll pair comparing NVENC HEVC 4:4:4 CBR and lossless on two owned X11 endpoints.',
              'diagnostic_only':True,
              'measurement_limits':'Each arm uses a 30-second warmup and 60-second scored window per phase. One pair cannot estimate across-run variance. Static metrics measure a selected glyph mask and crop. Settling uses the first final marker observed on each endpoint clock, and does not time transit from source to viewer, or physical display response.',
              'manifest':manifest,'trials':trials,'matched_qualified_pair':matched,
              'summary':{'attempt_status_counts':dict(Counter(trial['status'] for trial in trials)),
                         'viewer_fps':[trial['phases']['motion']['viewer']['raster']['unique_content_fps']
                                       for trial in valid],
                         'pilot_trials_at_least_27_fps':sum(
                             trial['phases']['motion']['viewer']['raster']['unique_content_fps'] >= 27
                             for trial in valid
                         ),
                         'composite_gate_met_count':sum(
                             trial['viewer_motion_gate_met'] and trial['viewer_static_exact_gate_met'] for trial in valid
                         )},
              'archive':{'path':archive.name,'sha256':digest(archive.read_bytes()),
                         'entries':{name:digest(data) for name,data in entries.items()}}}
    (output/(REPORT_NAME+'.json')).write_text(json.dumps(report,indent=2)+'\n')
    replay(report, archive)
    print(report['summary'])


def replay(report, archive):
    assert digest(archive.read_bytes()) == report['archive']['sha256']
    with ZipFile(archive) as raw:
        assert raw.testzip() is None
        assert set(raw.namelist()) == set(report['archive']['entries'])
        for member, expected in report['archive']['entries'].items():
            assert digest(raw.read(member)) == expected
        for trial in report['trials']:
            if trial['status'] != 'completed':
                continue
            name = f"trial-{trial['trial']:02}"
            identities = json.loads(raw.read(f'{name}/endpoints.json'))
            assert identities == trial['endpoints']
            assert json.loads(raw.read(f'{name}/codec-active.json')) == trial['codec_activation']
            assert json.loads(raw.read(f'{name}/session-route.json')) == trial['session_route']
            with TemporaryDirectory(prefix='jwm-terminal-bundle-replay.') as work:
                root = Path(work)
                source = root/'source-static.ppm'
                viewer = root/'viewer-static.ppm'
                source.write_bytes(raw.read(f'{name}/host/source-static.ppm'))
                viewer.write_bytes(raw.read(f'{name}/viewer/viewer-static.ppm'))
                assert digest(source.read_bytes()) == trial['source_static_sha256']
                assert measure_static_text(Photo(source),Photo(viewer)) == trial['static_text']
                for role in ('host', 'viewer'):
                    observed = root / role
                    observed.mkdir()
                    trace = f'{role}-clocked-telemetry.jsonl'
                    for member in (trace, *(f'{phase}-{suffix}' for phase in ('static','motion')
                                            for suffix in ('scope.json','pixels.jsonl'))):
                        (observed/member).write_bytes(raw.read(f'{name}/{role}/{member}'))
                    (root/trace).symlink_to(observed/trace)
                    for phase in ('static','motion'):
                        raster, telemetry = measure(phase, role, observed, root, set())
                        expected = trial['phases'][phase][role]
                        assert raster == expected['raster'] and telemetry == expected['telemetry']
                    assert static_signature_population(observed) == trial['static_glyph_signature_sample_counts'][role]
                    for member in ('settle-pixels.jsonl','settle-scope.json',
                                   'source-settle-end.ppm' if role == 'host' else 'viewer-settle-end.ppm'):
                        (observed/member).write_bytes(raw.read(f'{name}/{role}/{member}'))
                assert settling_observation(root/'host', root/'viewer', trial['marker_case']) == trial['settling']


if __name__=='__main__':
    if sys.argv[1] == 'replay':
        replay(read_json(Path(sys.argv[2])), Path(sys.argv[3]))
        print('Replayed the archive with matching raster counts and telemetry')
    else:
        publish(Path(sys.argv[1]),Path(sys.argv[2]))
