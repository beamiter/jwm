"""Record the final XTerm raster and its glyph-mask stability per endpoint."""

from collections import Counter
import json
import time

from score import SECOND, write_json
from terminal_scroll import MOTION_SECONDS, SOURCE_FPS, sample


FINAL_MARKER = MOTION_SECONDS * SOURCE_FPS
OBSERVE_SECONDS = 10
ARRIVAL_TIMEOUT_SECONDS = 16


def collect_settle(run, lane, pixels, xid, width, case, processes):
    origin = time.monotonic_ns()
    arrival_deadline = origin + ARRIVAL_TIMEOUT_SECONDS * SECOND
    deadline = arrival_deadline
    arrival = None
    health_check = 0
    with (run / 'settle-pixels.jsonl').open('x') as observer:
        while (now := time.monotonic_ns()) < deadline:
            if now >= health_check:
                dead = [proc.args[0] for proc in processes if proc.poll() is not None]
                if dead:
                    raise RuntimeError(f'owned actors ended during text settling: {dead}')
                health_check = now + SECOND
            marker, glyph = sample(pixels, xid, width, case)
            end = time.monotonic_ns()
            row = {'side': lane, 'start_monotonic_ns': now, 'end_monotonic_ns': end,
                   'marker': marker, 'scroll_signature': glyph}
            print(json.dumps(row, separators=(',', ':')), file=observer)
            if arrival is None and marker == FINAL_MARKER and end < arrival_deadline:
                arrival = end
                deadline = arrival + OBSERVE_SECONDS * SECOND
            slot = (end - origin) * 90 // SECOND + 1
            next_tick = min(deadline, origin + slot * SECOND // 90)
            time.sleep(max(0, (next_tick - time.monotonic_ns()) / SECOND))
    scope = {'lane': lane, 'phase_start_monotonic_ns': origin,
             'first_final_marker_monotonic_ns': arrival, 'end_monotonic_ns': deadline,
             'observer_end_monotonic_ns': time.monotonic_ns(),
             'arrival_deadline_monotonic_ns': arrival_deadline, 'target_marker': FINAL_MARKER}
    write_json(run / 'settle-scope.json', scope)


def measure_settling(rows, scope, reference):
    start = scope['phase_start_monotonic_ns']
    deadline = scope['arrival_deadline_monotonic_ns']
    end = scope['end_monotonic_ns']
    arrival = next((r['end_monotonic_ns'] for r in rows
                    if r['marker'] == FINAL_MARKER and r['end_monotonic_ns'] < deadline), None)
    if (deadline - start != ARRIVAL_TIMEOUT_SECONDS * SECOND
            or scope['target_marker'] != FINAL_MARKER
            or arrival != scope['first_final_marker_monotonic_ns']
            or end != (deadline if arrival is None else arrival + OBSERVE_SECONDS * SECOND)
            or scope['observer_end_monotonic_ns'] < end):
        raise ValueError('settling scope does not match the archived local marker observations')
    if any(r['side'] != scope['lane'] or r['start_monotonic_ns'] > r['end_monotonic_ns'] for r in rows):
        raise ValueError('settling observer row has an invalid lane or interval')
    if any(a['end_monotonic_ns'] > b['start_monotonic_ns'] for a, b in zip(rows, rows[1:])):
        raise ValueError('settling observer rows overlap')
    if arrival is None:
        return {'target_marker_observed': False, 'waited_seconds': ARRIVAL_TIMEOUT_SECONDS, 'reads': len(rows)}
    kept = [row for row in rows if arrival <= row['end_monotonic_ns'] < end]
    population = Counter(row['scroll_signature'] for row in kept
                         if row['marker'] == FINAL_MARKER and row['scroll_signature'] is not None)
    matches = [reference is not None and row['marker'] == FINAL_MARKER
               and row['scroll_signature'] == reference for row in kept]
    first = next((i for i, matched in enumerate(matches) if matched), None)
    last_miss = max((i for i, matched in enumerate(matches) if not matched), default=-1)
    stable = last_miss + 1 if last_miss + 1 < len(kept) else None

    def elapsed(index):
        return (kept[index]['end_monotonic_ns'] - arrival) / 1e6 if index is not None else None

    return {'target_marker_observed': True, 'scope_seconds': OBSERVE_SECONDS,
            'reads': len(kept), 'exact_glyph_reads': sum(matches),
            'other_marker_reads': sum(row['marker'] != FINAL_MARKER for row in kept),
            'invalid_glyph_reads': sum(row['scroll_signature'] is None for row in kept),
            'distinct_glyph_signatures': len(population), 'source_reference_available': reference is not None,
            'first_exact_ms_after_local_final_marker': elapsed(first),
            'first_exact_ms_with_no_later_miss_in_scope': elapsed(stable)}
