import asyncio
from contextlib import asynccontextmanager
from pathlib import Path
import runpy

if not hasattr(asyncio, "timeout"):
    @asynccontextmanager
    async def timeout(seconds):
        if seconds is None:
            yield
            return
        owner = asyncio.current_task()
        expired = False

        def expire():
            nonlocal expired
            expired = True
            owner.cancel()

        timer = asyncio.get_running_loop().call_later(seconds, expire)
        try:
            yield
        except asyncio.CancelledError:
            if not expired:
                raise
            raise TimeoutError from None
        finally:
            timer.cancel()

    asyncio.timeout = timeout

runpy.run_path(str(Path(__file__).with_name("remote-fault-proxy.py")), run_name="__main__")
