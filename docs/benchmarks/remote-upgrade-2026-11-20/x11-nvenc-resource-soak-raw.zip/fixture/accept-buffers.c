#define _GNU_SOURCE
#include <dlfcn.h>
#include <netinet/in.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>

static bool loopback(int fd) {
    struct sockaddr_in addr = {0};
    socklen_t length = sizeof(addr);
    return getsockname(fd, (struct sockaddr *)&addr, &length) == 0
        && length == sizeof(addr) && addr.sin_family == AF_INET
        && ntohl(addr.sin_addr.s_addr) == INADDR_LOOPBACK;
}

int accept4(int fd, struct sockaddr *addr, socklen_t *length, int flags) {
    int (*real_accept4)(int, struct sockaddr *, socklen_t *, int) =
        dlsym(RTLD_NEXT, "accept4");
    int new_fd = real_accept4(fd, addr, length, flags);
    const char *requested = getenv("P09_SEND_BUFFER");
    if (new_fd >= 0 && requested && loopback(new_fd)) {
        int bytes = atoi(requested), actual = 0;
        socklen_t size = sizeof(actual);
        if (bytes < 4096 || setsockopt(new_fd, SOL_SOCKET, SO_SNDBUF, &bytes, sizeof(bytes))
            || getsockopt(new_fd, SOL_SOCKET, SO_SNDBUF, &actual, &size)) {
            perror("P09 private socket send buffer");
            return new_fd;
        }
        fprintf(stderr, "P09_SOCKET_BUFFER requested=%d effective=%d\n", bytes, actual);
    }
    return new_fd;
}
