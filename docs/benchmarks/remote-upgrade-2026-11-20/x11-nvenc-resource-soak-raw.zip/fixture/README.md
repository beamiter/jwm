# Isolated sustained NVENC session

The controller runs one 1080p H.264 NVENC session between the existing two
release installations. It uses the same isolated Xvfb source, deterministic
motion scene, X11 hardware-decode viewer, and private SSH forward as the P09
benchmark. It shares the benchmark lock. Run it after scored work.

## Stage and run

The viewer needs the existing release at
`/tmp/jwm-p08-p09-release/jwm-remote`. The source needs its matching release at
that path on Ubuntu. Stage the soak in a new private source directory.

```sh
cd /tmp/jwm-p09-soak
peer=ubuntu@192.168.0.78
remote_dir=$(ssh "$peer" 'mktemp -d /tmp/jwm-p09-soak.XXXXXXXX')
scp source.py resources.py processes.py remote-fault-proxy.py proxy-compat.py \
  p09-workload.c accept-buffers.c "$peer:$remote_dir/"
ssh "$peer" "cd '$remote_dir' &&
  cc -std=c11 -O3 -Wall -Wextra -Werror -o p09-workload p09-workload.c \$(pkg-config --cflags --libs x11 xdamage xext) &&
  cc -shared -fPIC -O2 -o accept-buffers.so accept-buffers.c -ldl"
python3 -u soak.py --peer "$peer" --remote-dir "$remote_dir" \
  --label soak-fixed-1080p --arm fixed --measure-seconds 900 --sample-seconds 5
```

The repeatable shaped variant uses `--arm adaptive --cap 400000
--send-buffer 4096 --recv-buffer 4096` and a fresh label. The source compiles a
scratch painter with a longer duration guard. Its scene and marker format are
unchanged. A scored P09 painter limited to 300 seconds would stop before soak
measurement ends.

Each endpoint starts a local monotonic clock anchor when it logs its first
active, authenticated telemetry window with a frame ACK. The collector keeps
the connection alive for 60 seconds of burn-in and at least 900 measured seconds
on both endpoints. It samples on an absolute schedule and records missed slots
when it runs late. The viewer asks its own existing window to close, then
both endpoints must exit successfully. Raw source artifacts are copied after
cleanup, including failed trials when the source is still reachable.

## Read the results

`<label>/result.json` reports the scope, raw data coverage and stream identity.
The adjacent JSONL files contain up to 206 resource samples and 250 typed
telemetry windows per endpoint. Each process is tracked by PID, Linux start
ticks, and the executable device/inode. All samples verify that identity
before and after reading `/proc/<pid>/status` and `/proc/<pid>/fd`.

Resource summaries exclude burn-in and report the observed minimum, median,
and peak for RSS in KiB, thread count, and descriptor count. Trend is the
difference between observed medians in the first versus last minute of the
measurement. The summaries retain missed slots and the largest interval
between samples, including the measurement boundaries. Sampled peaks can miss
short-lived changes.

The host's retained whole telemetry windows include current outstanding credit
counts, per-window peaks, end-of-window distribution, H.264 throughput and
ACKs, zero-send windows, and the greatest available per-window credit-wait
p99. The viewer contributes decoder queue depth and receive/draw/ACK counts.
Telemetry windows use their recorded duration and local arrival time. Coverage
edges are reported because whole telemetry windows need not span the exact
resource interval. The two absolute monotonic clocks are separate.

These measurements cover the JWM endpoint processes in this isolated setup.
The source painter, Xvfb, SSH, and the optional fault proxy run as separate
processes. Process RSS covers CPU-resident memory and can include shared pages.
It does not measure GPU VRAM, the compositor's memory, or display timing.
Frame counters report software progress. Resource trends are descriptive for
this session and carry no new resource pass thresholds.

## Local verification

```sh
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest -v test_resources.py
cc -fsyntax-only -std=c11 -Wall -Wextra -Werror p09-workload.c \
  $(pkg-config --cflags x11 xdamage xext)
```

Unit cases use fake PID records, time, resource samples, and telemetry.
