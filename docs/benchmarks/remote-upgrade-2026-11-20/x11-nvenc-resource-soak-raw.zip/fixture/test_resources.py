"""Resource accounting on fake proc entries, clocks, subprocess pipes and telemetry."""
import ast
from dataclasses import replace
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from resources import (BURN_SECONDS, MAX_RESOURCE_SAMPLES, SECOND, Plan, TelemetryRelay,
                       collect, read_identity, resources, start_ticks, summarize_resources,
                       summarize_video, track)

ROOT = Path(__file__).resolve().parent


def stat(pid, ticks, state="S"):
    return f"{pid} (comm with ) and spaces) " + " ".join([state] + ["0"] * 18 + [str(ticks), "0"])


class FakeClock:
    def __init__(self):
        self.now = SECOND
        self.skip_once_at = None

    def __call__(self):
        return self.now

    def sleep(self, seconds):
        self.now += round(seconds * SECOND)
        if self.skip_once_at is not None and self.now >= self.skip_once_at:
            self.skip_once_at = None
            self.now += 17 * SECOND


class ResourceTests(unittest.TestCase):
    def test_fake_proc_counts_and_pid_reuse(self):
        with tempfile.TemporaryDirectory(dir=ROOT) as folder:
            tmp = Path(folder)
            proc = tmp / "proc"
            executable = tmp / "jwm-remote"
            executable.touch()
            target = proc / "91"
            (target / "fd").mkdir(parents=True)
            (target / "stat").write_text(stat(91, 700))
            (target / "exe").symlink_to(executable)
            (target / "status").write_text("VmRSS:\t12000 kB\nThreads:\t9\n")
            for name in ("0", "4", "11", "not-an-fd"):
                (target / "fd" / name).touch()
            identity = track(91, executable, proc)
            self.assertEqual(identity.start_ticks, 700)
            self.assertEqual(resources(identity, proc), {"rss_kib": 12000, "threads": 9, "fds": 3})
            (target / "stat").write_text(stat(91, 800))
            with self.assertRaisesRegex(RuntimeError, "changed before"):
                resources(identity, proc)
            (target / "stat").write_text(stat(91, 700))
            with patch("resources.read_identity", side_effect=(identity, replace(identity, start_ticks=800))):
                with self.assertRaisesRegex(RuntimeError, "changed during"):
                    resources(identity, proc)
            bad = tmp / "wrong-executable"
            bad.touch()
            with self.assertRaisesRegex(RuntimeError, "different executable"):
                track(91, bad, proc)
            with self.assertRaises(RuntimeError):
                start_ticks(stat(91, 700, "Z"), 91)

    def make_samples(self, *, delayed=False, plan=Plan()):
        clock = FakeClock()
        if delayed:
            clock.skip_once_at = clock.now + 180 * SECOND
        anchor = clock.now
        output = io.StringIO()

        def fake_sample(_identity):
            elapsed = (clock.now - anchor) // SECOND
            rss = 99999 if elapsed < BURN_SECONDS else 12000 + (100 if elapsed > 730 else 0)
            return {"rss_kib": rss, "threads": 8, "fds": 9}

        from resources import Identity
        collect(output, "host", Identity(1, 2, 3, 4), plan, anchor, lambda: None,
                clock=clock, sleep=clock.sleep, sample=fake_sample)
        return [json.loads(line) for line in output.getvalue().splitlines()]

    def test_sixty_second_burn_in_and_full_measured_trend(self):
        rows = self.make_samples()
        summary = summarize_resources(rows, "host")
        self.assertEqual(summary["measurement_seconds"], 900)
        self.assertEqual(summary["burn_in_samples"], 12)
        self.assertEqual(summary["resource_samples"], 180)
        self.assertEqual(summary["missed_sample_slots"], 0)
        self.assertEqual(summary["resources"]["rss_kib"]["peak"], 12100)
        self.assertEqual(summary["resources"]["rss_kib"]["median_delta"], 100)
        self.assertEqual(summary["resources"]["fds"]["median_delta"], 0)
        self.assertLessEqual(len(self.make_samples(plan=Plan(960, 5))) - 2, MAX_RESOURCE_SAMPLES)

    def test_delayed_scheduler_skips_slots_without_backfill(self):
        rows = self.make_samples(delayed=True)
        summary = summarize_resources(rows, "host")
        self.assertEqual(summary["missed_sample_slots"], 3)
        self.assertEqual(summary["resource_samples"], 177)
        self.assertGreater(summary["max_gap_between_samples_or_boundary_seconds"], 5)

    def test_incomplete_measurement_rejected(self):
        rows = self.make_samples()
        rows[-1]["monotonic_ns"] -= 1
        with self.assertRaisesRegex(ValueError, "finish its measured interval"):
            summarize_resources(rows, "host")


class VideoTests(unittest.TestCase):
    def test_measured_credits_keep_zero_window_and_exclude_startup_and_tail(self):
        summary = {"measurement_start_ns": 61 * SECOND, "measurement_end_ns": 961 * SECOND}
        first = {
            "session_id": "known", "window_seconds": 5, "h264_frames": 49, "captured": 55,
            "hevc444_frames": 0, "jpeg_atlases": 0, "png_atlases": 0, "drawn_acks": 48, "sent": 49,
            "source_dimensions": [1920, 1080], "encoded_dimensions": [1920, 1080],
            "outstanding": 1, "max_outstanding": 2, "bytes": 1000,
            "stages": {"credit_wait_ms": {"quantiles": {"p99_ms": 3.1}}},
        }
        second = first | {"sent": 0, "h264_frames": 0, "drawn_acks": 0, "bytes": 0, "outstanding": 2,
                          "max_outstanding": 0}
        outside = first | {"session_id": "discarded"}
        windows = [{"arrived_monotonic_ns": end * SECOND, "record": row} for end, row in (
            (60, outside), (64, outside), (66, first), (71, second), (963, outside))]
        video, kept = summarize_video(windows, "host", summary, 1920, 1080)
        self.assertEqual(len(kept), 2)
        self.assertEqual(video["drawn_acks"], 48)
        self.assertEqual(video["zero_sent_windows"], 1)
        self.assertEqual(video["outstanding_credits_at_window_end"], {1: 1, 2: 1})
        self.assertEqual(video["peak_reported_outstanding_credits"], 2)

    def test_fake_viewer_output_tracks_first_active_authenticated_window(self):
        class FakeProcess:
            returncode = None

            def poll(self):
                return None

        inactive = {"type": "jwm_remote_viewer_stats", "window_seconds": 5, "session_id": "v",
                    "drawn": 0, "acked": 0}
        active = inactive | {"drawn": 40, "acked": 40}
        final = inactive | {"final": True, "drawn": 10, "acked": 10}
        p = FakeProcess()
        p.stderr = io.BytesIO(("ordinary diagnostics\n" + "\n".join(map(json.dumps, (
            inactive, active, final))) + "\n").encode())
        diag, typed = io.BytesIO(), io.StringIO()
        relay = TelemetryRelay(p, "viewer", diag, typed)
        relay.finish()
        self.assertFalse(relay.worker.is_alive())
        relay.check()
        rows = [json.loads(line) for line in typed.getvalue().splitlines()]
        self.assertEqual(len(rows), 3)
        self.assertEqual(relay.anchor, rows[1]["arrived_monotonic_ns"])
        self.assertIn(b"ordinary diagnostics", diag.getvalue())

    def test_python_310_grammar(self):
        for script in ROOT.glob("*.py"):
            ast.parse(script.read_text(), filename=str(script), feature_version=(3, 10))


if __name__ == "__main__":
    unittest.main()
