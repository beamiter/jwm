#!/usr/bin/env python3
"""Owned Xvfb and authenticated loopback trials for the adaptive video ACK."""
from contextlib import ExitStack
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

REPO = Path('/home/yj/projects/jwm')
PAINTER = Path('/tmp/jwm-native-x11-resource-soak.6Wufhz33/run/observer')
PAINTER_PIN = 'd981ba7314b92529941e9a24a6d90f36f738e9679bc5abd2f417c6d0df672416'
FFMPEG = '/tmp/jwm-remote-ffmpeg/usr/lib/x86_64-linux-gnu'
FEEDBACK = 'viewer rate feedback negotiated (application v36)'
RATE = re.compile(r'hardware rate target (\d+) fps, (\d+)% nominal bitrate \((\w+)\)')
VIEWER = re.compile(r'viewer rate feedback \((\d+) drawn frames, mean decode ([\d.]+) ms, queue ([\d.]+) ms, presentation ([\d.]+) ms\)')


def load_fixture():
    spec = importlib.util.spec_from_file_location('recovery_fixture', REPO/'scripts/test-remote-recovery-window.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def sha(file):
    return hashlib.sha256(Path(file).read_bytes()).hexdigest()


def require(condition, detail):
    if not condition:
        raise RuntimeError(detail)


def logs(path):
    return path.read_text(errors='replace')


def json_lines(path, kind):
    return [row for line in logs(path).splitlines(keepends=True) if line.startswith('{') and line.endswith('\n')
            for row in [json.loads(line)] if row.get('type') == kind]


def run_arm(helper, env, root, fixture, run_id, adaptive, offer):
    host_log, viewer_log = root/'host.log', root/'viewer.log'
    pressure = adaptive and offer
    with ExitStack() as cleanup:
        source, source_display = fixture.fixture.launch()
        cleanup.callback(fixture.stop, source)
        viewer_server, viewer_display = fixture.fixture.launch()
        cleanup.callback(fixture.stop, viewer_server)

        def start(name, args, changes=None):
            child_env = env | (changes or {})
            stdout = cleanup.enter_context((root/f'{name}.stdout').open('wb'))
            stderr = cleanup.enter_context((root/f'{name}.log').open('wb'))
            process = subprocess.Popen(args, env=child_env, stdout=stdout, stderr=stderr, stdin=subprocess.DEVNULL)
            cleanup.callback(fixture.stop, process)
            return process

        key = root/'key'
        cleanup.callback(key.unlink, missing_ok=True)
        subprocess.run([helper, 'keygen', '--output', key], env=env, check=True,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5)
        host = start('host', [helper, 'host', '--display', source_display, '--listen', '127.0.0.1:0',
                              '--key-file', key, '--capture-source', 'root', '--allow-h264', '--fps', '30',
                              '--scaling', 'auto', '--stats-json', '--once'],
                     {'JWM_REMOTE_ADAPT_VIDEO': 'desktop'} if adaptive else {})
        listen = fixture.wait_for('owned NVENC listener', lambda: re.search(r'listening on (127\.0\.0\.1:\d+)', logs(host_log)))
        start('painter', [PAINTER, 'paint', '--display', source_display, '--width', '1280', '--height', '800',
                          '--fps', '60', '--seconds', '135' if pressure else '24', '--run-id', str(run_id), '--seed', '7'])
        fixture.wait_for('owned motion painter', lambda: 'p09_start' in logs(root/'painter.stdout'))
        gate = root/'slow'
        viewer_env = {'JWM_REMOTE_ADAPT_FEEDBACK': '1'} if offer else {}
        if pressure:
            gate.touch(exist_ok=False)
            viewer_env.update(LD_PRELOAD=str(helper.parent/'slow-rgb.so'), JWM_FEEDBACK_FIXTURE_DELAY=str(gate))
        viewer = start('viewer', [helper, 'connect', listen[1], '--display', viewer_display, '--key-file', key,
                                  '--view-only', '--window-size', '1280x800', '--scaling', 'cpu', '--stats-json'], viewer_env)
        fixture.wait_for('actual H.264 NVENC send', lambda: 'hardware H.264 encoding active (NVENC)' in logs(host_log), 15)
        fixture.wait_for('actual H.264 decode', lambda: 'hardware H.264 decoding active' in logs(viewer_log), 15)
        require((FEEDBACK in logs(host_log)) == (FEEDBACK in logs(viewer_log)) == pressure,
                'viewer ACK profile did not match negotiated scope')
        if pressure:
            fixture.wait_for('viewer-relative FPS reduction', lambda: ('24', '100', 'Viewer') in RATE.findall(logs(host_log)), 35)
            fixture.wait_for('an actual NVENC reopen at 24 fps', lambda: 'NVENC opened 24 fps at 100% nominal bitrate' in logs(host_log), 8)
            require(any(float(row[1]) >= 45 for row in VIEWER.findall(logs(host_log))), 'delayed decode sample was absent')
            gate.unlink()
            fixture.wait_for('viewer-relative recovery to 28 fps', lambda: ('28', '100', 'Clear') in RATE.findall(logs(host_log)), 45)
            fixture.wait_for('viewer-relative recovery to 30 fps', lambda: ('30', '100', 'Clear') in RATE.findall(logs(host_log)), 45)
            fixture.wait_for('an actual NVENC reopen at 30 after recovery',
                             lambda: logs(host_log).count('NVENC opened 30 fps at 100% nominal bitrate') >= 2, 8)
        else:
            fixture.wait_for('legacy-layout drawn ACK', lambda: any(row['drawn_acks'] > 0 for row in
                             json_lines(host_log, 'jwm_remote_host_stats')), 12)
        search_env = env | {'DISPLAY': viewer_display}
        window = fixture.wait_for('owned viewer window', lambda: subprocess.run(
            ['xdotool', 'search', '--name', 'JWM Remote'], env=search_env, capture_output=True,
            text=True, check=False, timeout=3).stdout.splitlines())
        require(len(window) == 1, 'more than one owned viewer')
        fixture.request_window_close(viewer_display, window[0])
        viewer_exit, host_exit = viewer.wait(timeout=6), host.wait(timeout=6)
        require(viewer_exit == host_exit == 0, 'owned session did not shut down cleanly')
        host_windows = json_lines(host_log, 'jwm_remote_host_stats')
        viewer_windows = json_lines(viewer_log, 'jwm_remote_viewer_stats')
        host_ack = sum(row['drawn_acks'] for row in host_windows)
        viewer_ack = sum(row['acked'] for row in viewer_windows)
        require(host_ack > 0 and host_ack == viewer_ack, 'acknowledgement totals differ')
        require(len({row['session_id'] for row in host_windows + viewer_windows}) == 1,
                'frames crossed authenticated sessions')
        require(all(row['jpeg_atlases'] == 0 and row['hevc444_frames'] == 0 for row in host_windows),
                'hardware test switched codecs')
        return {'profile': 'video_feedback_v36' if pressure else 'standard_v35', 'adaptation': adaptive,
                'viewer_offered': offer, 'viewer_timing_windows': [list(map(float, row)) for row in VIEWER.findall(logs(host_log))],
                'rate_changes': RATE.findall(logs(host_log)), 'drawn_acks': host_ack,
                'h264_frames': sum(row['h264_frames'] for row in host_windows), 'host_exit': host_exit, 'viewer_exit': viewer_exit}


def main():
    helper, output = map(lambda argument: Path(argument).resolve(), sys.argv[1:])
    output.mkdir(mode=0o700)
    require(sha(PAINTER) == PAINTER_PIN, 'owned painter fingerprint differs')
    env = {key: value for key, value in os.environ.items() if not key.startswith('JWM_REMOTE_') and key not in
           ('DISPLAY', 'XAUTHORITY', 'WAYLAND_DISPLAY', 'WAYLAND_SOCKET', 'LD_PRELOAD', 'JWM_FEEDBACK_FIXTURE_DELAY')}
    env.update(LD_LIBRARY_PATH=FFMPEG, XDG_RUNTIME_DIR=str(output))
    fixture = load_fixture()
    results = []
    for ordinal, (name, adaptive, offer) in enumerate((('viewer-off', True, False), ('host-off', False, True),
                                                       ('viewer-pressure', True, True)), 35):
        root = output/name
        root.mkdir(mode=0o700)
        result = run_arm(helper, env, root, fixture, ordinal, adaptive, offer)
        result['arm'] = name
        results.append(result)
        (output/'result.json').write_text(json.dumps({'binary_sha256': sha(helper), 'cases': results}, indent=2)+'\n')
        print(name, result['profile'], result['rate_changes'], result['drawn_acks'], flush=True)


if __name__ == '__main__':
    main()
