#define _GNU_SOURCE
#include <dlfcn.h>
#include <errno.h>
#include <pthread.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

struct SwsContext;
typedef int (*scale_fn)(struct SwsContext *, const uint8_t *const [], const int [],
                       int, int, uint8_t *const [], const int []);
static pthread_once_t initialized = PTHREAD_ONCE_INIT;
static scale_fn real_scale;

static void resolve_scale(void)
{
    real_scale = (scale_fn)dlsym(RTLD_NEXT, "sws_scale");
    if (!real_scale)
        _exit(125);
}

int sws_scale(struct SwsContext *context, const uint8_t *const source[],
              const int source_stride[], int first, int height,
              uint8_t *const dest[], const int dest_stride[])
{
    int saved_errno = errno;
    pthread_once(&initialized, resolve_scale);
    const char *gate = getenv("JWM_FEEDBACK_FIXTURE_DELAY");
    if (gate && access(gate, F_OK) == 0) {
        struct timespec remaining = { .tv_sec = 0, .tv_nsec = 45000000 };
        while (nanosleep(&remaining, &remaining) == -1 && errno == EINTR) {}
    }
    errno = saved_errno;
    return real_scale(context, source, source_stride, first, height, dest, dest_stride);
}
