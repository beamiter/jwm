#!/usr/bin/env python3
"""Publish and replay the private adaptive video feedback fixture."""
import hashlib
import json
from pathlib import Path
import re
import sys
from zipfile import ZIP_DEFLATED, ZipFile
from smoke import FEEDBACK, RATE, VIEWER, PAINTER_PIN, json_lines, require, sha

STEM = 'x11-nvenc-viewer-feedback-recovery'
CASES = ('viewer-off', 'host-off', 'viewer-pressure')


def encode(data):
    return (json.dumps(data, indent=2, allow_nan=False) + '\n').encode()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def active_lines(path):
    tokens = (FEEDBACK, 'H.264 NVENC negotiated', 'NVENC opened', 'encoding active (NVENC)',
              'hardware H.264 decoding active', 'viewer rate feedback (', 'hardware rate target ')
    return [line for line in path.read_text().splitlines() if any(token in line for token in tokens)]


def capture(run, stage):
    result = json.loads((run/'result.json').read_text())
    require((stage/'smoke-v1.exit').read_text().strip() == '0', 'controller did not exit cleanly')
    require(sha(stage/'jwm-remote') == result['binary_sha256'], 'runtime binary differs')
    manifest = (stage/'source.sha256').read_text().splitlines()
    source = {name: pin for line in manifest for pin, name in [line.split(maxsplit=1)]}
    require(all(sha(Path(name)) == pin for name, pin in source.items()), 'current build source differs')
    compile_scope = {}
    for key, filename in (('library', 'core-test.log'), ('cli', 'cli-test.log')):
        match = re.search(r'test result: ok\. (\d+) passed; 0 failed; (\d+) ignored', (stage/filename).read_text())
        require(match is not None, 'Cargo regression did not pass')
        compile_scope[key] = dict(zip(('passed', 'ignored'), map(int, match.groups())))
    result.update(terminal_exit=0, source_sha256=source, cargo_tests=compile_scope, painter_sha256=PAINTER_PIN,
                  scope='One-machine authenticated IPv4 loopback, private Xvfb source/viewer at 1280×800, '
                        'hardware H.264 NVENC at nominal 30 FPS, and a removable 45 ms delay in the viewer-only '
                        'RGB conversion shim. Functional rate-transition evidence.')
    members = {'run.json': encode(result)}
    for name in ('smoke.py', 'slow-rgb.c', 'publish.py'):
        members['fixture/'+name] = (stage/name).read_bytes()
    for name in CASES:
        records = {}
        for side, fields in (('host', ('h264_frames', 'hevc444_frames', 'jpeg_atlases', 'drawn_acks', 'source_dimensions', 'encoded_dimensions')),
                             ('viewer', ('acked', 'received', 'negotiated_codec'))):
            path = run/name/f'{side}.log'
            windows = json_lines(path, f'jwm_remote_{side}_stats')
            records[side] = {'signals': active_lines(path), 'windows': [
                {key: row[key] for key in fields} | {'session_alias': digest(row['session_id'].encode())}
                for row in windows]}
        members['observations/'+name+'.json'] = encode(records)
    return members


def reconstruct(members):
    recorded = json.loads(members['run.json'])
    require(recorded['terminal_exit'] == 0 and [x['arm'] for x in recorded['cases']] == list(CASES), 'cases incomplete')
    for case in recorded['cases']:
        scope = json.loads(members['observations/'+case['arm']+'.json'])
        host, viewer = scope['host'], scope['viewer']
        windows = host['windows']
        require(bool(windows) and bool(viewer['windows']) and all(
            row['jpeg_atlases'] == row['hevc444_frames'] == 0 for row in windows), 'hardware route differs')
        require(len({row['session_alias'] for row in windows + viewer['windows']}) == 1, 'session scope differs')
        require(all(row['negotiated_codec'] == 'H.264' for row in viewer['windows']), 'viewer codec differs')
        require(sum(row['drawn_acks'] for row in windows) == sum(row['acked'] for row in viewer['windows']) == case['drawn_acks'] > 0,
                'ACK validation changed')
        require(sum(row['h264_frames'] for row in windows) == case['h264_frames'], 'hardware coverage changed')
        expect_v36 = case['profile'] == 'video_feedback_v36'
        require(all(any(FEEDBACK in line for line in lane['signals']) == expect_v36 for lane in (host, viewer)),
                'wire profile changed')
        host_text = '\n'.join(host['signals'])
        require([list(row) for row in RATE.findall(host_text)] == case['rate_changes'], 'rate history changed')
        require([list(map(float, row)) for row in VIEWER.findall(host_text)] == case['viewer_timing_windows'], 'feedback windows changed')
        require(case['host_exit'] == case['viewer_exit'] == 0, 'endpoint exits changed')
        if expect_v36:
            require(case['rate_changes'] == [['24','100','Viewer'],['28','100','Clear'],['30','100','Clear']], 'rate transition failed')
    return recorded


def main():
    command, *args = sys.argv[1:]
    if command == 'publish':
        run, stage, output = map(Path, args)
        members = capture(run, stage)
        result = reconstruct(members)
        output.mkdir(mode=0o700)
        archive = output/(STEM+'-raw.zip')
        with ZipFile(archive, 'x', compression=ZIP_DEFLATED) as bundle:
            for name, content in sorted(members.items()):
                bundle.writestr(name, content)
        result['archive'] = {'sha256': sha(archive), 'members': {name: digest(content) for name, content in members.items()}}
        (output/(STEM+'.json')).write_bytes(encode(result))
    else:
        require(command == 'replay', 'unknown command')
        report, archive = map(Path, args)
        expected = json.loads(report.read_text())
        pins = expected.pop('archive')
        require(sha(archive) == pins['sha256'], 'archive fingerprint differs')
        with ZipFile(archive) as bundle:
            require(bundle.testzip() is None and sorted(bundle.namelist()) == sorted(pins['members']), 'archive members differ')
            members = {name: bundle.read(name) for name in bundle.namelist()}
        require({name: digest(content) for name,content in members.items()} == pins['members'], 'member fingerprint differs')
        require(reconstruct(members) == expected, 'adaptive feedback replay differs')
        print('ACK scope, wire profiles, and three rate changes reproduced.')


if __name__ == '__main__':
    main()
