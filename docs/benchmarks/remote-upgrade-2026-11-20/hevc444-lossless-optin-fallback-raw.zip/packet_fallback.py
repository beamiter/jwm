#!/usr/bin/env python3
"""Run bounded HEVC lossless fallback on two owned X11 servers."""
import argparse
from contextlib import ExitStack
import hashlib
import json
import os
from pathlib import Path
import random
import re
import subprocess
import tempfile
import time

from Xlib import X, display
from processes import clean_env, get_display, start_display, stop, wait_for

WIDTH, HEIGHT = 1920, 1080
GEOMETRY = f'{WIDTH}x{HEIGHT}'
USE_LOSSLESS = 'JWM_REMOTE_HEVC444_LOSSLESS'
ACTIVE = 'jwm-remote: hardware HEVC 4:4:4 encoding active (NVENC, lossless constant QP 0)'
FALLBACK = 'jwm-remote: HEVC 4:4:4 lossless encoding failed, switching to JPEG: video access unit exceeds 1 MiB'


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def has_line(path, expected):
    return True if expected in path.read_text().splitlines() else None


def frame_stats(path, role):
    kind = f'jwm_remote_{role}_stats'
    result = []
    for line in path.read_bytes().splitlines():
        if not line.startswith(b'{'):
            continue
        try:
            row = json.loads(line)
        except ValueError:
            continue
        if row.get('type') == kind:
            result.append(row)
    return result


def observe(path, role, codec, min_sequence=0):
    field = 'last_sent_frame' if role == 'host' else 'last_frame'
    ack = 'drawn_acks' if role == 'host' else 'acked'
    for row in reversed(frame_stats(path, role)):
        scope = row.get(field)
        if (scope and scope.get('source_dimensions') == scope.get('encoded_dimensions') == [WIDTH, HEIGHT]
                and scope['codec'] == codec and scope['sequence'] > min_sequence and row[ack] > 0):
            return {'scope': scope, 'session_id': row['session_id'], 'drawn_acks_in_window': row[ack]}
    return None


def sample(window):
    blue, green, red, _alpha = window.get_image(WIDTH//2 + 80, HEIGHT//2 + 120, 1, 1, X.ZPixmap, 0x00ffffff).data
    return red, green, blue


def color_match(window, expected):
    actual = sample(window)
    return actual if max(abs(x-y) for x,y in zip(actual, expected)) <= 12 else None


def run(binary, stage, library_dir, failure):
    with ExitStack() as owned:
        def log(name):
            return owned.enter_context((stage / name).open('wb'))

        def xserver(role):
            child = start_display(WIDTH, HEIGHT, log(f'{role}-xvfb.log'))
            owned.callback(stop, child)
            display_id = get_display(child)
            conn = display.Display(display_id)
            owned.callback(conn.close)
            return display_id, conn

        source_display, source = xserver('source')
        viewer_display, viewer = xserver('viewer')
        root = source.screen().root
        info = source.display.info
        require(source.screen().root_depth == 24 and info.image_byte_order == X.LSBFirst
                and any(p.depth == 24 and p.bits_per_pixel == 32 for p in info.pixmap_formats),
                'Xvfb does not provide the expected 24-bit little-endian image parameters')
        gc = root.create_gc()
        start_color = (48, 89, 177)
        end_color = (209, 59, 48)

        def fill(rgb):
            red, green, blue = rgb
            gc.change(foreground=(red << 16) | (green << 8) | blue)
            root.fill_rectangle(gc, 0, 0, WIDTH, HEIGHT)
            source.sync()

        fill(start_color)
        env = clean_env()
        env.pop('XAUTHORITY', None)
        env.pop('LD_LIBRARY_PATH', None)
        if library_dir:
            env['LD_LIBRARY_PATH'] = library_dir
        for name in ('config', 'cache', 'run'):
            (stage / name).mkdir(mode=0o700)
        env.update(XDG_CONFIG_HOME=str(stage/'config'), XDG_CACHE_HOME=str(stage/'cache'),
                   XDG_RUNTIME_DIR=str(stage/'run'))
        key = stage / 'key'
        subprocess.run([binary, 'keygen', '--output', str(key)], env=env, timeout=8,
                       stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, check=True)
        owned.callback(key.unlink, missing_ok=True)
        host_env = env | {USE_LOSSLESS: '1'}
        if failure == 'unsupported':
            host_env['CUDA_VISIBLE_DEVICES'] = '-1'
        host = subprocess.Popen([binary, 'host', '--listen', '127.0.0.1:0', '--once',
                                 '--display', source_display, '--capture-source', 'root',
                                 '--allow-h264', '--allow-hevc444', '--stats-json', '--fps', '30', '--key-file', str(key)],
                                env=host_env, stderr=log('host.log'),
                                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL)
        owned.callback(stop, host)
        host_log = stage / 'host.log'
        listener = wait_for(host, lambda: re.search(r'listening on (127\.0\.0\.1:\d+)', host_log.read_text()))
        client = subprocess.Popen([binary, 'session', listener[1], '--display', viewer_display,
                                   '--stats-json', '--scaling', 'cpu', '--window-size', GEOMETRY, '--key-file', str(key)],
                                  env=env, stdin=subprocess.PIPE, stdout=log('session.jsonl'), stderr=log('viewer.log'))
        owned.callback(stop, client)
        viewer_log = stage / 'viewer.log'

        def opened_viewer():
            for candidate in viewer.screen().root.query_tree().children:
                if 'JwmRemote' in (candidate.get_wm_class() or ()):
                    spec = candidate.get_geometry()
                    require((spec.width, spec.height) == (WIDTH, HEIGHT), 'viewer did not retain 1:1 geometry')
                    return candidate
            return None

        draw = wait_for(client, opened_viewer)
        if failure == 'unsupported':
            wait_for(host, lambda: has_line(host_log,
                'jwm-remote: HEVC 4:4:4 lossless unavailable, using ordinary JPEG capture'))
            probe = next((line for line in host_log.read_text().splitlines()
                          if 'HEVC 4:4:4 lossless NVENC probe failed:' in line), None)
            require(probe is not None and not has_line(host_log, ACTIVE), 'unexpected hardware evidence')
            pixel = wait_for(client, lambda: color_match(draw, start_color))
            evidence = [wait_for(host, lambda: observe(host_log, 'host', 'JPEG')),
                        wait_for(client, lambda: observe(viewer_log, 'viewer', 'JPEG'))]
            require(len({row['session_id'] for row in evidence}) == 1, 'different authenticated sessions')
            results = {'fallback': probe, 'initial_rgb': pixel, 'negotiated_jpeg': evidence}
        else:
            wait_for(host, lambda: has_line(host_log, ACTIVE))
            wait_for(client, lambda: has_line(viewer_log, 'jwm-remote: HEVC 4:4:4 hardware decoder active (NVDEC)'))
            first_pixel = wait_for(client, lambda: color_match(draw, start_color))
            host_start = wait_for(host, lambda: observe(host_log, 'host', 'HEVC 4:4:4'))
            viewer_start = wait_for(client, lambda: observe(viewer_log, 'viewer', 'HEVC 4:4:4'))

            # Prevent capture of half a noise field while the X connection writes bounded PutImage chunks.
            generator = random.Random(3611)
            source.grab_server()
            try:
                for y in range(0, HEIGHT, 20):
                    rows = min(20, HEIGHT-y)
                    pixels = bytearray(generator.randbytes(WIDTH * rows * 4))
                    pixels[3::4] = bytes(WIDTH * rows)
                    root.put_image(gc, 0, y, WIDTH, rows, X.ZPixmap, 24, 0, bytes(pixels))
            finally:
                source.ungrab_server()
                source.sync()
            wait_for(host, lambda: has_line(host_log, FALLBACK))
            fill(end_color)
            final_pixel = wait_for(client, lambda: color_match(draw, end_color))
            min_sequence = max(host_start['scope']['sequence'], viewer_start['scope']['sequence'])
            host_end = wait_for(host, lambda: observe(host_log, 'host', 'JPEG', min_sequence))
            viewer_end = wait_for(client, lambda: observe(viewer_log, 'viewer', 'JPEG', min_sequence))
            evidence = [host_start, viewer_start, host_end, viewer_end]
            require(len({row['session_id'] for row in evidence}) == 1, 'authenticated session was replaced')
            require(len({row['scope']['source_epoch'] for row in evidence}) == 1, 'fallback replaced the source')
            require(len({row['scope']['geometry_epoch'] for row in evidence}) == 1, 'fallback replaced the geometry')
            results = {'fallback': FALLBACK, 'initial_rgb': first_pixel, 'restored_rgb': final_pixel,
                       'hardware_before_jpeg': evidence[:2], 'jpeg_after_packet_limit': evidence[2:]}
        client.stdin.write(b'{"command":"disconnect","request":1}\n')
        client.stdin.flush()
        require(client.wait(timeout=12) == host.wait(timeout=12) == 0, 'owned session did not exit cleanly')
        snapshots = [json.loads(line) for line in (stage / 'session.jsonl').read_text().splitlines()]
        require(any(row.get('state') == 'closed' for row in snapshots), 'missing closed snapshot')
        for row in evidence:
            row['session_id'] = 'authenticated-session'
        print(json.dumps({'status': 'passed', 'failure': failure,
                          'owned_exits': [host.returncode, client.returncode]} | results, indent=2))


def main():
    os.umask(0o077)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--release', type=Path, required=True)
    parser.add_argument('--sha256', required=True)
    parser.add_argument('--lib-dir')
    parser.add_argument('--failure', choices=('packet-limit', 'unsupported'), default='packet-limit')
    args = parser.parse_args()
    binary = args.release.resolve(strict=True)
    with binary.open('rb') as file:
        require(hashlib.file_digest(file, 'sha256').hexdigest() == args.sha256, 'binary pin mismatch')
    stage = Path(tempfile.mkdtemp(prefix='fallback.', dir=Path(__file__).resolve().parent))
    print(stage, flush=True)
    run(str(binary), stage, args.lib_dir, args.failure)


if __name__ == '__main__':
    main()
