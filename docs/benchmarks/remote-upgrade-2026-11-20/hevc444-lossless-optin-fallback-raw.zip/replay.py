#!/usr/bin/env python3
"""Verify selected authenticated telemetry, route markers and owned process exits."""
from hashlib import sha256
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ACTIVE = 'jwm-remote: hardware HEVC 4:4:4 encoding active (NVENC, lossless constant QP 0)'
UNAVAILABLE = 'jwm-remote: HEVC 4:4:4 lossless unavailable, using ordinary JPEG capture'
FALLBACK = 'jwm-remote: HEVC 4:4:4 lossless encoding failed, switching to JPEG: video access unit exceeds 1 MiB'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_text())


def replay():
    manifest = read(ROOT / 'members.sha256.json')
    actual = {str(path.relative_to(ROOT)) for path in ROOT.rglob('*') if path.is_file()}
    require(actual == set(manifest) | {'members.sha256.json'}, 'bundle membership differs')
    for name, digest in manifest.items():
        require(sha256((ROOT / name).read_bytes()).hexdigest() == digest, f'{name} digest differs')
    startup = read(ROOT / 'startup-rejections.json')
    require({row['case'] for row in startup} == {'invalid', 'adaptation', 'gpu-capture', 'h264-only', 'x11-window'}
            and all(row['exit'] == 1 and row['listener_started'] is False for row in startup),
            'missing startup option rejection evidence')
    proof = read(ROOT / 'unit-evidence.json')
    require(all(proof.values()) and len(proof) == 3, 'missing exact samples or option boundary test')
    result = {'startup_rejections': len(startup), 'unit_evidence': proof, 'scenarios': {}}
    for name in ('packet-limit', 'unsupported'):
        case = ROOT / name
        outcome = read(case / 'outcome.json')
        require(outcome['status'] == 'passed' and outcome['owned_exits'] == [0, 0], 'unclean owned process exit')
        markers = set(read(case / 'route.json'))
        host, viewer = (read(case / f'{role}-frames.json') for role in ('host', 'viewer'))
        points = host + viewer
        require(len({row['session_id'] for row in points}) == 1, 'authentication scope differs')
        require({(row['scope']['source_epoch'],row['scope']['geometry_epoch']) for row in points} == {(1,2)},
                'geometry or source scope differs')
        require(all(row['scope']['source_dimensions'] == row['scope']['encoded_dimensions'] == [1920,1080]
                    and row['drawn_acks_in_window'] > 0 for row in points), 'missing native dimensions or drawn ACK')
        require(read(case / 'viewer-lifecycle.json')[-2:] == ['closing','closed'], 'viewer lifecycle missing')
        if name == 'packet-limit':
            require({ACTIVE, FALLBACK, 'jwm-remote: HEVC 4:4:4 hardware decoder active (NVDEC)'} <= markers,
                    'missing real hardware path or packet-limit marker')
            for prior, following, lane in zip(outcome['hardware_before_jpeg'], outcome['jpeg_after_packet_limit'], (host,viewer)):
                require(prior in lane and following in lane and prior['scope']['codec'] == 'HEVC 4:4:4'
                        and following['scope']['codec'] == 'JPEG'
                        and prior['scope']['sequence'] < following['scope']['sequence'], 'missing forward JPEG transition')
            require(all(abs(a-b) <= 12 for a,b in zip(outcome['restored_rgb'], [209,59,48])), 'missing restored picture')
        else:
            require({UNAVAILABLE, 'CUDA_ERROR_NO_DEVICE: no CUDA-capable device is detected'} <= markers
                    and ACTIVE not in markers, 'missing unsupported-device diagnostic')
            require({row['scope']['codec'] for row in points} == {'JPEG'}, 'unexpected active hardware record')
            require(outcome['negotiated_jpeg'][0] in host and outcome['negotiated_jpeg'][1] in viewer,
                    'JPEG from startup did not match drawn evidence')
        require(all(abs(a-b) <= 12 for a,b in zip(outcome['initial_rgb'], [48,89,177])), 'missing initial RGB witness')
        result['scenarios'][name] = outcome
    return result


if __name__ == '__main__':
    print(json.dumps(replay(), indent=2, sort_keys=True))
