#!/usr/bin/env bash
set -euo pipefail
umask 077
cd "$(dirname "$0")"
if [[ ${1-} != 'execute' ]]; then
    nohup bash "$PWD/run-peer.sh" execute </dev/null >controller.log 2>&1 &
    printf '%s\n' "$!" > controller.pid
    exit 0
fi
status=0
python3 -B -m py_compile encode_only.py inspect_rss.py resources.py || status=$?
if [[ "$status" -eq 0 ]]; then
    python3 -B "$PWD/encode_only.py" "$PWD" || status=$?
fi
printf '%s\n' "$status" > controller.exit
exit "$status"
