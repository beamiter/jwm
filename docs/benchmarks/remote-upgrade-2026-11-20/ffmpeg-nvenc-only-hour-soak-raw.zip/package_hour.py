"""Package replayable encoder samples with address-redacted VMA ledgers."""
import argparse
import json
from pathlib import Path
import re
from shutil import copyfile
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile

from encode_only import SNAPSHOTS, require, sha256
from publish import report

STEM = 'ffmpeg-nvenc-only-hour-soak'
RANGE = re.compile(r'^([0-9a-f]+)-([0-9a-f]+)(?= [rwxps-]{4} )', re.MULTILINE)
ROOT_NAMES = ('encode_only.py','inspect_rss.py','resources.py','protected-library-identities.json','run-peer.sh',
              'inputs.sha256','vma_analyzer.py','publish.py','package_hour.py')
REMOTE_NAMES = ('encode_only.py','inspect_rss.py','resources.py','protected-library-identities.json','run-peer.sh',
                'bounds.json','result.json','controller.exit','samples.jsonl','progress.jsonl','ffmpeg-version.txt')
SNAPSHOT_RECORDS = tuple(f'{name}{ext}' for _,name in SNAPSHOTS for ext in ('.json','.smaps'))


def redacted_maps(paths):
    records = {path.name: path.read_text() for path in paths}
    # A shared rank replaces every actual boundary across the entire run.
    # This retains equal, overlapping and disjoint extents. The kernel's
    # Size/Rss fields still carry the actual size in KiB of every VMA.
    points = sorted({int(value,16) for raw in records.values()
                     for match in RANGE.finditer(raw) for value in match.groups()})
    require(len(points) > 1, 'no VMA boundaries to redact')
    synthetic = {number: f'{(i+1)*4096:x}' for i,number in enumerate(points)}
    def marker(match):
        return '-'.join(synthetic[int(value,16)] for value in match.groups())
    return {name: RANGE.sub(marker, raw) for name,raw in records.items()}


def sanitize(source, dest):
    for filename in ROOT_NAMES:
        copyfile(source/filename, dest/filename)
    raw = source/'remote'
    staged = dest/'remote'
    staged.mkdir()
    for filename in (*REMOTE_NAMES, *(name for name in SNAPSHOT_RECORDS if name.endswith('.json'))):
        copyfile(raw/filename, staged/filename)
    for name, content in redacted_maps(raw/name for name in SNAPSHOT_RECORDS if name.endswith('.smaps')).items():
        (staged/name).write_text(content)
    ffmpeg_log = re.sub(r'(?<= @ )0x[\da-fA-F]+', '<address removed>', (raw/'ffmpeg.log').read_text())
    (staged/'ffmpeg.log').write_text(ffmpeg_log)


def names():
    return set(ROOT_NAMES) | {f'remote/{file}' for file in (*REMOTE_NAMES, *SNAPSHOT_RECORDS,'ffmpeg.log')}


def replay(summary, archive):
    retained = json.loads(summary.read_text())
    pins = retained.pop('archive')
    require(sha256(archive) == pins['sha256'], 'archive digest differs')
    require(pins['vma_header_encoding'] == 'shared ordered boundary identifiers', 'VMA encoding changed')
    with TemporaryDirectory(prefix='jwm-hour-soak-replay.') as temporary:
        root = Path(temporary)
        with ZipFile(archive) as bundle:
            require(len(bundle.namelist()) == len(names()) and set(bundle.namelist()) == names()
                    and bundle.testzip() is None, 'archive member roster differs')
            for member in sorted(names()):
                bundle.extract(member, root)
        require({name: sha256(root/name) for name in names()} == pins['members_sha256'], 'archive evidence digest differs')
        require(report(root) == retained, 'reproduced encoder soak results differ')
    print('Reproduced FFmpeg frame counts, samples, stable tail and VMA attribution from the archive.')


def package(source, output):
    original = report(source)
    output.mkdir(mode=0o700)
    archive = output/f'{STEM}-raw.zip'
    with TemporaryDirectory(prefix='jwm-hour-soak-package.') as temporary:
        root = Path(temporary)
        sanitize(source, root)
        require(report(root) == original, 'sanitized evidence changes the exact measured results')
        pins = {name: sha256(root/name) for name in names()}
        with ZipFile(archive, 'x', compression=ZIP_DEFLATED, compresslevel=7) as bundle:
            for name in sorted(pins):
                bundle.write(root/name, name)
    result = original | {'archive': {'sha256': sha256(archive), 'members_sha256': pins,
                                      'vma_header_encoding': 'shared ordered boundary identifiers'}}
    summary = output/f'{STEM}.json'
    summary.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    replay(summary, archive)


if __name__ == '__main__':
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('action', choices=('package','replay'))
    cli.add_argument('first', type=Path)
    cli.add_argument('second', type=Path)
    args = cli.parse_args()
    {'package':package,'replay':replay}[args.action](args.first.resolve(), args.second.resolve())
