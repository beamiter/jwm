"""Replay the owned host RSS diagnostic and publish address-free categories."""
from collections import defaultdict
import importlib
import json
from pathlib import Path
import re
import sys

HEADER = re.compile(r"^([0-9a-f]+-[0-9a-f]+) ([rwxps-]{4}) [0-9a-f]+ [0-9a-f]+:[0-9a-f]+ (\d+)\s*(.*)$")
RESIDENT_FIELDS = ("Size","Rss","Pss","Anonymous","Private_Dirty","Private_Clean","Shared_Dirty","Shared_Clean","Swap")
COUNT_TYPES = ("rss_kib","rss_anon_kib","rss_file_kib","rss_shmem_kib","threads","fds")


def classify(permissions, inode, pathname):
    if pathname == "[heap]":
        return "process_heap"
    if pathname.startswith("[stack"):
        return "process_stack"
    if pathname.startswith("/dev/nvidia"):
        return "nvidia_device"
    if pathname.startswith(("memfd:", "/memfd:", "/SYSV", "/dev/shm/")):
        return "shared_memory"
    if pathname.startswith("[") and not pathname.startswith("[anon"):
        return "special_kernel"
    if pathname.startswith("/") and inode != "0":
        if re.search(r"(?:libnvidia[a-z0-9_-]*|libcuda)\.so", pathname):
            return "nvidia_user_space_library"
        if re.search(r"/lib(?:avcodec|avutil|avformat|swscale)\.so", pathname):
            return "ffmpeg_user_space_library"
        return "file_backed_other"
    shared = permissions.endswith("s")
    return "anonymous_shared" if shared else "anonymous_private"


def vm_maps(path):
    rows={}
    fields=None
    for line in path.read_text().splitlines():
        match=HEADER.match(line)
        if match:
            bounds, *details=match.groups()
            fields={"category":classify(*details)}
            rows[bounds]=fields
            continue
        key,_,value=line.partition(":")
        if key in RESIDENT_FIELDS and fields is not None:
            amount,unit=value.split()
            if unit!="kB":
                raise ValueError("unexpected VMA KiB accounting unit")
            fields[key+"_kib"]=int(amount)
    if not rows:
        raise ValueError("no VMA map headers")
    return rows


def vm_category(path):
    by_category=defaultdict(lambda:{"mappings":0})
    for fields in vm_maps(path).values():
        group=by_category[fields["category"]]
        group["mappings"]+=1
        for key,value in fields.items():
            if key!="category":
                group[key]=group.get(key,0)+value
    return dict(by_category)


def vma_changes(root):
    paths=[root/f"vma-{tag}.smaps" for tag in ("start","end")]
    if not all(path.is_file() for path in paths):
        return None
    before,after=[vm_maps(path) for path in paths]
    changes=[]
    for bounds in before.keys() & after.keys():
        a,b=before[bounds],after[bounds]
        resident=b["Rss_kib"]-a["Rss_kib"]
        anonymous=b["Anonymous_kib"]-a["Anonymous_kib"]
        if resident or anonymous:
            changes.append({"category":b["category"],"size_kib":b["Size_kib"],
                            "rss_start_kib":a["Rss_kib"],"rss_end_kib":b["Rss_kib"],
                            "rss_delta_kib":resident,"anonymous_delta_kib":anonymous})
    changes.sort(key=lambda row:(-abs(row["rss_delta_kib"]),row["category"],row["size_kib"]))
    return {"maps_start":len(before),"maps_end":len(after),
            "added_ranges":len(after.keys()-before.keys()),"removed_ranges":len(before.keys()-after.keys()),
            "matched_ranges_with_rss_or_anonymous_change":len(changes),
            "largest_changes_in_matched_ranges":changes[:20]}


def read(path):
    return json.loads(path.read_text())


def public_bracket(root, tag, scope):
    data=read(root/f"{tag}.json")
    maps=root/f"{tag}.smaps"
    return {"sample_start_offset_ms":(data["begin_ns"]-scope)/1e6,
            "sample_duration_ms":(data["end_ns"]-data["begin_ns"])/1e6,
            "availability":data["tracks"],"rollup_kib":data["rollup_kib"],
            "vma_kib_by_category":vm_category(maps) if maps.is_file() else None}


def public_arm(probe, root, mode, run_id):
    result=probe.assess(root,mode,run_id)
    raw=read(root/"result.json")
    # JSON serializes numeric dictionary keys in step histograms as strings.
    if json.loads(json.dumps(result,allow_nan=False)) != raw:
        raise ValueError("fresh offline endpoint scorer does not match actual result")
    resources=probe.read_rows(root/"remote/host-resources.jsonl")
    start,end=(resources[0][key] for key in ("measurement_start_ns","measurement_end_ns"))
    result["host"].pop("session_id")
    result["host"]["vma"]={
        "vma-start":public_bracket(root/"remote","vma-start",start),
        "vma-end":public_bracket(root/"remote","vma-end",end)}
    result["host"]["vma_changes"]=vma_changes(root/"remote")
    result["host"]["samples"]=[{"elapsed_seconds":(row["sample_ns"]-start)/1e9}
                                 | {name:row[name] for name in COUNT_TYPES}
                               for row in resources if row.get("phase")=="measured"]
    return result


def publish(run,early_failure):
    sys.path.insert(0,str(run/"fixture"))
    probe=importlib.import_module("inspect_rss")
    protocol=read(run/"protocol.json")
    for name,pin in protocol["files_sha256"].items():
        if probe.sha256(run/"fixture"/name)!=pin:
            raise ValueError("captured fixture source differs")
    controller=read(run/"result.json")
    if controller["status"]!="complete" or (run/"controller.exit").read_text().strip()!="0":
        raise ValueError("paired study did not complete")
    arms={}
    for mode,run_id in zip(protocol["mode_order"],(101,102)):
        arms[mode]=public_arm(probe,run/mode,mode,run_id)
    before=read(run/"remote-pins-before.json")
    for mode in arms:
        if read(run/f"remote-pins-after-{mode}.json")!=before:
            raise ValueError("remote source pins changed")
    pins={Path(path).name:pin for path,pin in before.items()}
    failure=read(early_failure/"result.json")
    if failure["status"]!="incomplete" or any(
            "the controlling SSH session closed; stopping" not in (early_failure/m/"remote/host.log").read_text()
            for m in ("on","off")):
        raise ValueError("early failed fixture record did not match the tested provenance")
    return {"status":"complete","protocol":protocol,"asset_pins":pins,
            "terminal":"actual paired controller and all scored endpoints exit 0",
            "discarded_attempt":{"status":"early_startup_failure_both_arms","retained_samples":0,
                                 "cause":"private fixture closed controlling key-stdin pipe too early",
                                 "recovery":"kept pipe open after flushing key",
                                 "controller_exit":int((early_failure/"controller.exit").read_text())},
            "capture_mode_matches":controller["matching_capture_route"],
            "sent_fps_difference":controller["wire_rate_difference"],
            "arms":arms,"scope":"Two fixed 240s arms on the same Ubuntu NVENC host and pinned client. "
                                 "No X server or GPU memory attribution. VMA categories discard absolute paths and addresses. "
                                 "The JSON toggle bundles output with optional stage instrumentation."}


if __name__=="__main__":
    print(json.dumps(publish(*(Path(name) for name in sys.argv[1:])),indent=2,allow_nan=False))
