#!/usr/bin/env python3
"""Measure only an owned, paced FFmpeg NVENC process on the Ubuntu benchmark host."""

from contextlib import suppress
import json
import os
from pathlib import Path
from statistics import linear_regression
import subprocess
import sys
from threading import Thread
import time

from inspect_rss import read_process, require, sha256, snapshot
from resources import SECOND, read_identity, sleep_until, track, write_row


BURN_IN, MEASURE, INTERVAL = 60, 3600, 30
SNAPSHOTS = ((0, 'vma-start'), (900, 'vma-15m'), (1800, 'vma-30m'),
             (2700, 'vma-45m'), (3300, 'vma-55m'), (3600, 'vma-end'))
TOTAL_SECONDS = BURN_IN + MEASURE + 7
FFMPEG = Path('/usr/bin/ffmpeg')
FFMPEG_SHA = '36d94a605d612e4090d1b8aec889d0c0801c6eafb1593c90f5c0dfd2e2966a45'
CMD = [str(FFMPEG), '-hide_banner', '-nostdin', '-nostats', '-progress', 'pipe:1',
       '-re', '-f', 'lavfi', '-i', 'testsrc2=size=1920x1080:rate=30', '-t', str(TOTAL_SECONDS), '-an',
       '-c:v', 'h264_nvenc', '-pix_fmt', 'yuv420p', '-preset', 'p1', '-tune', 'ull', '-rc', 'cbr',
       '-b:v', '6000000', '-maxrate', '6000000', '-bufsize', '400000', '-g', '60', '-bf', '0',
       '-rc-lookahead', '0', '-delay', '0', '-zerolatency', '1', '-forced-idr', '1', '-flags', '+low_delay',
       '-f', 'null', '/dev/null']
FIELDS = ('rss_kib', 'rss_anon_kib', 'rss_file_kib', 'rss_shmem_kib', 'threads', 'fds')


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def stat_key(path):
    value = path.stat()
    return [os.major(value.st_dev), os.minor(value.st_dev), value.st_ino]


def map_libraries(contents, library_names):
    result = {}
    for line in contents.splitlines():
        fields = line.split(None, 5)
        if len(fields) != 6 or not fields[5].startswith('/'):
            continue
        path = Path(fields[5])
        if path.name not in library_names:
            continue
        major, minor = (int(value, 16) for value in fields[3].split(':'))
        row = {'file_identity': [major, minor, int(fields[4])], 'path': str(path)}
        require(path.name not in result or result[path.name] == row, 'duplicate mapped library identity')
        result[path.name] = row
    return result


def pin_files(expected, resources=None):
    require(sha256(FFMPEG) == FFMPEG_SHA, 'installed FFmpeg executable changed')
    if resources is not None:
        require(set(resources) == set(expected), 'live process did not load the complete pinned library set')
    for name, pin in expected.items():
        file = Path(pin['path'])
        require(stat_key(file) == pin['file_identity'] and sha256(file) == pin['sha256'],
                f'{name} no longer matches protected original host mapping and recorded file digest')
        if resources is not None:
            require(resources[name]['file_identity'] == pin['file_identity'],
                    f'owned FFmpeg mapped a different {name} file identity')


class Progress:
    def __init__(self, process, output):
        self.anchor = None
        self.last = None
        self.error = None
        self.rows = []
        self.thread = Thread(target=self.relay, args=(process.stdout, output))
        self.thread.start()

    def relay(self, stream, output):
        try:
            values = {}
            for line in stream:
                field, value = line.strip().split('=', 1)
                values[field] = value.strip()
                if field != 'progress':
                    continue
                frame = int(values['frame'])
                out_time = values['out_time_us']
                row = {'monotonic_ns': time.monotonic_ns(), 'encoded_frames': frame,
                       'out_time_us': int(out_time) if out_time != 'N/A' else None,
                       'progress': values['progress']}
                require(not self.rows or frame >= self.rows[-1]['encoded_frames'], 'encoded frame count went backwards')
                self.rows.append(row)
                write_row(output, row)
                self.last = row
                if self.anchor is None and frame > 0:
                    self.anchor = row['monotonic_ns']
                values = {}
        except (OSError, ValueError, KeyError) as error:
            self.error = error

    def health(self, process):
        require(self.error is None, f'progress acquisition failed: {self.error}')
        require(process.poll() is None, f'FFmpeg exited before the retained boundary: {process.returncode}')


def sample(identity, due, progress, role):
    start = time.monotonic_ns()
    counters = read_process(identity)
    reading = progress.last
    require(reading is not None and reading['monotonic_ns'] <= time.monotonic_ns(),
            'no complete encoded frame progress sample')
    return {'phase': role, 'scheduled_ns': due, 'start_ns': start, 'sample_ns': time.monotonic_ns(),
            'progress_ns': reading['monotonic_ns'], 'encoded_frames': reading['encoded_frames'], **counters}


def check_run(root):
    bounds = json.loads((root/'bounds.json').read_text())
    rows = [json.loads(line) for line in (root/'samples.jsonl').read_text().splitlines()]
    progress = [json.loads(line) for line in (root/'progress.jsonl').read_text().splitlines()]
    measured = [row for row in rows if row['phase'] == 'measured']
    start, end = bounds['start_ns'], bounds['end_ns']
    require(len(measured) == MEASURE // INTERVAL and end-start == MEASURE*SECOND and rows[-1]['phase'] == 'retained_end',
            'retained resource sample count or boundary missing')
    require(all(row['scheduled_ns'] == start+i*INTERVAL*SECOND and row['scheduled_ns'] <= row['start_ns'] <= row['sample_ns']
                < row['scheduled_ns']+SECOND and row['progress_ns'] <= row['sample_ns'] < row['progress_ns']+2*SECOND
                for i, row in enumerate(measured)), 'late resource or progress sample')
    require(all(a['encoded_frames'] < b['encoded_frames'] for a, b in zip(measured, measured[1:])),
            'an owned encode progress slot stalled')
    frames = rows[-1]['encoded_frames']-measured[0]['encoded_frames']
    require(29.8 <= frames/MEASURE <= 30.2 and progress[-1]['progress'] == 'end'
            and progress[-1]['encoded_frames'] == TOTAL_SECONDS * 30,
            'expected paced hardware output progress was not observed')
    duration = [(row['sample_ns']-start)/SECOND for row in measured]
    frame_axis = [row['encoded_frames'] for row in measured]
    fields = {}
    for field in FIELDS:
        values = [row[field] for row in measured]
        fields[field] = {'first': values[0], 'last_30s_sample': values[-1], 'retained_end': rows[-1][field],
                         'min': min(values), 'max': max(values),
                         'slope_per_minute': linear_regression(duration, values).slope*60}
        if field.endswith('_kib'):
            fields[field]['slope_bytes_per_encoded_frame'] = linear_regression(frame_axis, values).slope*1024
    brackets = {}
    for offset, tag in SNAPSHOTS:
        due = start + offset * SECOND
        row = json.loads((root/f'{tag}.json').read_text())
        require(row['identity'] == bounds['identity'] and due <= row['begin_ns'] < due+SECOND
                and all(info['availability'] == 'captured' for info in row['tracks'].values()),
                'exact-PID VMA evidence was unavailable or late')
        brackets[tag] = {'rollup_kib': row['rollup_kib'], 'capture_delay_ms': (row['begin_ns']-due)/1e6}
    return {'measurement_seconds': (end-start)/SECOND, 'burn_in_seconds': BURN_IN,
            'retained_resources_slots': len(measured), 'scored_progress_delta_frames': frames,
            'encoded_fps_from_progress': frames/MEASURE, 'terminal_progress_frames': progress[-1]['encoded_frames'],
            'resources': fields, 'vma_boundary': brackets}


def run(root):
    expected = json.loads((root/'protected-library-identities.json').read_text())['libraries']
    pin_files(expected)
    env = {'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8'}
    for name, flags in (('ffmpeg-version.txt', ['-version']),
                        ('ffmpeg-nvenc-options.txt', ['-hide_banner', '-h', 'encoder=h264_nvenc'])):
        (root/name).write_bytes(subprocess.check_output([str(FFMPEG), *flags], env=env, timeout=10))
    require('NVIDIA NVENC H.264 encoder' in (root/'ffmpeg-nvenc-options.txt').read_text(), 'no installed NVENC encoder')
    target = None
    with (root/'ffmpeg.log').open('wb') as stderr, (root/'progress.jsonl').open('w') as progress_log:
        try:
            target = subprocess.Popen(CMD, stdout=subprocess.PIPE, stderr=stderr, stdin=subprocess.DEVNULL,
                                      text=True, env=env, cwd=root)
            ident = track(target.pid, FFMPEG)
            progress = Progress(target, progress_log)
            limit = time.monotonic()+10
            while progress.anchor is None:
                progress.health(target)
                require(time.monotonic() < limit, 'first hardware frame progress timed out')
                time.sleep(.05)
            proc = Path('/proc')/str(ident.pid)
            early_maps = map_libraries((proc/'maps').read_text(), expected)
            require(read_identity(ident.pid) == ident, 'FFmpeg process identity changed before mapping check')
            pin_files(expected, early_maps)
            start = progress.anchor + BURN_IN * SECOND
            end = start + MEASURE * SECOND
            checkpoints = {start + offset*SECOND: tag for offset, tag in SNAPSHOTS}
            save(root/'bounds.json', {'start_ns':start,'end_ns':end,'identity':vars(ident)})
            print('Owned FFmpeg active with exact libavcodec/libavutil/CUDA/NVENC map identities.', flush=True)

            def health():
                progress.health(target)

            with (root/'samples.jsonl').open('w') as output:
                for due in range(progress.anchor+INTERVAL*SECOND, end, INTERVAL*SECOND):
                    sleep_until(due, health)
                    if (tag := checkpoints.get(due)) is not None:
                        snapshot(ident, root, tag)
                    write_row(output, sample(ident, due, progress, 'burn_in' if due < start else 'measured'))
                sleep_until(end, health)
                snapshot(ident, root, 'vma-end')
                write_row(output, sample(ident, end, progress, 'retained_end'))
            for _, tag in SNAPSHOTS:
                pin_files(expected, map_libraries((root/f'{tag}.smaps').read_text(), expected))
            status = target.wait(timeout=12)
            progress.thread.join(timeout=3)
            require(not progress.thread.is_alive() and progress.error is None and status == 0,
                    f'owned FFmpeg exited uncleanly: {status}, {progress.error}')
            require('h264 (h264_nvenc)' in (root/'ffmpeg.log').read_text(), 'FFmpeg did not name NVENC as active encoder')
            report = check_run(root)
            save(root/'result.json', report | {'ffmpeg_exit': status, 'ffmpeg_sha256':FFMPEG_SHA,
                                               'command': CMD, 'libraries': expected})
            print('Finished 60s burn-in, 3600s retained samples, and owned FFmpeg exit 0.', flush=True)
        finally:
            if target is not None and target.poll() is None:
                target.terminate()
                with suppress(subprocess.TimeoutExpired):
                    target.wait(timeout=2)
                if target.poll() is None:
                    target.kill()
                    target.wait(timeout=2)


if __name__ == '__main__':
    run(Path(sys.argv[1]).resolve(strict=True))
