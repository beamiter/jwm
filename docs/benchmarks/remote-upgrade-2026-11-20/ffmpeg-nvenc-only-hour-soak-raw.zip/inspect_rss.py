"""Identify and score the pinned 1080p host-only instrumentation comparison."""
from collections import Counter
from dataclasses import asdict, dataclass
import hashlib
import json
from pathlib import Path
import re
from statistics import linear_regression
import time

from resources import BURN_SECONDS, SECOND, read_identity, read_rows

HOST = Path("/tmp/jwm-p09-resolution-candidate/jwm-remote")
HOST_PIN = "59572059a51aae67c91eff3013012352b932850806647cb81ccda2756522b47b"
PAINTER = Path("/tmp/jwm-native-prefetch-soak.4KciT3DT/p09-workload")
PAINTER_PIN = "9f4b6b456ba6184250aa856a58925a2f2eae3043f37c384e65114ba02733da96"
OBSERVER = Path("/tmp/jwm-native-x11-resource-soak.6Wufhz33/run/observer")
OBSERVER_PIN = "d981ba7314b92529941e9a24a6d90f36f738e9679bc5abd2f417c6d0df672416"
WIDTH, HEIGHT, FPS = 1920, 1080, 30
SIZE = [WIDTH, HEIGHT]
MEASURE = 240
INTERVAL = 5
BASE_FIELDS = ("VmRSS", "RssAnon", "RssFile", "RssShmem")
ROLLUP_FIELDS = ("Rss", "Pss", "Pss_Anon", "Pss_File", "Pss_Shmem", "Private_Dirty",
                 "Private_Clean", "Shared_Dirty", "Shared_Clean", "Anonymous", "Swap")
NVENC = "hardware H.264 encoding active (NVENC)"
TEXT_STATS = re.compile(
    r"^jwm-remote: host (?P<window_seconds>\d+(?:\.\d+)?)s mode (?P<mode>\S+)"
    r" scheduled (?P<scheduled>\d+) captured (?P<captured>\d+).*?"
    r" encoded (?P<encoded>\d+) keyframes \d+ .*? sent (?P<sent>\d+) \([^)]+\)"
    r" bytes (?P<bytes>\d+) drawn-acks (?P<drawn_acks>\d+) retired \d+ .*?"
    r" outstanding current/max (?P<outstanding>\d+)/(?P<max_outstanding>\d+)"
)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha256(path):
    state = hashlib.sha256()
    with open(path, "rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            state.update(block)
    return state.hexdigest()


@dataclass(frozen=True)
class Plan:
    measured_seconds: int = MEASURE
    interval_seconds: int = INTERVAL

    def bounds(self, anchor):
        return anchor + BURN_SECONDS * SECOND, anchor + (BURN_SECONDS + MEASURE) * SECOND


def kib_fields(text, names):
    fields = {}
    for line in text.splitlines():
        key, _, value = line.partition(":")
        if key in names:
            count, unit = value.split()
            require(unit == "kB", f"unexpected Linux {key} unit")
            fields[key] = int(count)
    return fields


def read_process(identity, proc=Path("/proc")):
    require(read_identity(identity.pid, proc) == identity, "host PID identity changed before sample")
    target = proc / str(identity.pid)
    status = (target / "status").read_text()
    fields = kib_fields(status, BASE_FIELDS)
    require(set(fields) == set(BASE_FIELDS), "missing host RSS memory classes")
    threads = next(int(line.split()[1]) for line in status.splitlines() if line.startswith("Threads:"))
    descriptors = sum(path.name.isdecimal() for path in (target / "fd").iterdir())
    require(read_identity(identity.pid, proc) == identity, "host PID identity changed during sample")
    return {"rss_kib": fields["VmRSS"], "rss_anon_kib": fields["RssAnon"],
            "rss_file_kib": fields["RssFile"], "rss_shmem_kib": fields["RssShmem"],
            "threads": threads, "fds": descriptors}


def snapshot(identity, destination, tag, proc=Path("/proc")):
    require(read_identity(identity.pid, proc) == identity, "host PID identity changed before VMA snapshot")
    collected_ns = time.monotonic_ns()
    target = proc / str(identity.pid)
    descriptions = {}
    raw = {}
    for name in ("smaps_rollup", "smaps"):
        try:
            raw[name] = (target / name).read_text(errors="replace")
        except OSError as error:
            descriptions[name] = {"availability": "unavailable", "errno": error.errno}
            continue
        descriptions[name] = {"availability": "captured"}
    require(read_identity(identity.pid, proc) == identity, "host PID identity changed during VMA snapshot")
    for name, contents in raw.items():
        (destination / f"{tag}.{name}").write_text(contents)
    rollup = kib_fields(raw.get("smaps_rollup", ""), ROLLUP_FIELDS)
    (destination / f"{tag}.json").write_text(json.dumps({
        "identity": asdict(identity), "begin_ns": collected_ns, "end_ns": time.monotonic_ns(),
        "tracks": descriptions, "rollup_kib": rollup,
    }, indent=2) + "\n")


def parse_host_line(line, mode):
    if mode == "on" and line.startswith("{"):
        record = json.loads(line)
        return record if record.get("type") == "jwm_remote_host_stats" else None
    if mode == "off":
        match = TEXT_STATS.search(line)
        if match:
            values = {name: int(value) for name, value in match.groupdict().items()
                      if name not in ("mode", "window_seconds")}
            return values | {"mode": match["mode"], "window_seconds": float(match["window_seconds"])}
    return None


def bound_windows(rows, start, end, counters):
    retained = []
    for entry in rows:
        time_ns = entry["arrived_monotonic_ns"]
        record = entry["record"]
        seconds = record["window_seconds"]
        if not record.get("final") and 4.9 <= seconds <= 10 and start + round(seconds*SECOND) <= time_ns <= end:
            retained.append(record)
    covered = sum(record["window_seconds"] for record in retained)
    require(MEASURE - 12 <= covered <= MEASURE + 1, "insufficient complete telemetry windows")
    sums = {key: sum(record[key] for record in retained) for key in counters}
    require(all(sums.values()), "missing active counters")
    return retained, {"covered_seconds": covered, "windows": len(retained), "counters": sums,
                      "rates_per_second": {key: value / covered for key,value in sums.items()}}


def host_summary(root, mode):
    measured = read_rows(root / "host-resources.jsonl")
    start, end = measured[0]["measurement_start_ns"], measured[0]["measurement_end_ns"]
    require(end-start == MEASURE*SECOND and measured[-1]["type"]=="p09_soak_end"
            and measured[-1]["monotonic_ns"] >= end and measured[-1]["missed_sample_slots"] == 0,
            "host resource sampler did not reach its retained terminal boundary")
    samples = [row for row in measured if row.get("phase") == "measured"]
    require(len(samples) == MEASURE//INTERVAL and all(
        row["scheduled_ns"] == start+index*INTERVAL*SECOND and
        row["scheduled_ns"] <= row["sample_start_ns"] <= row["sample_ns"] < row["scheduled_ns"]+INTERVAL*SECOND
        for index, row in enumerate(samples)), "missing or delayed host sample")
    diagnostic = (root / "host.log").read_text()
    require(diagnostic.count("authenticated session started (view only)") == 1
            and diagnostic.count("connection from 127.0.0.1:") == 1
            and diagnostic.count(NVENC) == 1 and "H.264 NVENC negotiated" in diagnostic
            and not any(token in diagnostic for token in ("hardware encoding failed", "switching to JPEG",
                                                            "NVENC opened", "adaptive video")),
            "host did not run one fixed authenticated H.264 NVENC session")
    all_windows = read_rows(root / "host-clock.jsonl")
    retained, report = bound_windows(all_windows, start, end, ("captured","sent","drawn_acks","bytes"))
    report["mode"] = retained[0]["mode"]
    require({row["mode"] for row in retained} == {report["mode"]}, "capture mode changed")
    require(max(row["max_outstanding"] for row in retained) <= 2, "host declared excess frame credits")
    if mode == "on":
        for row in retained:
            require(row["source_dimensions"] == SIZE == row["encoded_dimensions"]
                    and row["sent"] == row["h264_frames"] and not any(
                row[k] for k in ("jpeg_atlases","png_atlases","hevc444_frames")),
                "host changed dimensions or codec in JSON windows")
        auth = {r.get("session_id") for r in retained}
        require(len(auth) == 1 and all(auth), "host did not report one session ID")
        report["session_id"] = auth.pop()
    else:
        require(not any("jwm_remote_host_stats" in line for line in diagnostic.splitlines()
                        if line.startswith("{")), "host emitted JSON stats in OFF arm")
        report["session_id"] = None
    time_axis = [(row["sample_ns"]-start)/SECOND for row in samples]
    result = {}
    for field in ("rss_kib","rss_anon_kib","rss_file_kib","rss_shmem_kib","threads","fds"):
        numbers = [row[field] for row in samples]
        result[field] = {"first": numbers[0], "last": numbers[-1], "min":min(numbers), "max":max(numbers),
                         "linear_slope_per_minute":linear_regression(time_axis,numbers).slope*60,
                         "step_counts":dict(Counter(b-a for a,b in zip(numbers,numbers[1:])))}
    maps = {tag:json.loads((root/f"{tag}.json").read_text()) for tag in ("vma-start","vma-end")}
    require(all(entry["identity"]==measured[0]["identity"] for entry in maps.values()),
            "VMA snapshot was collected from a different process")
    require(abs(maps["vma-start"]["begin_ns"] - start) < 2*SECOND
            and abs(maps["vma-end"]["begin_ns"] - end) < 2*SECOND,
            "VMA snapshot outside its bracket")
    return report | {"host_retained_samples":len(samples), "rss":result, "vma":maps}


def assess(root, mode, run_id):
    host = host_summary(root/"remote", mode)
    scans = read_rows(root/"observed.jsonl")
    first,last = scans[0],scans[-1]
    require(first["type"] == "p09_start" and [first["width"],first["height"]] == SIZE
            and last["type"] == "p09_end" and first["run_id"] == last["run_id"] == run_id
            and not (last["interrupted"] or last["target_lost"] or last["reordered"] or last["wrong_run"]),
            "observer did not finish the exact owned drawable")
    start,end = Plan().bounds(first["monotonic_ns"])
    points = [row for row in scans if row["type"]=="p09_frame" and start<=row["monotonic_ns"]<end]
    require(bool(points) and last["monotonic_ns"] >= end and
            all(a["source_frame"]<b["source_frame"] for a,b in zip(points,points[1:])),
            "independent marker progress or duration missing")
    require(all(any(start+minute*60*SECOND<=point["monotonic_ns"]<start+(minute+1)*60*SECOND
                    for point in points) for minute in range(MEASURE//60)), "missing observed minute")
    rows,viewer=bound_windows(read_rows(root/"viewer-clock.jsonl"),start,end,("received","drawn","acked"))
    auth={r.get("session_id") for r in rows}
    require(len(auth)==1 and all(auth) and (host["session_id"] is None or host["session_id"] in auth),
            "viewer session ID missing or does not match host")
    frames=[r["last_frame"] for r in rows]
    require(all(f and f["codec"]=="H.264" and f["source_dimensions"]==SIZE==f["encoded_dimensions"]
                for f in frames) and all(r["negotiated_codec"]=="H.264" for r in rows),
            "viewer did not receive the declared 1080p H.264 stream")
    begins,final=read_rows(root/"remote/paint.jsonl")
    require(begins["type"]=="p09_start" and final["type"]=="p09_end" and
            begins["run_id"]==final["run_id"]==run_id and begins["fps"]==60
            and [begins["width"],begins["height"]]==SIZE and
            final["last_submit_ns"]-final["first_submit_ns"] >= (BURN_SECONDS+MEASURE)*SECOND,
            "the owned source did not cover the retained continuous motion")
    receive_rate=viewer["rates_per_second"]["received"]
    require(abs(receive_rate-host["rates_per_second"]["sent"]) <= max(.5,receive_rate*.03),
            "different host sent and viewer received cadence")
    terminal=json.loads((root/"terminal.json").read_text())
    require(terminal=={"observer":0,"viewer":0,"source":0}, "actor did not exit cleanly")
    return {"status":"complete","stats_json":mode=="on","host":host,"viewer":viewer,
            "session_binding":"matching host and viewer correlation ID" if mode=="on" else
            "private generated key and one host --once via owned SSH loopback; host JSON ID absent",
            "independent_markers":{"unique":len(points),"visible_fps":len(points)/MEASURE},
            "retained_seconds":MEASURE}
