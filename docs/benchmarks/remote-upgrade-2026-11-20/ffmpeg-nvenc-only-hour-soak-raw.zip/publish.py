"""Replay the owned extended FFmpeg run and describe VMA growth without addresses."""
import json
from pathlib import Path
import re
from statistics import linear_regression

import vma_analyzer as vm
from encode_only import BURN_IN, CMD, FFMPEG_SHA, FIELDS, MEASURE, SNAPSHOTS, check_run, map_libraries, require, sha256


def read(path):
    return json.loads(path.read_text())


def history(root, bounds):
    before = vm.vm_maps(root/'vma-start.smaps')
    after = vm.vm_maps(root/'vma-15m.smaps')
    growing_range = max(
        (name for name in before.keys() & after.keys() if before[name]['category'] == 'anonymous_private'),
        key=lambda name: after[name]['Rss_kib'] - before[name]['Rss_kib'],
    )
    require(after[growing_range]['Rss_kib'] > before[growing_range]['Rss_kib'],
            'no growing anonymous mapping localized in the first observation pair')
    lo, hi = (int(value,16) for value in growing_range.split('-'))
    samples = []
    for seconds, tag in SNAPSHOTS:
        snapshot = vm.public_bracket(root, tag, bounds['start_ns'] + seconds * 10**9)
        maps = vm.vm_maps(root/f'{tag}.smaps')
        intersecting = []
        for extent, data in maps.items():
            start, end = (int(value,16) for value in extent.split('-'))
            if start < hi and end > lo:
                intersecting.append(data)
        samples.append({'seconds': seconds, 'same_original_extent': growing_range in maps,
                        'added_extents_since_start': len(maps.keys() - before.keys()),
                        'removed_extents_since_start': len(before.keys() - maps.keys()),
                        'original_extent_overlaps': intersecting, 'snapshot': snapshot})
    return samples


def report(stage):
    raw = stage/'remote'
    measured = check_run(raw)
    result = read(raw/'result.json')
    require(all(result[key] == value for key,value in measured.items()), 'observed and replayed sample results differ')
    require(result['command'] == CMD and result['ffmpeg_sha256'] == FFMPEG_SHA and result['ffmpeg_exit'] == 0
            and (raw/'controller.exit').read_text().strip() == '0', 'owned FFmpeg or controller failed')
    for line in (stage/'inputs.sha256').read_text().splitlines():
        digest, name = line.split()
        require(sha256(stage/name) == sha256(raw/name) == digest, 'staged fixture digest differs')
    expected = read(raw/'protected-library-identities.json')
    require(result['libraries'] == expected['libraries'], 'installed-library metadata differs')
    for _, tag in SNAPSHOTS:
        mapped = map_libraries((raw/f'{tag}.smaps').read_text(), result['libraries'])
        require(set(mapped) == set(result['libraries'])
                and all(mapped[name]['file_identity'] == pin['file_identity']
                        for name,pin in result['libraries'].items()), 'active encoder loaded different libraries')

    bounds = read(raw/'bounds.json')
    start = bounds['start_ns']
    rows = [{'elapsed_seconds': (row['sample_ns']-start)/1e9,
             'encoded_frames': row['encoded_frames'], 'phase': row['phase']}
            | {field: row[field] for field in FIELDS}
            for row in (json.loads(s) for s in (raw/'samples.jsonl').read_text().splitlines())
            if row['phase'] in ('measured', 'retained_end')]
    stable_from = len(rows) - 1
    final_anon = rows[-1]['rss_anon_kib']
    while stable_from > 0 and rows[stable_from - 1]['rss_anon_kib'] == final_anon:
        stable_from -= 1
    unchanged = {
        'anonymous_rss_kib': final_anon,
        'first_sample_elapsed_seconds': rows[stable_from]['elapsed_seconds'],
        'duration_seconds_through_terminal_measure': rows[-1]['elapsed_seconds'] - rows[stable_from]['elapsed_seconds'],
        'samples': len(rows) - stable_from,
    }
    slopes = {}
    for begin,end in ((0,900),(900,1800),(1800,2700),(2700,3300),(3300,3600)):
        kept = [row for row in rows if begin <= row['elapsed_seconds'] < end]
        slopes[f'{begin}-{end}'] = linear_regression(
            [row['elapsed_seconds'] for row in kept], [row['rss_anon_kib'] for row in kept]).slope * 60
    return measured | {
        'status': 'complete',
        'scope': f'Owned Ubuntu FFmpeg null-output process, {BURN_IN}s burn-in and {MEASURE}s of analysis. '
                 'Same pinned H.264 NVENC library identities as the earlier 240s diagnostic. '
                 'Reads Linux process RSS and VMAs.',
        'ffmpeg_sha256': FFMPEG_SHA, 'ffmpeg_version': (raw/'ffmpeg-version.txt').read_text().splitlines()[0],
        'encoder_setup_lines': [re.sub(r'(?<= @ )0x[\da-fA-F]+', '<address removed>', line)
                                for line in (raw/'ffmpeg.log').read_text().splitlines()
                                if 'Stream #' in line or 'cpb:' in line],
        'command': CMD, 'pinned_libraries': result['libraries'], 'samples': rows,
        'anon_rss_slope_kib_per_minute_by_interval': slopes,
        'unchanged_anonymous_rss_tail': unchanged,
        'anonymous_mapping_history': history(raw, bounds),
        'fixture_sha256': {name: digest for digest,name in
                           (line.split() for line in (stage/'inputs.sha256').read_text().splitlines())},
    }


if __name__ == '__main__':
    print(json.dumps(report(Path(__file__).resolve().parent), indent=2, allow_nan=False))
