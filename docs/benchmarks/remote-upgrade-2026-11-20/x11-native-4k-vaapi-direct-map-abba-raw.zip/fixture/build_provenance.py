"""Capture an offline candidate build's digest and sanitized test evidence."""

import re

from evidence_io import digest, encoded
from finalize_abba import require
from processes import sha256
from stages import bounded_read


BUILD_MEMBER = "build/evidence.json"
SOURCE_NAMES = {"Cargo.toml", "Cargo.lock", "src/remote/h264.rs", "src/remote/client.rs"}
FFMPEG_SONAMES = {"libavcodec.so.60", "libavutil.so.58", "libswscale.so.7"}
DEVICE_TEST = "remote::h264::tests::direct_vaapi_map_matches_download_and_recovers_on_same_surface"
SHA256 = re.compile(r"[0-9a-f]{64}")
RUSTC = re.compile(r"rustc [0-9]+\.[0-9]+\.[0-9]+ \([0-9a-f]+ [0-9]{4}-[0-9]{2}-[0-9]{2}\)")
TEST_RUN = re.compile(r"running ([0-9]+) tests?")
TEST_RESULT = re.compile(
    r"test result: (ok|FAILED)\. ([0-9]+) passed; ([0-9]+) failed; "
    r"([0-9]+) ignored; ([0-9]+) measured; ([0-9]+) filtered out; finished in ([0-9.]+)s"
)
RELEASE_RESULT = re.compile(r"\s*Finished `release` profile \[optimized\] target\(s\) in [0-9ms. ]+")
LINK_SONAME = re.compile(r"\s*(lib(?:avcodec|avutil|swscale)\.so\.[0-9]+) => (\S+) \(0x[0-9a-f]+\)")


def extract_one(pattern, lines):
    selected = [line.strip() for line in lines if pattern.fullmatch(line.strip())]
    require(len(selected) == 1, "build logs lack one expected terminal record")
    return selected[0]


def source_pins(text):
    pins = {}
    for line in text.splitlines():
        match = re.fullmatch(r"([0-9a-f]{64})  ([A-Za-z0-9_./-]+)", line)
        require(match is not None and match[2] not in pins, "invalid or repeated build source SHA")
        pins[match[2]] = match[1]
    require(pins.keys() == SOURCE_NAMES, "unexpected build source manifest")
    return pins


def collect_build_evidence(build):
    manifest = bounded_read(build / "binary.sha256")
    binary = re.fullmatch(r"([0-9a-f]{64})  [^\r\n]*jwm-remote\n?", manifest.decode())
    require(binary is not None, "invalid candidate binary digest manifest")
    release = build / "jwm-remote"
    require(binary[1] == sha256(release), "candidate binary differs from its build manifest")
    files = {name: bounded_read(build / name) for name in (
        "source.sha256", "rustc.txt", "build.exit", "build.log", "linkage.log",
        "remote-unit.exit", "remote-unit.log", "vaapi-device-test.exit", "vaapi-device-test.log",
    )}
    release_log = files["build.log"].decode().splitlines()
    link = [match[1] for line in files["linkage.log"].decode().splitlines()
            if (match := LINK_SONAME.fullmatch(line)) and match[2].endswith("/" + match[1])]
    evidence = {
        "viewer_binary_sha256": binary[1],
        "viewer_binary_bytes": release.stat().st_size,
        "source_sha256": source_pins(files["source.sha256"].decode()),
        "rustc": files["rustc.txt"].decode().strip(),
        "release_exit": int(files["build.exit"].strip()),
        "release_terminal_record": extract_one(RELEASE_RESULT, release_log),
        "ffmpeg_sonames": sorted(link),
        "tests": {},
        "original_files_sha256": {name: digest(data) for name, data in files.items()} |
                                 {"binary.sha256": digest(manifest)},
    }
    for name in ("remote-unit", "vaapi-device-test"):
        log = files[name + ".log"].decode().splitlines()
        starts = [line.strip() for line in log if TEST_RUN.fullmatch(line.strip())]
        terminals = [line.strip() for line in log if TEST_RESULT.fullmatch(line.strip())]
        require(starts and terminals, "missing Cargo start or terminal evidence")
        # The library test suite starts subprocess tests and includes their output.
        test = {
            "exit_status": int(files[name + ".exit"].strip()),
            "running": starts[0],
            "terminal_record": terminals[-1],
        }
        if name == "vaapi-device-test":
            test["test_case"] = extract_one(re.compile(r"test " + re.escape(DEVICE_TEST) + r" \.\.\. ok"), log)
        evidence["tests"][name] = test
    return encoded(evidence)


def replay_build_evidence(evidence, viewer_pin):
    require(evidence["viewer_binary_sha256"] == viewer_pin and SHA256.fullmatch(viewer_pin) and
            type(evidence["viewer_binary_bytes"]) is int and evidence["viewer_binary_bytes"] > 0,
            "candidate build binary does not match the scored viewer pin")
    pins = evidence["source_sha256"]
    require(pins.keys() == SOURCE_NAMES and all(SHA256.fullmatch(value) for value in pins.values()),
            "invalid build source pins")
    require(RUSTC.fullmatch(evidence["rustc"]) and evidence["release_exit"] == 0 and
            RELEASE_RESULT.fullmatch(evidence["release_terminal_record"]),
            "viewer optimized build has no qualifying terminal record")
    require(evidence["ffmpeg_sonames"] == sorted(FFMPEG_SONAMES), "unexpected viewer FFmpeg linkage")
    require(evidence["tests"].keys() == {"remote-unit", "vaapi-device-test"}, "unexpected build tests")
    tests = {}
    for name, details in evidence["tests"].items():
        terminal = TEST_RESULT.fullmatch(details["terminal_record"])
        started = TEST_RUN.fullmatch(details["running"])
        require(terminal is not None and started is not None, "unrecognized Cargo test result")
        result, passed, failed, ignored, measured, filtered, seconds = terminal.groups()
        counts = dict(zip(("passed", "failed", "ignored", "measured", "filtered_out"),
                          map(int, (passed, failed, ignored, measured, filtered))))
        require(sum(counts[key] for key in ("passed", "failed", "ignored", "measured")) == int(started[1]),
                "Cargo test totals differ from tests started")
        require(details["exit_status"] == 0 and result == "ok" and counts["failed"] == 0 and counts["passed"] > 0,
                "candidate build tests did not exit cleanly")
        tests[name] = counts | {"exit_status": details["exit_status"], "finished_seconds": float(seconds)}
        if name == "vaapi-device-test":
            require(details["test_case"] == f"test {DEVICE_TEST} ... ok" and counts["passed"] == 1,
                    "missing exact device test outcome")
            tests[name]["test_case"] = DEVICE_TEST
    return {
        "viewer_binary_sha256": viewer_pin,
        "viewer_binary_bytes": evidence["viewer_binary_bytes"],
        "source_sha256": pins,
        "rustc": evidence["rustc"],
        "release_profile": "optimized",
        "release_exit": evidence["release_exit"],
        "ffmpeg_sonames": evidence["ffmpeg_sonames"],
        "tests": tests,
        "evidence_member": BUILD_MEMBER,
        "scope": (
            "Verified candidate build and retained Cargo test records. The release binary hash is verified against the "
            "viewer pin. The test counts describe separate Cargo test executables from the retained build lane."
        ),
    }
