#!/usr/bin/env python3
"""Safe evidence collection shared with the verified 4K X11 fixture."""

import hashlib
import json
from pathlib import Path
import re

from stages import bounded_read


RAW_FIELDS = (
    "result.json",
    "observed.jsonl",
    "viewer-clock.jsonl",
    "retained-host.jsonl",
    "retained-viewer.jsonl",
    "retained-markers.jsonl",
    "remote/paint.jsonl",
    "remote/binaries.json",
)
ROLE_LOGS = {
    "host": ("remote/host.log", "remote/host-telemetry.jsonl", {
        "nvenc_negotiated": "H.264 NVENC negotiated",
        "hardware_encode_failed": "hardware encoding failed",
    }),
    "viewer": ("viewer.log", "viewer-telemetry.jsonl", {
        "vaapi_active": "H.264 hardware decoder active (VAAPI)",
        "session_ended": "jwm-remote: session ended",
        "jpeg_switch": "host switched to JPEG",
    }),
}
FAILURE_REASONS = (
    "source and observer trial markers did not match",
    "the exact observation drawable or trial was lost",
    "the observer ended before the full measured interval",
    "viewer pixels did not produce a valid marker stream",
    "observer retained stale or duplicate markers",
    "the measured windows did not keep the fixed H.264 codec",
    "source or encoded image was resized unexpectedly",
    "source manifest does not match the requested A/B case",
    "insufficient telemetry",
    "arm measured the wrong readback route",
    "unexpected CPU rescaling in native-size A/B",
    "A/B did not measure an active readback window",
    "the presentation observer failed",
    "viewer exited before the presentation observer",
    "viewer failed to close",
    "viewer telemetry drain did not finish",
    "remote host failed to close",
    "source painter ended during the benchmark",
    "source was not capable of the requested rate",
    "host and viewer telemetry are from different authenticated sessions",
)
SHA = re.compile(r"[0-9a-f]{64}")
IP4 = re.compile(rb"(?<![0-9.])(?:192\.168|10\.\d{1,3}|172\.(?:1[6-9]|2\d|3[01]))\.\d{1,3}\.\d{1,3}(?![0-9.])")
ERROR = re.compile(r"^(?:\w+\.)*(\w*(?:Error|Exception|Timeout)):", re.M)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encoded(data):
    return (json.dumps(data, indent=2, allow_nan=False) + "\n").encode()


def read_json(data):
    return json.loads(data)


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)


def typed_log(data, role):
    allowed = {f"jwm_remote_{role}_stats", "jwm_remote_command_result"}
    rows = []
    malformed = 0
    for line in data.splitlines(keepends=True):
        if not line.startswith(b"{"):
            continue
        try:
            parsed = json.loads(line)
            if parsed.get("type") in allowed:
                rows.append(line.rstrip(b"\r\n") + b"\n")
        except (ValueError, AttributeError):
            malformed += 1
    return b"".join(rows), malformed


def failure_summary(data):
    text = data.decode(errors="replace")
    return {
        "sha256_before_omission": digest(data),
        "recognized_reasons": [reason for reason in FAILURE_REASONS if reason in text],
        "terminal_error_types": ERROR.findall(text),
    }


def route_diagnostics(folder, archive_name, entries):
    result = {}
    for role, (log_file, raw_file, phrases) in ROLE_LOGS.items():
        path = folder / log_file
        if path.is_file():
            data = bounded_read(path)
            clean, malformed = typed_log(data, role)
            entries[f"run/{archive_name}/{raw_file}"] = clean
            result[role] = {
                "sha256_before_omission": digest(data),
                "unparsed_json_candidates": malformed,
                "matches": {key: data.count(phrase.encode()) for key, phrase in phrases.items()},
            }
        else:
            result[role] = None
    return result


def link_summary(path):
    data = bounded_read(path)
    text = data.decode(errors="replace")
    count = re.findall(r"(\d+) packets transmitted, (\d+)(?: packets)? received", text)
    timing = re.findall(r"rtt min/avg/max/mdev = ([0-9.]+)/([0-9.]+)/([0-9.]+)/([0-9.]+) ms", text)
    return {
        "sha256_before_omission": digest(data),
        "packets": dict(zip(("transmitted", "received"), map(int, count[-1]))) if count else None,
        "rtt_ms": dict(zip(("min", "mean", "max", "mdev"), map(float, timing[-1]))) if timing else None,
    }


