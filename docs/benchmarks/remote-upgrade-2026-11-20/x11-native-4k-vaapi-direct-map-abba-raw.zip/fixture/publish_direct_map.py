#!/usr/bin/env python3
"""Publish/replay the fixed 4K X11 CPU viewer direct-map comparison offline."""

import argparse
import json
from pathlib import Path
import re
import tempfile
from zipfile import ZIP_DEFLATED, ZipFile

from build_provenance import BUILD_MEMBER, collect_build_evidence, replay_build_evidence
from direct_stats import STAGED_BYTES_PER_FRAME, validate_viewer_route
from evidence_io import (
    IP4, RAW_FIELDS, digest, encoded, failure_summary, link_summary, route_diagnostics, write,
)
from finalize_abba import analyze_trial, require, rollup
from run_abba import EXPECTED, LABEL, ORDER
from stages import bounded_read


STEM = "x11-native-4k-vaapi-direct-map-abba"
SIZE = [3840, 2160]
SOURCES = ("fixture_4k.py", "source.py", "processes.py", "p09-workload.c", "run_abba.py")
REPLAYER = ("build_provenance.py", "direct_stats.py", "evidence_io.py", "finalize_abba.py",
            "stages.py", "publish_direct_map.py")
COUNTERS = ("mapped_frames", "fallback_frames", "staged_bytes", "download_observations",
            "conversion_observations", "active_windows", "windows_with_successful_maps",
            "windows_with_fallback_frames", "all_failed_or_disabled_windows")


def case_name(index, mode):
    return f"{LABEL}-{index:02}-{mode}-fixed"


def all_names():
    return [case_name(index, mode) + suffix for index, mode in enumerate(ORDER, 1) for suffix in ("", "-retry")]


def collection(stage, controller_log=None, build_dir=None):
    entries = {}
    protocol = json.loads(bounded_read(stage / "protocol.json"))
    entries["run/protocol.json"] = encoded(protocol)
    exit_status = int((stage / "live.exit").read_text().strip())
    entries["run/terminal.json"] = encoded({"exit_status": exit_status})
    for name in SOURCES + REPLAYER:
        local = bounded_read(Path(__file__).with_name(name))
        if name in SOURCES:
            require(digest(local) == protocol["fixture_sources_sha256"][name], "staged fixture source differs: " + name)
        entries["fixture/" + name] = IP4.sub(b"<private-peer>", local)
    # Record a digest for every archived source form and separately keep the
    # pre-stage copies' exact hashes in the protocol.
    entries["fixture/source-archive-sha256.json"] = encoded({
        name: digest(entries["fixture/" + name]) for name in SOURCES + REPLAYER
    })
    for name in all_names():
        folder = stage / name
        if folder.is_dir():
            for relative in RAW_FIELDS + ("viewer-control.json",):
                path = folder / relative
                if path.is_file():
                    entries[f"run/{name}/{relative}"] = bounded_read(path)
            diagnostics = route_diagnostics(folder, name, entries)
            for relative in ("observer-stderr.log", "remote/paint-stderr.log", "disconnect.log", "remote-copy-error.log"):
                path = folder / relative
                if path.is_file():
                    data = bounded_read(path)
                    diagnostics[relative] = {"bytes": len(data), **failure_summary(data)}
            entries[f"run/{name}/diagnostics.json"] = encoded(diagnostics)
        error = stage / f"{name}-error.log"
        if error.is_file():
            entries[f"run/{name}-error.json"] = encoded(failure_summary(bounded_read(error)))
    if controller_log is not None:
        data = bounded_read(controller_log)
        text = data.decode(errors="replace")
        starts = re.findall(r"^started ([a-z0-9-]+)$", text, re.M)
        failures = re.findall(r"^failed ([a-z0-9-]+):", text, re.M)
        known = set(all_names())
        entries["run/controller.json"] = encoded({
            **failure_summary(data),
            "reported_starts": [name for name in starts if name in known],
            "reported_failures": [name for name in failures if name in known],
        })
    for phase in ("before", "after"):
        ping = stage / f"link-{phase}.txt"
        if ping.is_file():
            entries[f"run/link-{phase}.json"] = encoded(link_summary(ping))
    if build_dir is not None:
        entries[BUILD_MEMBER] = collect_build_evidence(build_dir)
    return entries


def verify_protocol(protocol, entries):
    for field, expected in {
        "schema_version": 1, "label": LABEL, "order": list(ORDER),
        "dimensions": SIZE, "requested_fps": 30, "source_requested_fps": 60,
        "host_scaling_policy": "auto", "viewer_scaling_policy": "cpu",
        "warmup_seconds": 30, "score_seconds": 60, "observer_seconds": 105,
    }.items():
        require(protocol[field] == expected, "unexpected fixed acquisition protocol: " + field)
    pins = protocol["binary_pins"]
    require(pins == EXPECTED | {"viewer_binary_sha256": pins["viewer_binary_sha256"]} and
            re.fullmatch(r"[0-9a-f]{64}", pins["viewer_binary_sha256"]),
            "pinned endpoint or fixture binary differs")
    source_bytes = json.loads(entries["fixture/source-archive-sha256.json"])
    require(source_bytes == {name: digest(entries["fixture/" + name]) for name in SOURCES + REPLAYER},
            "archived validator or fixture source differs")
    return pins


def candidate_result(folder, mode, index, pins):
    case, stats = analyze_trial(folder, "auto", index, SIZE)
    control = json.loads(bounded_read(folder / "viewer-control.json"))
    require(control == {
        "viewer_mode": mode,
        "viewer_environment_opt_in": "1" if mode == "on" else None,
        "viewer_binary_sha256": pins["viewer_binary_sha256"],
        "viewer_scaling_policy": "cpu",
    } and stats["binary_pins"] == pins, "actual selected viewer binary/mode differs from declared arm")
    stats["vaapi_map_route"] = validate_viewer_route(case["viewer"], mode)
    return case, stats


def arm_summary(cases):
    counts = [stats["vaapi_map_route"] for _, stats in cases]
    return rollup(cases) | {"vaapi_map_route_totals": {key: sum(item[key] for item in counts) for key in COUNTERS}}


def pairs(accepted):
    result = []
    for index in range(0, len(accepted), 2):
        pair = accepted[index:index+2]
        scope = {"slots": [index + 1, index + 2], "execution_order": list(ORDER[index:index+2])}
        if None in pair:
            result.append(scope | {"status": "incomplete"})
            continue
        selected = {mode: row for mode, row in zip(ORDER[index:index+2], pair)}
        off, on = selected["off"], selected["on"]
        result.append(scope | {
            "status": "valid",
            "on_minus_off_unique_fps": on["unique_fps"] - off["unique_fps"],
            "on_minus_off_observer_gap_p95_ms": on["p95_gap_ms"] - off["p95_gap_ms"],
            "on_minus_off_observer_max_gap_ms": on["max_gap_ms"] - off["max_gap_ms"],
        })
    return result


def trial_report(root, protocol, pins):
    trials = []
    chosen = []
    tokens = set()
    lanes = {"off": [], "on": []}
    for index, mode in enumerate(ORDER, 1):
        name = case_name(index, mode)
        attempts = []
        accepted = None
        for attempt in (name, name + "-retry"):
            folder = root / attempt
            fail = root / f"{attempt}-error.json"
            present = folder.is_dir()
            if not (present or fail.is_file() or attempt == name):
                continue
            item = {"name": attempt, "raw_directory": attempt if present else None}
            if fail.is_file():
                item |= {"status": "failed", "failure": json.loads(bounded_read(fail))}
            elif not (folder / "result.json").is_file():
                item["status"] = "incomplete_attempt" if present else "missing_attempt"
            else:
                try:
                    require(attempt == name or protocol["retry_failed_trial"] is True, "unplanned retry attempt")
                    case, stats = candidate_result(folder, mode, index, pins)
                    require(stats["authenticated_session_id"] not in tokens, "authenticated session reused between slots")
                except (OSError, ValueError, TypeError, KeyError, IndexError) as error:
                    item |= {"status": "invalid_evidence",
                             "error": str(error) if type(error) is ValueError else type(error).__name__}
                else:
                    item |= {"status": "valid", "metrics": stats}
                    if accepted is None:
                        accepted = item
                        lanes[mode].append((case, stats))
                        tokens.add(stats["authenticated_session_id"])
            attempts.append(item)
        chosen.append(accepted["metrics"] if accepted is not None else None)
        trials.append({
            "block": (index - 1) // 4 + 1, "slot": index, "mode": mode,
            "accepted_case": accepted["name"] if accepted is not None else None, "attempts": attempts,
        })
    return trials, chosen, lanes


def reconstruct(entries):
    protocol = json.loads(entries["run/protocol.json"])
    pins = verify_protocol(protocol, entries)
    terminal = json.loads(entries["run/terminal.json"])["exit_status"]
    require(type(terminal) is int, "invalid terminal status")
    allowed = set(all_names())
    with tempfile.TemporaryDirectory(prefix="jwm-4k-map-replay.") as name:
        root = Path(name)
        for member, data in entries.items():
            path = Path(member)
            require(not path.is_absolute() and ".." not in path.parts, "unsafe archive member")
            if len(path.parts) >= 2 and path.parts[0] == "run":
                candidate = path.parts[1].removesuffix("-error.json")
                if candidate in allowed:
                    write(root.joinpath(*path.parts[1:]), data)
        trials, chosen, lanes = trial_report(root, protocol, pins)
    complete = terminal == 0 and None not in chosen
    activated = complete and all(row["vaapi_map_route"]["mapped_frames"] > 0 for _, row in lanes["on"])
    every_active_b_window_mapped = complete and all(
        row["vaapi_map_route"]["windows_with_successful_maps"] == row["vaapi_map_route"]["active_windows"]
        for _, row in lanes["on"]
    )
    meets = complete and all(row["existing_27_fps_gate_met"] for _, row in lanes["on"])
    report = {
        "schema_version": 1, "protocol": protocol, "controller_exit": terminal,
        "status": "complete" if complete else "controller_failed" if terminal != 0 else "incomplete_evidence",
        "independent_arm_summaries": {arm: arm_summary(values) for arm, values in lanes.items()},
        "trials": trials, "adjacent_pairs": pairs(chosen),
        "all_on_trials_show_mapping": activated,
        "every_active_on_window_has_some_mapped_frames": every_active_b_window_mapped,
        "all_on_trials_meet_27_unique_fps": meets,
        "candidate_27_fps_qualification": activated and meets,
        "staged_nv12_bytes_per_mapped_frame": STAGED_BYTES_PER_FRAME,
        "link": {phase: json.loads(entries[f"run/link-{phase}.json"])
                 for phase in ("before", "after") if f"run/link-{phase}.json" in entries},
        "controller": json.loads(entries["run/controller.json"]) if "run/controller.json" in entries else {},
        "method": (
            "One pinned Ubuntu fixed H.264 NVENC host using exact MIT-SHM readback; one pinned Mint "
            "caller-supplied binary using VA-API and CPU X11 RGB presentation with the flag unset or set to 1. "
            "Software stage summaries use whole telemetry windows and their per-window quantiles. "
            "Per-window fallback counts include frames after a decoder scope stopped retrying. "
            "Only visible, increasing source markers in the exact local 60-second interval count toward 27 FPS. "
            "Raw logs retain typed records and sanitized failure/route diagnostics."
        ),
    }
    if BUILD_MEMBER in entries:
        report["viewer_build"] = replay_build_evidence(json.loads(entries[BUILD_MEMBER]),
                                                     pins["viewer_binary_sha256"])
    return json.loads(encoded(report))


def replay(summary, archive):
    expected = json.loads(summary.read_bytes())
    index = expected.pop("archive")
    require(index["path"] == archive.name and index["sha256"] == digest(archive.read_bytes()), "raw ZIP identity changed")
    with ZipFile(archive) as reader:
        names = reader.namelist()
        require(len(set(names)) == len(names) and set(names) == set(index["entries"]), "raw ZIP inventory changed")
        entries = {name: reader.read(name) for name in names}
    require({name: digest(data) for name, data in entries.items()} == index["entries"], "raw ZIP entry changed")
    require(reconstruct(entries) == expected, "offline score and qualification differ")
    return expected


def publish(entries, out):
    report = reconstruct(entries)
    out.mkdir(parents=True, exist_ok=True)
    summary = out / f"{STEM}.json"
    archive = out / f"{STEM}-raw.zip"
    require(not summary.exists() and not archive.exists(), "use a fresh publication directory")
    with ZipFile(archive, "x", compression=ZIP_DEFLATED, compresslevel=7) as writer:
        for name, data in sorted(entries.items()):
            writer.writestr(name, data)
    report["archive"] = {"path": archive.name, "sha256": digest(archive.read_bytes()),
                         "entries": {name: digest(data) for name, data in entries.items()}}
    with summary.open("xb") as output:
        output.write(encoded(report))
    replay(summary, archive)
    print(report["status"], summary, archive)


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    commands = cli.add_subparsers(dest="command", required=True)
    pack = commands.add_parser("publish")
    pack.add_argument("--run", required=True, type=Path)
    pack.add_argument("--out", required=True, type=Path)
    pack.add_argument("--controller-log", type=Path)
    pack.add_argument("--build-dir", type=Path, help="Optional exact terminal viewer build evidence")
    verify = commands.add_parser("replay")
    verify.add_argument("summary", type=Path)
    verify.add_argument("archive", type=Path)
    args = cli.parse_args()
    if args.command == "publish":
        if not (args.run / "live.exit").is_file():
            cli.error("no terminal controller status; leave running trial data untouched")
        publish(collection(args.run, args.controller_log, args.build_dir), args.out)
    else:
        print(replay(args.summary, args.archive)["status"], "reproduced from", args.archive)


if __name__ == "__main__":
    main()
