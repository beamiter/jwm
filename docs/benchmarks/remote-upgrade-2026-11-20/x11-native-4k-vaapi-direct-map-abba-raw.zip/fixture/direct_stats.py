"""Verify per-window routing allocated to exact 3840×2160 NV12 CPU viewer frames."""

from finalize_abba import require


STAGED_BYTES_PER_FRAME = 3840 * 2160 * 3 // 2


def count(data, key):
    value = data[key]
    require(type(value) is int and value >= 0, f"invalid direct-map count for {key}")
    return value


def observations(row, stage):
    return count(row["stages"][stage], "observations")


def validate_viewer_route(windows, mode):
    results = []
    for index, row in enumerate(windows, 1):
        require(count(row, "native_presented") == 0 and
                (not row["drawn"] or row["last_presentation_path"] == "rgb") and
                observations(row, "native_preparation_and_submit_ms") == 0,
                "viewer escaped CPU X11 RGB presentation")
        map_work = row["hardware_rgb_work"]["vaapi_map"]
        mapped = count(map_work, "mapped_frames")
        fallback = count(map_work, "fallback_frames")
        staged_bytes = count(map_work, "staged_bytes")
        map_timing = observations(row, "hardware_direct_map_ms")
        downloads = observations(row, "hardware_download_ms")
        converted = observations(row, "hardware_conversion_ms")
        require(mapped == map_timing and staged_bytes == mapped * STAGED_BYTES_PER_FRAME,
                "VA-API stage count or NV12 staged byte count differs from successful frames")
        if mode == "off":
            require(mapped == fallback == staged_bytes == 0 and converted == downloads,
                    "baseline used direct mapping or omitted its measured VA-API transfer")
        else:
            require(mapped + fallback == converted and fallback == downloads,
                    "candidate conversion does not reconcile mapped frames and scoped transfer fallback")
        results.append({
            "window": index, "seconds": row["window_seconds"], "mapped_frames": mapped,
            "fallback_frames": fallback, "staged_bytes": staged_bytes, "download_observations": downloads,
            "conversion_observations": converted,
        })
    totals = {key: sum(row[key] for row in results) for key in (
        "mapped_frames", "fallback_frames", "staged_bytes", "download_observations", "conversion_observations",
    )}
    active = [row for row in results if row["conversion_observations"]]
    require(bool(active), "no scored VA-API CPU-converted frames")
    return {
        **totals,
        "active_windows": len(active),
        "windows_with_successful_maps": sum(row["mapped_frames"] > 0 for row in active),
        "windows_with_fallback_frames": sum(row["fallback_frames"] > 0 for row in active),
        "all_failed_or_disabled_windows": sum(row["fallback_frames"] > 0 and row["mapped_frames"] == 0 for row in active),
        "windows": results,
    }
