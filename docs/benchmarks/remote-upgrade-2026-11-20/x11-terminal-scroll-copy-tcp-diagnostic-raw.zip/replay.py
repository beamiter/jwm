#!/usr/bin/env python3
"""Offline replay of the sanitized XTerm B archive. No live endpoints are used."""
import hashlib
import json
from pathlib import Path
import sys

from score import SECOND, score_pixels

HOST_PIN = '7cbcbb0de69d6143b72be1eea43c27618c849b9f8925f6d77c0a283302964fe0'
XTERM_PIN = '5415c1445d44e4c347fe51e30dd8f014de7e489873cfc82fe32af628dc01d4c4'
TAG = 97
COUNTERS = ('bytes_sent', 'bytes_acked', 'bytes_received', 'bytes_retrans', 'total_retransmissions', 'data_segs_out', 'data_segs_in')
IDENTITY_FIELDS = ('pid', 'start_ticks', 'exe_device', 'exe_inode')
INTERVAL_NS = 250000000
MAX_SAMPLES = 440
VIEWER_PIN = 'aaa1ed44223181963b3463fb169d56c9a76b31a514f29915f7ad5d47002690a3'
SCOPE = ('static', 'motion')


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def scroll_copy_summary(rows, scope):
    """Count only the host's selected, authenticated post-write windows."""
    require(len(rows) == scope['whole_windows'], 'selected scroll-copy telemetry membership differs')
    require(sorted({row['session_id'] for row in rows}) == scope['session_ids']
            and all(row['type'] == 'jwm_remote_host_stats' and not row.get('final') for row in rows),
            'scroll-copy counters did not come from the selected host session')
    counts = []
    for row in rows:
        if 'scroll_copy_frames' not in row:
            continue
        sent, copies = row['sent'], row['scroll_copy_frames']
        require(type(sent) is int and type(copies) is int and 0 <= copies <= sent,
                'scroll-copy post-write counter is outside its sent frame bound')
        counts.append(copies)
    complete = bool(rows) and len(counts) == len(rows)
    return {'selected_windows': len(rows), 'windows_with_counter': len(counts),
            'complete_counter_coverage': complete, 'scroll_copy_frames': sum(counts) if complete else None,
            'scroll_copy_frames_in_reported_windows': sum(counts) if counts else None}


def reported_scroll_copy(trial):
    if trial['status'] != 'completed':
        return False
    return all(row['complete_counter_coverage'] for row in trial['evidence']['host_scroll_copy'].values())


def used_scroll_copy(trial):
    return reported_scroll_copy(trial) and trial['evidence']['host_scroll_copy']['motion']['scroll_copy_frames'] > 0


def grade_trial(run, role, pin, viewer_pin, tag, expected_xterm):
    identity = json.loads((run / 'identity.json').read_text())
    scope = json.loads((run / 'result.json').read_text())
    start_viewer = json.loads((run / 'viewer/identity.json').read_text())
    require(identity['viewer'] == start_viewer, 'live and fetched Ubuntu viewer identities disagree')
    require(identity['host']['endpoint_executable_sha256'] == identity['host']['release_sha256'] == pin,
            'actual source executable does not match selected arm pin')
    require(identity['viewer']['endpoint_executable_sha256'] == identity['viewer']['release_sha256'] == viewer_pin,
            'actual Ubuntu viewer executable does not match shared viewer pin')
    require(int(identity['run_id'][-2:], 16) == tag
            and identity['host']['xterm']['sha256'] == expected_xterm,
            'paired marker tag or source terminal executable changed')
    if scope['telemetry_complete']:
        for phase in SCOPE:
            for endpoint in ('host', 'viewer'):
                stats = scope['phases'][phase][endpoint]['telemetry']
                require(stats['session_ids'] == scope['authenticated_session_ids'],
                        'phase telemetry did not share one authenticated session')
    routes = {phase: {endpoint: scope['phases'][phase][endpoint]['telemetry']['routes']
                      for endpoint in ('host', 'viewer')} for phase in SCOPE}
    motion = scope['phases']['motion']['viewer']['samples']['viewer']
    host_windows = {phase: [json.loads(line) for line in (run / f'{phase}-host.jsonl').read_text().splitlines()]
                    for phase in SCOPE}
    scroll_copy = {phase: scroll_copy_summary(rows, scope['phases'][phase]['host']['telemetry'])
                   for phase, rows in host_windows.items()}
    codec_p95 = [value for row in host_windows['motion']
                 if (value := row['stages']['codec_ms']['quantiles']['p95_ms']) is not None]
    return {
        'arm': role, 'host_release_sha256': pin, 'viewer_release_sha256': viewer_pin,
        'marker_tag': tag, 'capture_routes': routes, 'session_ids': scope['authenticated_session_ids'],
        'viewer_motion_gap_ms': motion['gap_ms'], 'viewer_motion_zero_bins': motion['zero_unique_bins'],
        'viewer_motion_invalid_marker_reads': motion['invalid_marker_reads'],
        'viewer_motion_reordered_marker_reads': motion['reordered_marker_reads'],
        'host_codec_p95_max_window_ms': max(codec_p95, default=None),
        'host_scroll_copy': scroll_copy,
    }


def valid(result):
    return all(result[name] for name in ('source_qualified', 'telemetry_complete', 'static_unchanged'))


def load(path):
    return json.loads(path.read_text())


def lines(path):
    with path.open() as raw:
        return [json.loads(line) for line in raw]


def checked_trace(path, run_id, role, process, port):
    rows = lines(path)
    require(bool(rows), f'{role} TCP trace is empty')
    *samples, summary = rows
    require(summary['type'] == 'scroll_copy_tcp_summary'
                   and summary['clock'] == 'CLOCK_MONOTONIC'
                   and summary['interval_ns'] == INTERVAL_NS and summary['max_sample_slots'] == MAX_SAMPLES
                   and len(samples) <= MAX_SAMPLES, f'{role} TCP summary or bound is invalid')
    require(all(summary[key] == process[key] for key in IDENTITY_FIELDS),
                   f'{role} TCP sampler owner changed')
    require(all(row['role'] == role and row['run_id'] == run_id and row['remote_port'] == port
                       and row['schema_version'] == 1 and row['socket_inode'] == summary['socket_inode']
                       and summary['start_monotonic_ns'] <= row['start_monotonic_ns']
                           <= row['end_monotonic_ns'] <= summary['end_monotonic_ns'] for row in rows),
                   f'{role} TCP trace changed socket or order')
    require(all(row['type'] == 'scroll_copy_tcp_sample' for row in samples)
                   and all(a['end_monotonic_ns'] < b['start_monotonic_ns'] for a, b in zip(samples, samples[1:]))
                   and sum(summary['counts'].get(key, 0) for key in ('tcp_info', 'queue_only')) == len(samples),
                   f'{role} TCP sample coverage is inconsistent')
    return samples, summary


def lane(path, role, session):
    side = 'source' if role == 'host' else 'viewer'
    filename = 'last_sent_frame' if role == 'host' else 'last_frame'
    scope = load(path / 'motion-scope.json')
    start, end = scope['score_start_monotonic_ns'], scope['score_end_monotonic_ns']
    require((start - scope['phase_start_monotonic_ns'], end - start,
                    scope['telemetry_phase_end_monotonic_ns'] - end) == (30 * SECOND, 60 * SECOND, 8 * SECOND),
                   f'{role} motion phase did not use the original 30/60/8 timings')
    require(scope['telemetry']['session_ids'] == [session], f'{role} telemetry session changed')
    roi = lines(path / 'motion-pixels.jsonl')
    require(all(row['side'] == side and row['start_monotonic_ns'] <= row['end_monotonic_ns'] for row in roi)
                   and all(a['end_monotonic_ns'] < b['end_monotonic_ns'] for a, b in zip(roi, roi[1:])),
                   f'{role} ROI sampling clock changed')
    score = score_pixels(roi, start, end)
    require(score == scope['samples'][side], f'{role} motion raster did not replay')
    points = [start, *score.pop('accepted_observations_monotonic_ns'), end]
    gap = max(zip(points, points[1:]), key=lambda span: span[1] - span[0])
    inside = [row for row in roi if gap[0] < row['end_monotonic_ns'] < gap[1]]
    roi_check = {'interior_reads': len(inside), 'valid_marker_reads': sum(row['marker'] is not None for row in inside),
                 'distinct_valid_markers': len({row['marker'] for row in inside if row['marker'] is not None}),
                 'distinct_valid_scroll_signatures': len({row['scroll_signature'] for row in inside
                                                          if row['scroll_signature'] is not None}),
                 'longest_gap_local_monotonic_ns': gap}
    windows = []
    for row in lines(path / f'{role}-clocked-telemetry.jsonl'):
        data, finish = row['record'], row['end_monotonic_ns']
        if data['session_id'] != session:
            continue
        begin = finish - round(data['window_seconds'] * SECOND)
        frame = data.get(filename)
        if not frame or finish < scope['phase_start_monotonic_ns'] or begin > scope['telemetry_phase_end_monotonic_ns']:
            continue
        require(frame['codec'] == 'JPEG' and frame['source_dimensions'] == frame['encoded_dimensions'] == [1920, 1080],
                       f'{role} motion frame identity changed')
        key = (frame['source_epoch'], frame['geometry_epoch'], frame['sequence'])
        fields = (('captured', 'sent', 'drawn_acks', 'outstanding', 'backpressure_skipped', 'scroll_copy_frames')
                  if role == 'host' else ('received', 'decoded', 'drawn', 'acked', 'replaced'))
        windows.append({'begin': begin, 'end': finish, 'frame': key,
                        'counts': {field: data.get(field) for field in fields}})
    return (start, end), score, gap, roi_check, windows


def progress(rows, span):
    points = [row for row in rows if span[0] <= row['start_monotonic_ns'] <= row['end_monotonic_ns'] <= span[1]]
    if not points:
        return {'samples': 0}
    local = [(row.get('tcp_info') or {}) for row in points]
    deltas = {}
    for key in COUNTERS:
        available = [point[key] for point in local if key in point]
        deltas[key] = {'observations': len(available), 'delta': available[-1] - available[0]
                       if len(available) > 1 else None}
    flat_acks = []
    for a, b in zip(points, points[1:]):
        a_info, b_info = a['tcp_info'] or {}, b['tcp_info'] or {}
        intervals = b['start_monotonic_ns'] - a['start_monotonic_ns']
        if (intervals <= INTERVAL_NS * 3 // 2 and a['tx_queue_bytes'] > 0 and b['tx_queue_bytes'] > 0
                and a_info.get('bytes_acked') is not None and a_info.get('bytes_acked') == b_info.get('bytes_acked')):
            flat_acks.append([a['end_monotonic_ns'], b['end_monotonic_ns']])
    return {'samples': len(points), 'first_sample_local_monotonic_ns': points[0]['start_monotonic_ns'],
            'last_sample_local_monotonic_ns': points[-1]['end_monotonic_ns'],
            'max_sample_read_ms': max(row['end_monotonic_ns'] - row['start_monotonic_ns'] for row in points) / 1e6,
            'max_sample_spacing_ms': max((b['start_monotonic_ns'] - a['start_monotonic_ns']
                                         for a, b in zip(points, points[1:])), default=0) / 1e6,
            'max_send_queue_bytes': max(row['tx_queue_bytes'] for row in points),
            'max_receive_queue_bytes': max(row['rx_queue_bytes'] for row in points),
            'counter_deltas': deltas, 'neighbor_samples_with_pending_tx_and_same_bytes_acked': flat_acks}


def replay(run):
    ident, result = load(run / 'identity.json'), load(run / 'result.json')
    require(valid(result) and result['codec'] == 'JPEG' and result['jpeg_quality'] == 85
                   and result['source_and_requested_viewer_dimensions'] == [1920, 1080], 'XTerm fixture qualification failed')
    require(ident['distinct_machines_verified_before_redaction'] is True
                   and all(ident[role]['clock'] == 'CLOCK_MONOTONIC' for role in ('host', 'viewer')),
                   'endpoint machine or clock scope changed')
    evidence = grade_trial(run, 'B', HOST_PIN, VIEWER_PIN, TAG, XTERM_PIN)
    require(used_scroll_copy({'status': 'completed', 'evidence': evidence}),
                   'arm B has no measured post-write scroll-copy evidence')
    session, = result['authenticated_session_ids']
    host_span, host_score, _, _, host = lane(run, 'host', session)
    view = run / 'viewer'
    view_span, view_score, view_gap, gap_roi, viewer = lane(view, 'viewer', session)
    overlap = [w for w in viewer if w['begin'] < view_gap[1] and w['end'] > view_gap[0]]
    neighbors = []
    for w in overlap:
        key = w['frame']
        epoch = [h for h in host if h['frame'][:2] == key[:2]]
        before = [h for h in epoch if h['frame'][2] <= key[2]]
        after = [h for h in epoch if h['frame'][2] >= key[2]]
        for h in (before[-1:], after[:1]):
            if h and h[0] not in neighbors:
                neighbors.append(h[0])
    host_rows, host_summary = checked_trace(run / 'tcp.jsonl', ident['run_id'], 'mint_ssh', ident['ssh_master'], 22)
    view_rows, view_summary = checked_trace(view / 'tcp.jsonl', ident['run_id'], 'ubuntu_viewer',
                                            ident['viewer']['endpoint_process'], ident['remote_port'])
    host_near = (min(w['begin'] for w in neighbors), max(w['end'] for w in neighbors)) if neighbors else None
    return {'scope': 'one independent XTerm scroll-copy B diagnostic', 'motion': evidence,
            'motion_gate_met': result['viewer_motion_gate_met'],
            'mint': {'score_clock': 'Mint CLOCK_MONOTONIC', 'raster': host_score, 'sampler': host_summary,
                     'scored_tcp': progress(host_rows, host_span), 'sequence_neighbor_windows': neighbors,
                     'tcp_in_sequence_neighbor_window_union_span': progress(host_rows, host_near) if host_near else None},
            'ubuntu': {'score_clock': 'Ubuntu CLOCK_MONOTONIC', 'raster': view_score, 'sampler': view_summary,
                       'scored_tcp': progress(view_rows, view_span), 'longest_gap_roi': gap_roi,
                       'tcp_inside_viewer_raster_gap': progress(view_rows, view_gap), 'overlapping_viewer_stats': overlap},
            'cross_machine_join': 'same session and source/geometry/sequence positions in aggregate stats, no clock conversion'}


def check_phases(run):
    result = load(run / 'result.json')
    sessions = result['authenticated_session_ids']
    for phase in SCOPE:
        for endpoint, side, root in (('host', 'source', run), ('viewer', 'viewer', run / 'viewer')):
            scope = load(root / f'{phase}-scope.json')
            require(scope == result['phases'][phase][endpoint], 'phase scope diverged from controller record')
            start, end = scope['score_start_monotonic_ns'], scope['score_end_monotonic_ns']
            duration = (start - scope['phase_start_monotonic_ns'], end - start,
                        scope['telemetry_phase_end_monotonic_ns'] - end)
            require(duration == (30 * SECOND, 60 * SECOND, 8 * SECOND), 'original phase timing changed')
            require(scope['telemetry']['session_ids'] == sessions, 'phase changed authenticated session')
            reads = lines(root / f'{phase}-pixels.jsonl')
            require(all(row['side'] == side and row['start_monotonic_ns'] <= row['end_monotonic_ns'] for row in reads)
                    and all(a['end_monotonic_ns'] < b['start_monotonic_ns'] for a, b in zip(reads, reads[1:])),
                    'ROI timing or side changed')
            replayed = score_pixels(reads, start, end)
            require(replayed == scope['samples'][side], 'ROI score did not replay')
            if phase == 'static':
                require(replayed['unique_marker_changes'] == replayed['scroll_changes_seen'] == 0
                        and replayed['distinct_scroll_signatures'] == 1, 'static raster changed')


if __name__ == '__main__':
    root = Path(__file__).resolve().parent
    raw = root / 'raw'
    manifest = load(root / 'manifest.json')
    require(hashlib.sha256((root / 'B.snapshot').read_bytes()).hexdigest() == manifest['source_snapshot_sha256'],
            'source snapshot digest changed')
    require(hashlib.sha256((root / 'score.py').read_bytes()).hexdigest() == manifest['fixture_sha256']['score.py'],
            'original raster scorer digest changed')
    check_phases(raw)
    recomputed = json.loads(json.dumps(replay(raw)))
    require(recomputed == load(root / 'observed-analysis.json'), 'analysis changed after offline replay')
    print(json.dumps({'status': 'verified offline', 'longest_viewer_gap_ms': recomputed['ubuntu']['raster']['gap_ms']['max'],
                      'scored_tcp_samples': {role: recomputed[role]['scored_tcp']['samples'] for role in ('mint', 'ubuntu')},
                      'viewer_gap_tcp_samples': recomputed['ubuntu']['tcp_inside_viewer_raster_gap']['samples'],
                      'viewer_gap_loopback_received_bytes_delta': recomputed['ubuntu']['tcp_inside_viewer_raster_gap']
                          ['counter_deltas']['bytes_received']['delta']}, sort_keys=True))
