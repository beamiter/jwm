Extract the archive and run python3 -B replay.py. All replay operations are offline.
raw/ retains both endpoint clocks separately. Consecutive numeric ROI observations are original.
Typed TCP samples and product stats retain measured fields; trial and session IDs are aliases.
The identity record retains pins and numeric process/socket equality inputs. Distinct machines
and exact live versus fetched viewer identity were verified against originals before redaction.
Runtime keys, machine/boot IDs, addresses, executable paths, shell logs and full images are omitted.
The archive supports raster-score, aggregate-window and socket-counter replay.
