#!/usr/bin/env python3
"""Verify sanitized HEVC trace, geometry, and browser raster in this directory."""
import hashlib
import json
from pathlib import Path

from align import align, read_raster, read_trace, source_reference
from hevc_evidence import CODEC, SIZE, assess, matching_frame_scope, read_jsonl, static_stillness
from score import MEASURE_SECONDS, REQUESTED_FPS, SECOND, TAIL_SECONDS, WARM_SECONDS, score_pixels

def select_telemetry(run_dir, phase, role, dimensions=(960, 640)):
    start = phase['score_start_monotonic_ns']
    last = phase['telemetry_phase_end_monotonic_ns']
    retained = []
    for line in (run_dir / f'{role}-clocked-telemetry.jsonl').read_text().splitlines():
        row = json.loads(line)
        window = row['record']
        end = row['end_monotonic_ns']
        duration = round(window['window_seconds'] * SECOND)
        if duration > 0 and start <= end - duration and end <= last:
            retained.append(row)
    selected = read_jsonl(run_dir / f"{phase['phase']}-{role}.jsonl")
    if selected != [row['record'] for row in retained]:
        raise ValueError('selected phase telemetry did not replay from its endpoint clock')
    scope_field = 'last_sent_frame' if role == 'host' else 'last_frame'
    scopes = [row['record'][scope_field] for row in retained if row['record'].get(scope_field)]
    routes = sorted({route for row in retained for route in (
        row['record'].get('mode' if role == 'host' else 'last_presentation_path'),) if route})
    return {'whole_windows': len(retained),
            'window_seconds': sum(row['record']['window_seconds'] for row in retained),
            'session_ids': sorted({row['record']['session_id'] for row in retained if row['record'].get('session_id')}),
            'routes': routes, 'frame_scopes_observed': len(scopes),
            'viewer_backends': sorted({row['record']['viewer_backend'] for row in retained
                                       if row['record'].get('viewer_backend')}),
            'frame_scopes_match_requested_jpeg': all(
                scope.get('codec') == 'JPEG' and scope.get('source_dimensions') == list(dimensions)
                and scope.get('encoded_dimensions') == list(dimensions) for scope in scopes),
            'first_window_end_monotonic_ns': retained[0]['end_monotonic_ns'] if retained else None,
            'last_window_end_monotonic_ns': retained[-1]['end_monotonic_ns'] if retained else None}


def summarize(run, transport):
    scopes = {}
    for name in ('static', 'motion'):
        host = json.loads((run / f'{name}-scope.json').read_text())
        viewer = json.loads((run / 'viewer' / f'{name}-scope.json').read_text())
        scopes[name] = {'host': host, 'viewer': viewer}
    entries = [(name, endpoint_name, phase['telemetry']) for name, pair in scopes.items()
               for endpoint_name, phase in pair.items()]
    sessions = {session for _, _, stats in entries for session in stats['session_ids']}
    complete = len(sessions) == 1 and all(
        len(stats['session_ids']) == 1 and stats['window_seconds'] >= MEASURE_SECONDS
        and stats['frame_scopes_match_requested_codec']
        and (name == 'static' or stats['frame_scopes_observed'] > 0)
        for name, _, stats in entries)
    for phase in scopes.values():
        capture = phase['host']['telemetry']
        presentation = phase['viewer']['telemetry']
        complete = (complete and capture['routes'] == ['root/xrender/shm/no-damage/cursor-events']
                    and presentation['viewer_backends'] == ['x11'] and presentation['routes'] == ['rgb'])
    host = scopes['motion']['host']['samples']['source']
    viewer = scopes['motion']['viewer']['samples']['viewer']
    scope_complete = complete
    hardware = assess(run, sorted(sessions))
    complete = scope_complete and hardware['verified']
    capable = host['unique_content_fps'] >= REQUESTED_FPS and host['scroll_changes_seen'] >= MEASURE_SECONDS
    result = {'scope': ('diagnostic X11 raster observations on separate machines over OpenSSH'
                        if transport == 'dual' else 'diagnostic X11 raster observations on one machine over loopback'),
              'source_and_requested_viewer_dimensions': SIZE, 'codec': CODEC, 'diagnostic_only': True,
              'hardware_path': hardware, 'static_unchanged': static_stillness(scopes),
              'original_capture_and_presentation_scope_complete': scope_complete,
              'authenticated_session_ids': sorted(sessions), 'telemetry_complete': complete,
              'source_motion_fps': host['unique_content_fps'], 'viewer_motion_fps': viewer['unique_content_fps'],
              'source_qualified': capable,
              'viewer_motion_gate_met': (viewer['unique_content_fps'] >= 0.9 * REQUESTED_FPS
                                         and viewer['scroll_changes_seen'] >= MEASURE_SECONDS)
                                        if capable and complete else None, 'phases': scopes}
    result['diagnostic_motion_and_static_met'] = (result['viewer_motion_gate_met'] is True
                                                   and result['static_unchanged'])
    if not complete:
        raise RuntimeError(f'HEVC diagnostic qualification failed (scope complete={scope_complete}): '
                           f'{hardware["errors"]}')
    return {key: value for key, value in result.items() if key != 'phases'}


def replay_trace(run, sessions):
    host, viewer = run, run / 'viewer'
    host_id, sent = read_trace(host / 'host.log', 'host')
    viewer_id, presented = read_trace(viewer / 'viewer.log', 'viewer')
    if sessions != [host_id] or host_id != viewer_id or {row['codec'] for row in sent} != {CODEC}:
        raise ValueError('trace did not match the qualified authenticated HEVC session')
    sr, sk, s0, s1, source_scope = read_raster(host / 'static-pixels.jsonl', host / 'static-scope.json', 'source')
    vr, vk, v0, v1, viewer_scope = read_raster(viewer / 'static-pixels.jsonl', viewer / 'static-scope.json', 'viewer')
    if sk != vk or s1 - s0 != v1 - v0 or s1 - s0 != MEASURE_SECONDS * 1_000_000_000:
        raise ValueError('trace raster intervals or format changed')
    for path, scope in ((host, source_scope), (viewer, viewer_scope)):
        if scope['telemetry']['session_ids'] != sessions:
            raise ValueError('static phase telemetry differs from the trace session')
        guards = json.loads((path / 'geometry-guard.json').read_text())
        for phase in ('static', 'motion'):
            pre, post = guards[f'before_{phase}'], guards[f'after_{phase}']
            phase_scope = json.loads((path / f'{phase}-scope.json').read_text())
            if not (pre['monotonic_ns'] <= phase_scope['phase_start_monotonic_ns']
                    < phase_scope['observer_end_monotonic_ns'] <= post['monotonic_ns']
                    and pre['drawable_xid'] == post['drawable_xid']
                    and pre['geometry'] == post['geometry']
                    and pre['structure_notify_events'] == post['structure_notify_events'] == 0):
                raise ValueError(f'incomplete fixed-geometry guard in {phase}')
    return align(sent, presented, vr, v0, v1, source_reference(sr, sk, s0, s1))


def read(path):
    return json.loads(path.read_text())


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def verify_phase(raw, role, side, phase, session):
    scope = read(raw / f'{phase}-scope.json')
    warm, first, last, tail = (scope[f'{label}_monotonic_ns'] for label in (
        'phase_start', 'score_start', 'score_end', 'telemetry_phase_end'))
    require(scope['phase'] == phase and (first-warm, last-first, tail-last) == (
        WARM_SECONDS*SECOND, MEASURE_SECONDS*SECOND, TAIL_SECONDS*SECOND), 'wrong phase timing')
    roi = read_jsonl(raw / f'{phase}-pixels.jsonl')
    require(all(row['side'] == side and row['start_monotonic_ns'] <= row['end_monotonic_ns'] for row in roi)
            and all(a['end_monotonic_ns'] < b['start_monotonic_ns'] for a, b in zip(roi, roi[1:])),
            'raster clock or side mismatch')
    require(score_pixels(roi, first, last) == scope['samples'][side], 'raster score changed')
    computed = select_telemetry(raw, scope, role, SIZE)
    computed.pop('frame_scopes_match_requested_jpeg')
    frame_key = 'last_sent_frame' if role == 'host' else 'last_frame'
    selected = read_jsonl(raw / f'{phase}-{role}.jsonl')
    computed['frame_scopes_match_requested_codec'] = all(
        matching_frame_scope(row[frame_key]) for row in selected if row.get(frame_key))
    require(computed == scope['telemetry'] and computed['session_ids'] == session,
            'phase telemetry qualification changed')


if __name__ == '__main__':
    folder = Path(__file__).resolve().parent
    raw = folder / 'raw'
    manifest = read(folder / 'manifest.json')
    for name in ('align.py', 'score.py', 'hevc_evidence.py'):
        require(hashlib.sha256((folder / name).read_bytes()).hexdigest() == manifest['pins']['fixtures'][name],
                f'fixture did not match original {name} digest')
    identity = read(raw / 'identity.json')
    require(identity['two_distinct_machines_verified_before_redaction'] is True and identity['transport'] == 'dual',
            'two-machine source identity was not verified')
    for role in ('host', 'viewer'):
        endpoint = identity[role]
        require(endpoint['release_sha256'] == endpoint['endpoint_executable_sha256'] == manifest['pins'][role]
                and endpoint['trace_env_verified'] and endpoint['drawable_size'] == list(SIZE)
                and endpoint['clock'] == 'CLOCK_MONOTONIC', 'endpoint digest, size, clock or opt-in changed')
    require(identity['host']['firefox_actual_sha256'] == manifest['pins']['firefox'], 'Firefox pin changed')
    require(read(raw / 'shutdown.json') == {'host_exit': 0, 'peer_exit': 0, 'viewer_disconnect_event': True},
            'session did not end cleanly')
    expected = read(folder / 'expected.json')
    for phase in ('static', 'motion'):
        verify_phase(raw, 'host', 'source', phase, expected['score']['authenticated_session_ids'])
        verify_phase(raw / 'viewer', 'viewer', 'viewer', phase, expected['score']['authenticated_session_ids'])
    score = json.loads(json.dumps(summarize(raw, 'dual')))
    trace = replay_trace(raw, score['authenticated_session_ids'])
    require(score == expected['score'] and trace == expected['trace_alignment'], 'recorded result did not replay')
    print(json.dumps({'status': 'verified', 'host_sent': trace['host_sent_hardware_frames'],
                      'host_idr': trace['host_sent_idrs'], 'viewer_motion_fps': score['viewer_motion_fps'],
                      'static_unchanged': score['static_unchanged'],
                      'source_exact': trace['source_reference']}, sort_keys=True))
