Extract to an empty directory and run: python3 -B replay.py
One fixed 1080p Firefox HEVC 4:4:4 IDR diagnostic on Mint and Ubuntu. Raw typed endpoint records
and numeric raster windows are retained. The source and viewer keep their original local monotonic clocks.
Authenticated session and XID values are represented by consistent aliases. Hardware activation markers
are the only unstructured log lines. No runtime paths, keys, addresses, process/device IDs, browser
profiles, screenshots, video bytes, or unfiltered logs are present. Live cross-device identity was checked
before redaction. The replay uses only archive files. The manifest names the unchanged score, capture
and trace procedure and links the source tree, runner, and selected release hashes.
