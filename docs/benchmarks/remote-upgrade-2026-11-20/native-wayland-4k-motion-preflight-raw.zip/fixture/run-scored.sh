#!/usr/bin/env bash
set -euo pipefail
cd /home/yj/projects/jwm
lab=$(cd "$(dirname "$0")" && pwd)
exec 9>/tmp/jwm-p08-p09-release/benchmark.lock
printf '%s\n' 'Waiting for exclusive Native Wayland 4K scoring lab time'
flock 9
export LD_LIBRARY_PATH=/tmp/jwm-remote-ffmpeg/usr/lib/x86_64-linux-gnu
test_binary=$(python3 - "$lab/build.jsonl" "$lab/p09-wayland-native-081/result.json" <<'PY'
import hashlib
import json
from pathlib import Path
import sys

entries = [json.loads(line) for line in Path(sys.argv[1]).read_text().splitlines()]
binary, = [row['executable'] for row in entries if row.get('reason') == 'compiler-artifact'
           and row['target']['name'] == 'jwm' and row['profile']['test'] and row.get('executable')]
pin = json.loads(Path(sys.argv[2]).read_text())['viewer_test_binary_sha256']
with Path(binary).open('rb') as data:
    if hashlib.file_digest(data, 'sha256').hexdigest() != pin:
        raise RuntimeError('compiled Wayland observer differs from the passed preflight')
print(binary)
PY
)
status=0
for run in 82 83 84; do
    printf 'Native Wayland 4K scored trial %d\n' "$run"
    if ! python3 -B "$lab/preflight.py" "$test_binary" --run-id "$run" --warmup 30 --seconds 60; then
        status=1
    fi
done
exit "$status"
