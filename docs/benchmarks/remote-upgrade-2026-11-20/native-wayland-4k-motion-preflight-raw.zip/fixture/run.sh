#!/usr/bin/env bash
set -euo pipefail
cd /home/yj/projects/jwm
lab=$(cd "$(dirname "$0")" && pwd)
exec 9>/tmp/jwm-p08-p09-release/benchmark.lock
printf '%s\n' 'Waiting for exclusive 4K Wayland marker lab time'
flock 9
printf '%s\n' 'Building the owned Wayland marker test'
export CARGO_TARGET_DIR=/tmp/jwm-remote-plan-check
export RUSTUP_TOOLCHAIN=stable CARGO_NET_OFFLINE=true CARGO_BUILD_JOBS=4
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_INCREMENTAL=0
export PKG_CONFIG_PATH=/tmp/jwm-remote-ffmpeg/usr/lib/x86_64-linux-gnu/pkgconfig
export LD_LIBRARY_PATH=/tmp/jwm-remote-ffmpeg/usr/lib/x86_64-linux-gnu
unset PKG_CONFIG_SYSROOT_DIR
sha256sum src/remote/host_wayland_gpu_4k{,_marker}_integration.rs \
    scripts/test-remote-wayland-4k-marker.sh > "$lab/marker-source-sha256.txt"
cargo test --locked --no-default-features --features remote-wayland,backend-wayland-udev,remote-h264 \
    --lib --no-run --message-format=json > "$lab/build.jsonl"
test_binary=$(python3 - "$lab/build.jsonl" <<'PY'
import json
from pathlib import Path
import sys

rows = [json.loads(line) for line in Path(sys.argv[1]).read_text().splitlines()]
binary, = [row['executable'] for row in rows if row.get('reason') == 'compiler-artifact'
           and row['target']['name'] == 'jwm' and row['profile']['test'] and row.get('executable')]
print(binary)
PY
)
sha256sum --check "$lab/marker-source-sha256.txt"
python3 -B "$lab/preflight.py" "$test_binary" --run-id 81 --seconds 8
