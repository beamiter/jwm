#!/usr/bin/env python3
"""Replay the archived Firefox HEVC raster, telemetry, and shutdown evidence."""

import hashlib
import json
import math
from pathlib import Path
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent / 'fixture'))
from hevc_evidence import CODEC, SIZE, assess, matching_frame_scope, static_stillness
from score import MEASURE_SECONDS, REQUESTED_FPS, SECOND, TAIL_SECONDS, WARM_SECONDS, score_pixels


ROOT = Path(__file__).resolve().parent
ROLES = {'host': 'source', 'viewer': 'viewer'}
PHASES = ('static', 'motion')
HOST_PATH = 'root/xrender/shm/no-damage/cursor-events'
SESSION_END = 'jwm-remote: session ended'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load(path):
    return json.loads(path.read_bytes())


def raw_rows(path):
    return [json.loads(line) for line in path.read_bytes().splitlines()]


def data_sha(data):
    return hashlib.sha256(data).hexdigest()


def score_phase(directory, role, phase, scope):
    stamps = [scope[f'{name}_monotonic_ns'] for name in (
        'phase_start', 'score_start', 'score_end', 'telemetry_phase_end', 'observer_end')]
    begin, start, end, tail, observer_end = stamps
    require(scope['phase'] == phase and (start - begin, end - start, tail - end) == tuple(
        n * SECOND for n in (WARM_SECONDS, MEASURE_SECONDS, TAIL_SECONDS)), 'phase intervals changed')
    readings = raw_rows(directory / f'{phase}-pixels.jsonl')
    require(readings and begin <= readings[0]['start_monotonic_ns'] < start
            and end < readings[-1]['end_monotonic_ns'] <= observer_end and observer_end >= tail,
            'raster sampling did not cover the full local phase')
    side = ROLES[role]
    require(all(row['side'] == side and row['start_monotonic_ns'] <= row['end_monotonic_ns']
                for row in readings) and all(a['end_monotonic_ns'] < b['end_monotonic_ns']
                for a, b in zip(readings, readings[1:])), 'raster records are out of scope')
    raster = score_pixels(readings, start, end)
    require(scope['samples'] == {side: raster}, f'{role} {phase} unchanged score did not replay')
    typed = raw_rows(directory / f'{role}-clocked-telemetry.jsonl')
    require(all(row['record']['type'] == f'jwm_remote_{role}_stats' for row in typed), 'invalid telemetry type')
    selected = [row for row in typed if start <= row['end_monotonic_ns']
                - round(row['record']['window_seconds'] * SECOND) < row['end_monotonic_ns'] <= tail]
    file_bytes = b''.join((json.dumps(row['record'], separators=(',', ':')) + '\n').encode()
                          for row in selected)
    require(file_bytes == (directory / f'{phase}-{role}.jsonl').read_bytes(),
            f'{role} {phase} retained window bytes differ')
    records = [row['record'] for row in selected]
    telem = scope['telemetry']
    frame_key = 'last_sent_frame' if role == 'host' else 'last_frame'
    frames = [record[frame_key] for record in records if record.get(frame_key)]
    sessions = sorted({record['session_id'] for record in records})
    seconds = sum(item['window_seconds'] for item in records)
    require(records and seconds >= MEASURE_SECONDS and len(sessions) == 1 and len(frames) > 0
            and all(matching_frame_scope(frame) for frame in frames), 'native-size HEVC scope missing')
    require(len(records) == telem['whole_windows'] and len(frames) == telem['frame_scopes_observed']
            and math.isclose(telem['window_seconds'], seconds, rel_tol=0, abs_tol=1e-10)
            and telem['session_ids'] == sessions and telem['frame_scopes_match_requested_codec']
            and [telem['first_window_end_monotonic_ns'], telem['last_window_end_monotonic_ns']]
            == [selected[0]['end_monotonic_ns'], selected[-1]['end_monotonic_ns']], 'retained scope mismatch')
    if role == 'host':
        require(telem['routes'] == [HOST_PATH] and all(record['mode'] == HOST_PATH for record in records),
                'unexpected host capture path')
    else:
        require(telem['routes'] == ['rgb'] and telem['viewer_backends'] == ['x11'] and all(
            record['viewer_backend'] == 'x11' and record['last_presentation_path'] == 'rgb'
            and record['negotiated_codec'] == CODEC for record in records), 'unexpected viewer presentation path')
    return {
        'phase_start_monotonic_ns': begin,
        'score_start_monotonic_ns': start,
        'score_end_monotonic_ns': end,
        'telemetry_phase_end_monotonic_ns': tail,
        'observer_end_monotonic_ns': observer_end,
        'telemetry': telem,
        'raster': {key: value for key, value in raster.items() if key != 'accepted_observations_monotonic_ns'},
    }


def ppm_digest(path):
    data = path.read_bytes()
    header = b'P6\n1920 1080\n255\n'
    require(data.startswith(header) and len(data) == len(header) + math.prod(SIZE) * 3,
            f'invalid full-size PPM {path.name}')
    return data_sha(data)


def replay(root):
    manifest = load(root / 'manifest.json')
    phases = (WARM_SECONDS, MEASURE_SECONDS, TAIL_SECONDS)
    require(manifest['diagnostic_batch'] and manifest['requested_trials'] == 1
            and manifest['requested_codec'] == CODEC and manifest['dimensions'] == list(SIZE)
            and (manifest['warm_seconds'], manifest['score_seconds'], manifest['telemetry_tail_seconds']) == phases
            and manifest['requested_fps'] == REQUESTED_FPS, 'runner did not retain the declared diagnostic conditions')
    fixture = root / 'fixture'
    for name in ('browser-trial.html', 'firefox-profile-user.js', 'fixture-manifest.json', 'score.py', 'hevc_evidence.py'):
        require(data_sha((fixture / name).read_bytes()) == manifest['pins']['fixtures'][name],
                f'fixture digest mismatch for {name}')
    fixture_contract = load(fixture / 'fixture-manifest.json')
    require(fixture_contract == manifest['workload'], 'workload manifest differs')
    original = (fixture / 'browser-original.html').read_bytes()
    trial_html = (fixture / 'browser-trial.html').read_bytes()
    before = fixture_contract['sole_trial_change']['before'].encode()
    after = fixture_contract['sole_trial_change']['after'].encode()
    require(data_sha(original) == fixture_contract['original_sha256'] and original.count(before) == 1
            and original.replace(before, after) == trial_html, 'original HTML changed outside its motion cutoff')
    require(manifest['pins']['fixtures']['score.py'] == '15f9e47b05e2fc90c12df8ee34ec0a20c643b4e4bd963856b0015c7f56d144d3',
            'scorer differs from the clean scored Firefox release')
    run = root / 'trial-01'
    result = load(run / 'result.json')
    require(load(root / 'outcomes.json') == [{'trial': 1, 'status': 'completed',
                                            'result': {k: v for k, v in result.items() if k != 'phases'}}],
            'terminal controller outcome differs from recorded trial')
    require(result['diagnostic_only'] and result['telemetry_complete'] and result['codec'] == CODEC
            and result['source_and_requested_viewer_dimensions'] == list(SIZE)
            and len(result['authenticated_session_ids']) == 1, 'missing completed HEVC session')
    endpoints = load(run / 'identity-digests.json')
    require(endpoints['distinct_owned_endpoints_verified'] and all(
        endpoints[role]['release_sha256'] == endpoints[role]['endpoint_executable_sha256'] == manifest['pins'][role]
        and endpoints[role]['drawable_size'] == list(SIZE) for role in ROLES)
        and endpoints['host']['firefox']['sha256'] == manifest['pins']['firefox'], 'runtime executable pin mismatch')
    evidence = {}
    for role in ROLES:
        directory = run if role == 'host' else run / 'viewer'
        evidence[role] = {}
        for phase in PHASES:
            scope = load(directory / f'{phase}-scope.json')
            require(scope == result['phases'][phase][role]
                    and scope['telemetry']['session_ids'] == result['authenticated_session_ids'],
                    f'{role} {phase} scope or session differs from the joined result')
            evidence[role][phase] = score_phase(directory, role, phase, scope)
        require(evidence[role]['static']['observer_end_monotonic_ns']
                <= evidence[role]['motion']['phase_start_monotonic_ns'], 'local phases overlap')
    hardware = assess(run, result['authenticated_session_ids'])
    require(hardware['verified'] and hardware == result['hardware_path'], 'hardware proof differs from recorded result')
    controls = raw_rows(run / 'peer-events-redacted.jsonl')
    commands = raw_rows(run / 'viewer' / 'control-in-redacted.jsonl')
    require([row['event'] for row in controls] == ['viewer_ready', 'viewer_static_started', 'viewer_static_done',
             'viewer_motion_armed', 'viewer_motion_done', 'viewer_disconnected']
            and [row['event'] for row in commands] == ['static', 'motion', 'disconnect']
            and len({row['run_id'] for row in controls + commands}) == 1, 'owned control closure sequence differs')
    shutdown = load(run / 'shutdown.json')
    require(shutdown == {'peer_exit': 0, 'host_exit': 0, 'viewer_disconnect_event': True}
            and (run / 'viewer' / 'disconnect.log').read_bytes() == b'', 'normal shutdown evidence missing')
    viewer_log = (run / 'viewer' / 'viewer.log').read_text().splitlines()
    final = [json.loads(line) for line in viewer_log if line.startswith('{')][-1]
    require(viewer_log[-1] == SESSION_END and final['final'] and final['acked'] > 0
            and [final['session_id']] == result['authenticated_session_ids'], 'missing final viewer session item')
    source = evidence['host']['motion']['raster']
    viewer = evidence['viewer']['motion']['raster']
    source_ok = source['unique_content_fps'] >= REQUESTED_FPS and source['scroll_changes_seen'] >= MEASURE_SECONDS
    motion_gate = viewer['unique_content_fps'] >= 0.9*REQUESTED_FPS and viewer['scroll_changes_seen'] >= MEASURE_SECONDS
    still = static_stillness(result['phases'])
    require(result['source_qualified'] == source_ok and result['static_unchanged'] == still
            and result['viewer_motion_gate_met'] == (motion_gate if source_ok else None)
            and result['diagnostic_motion_and_static_met'] == (source_ok and motion_gate and still)
            and (result['source_motion_fps'], result['viewer_motion_fps'])
            == (source['unique_content_fps'], viewer['unique_content_fps']), 'unchanged motion or static result differs')
    media = {name: ppm_digest(run / name) for name in ('source-static.ppm', 'source-static-end.ppm',
             'source-motion-end.ppm', 'viewer/viewer-static.ppm', 'viewer/viewer-motion-end.ppm')}
    return {
        'diagnostic_only': True,
        'manifest': manifest,
        'endpoints': endpoints,
        'hardware_path': hardware,
        'authenticated_session_id': result['authenticated_session_ids'][0],
        'phases': evidence,
        'source_qualified': source_ok,
        'viewer_motion_gate_met': result['viewer_motion_gate_met'],
        'static_unchanged': still,
        'diagnostic_motion_and_static_met': result['diagnostic_motion_and_static_met'],
        'normal_shutdown': shutdown,
        'raster_evidence': {'full_size_ppm_sha256': media,
                            'source_static_start_end_byte_equal': media['source-static.ppm'] == media['source-static-end.ppm']},
    }


if __name__ == '__main__':
    print(json.dumps(replay(ROOT), indent=2, sort_keys=True))
