# Firefox HEVC diagnostic replay

Extract this archive and run `python3 -B replay.py` from any directory. The
replay uses only stdlib Python and the unchanged Firefox raster scorer. It
reproduces all four endpoint/phase scores, selects typed windows byte-for-byte,
checks real NVENC/NVDEC activation and native 1080p frame scope, and confirms the
motion threshold, static failure and clean disconnect. Monotonic stamps are
compared only within the endpoint that recorded them.

The host and viewer logs keep all typed rows, the exact hardware activation
messages and viewer terminal message. The archive omits browser profiles,
private runtime paths, real endpoints or ports, key material and raw process
identities. PPMs are the five captured drawables and are not physical scanout.
