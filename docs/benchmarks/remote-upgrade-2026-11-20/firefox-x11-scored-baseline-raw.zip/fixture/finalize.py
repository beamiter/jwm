import hashlib
import json
from pathlib import Path
from statistics import median
import sys
from zipfile import ZIP_DEFLATED, ZipFile

from score import MEASURE_SECONDS, REQUESTED_FPS, SECOND, WARM_SECONDS, score_pixels


LAB = Path(__file__).resolve().parent
FIELDS = {'source': 'host', 'viewer': 'viewer'}


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read_json(path):
    return json.loads(path.read_text())


def read_rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def validate_trial(folder, trial):
    assert trial['source_size'] == trial['viewer_size'] == [960, 640]
    assert trial['codec'] == 'JPEG' and trial['jpeg_quality'] == 85
    assert trial['requested_fps'] == REQUESTED_FPS
    assert [phase['phase'] for phase in trial['phases']] == ['static', 'motion']
    sessions = set()
    sufficient_telemetry = True
    for phase in trial['phases']:
        name = phase['phase']
        start, end = (phase[f'score_{edge}_monotonic_ns'] for edge in ('start', 'end'))
        assert start - phase['phase_start_monotonic_ns'] == WARM_SECONDS * SECOND
        assert end - start == MEASURE_SECONDS * SECOND
        assert phase['observer_end_monotonic_ns'] >= end
        pixels = read_rows(folder / f'{name}-pixels.jsonl')
        for side, telemetry_role in FIELDS.items():
            rows = [row for row in pixels if row['side'] == side]
            assert score_pixels(rows, start, end) == phase['samples'][side]
            scope = phase['telemetry'][telemetry_role]
            trace = read_rows(folder / f'{name}-{telemetry_role}.jsonl')
            assert len(trace) == scope['whole_windows']
            assert abs(sum(row['window_seconds'] for row in trace) - scope['window_seconds']) < 1e-6
            assert sorted({row['session_id'] for row in trace}) == scope['session_ids']
            sessions.update(scope['session_ids'])
            sufficient_telemetry &= (scope['window_seconds'] >= MEASURE_SECONDS
                                     and scope['frame_scopes_match_960x640_jpeg']
                                     and len(scope['session_ids']) == 1)
            if name == 'motion':
                sufficient_telemetry &= scope['frame_scopes_observed'] > 0
    sufficient_telemetry &= len(sessions) == 1
    assert sufficient_telemetry == trial['telemetry_complete']
    idle = trial['phases'][0]['samples']
    assert trial['static_source_tile_changes'] == idle['source']['unique_tile_changes']
    assert trial['static_source_scroll_changes'] == idle['source']['scroll_changes_seen']
    motion = trial['phases'][1]['samples']
    source = motion['source']
    viewer = motion['viewer']
    source_qualified = (source['unique_content_fps'] >= REQUESTED_FPS
                        and source['scroll_changes_seen'] >= MEASURE_SECONDS)
    gate_met = (viewer['unique_content_fps'] >= REQUESTED_FPS * .9
                and viewer['scroll_changes_seen'] >= MEASURE_SECONDS) if source_qualified else None
    assert trial['source_qualified_for_viewer_motion_gate'] == source_qualified
    assert trial['viewer_motion_gate_met'] == gate_met


def summarize(trials):
    results = [row['result'] for row in trials if row['status'] == 'completed']
    rates = {role: [row['phases'][1]['samples'][role]['unique_content_fps'] for row in results]
             for role in FIELDS}
    return {
        'completed_results': len(results),
        'source_qualified_results': sum(row['source_qualified_for_viewer_motion_gate'] for row in results),
        'results_meeting_the_existing_viewer_gate': sum(row['viewer_motion_gate_met'] is True for row in results),
        'results_with_complete_telemetry': sum(row['telemetry_complete'] for row in results),
        'motion_rates': {role: {'trial_fps': values, 'median_fps': median(values) if values else None}
                         for role, values in rates.items()},
    }


def publish(batch, evidence):
    manifest = read_json(batch / 'manifest.json')
    assert manifest['trials'] == 3 and manifest['resolution'] == [960, 640]
    assert manifest['phase_warmup_s'] == WARM_SECONDS and manifest['phase_pixel_measure_s'] == MEASURE_SECONDS
    assert manifest['firefox_test_profile_extra_prefs'] == {'datareporting.policy.dataSubmissionEnabled': False}
    outcomes = read_json(batch / 'outcomes.json')
    assert [row['trial'] for row in outcomes] == [1, 2, 3]
    entries = {'trace/manifest.json': batch / 'manifest.json', 'trace/outcomes.json': batch / 'outcomes.json'}
    for name in ('README.md', 'run_baseline.py', 'score.py', 'processes.py', 'finalize.py',
                 'browser-original.html', 'browser-trial.html', 'fixture-manifest.json'):
        entries[f'fixture/{name}'] = LAB / name
    assert digest(LAB / 'browser-original.html') == manifest['workload']['original_sha256']
    assert digest(LAB / 'browser-trial.html') == manifest['workload']['trial_sha256']
    for outcome in outcomes:
        label = f'trial-{outcome["trial"]:02d}'
        folder = batch / label
        result_path = folder / 'result.json'
        if outcome['status'] == 'completed':
            trial = read_json(result_path)
            validate_trial(folder, trial)
            assert outcome['telemetry_complete'] == trial['telemetry_complete']
            assert outcome['source_qualified'] == trial['source_qualified_for_viewer_motion_gate']
            assert outcome['viewer_motion_gate_met'] == trial['viewer_motion_gate_met']
            outcome['result'] = trial
        for name in ('result.json', 'failure.log', 'source-static.json',
                     'static-layout-after-warmup.json', 'host.log', 'viewer.log',
                     'static-scope.json', 'static-pixels.jsonl', 'static-host.jsonl', 'static-viewer.jsonl',
                     'motion-scope.json', 'motion-pixels.jsonl', 'motion-host.jsonl', 'motion-viewer.jsonl'):
            if (folder / name).is_file():
                entries[f'trace/{label}/{name}'] = folder / name
    archive = evidence / 'firefox-x11-scored-baseline-raw.zip'
    staged = archive.with_suffix('.zip.tmp')
    digests = {name: digest(path) for name, path in entries.items()}
    with ZipFile(staged, 'w', compression=ZIP_DEFLATED, compresslevel=9) as writer:
        for name, path in entries.items():
            writer.write(path, name)
    with ZipFile(staged) as reader:
        assert reader.testzip() is None
        assert {name: hashlib.sha256(reader.read(name)).hexdigest() for name in reader.namelist()} == digests
    staged.replace(archive)
    report = {
        'schema_version': 1, 'manifest': manifest, 'trials': outcomes, 'summary': summarize(outcomes),
        'initial_failed_attempts': 'firefox-x11-initial-run-diagnosis.json',
        'archive': {'path': archive.name, 'sha256': digest(archive), 'entries': digests},
    }
    output = evidence / 'firefox-x11-scored-baseline.json'
    staged = output.with_suffix('.json.tmp')
    staged.write_text(json.dumps(report, indent=2) + '\n')
    staged.replace(output)
    print(json.dumps(report['summary'], indent=2))


if __name__ == '__main__':
    publish(Path(sys.argv[1]), Path(sys.argv[2]))
