# Firefox local software baseline

The controller starts two fresh owned 960×640 Xvfb displays, an isolated
Firefox profile with Software WebRender, and the pinned release's 1:1 X11
root-to-window session. It uses fixed JPEG quality 85 and a 30 FPS host ceiling.
It runs three independent sessions in sequence, and acquires the shared lab
lock itself. No connection to another machine or active desktop is used.

```sh
LD_LIBRARY_PATH=/tmp/jwm-remote-ffmpeg/usr/lib/x86_64-linux-gnu \
  python3 -B /tmp/jwm-firefox-browser-recovery.Tty09B/run_baseline.py --trials 3
```

Dependencies are the pinned `/tmp/jwm-p08-p09-release/jwm-remote`, local Firefox,
Xvfb, xwininfo, xdotool, dbus-run-session, and libX11. An ordinary three-trial
run lasts about ten minutes. Its raw files stay in a fresh owned `scored.*`
directory. Retained source and viewer 5 s telemetry can be fed to the repository
`scripts/remote-workload-report.py --workload browser` per phase and trial.

`browser-original.html` is the unmodified repository fixture and remains in the
scratch directory. The loaded `browser-trial.html` copy changes one JS expression,
`elapsed >= 30000` to `elapsed >= 105000`. Checksums and the exact change are in
`fixture-manifest.json`. The button, color, fonts, clipping, tile speed, scroll
speed, and text remain the same, including the original on-page 30-second label.
The static phase leaves the animation handler idle. The motion phase activates the
real page button with XTEST and starts after tile and glyph change is read from
Firefox's actual raster. The modal handler remains present and is outside the two
scored phases.

Each phase warms for 30 s and scores exactly `[30 s, 90 s)` using one local
monotonic clock. Reports include 60 one-second bins, including zero bins, valid
and invalid observations, nearest-rank gaps, and the longest gap with both
endpoints. The observer records a cyan tile edge from three narrow scanlines and
scroll glyph changes from a separate crop. Tile positions are digitized with a
two-pixel threshold and carried across the warm-up boundary; the glyph strip
independently verifies scrolling. The raw read window and 90 Hz sample ceiling
are recorded. FPS uses the 60 s denominator rather than dividing by activity
or counting API calls, JavaScript callbacks, or ACKs. The motion threshold is
27 viewer changes per second only if the source measures at least 30 changes per
second and demonstrates scrolling. Idle counts are reported separately.

Both phases remain active for another 8 s to retain at least 60 s of complete
host and viewer telemetry windows after warm-up. Those windows have separate
boundaries from the exact pixel score. Reported stage quantiles stay scoped to
recent observations per window. Authenticated session IDs, exact JPEG frame
scopes, and route diagnostics are retained. Times from this isolated software
run do not establish physical display timing or a two-machine GPU baseline.

The peer check found an executable path `/usr/bin/firefox` on Ubuntu. A separate
future two-machine run would verify its runtime/version, copy the same page
bytes and source-side raster observer to a private source Xvfb, keep the target
viewer observer local, and connect using the existing owned SSH tunnel. Align
phases by source activation and viewer-observed motion on each machine's own
clock; record distinct run IDs and durations without subtracting cross-machine
monotonic timestamps. The local runner is independent of that work.

## Offline Firefox startup recovery

The original three trials are retained at /tmp/jwm-firefox-browser-baseline.AQt8OcMI/scored.x92fzxo8. In each fresh profile Firefox first opened its privacy page in a background tab. With the offline proxy, the bundled data-reporting policy scheduled its 60-second first-run fallback infobar. The recorded notification precedes the first invalid local tile line by about 84–101 ms in the reconstructed wall-clock timeline. The fixture remained the selected tab. All three original motion activations then failed about 38 seconds later.

This isolated runner disables Firefox data submission only in the fresh test profile. Firefox's bundled policy also disables its reporting notice when this preference is false. The HTML, input coordinates, sampling, scoring windows and processes are carried over. The runner records the extra preference in the run manifest, archives the source raster at the static phase boundary, verifies the original placement before clicking, and archives the raster again if the post-click readiness check fails.
