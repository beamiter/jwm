#!/bin/sh
set -eu
finish() {
    kill "$wm" 2>/dev/null || true
    printf '\nJWM_GUEST_COMPOSITOR_TAIL\n'
    tail -n 90 /run/compositor.log
    printf '\nJWM_GUEST_DRM_EVENTS\n'
    grep -E 'KERNEL|UDEV|ACTION=remove|DEVNAME=dri|PCI_ID=' /run/drm-events.log || true
    cat /sys/kernel/tracing/trace | grep drm_vblank_event_delivered || true
}
mount -t tracefs tracefs /sys/kernel/tracing
echo mono > /sys/kernel/tracing/trace_clock
echo 1 > /sys/kernel/tracing/events/drm/drm_vblank_event_delivered/enable
/usr/lib/systemd/systemd-udevd --daemon --children-max=2 >/run/udevd.log 2>&1
udevadm control --ping
udevadm monitor --kernel --udev --subsystem-match=drm --property >/run/drm-events.log 2>&1 &
seatd -l error >/run/seatd.log 2>&1 &
export RUST_LOG=info,jwm::kms::presentation=debug PYTHONDONTWRITEBYTECODE=1
jwm --backend wayland-udev >/run/compositor.log 2>&1 &
wm=$!
trap finish EXIT
for counter in $(seq 1 80); do
    [ ! -S "$XDG_RUNTIME_DIR/wayland-1" ] || break
    kill -0 "$wm"
    sleep .1
done
log=$(find /tmp/jwm-logs-0 -name "jwm_*_p${wm}*.log" | head -1)
[ -f "$log" ]
exec_status=0
/usr/bin/python3.12 /payload/scripts/trigger-owned-guest.py /usr/bin/python3.12 /payload/scripts/test-remote-wayland-kms.py /usr/bin/jwm-remote     --wayland-display "$XDG_RUNTIME_DIR/wayland-1" --output Virtual-1 --kms-log "$log"     --require-path composited --check-viewport     --virtio-primary-rgb /usr/bin/test-virtio-drm-primary-rgb --virtio-drm-card /dev/dri/card0 --device-loss-card /sys/class/drm/card0 || exec_status=$?
if [ "$exec_status" -eq 0 ]; then
    kill -0 "$wm"
    [ "$(awk '{print $3}' "/proc/$wm/stat")" != Z ]
    echo JWM_GUEST_COMPOSITOR_AFTER_REMOVE=alive
fi
exit "$exec_status"
