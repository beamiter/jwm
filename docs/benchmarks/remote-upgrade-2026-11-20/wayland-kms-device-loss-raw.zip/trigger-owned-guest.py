import os
from pathlib import Path
import subprocess
import sys

marker = 'kms_test_virtio_device_removal=1'
if os.getuid() != 0 or marker not in Path('/proc/cmdline').read_text().split():
    raise RuntimeError('requires the dedicated guest boot')
drm = Path('/sys/class/drm/card0')
real_card = drm.resolve(strict=True)
[pci] = [node for node in real_card.parents if (node / 'vendor').is_file()
         and (node / 'vendor').read_text().strip() == '0x1af4'
         and (node / 'device').read_text().strip() == '0x1050']
if not (Path('/sys/bus/pci/devices') / pci.name).samefile(pci):
    raise RuntimeError('card is not the owned PCI function')
if (pci / 'driver').resolve().name != 'virtio-pci':
    raise RuntimeError('card is not attached to virtio-pci')
with subprocess.Popen(sys.argv[1:], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True) as observer:
    triggered = False
    for line in observer.stdout:
        print(line, end='', flush=True)
        if not triggered and line.rstrip() == 'JWM_KMS_DEVICE_LOSS_READY card0':
            (pci / 'remove').write_text('1')
            if any(path.exists() for path in (pci, drm, Path('/dev/dri/renderD128'),
                                              Path('/sys/class/drm/card0-Virtual-1'),
                                              Path('/sys/class/drm/card0-Virtual-2'))):
                raise RuntimeError('guest did not remove the PCI function, render node and both connectors')
            print(f'JWM_VIRTIO_DEVICE_REMOVED={pci.name}', flush=True)
            triggered = True
    status = observer.wait()
    if not triggered:
        raise RuntimeError('observer did not reach the removal marker')
    raise SystemExit(status)
