#!/usr/bin/env bash
set -euo pipefail
work=$1
qroot="$work/qemu"
export LD_LIBRARY_PATH="$qroot/usr/lib/x86_64-linux-gnu" QEMU_MODULE_DIR="$qroot/usr/lib/x86_64-linux-gnu/qemu"
timeout --signal=TERM --kill-after=5s 80s "$qroot/usr/bin/qemu-system-x86_64" \
  -machine q35,accel=kvm -cpu host -smp 4 -m 1536 -nodefaults \
  -kernel "$qroot/boot/vmlinuz-$(uname -r)" -initrd "$work/initramfs-scanout.cpio.gz" \
  -append "rdinit=/init console=ttyS0 quiet panic=-1 video=Virtual-2:1024x768e firmware_class.path=/edid-fixtures drm.edid_firmware=Virtual-2:virtio-1024x768.bin ${JWM_GUEST_FLAGS:-}" \
  -bios "$qroot/usr/share/seabios/bios-256k.bin" -L "$qroot/usr/share/qemu" \
  -display egl-headless,rendernode=/dev/dri/renderD128 -device virtio-vga-gl,id=jwmgpu,max_outputs=2,xres=1024,yres=768 \
  -virtfs "local,path=$work/payload,mount_tag=jwm-artifacts,security_model=none,readonly=on" \
  -qmp "unix:$work/qmp.sock,server=on,wait=off" \
  -vnc "unix:$work/vnc.sock" \
  -serial stdio -monitor none -nic none -no-reboot
