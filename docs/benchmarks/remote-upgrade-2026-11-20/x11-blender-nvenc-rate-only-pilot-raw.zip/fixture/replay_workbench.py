"""Reconstruct benchmark scores from raster ledgers, typed transport windows and PNG pairs."""

import argparse
import json
import re
from pathlib import Path
from statistics import median

from PIL import Image

from capture_quality import compare_images
from run_workbench import FULL, MODE_ORDER, REQUESTED_FPS, SECOND, score_pixels, score_telemetry, sha

PHASES = ('static', 'ordinary-motion', 'pressured-motion')


def expect(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_text())


def canonical(value):
    return json.loads(json.dumps(value, allow_nan=False))


def pixels(path):
    return (json.loads(line) for line in path.read_text().splitlines())


def anchor_metric(directory, tag):
    with Image.open(directory/f'{tag}-source.png') as source, Image.open(directory/f'{tag}-viewer.png') as viewer:
        return compare_images(source, viewer)


def median_if_any(items):
    values = [item for item in items if item is not None]
    return median(values) if values else None


def phase_values(root, phase):
    name = phase['phase']
    start = phase['score_start_monotonic_ns']
    end = phase['score_end_monotonic_ns']
    expect((end - start) == phase['scored_seconds'] * SECOND
           and (start - phase['phase_start_monotonic_ns']) == phase['warmup_seconds'] * SECOND,
           f'{root}: adaptive window does not match the run manifest')
    lanes = {side: [] for side in ('source', 'viewer')}
    for row in pixels(root/f'{name}-pixels.jsonl'):
        expect(row['end_monotonic_ns'] >= row['start_monotonic_ns'], 'X11 observation clock reversed')
        lanes[row['side']].append(row)
    visible = {role: score_pixels(samples, start, end) for role, samples in lanes.items()}
    expect(visible == phase['samples'], f'{root}: drawable gap or frame count mismatch')
    telemetry = {role: score_telemetry(root, phase, role) for role in ('host', 'viewer')}
    expect(canonical(telemetry) == phase['telemetry'], f'{root}: recorded transport windows differ')
    quality = [anchor_metric(root, item['label']) for item in phase['quality']]
    expect(quality == [item['metrics'] for item in phase['quality']], f'{root}: actual drawable anchor quality differs')
    with Image.open(root/f"{phase['quality'][0]['label']}-source.png") as first:
        for item, drift in zip(phase['quality'], phase['source_ui_stability'], strict=True):
            with Image.open(root/f"{item['label']}-source.png") as sample:
                expect(compare_images(first, sample)['rgb_mae'] == drift, 'source UI stability check changed')
    return {
        'source_distinct_fps': visible['source']['unique_content_fps'],
        'viewer_distinct_fps': visible['viewer']['unique_content_fps'],
        'viewer_distinct_gap_p95_ms': visible['viewer']['gap_ms']['p95'],
        'viewer_longest_gap_ms': visible['viewer']['gap_ms']['max'],
        'viewer_reads': visible['viewer']['reads'],
        'viewer_invalid_cube_reads': visible['viewer']['invalid_mesh_reads'],
        'viewer_zero_unique_second_bins': visible['viewer']['zero_unique_bins'],
        'encoded_rasters': {key: lane['encoded_rasters'] for key, lane in telemetry.items()},
        'scoped_telemetry_seconds': {key: lane['window_seconds'] for key, lane in telemetry.items()},
        'scoped_h264_only': all(lane['codecs'] == ['H.264'] and lane['source_rasters'] == [tuple(FULL)]
                               for lane in telemetry.values()),
        'transport_identity': sorted(set(session for lane in telemetry.values() for session in lane['sessions'])),
        'video_payload_mbit_per_second': telemetry['host'].get('video_payload_mbit_per_second'),
        'capture_to_drawn_ack_median_window_p95_ms': telemetry['host']['stage_tails'].get(
            'capture_start_to_ack_ms', {}).get('median_window_p95_ms'),
        'viewer_decode_median_window_p95_ms': telemetry['viewer']['stage_tails'].get(
            'decode_ms', {}).get('median_window_p95_ms'),
        'peak_outstanding': telemetry['host'].get('peak_outstanding'),
        'ui_rgb_mae': median(row['rgb_mae'] for row in quality),
        'ui_rgb_psnr_db': median_if_any([row['rgb_psnr_db'] for row in quality]),
        'ui_edge_contrast_preserved': median_if_any([row['relative_edge_contrast'] for row in quality]),
        'ui_source_mae_drift': max(phase['source_ui_stability']),
        'resource_samples': [item['resources'] for item in phase['quality']],
    }


def recovery_values(root, expected, static_phase):
    ledger = read(root/'recovery.json')
    expect(ledger == expected, f'{root}: recorded recovery boundary differs')
    limit = max(1., median(row['metrics']['rgb_mae'] for row in static_phase['quality']) + 1.)
    expect(expected['baseline_derived_ui_mae_threshold'] == limit, 'image comparison threshold changed')
    good = []
    for row in pixels(root/'recovery-pixels.jsonl'):
        span = row['viewer_cube']
        target = row['source_target_cube']
        scope = (row['last_viewer_report'] or {}).get('scope')
        matches = span and all(abs(span[name] - target[name]) <= 3 for name in ('left', 'right', 'center_x'))
        qualifies = bool(matches and scope and scope['encoded_dimensions'] == FULL and row['ui_quality']['rgb_mae'] <= limit)
        expect(row['eligible'] == qualifies, 'qualification changed for a measured recovery sample')
        if qualifies:
            good.append(row)
            if len(good) == 3:
                break
        else:
            good.clear()
    if len(good) == 3:
        expect(expected['first_sustained_observation'] == good[0]
               and expected['confirmed_observation'] == good[-1], 'recovery observation not in ledger')
        quality = anchor_metric(root, 'recovery-ui-confirmed')
        expect(quality == good[-1]['ui_quality'], 'recovered UI pixels differ from the recorded observation')
        return {
            'first_sustained_sample_upper_bound_ms': good[0]['offset_ms'],
            'confirmation_upper_bound_ms': good[-1]['offset_ms'],
            'first_sustained_viewer_raster_report': good[0]['last_viewer_report'],
            'viewport_recovery_metric': anchor_metric(root, 'recovery-viewport-confirmed'),
        }
    expect(expected['first_sustained_observation'] is None
           and expected['confirmed_observation'] is None, 'claimed recovery never occurred')
    return {'first_sustained_sample_upper_bound_ms': None, 'confirmation_upper_bound_ms': None,
            'timed_out': True}


def run_report(staging):
    manifest = read(staging/'manifest.json')
    expect(manifest.get('adapts_encoded_resolution') is False, 'rate-only comparison changed its policy')
    outcomes = read(staging/'outcomes.json')
    listed = tuple(manifest['mode_order'])
    expect(manifest['pilot'] or listed == MODE_ORDER, 'scored order did not follow repeated ABBA')
    expect(len(outcomes) == len(listed), 'trial ledger does not have a terminal state for every slot')
    expect([slot['mode'] for slot in outcomes] == list(listed), 'trial ledger does not match the order')
    for name, digest in manifest['fixture_sha256'].items():
        expect(sha(staging/'fixture'/name) == digest, 'fixture digest mismatch')
    trials = []
    for attempt in outcomes:
        index, mode = attempt['slot'], attempt['mode']
        directory = staging/f'trial-{index:02}-{mode}'
        if attempt['status'] != 'completed':
            expect((directory/'failure.log').is_file(), 'failed trial missing its trace')
            trials.append(attempt)
            continue
        observed = read(directory/'result.json')
        expect(observed['mode'] == mode and observed['host_exit'] == observed['viewer_exit'] == 0
               and observed['codec'] == 'H.264 NVENC YUV420', 'trial metadata differs')
        expect(tuple(phase['phase'] for phase in observed['phases']) == PHASES, 'phase ledger mismatch')
        for phase in observed['phases']:
            expect([phase['warmup_seconds'], phase['scored_seconds']] ==
                   manifest['warmup_and_score_seconds'][phase['phase']], 'observation duration differs')
        phases = {phase['phase']: phase_values(directory, phase) for phase in observed['phases']}
        host_text = (directory/'host.log').read_text()
        steps = re.findall(r'hardware rate target (\d+) fps, (\d+)% nominal bitrate \((\w+)\)', host_text)
        expect([list(step) for step in steps] == observed['host_rate_events'], 'host rate changes differ')
        expect((mode == 'adaptive') == any(int(fps) < REQUESTED_FPS and cause == 'Viewer'
                                         for fps, _, cause in steps),
               'adaptive rate did not respond to viewer pressure')
        expect(mode != 'fixed' or not steps, 'fixed arm unexpectedly changed its rate')
        expect(not observed['host_tier_events'] and
               not re.search(r'hardware resolution target (75|50)%', host_text),
               'rate-only policy changed the encoded raster')
        for name, phase in phases.items():
            expect(all(rasters == [tuple(FULL)] for rasters in phase['encoded_rasters'].values()),
                   f'encoded raster changed during {name}')
        actual = recovery_values(directory, observed['stop_to_clarity'], observed['phases'][0])
        completed_windows = all(phase['scoped_h264_only'] and all(seconds >= 49 for seconds in phase['scoped_telemetry_seconds'].values())
                                and len(phase['transport_identity']) == 1 for phase in phases.values())
        ordinary = phases['ordinary-motion']
        motion_gate = ordinary['source_distinct_fps'] >= REQUESTED_FPS and ordinary['viewer_distinct_fps'] >= .9*REQUESTED_FPS
        trials.append({'mode': mode, 'slot': index, 'status': 'completed', 'phases': phases,
                       'full_phase_windows_sufficient': completed_windows, 'ordinary_motion_gate_met': motion_gate,
                       'recovery': actual, 'tier_transitions': observed['host_tier_events'],
                       'rate_transitions': observed['host_rate_events']})
    completed = [trial for trial in trials if trial['status'] == 'completed']
    metrics = ('source_distinct_fps', 'viewer_distinct_fps', 'viewer_distinct_gap_p95_ms', 'viewer_longest_gap_ms',
               'capture_to_drawn_ack_median_window_p95_ms', 'video_payload_mbit_per_second',
               'ui_rgb_mae', 'ui_rgb_psnr_db', 'ui_edge_contrast_preserved')
    overview = {}
    for mode in ('fixed', 'adaptive'):
        group = [trial for trial in completed if trial['mode'] == mode]
        overview[mode] = {'completed': len(group), 'ordinary_motion_gate_met': sum(trial['ordinary_motion_gate_met'] for trial in group),
                          'full_phase_windows_sufficient': sum(trial['full_phase_windows_sufficient'] for trial in group)}
        overview[mode]['medians_by_phase'] = {
            phase: {field: median_if_any([trial['phases'][phase][field] for trial in group]) for field in metrics}
            for phase in PHASES
        }
        overview[mode]['recovery_upper_bound_median_ms'] = median_if_any(
             [trial['recovery']['first_sustained_sample_upper_bound_ms'] for trial in group])
    pairs = []
    if len(trials) >= 2:
        for pair in range(0,len(trials),2):
            group = trials[pair:pair+2]
            expected_modes = {trial['mode'] for trial in group}
            expect(expected_modes == {'fixed','adaptive'}, 'ABBA pair missing a mode')
            if any(item['status'] != 'completed' for item in group):
                pairs.append({'slots': [item['slot'] for item in group], 'complete': False})
                continue
            fixed = next(item for item in group if item['mode'] == 'fixed')
            adaptive = next(item for item in group if item['mode'] == 'adaptive')
            paired = {'slots': [item['slot'] for item in group], 'complete': True, 'adaptive_minus_fixed': {},
                      'source_ui_mae_between_arms': {}}
            for phase in PHASES:
                fixed_path = staging/f"trial-{fixed['slot']:02}-fixed"/f'{phase}-ui-2-source.png'
                adaptive_path = staging/f"trial-{adaptive['slot']:02}-adaptive"/f'{phase}-ui-2-source.png'
                with Image.open(fixed_path) as a, Image.open(adaptive_path) as b:
                    paired['source_ui_mae_between_arms'][phase] = compare_images(a, b)['rgb_mae']
                fields = {}
                for key in metrics:
                    f, a = (item['phases'][phase][key] for item in (fixed,adaptive))
                    fields[key] = a-f if f is not None and a is not None else None
                paired['adaptive_minus_fixed'][phase] = fields
            pairs.append(paired)
    return {'manifest': manifest, 'outcomes': trials, 'overview': overview, 'paired_trial_deltas': pairs}


if __name__ == '__main__':
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('run_root', type=Path)
    args = cli.parse_args()
    print(json.dumps(run_report(args.run_root.resolve()), indent=2, allow_nan=False))
