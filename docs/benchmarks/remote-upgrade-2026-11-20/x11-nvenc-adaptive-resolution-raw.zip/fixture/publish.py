#!/usr/bin/env python3
"""Publish and independently reconstruct the adaptive resolution diagnostic."""
import hashlib
import json
from pathlib import Path
import re
import statistics
import subprocess
import sys
from zipfile import ZIP_DEFLATED, ZipFile

STEM = 'x11-nvenc-adaptive-resolution'
CASES = ('ladder', 'scope-changes', 'tiers-disabled', 'fallback')
TIER = re.compile(r'hardware resolution target (\d+)% \((\w+)\)')
RATE = re.compile(r'hardware rate target (\d+) fps, (\d+)% nominal bitrate \((\w+)\)')
VIEWER = re.compile(r'viewer rate feedback \((\d+) drawn frames, mean decode ([\d.]+) ms, queue ([\d.]+) ms, presentation ([\d.]+) ms\)')
FEEDBACK = 'viewer rate feedback negotiated (application v36)'
PLAN = {
    'ladder': {'sizes': [(1280, 800), (960, 600), (640, 400), (960, 600), (1280, 800)],
               'changes': [('75', 'Viewer'), ('50', 'Viewer'), ('75', ('ViewerRecovery','Clear')), ('100', ('ViewerRecovery','Clear'))],
               'rates': [('24', '100', 'Viewer'), ('28', '100', 'Clear'), ('30', '100', 'Clear')],
               'sources': [1, 1, 1, 1, 1], 'pointers': 1},
    'scope-changes': {'sizes': [(1280, 800), (960, 600), (1120, 700), (840, 525), (896, 560)],
                      'changes': [('75', 'Viewer'), ('75', 'Viewer')], 'rates': [('24', '100', 'Viewer')],
                      'sources': [1, 1, 1, 1, 2], 'pointers': 1},
    'fallback': {'sizes': [(1280, 800), (960, 600), (1280, 800)],
                 'changes': [('75', 'Viewer')], 'rates': [('24', '100', 'Viewer')],
                 'sources': [1, 1, 1], 'pointers': 1},
    'tiers-disabled': {'sizes': [(1280, 800), (1280, 800)], 'changes': [],
                       'rates': [('24', '100', 'Viewer')], 'sources': [1, 1], 'pointers': 0},
}
PAINTER_SOURCE = Path('/tmp/jwm-native-x11-resource-soak.6Wufhz33/run/fixture/p09-workload.c')
PAINTER_BINARY = PAINTER_SOURCE.parent.parent/'observer'


def require(ok, detail):
    if not ok:
        raise ValueError(detail)


def encode(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def sha(value):
    return hashlib.sha256(value).hexdigest()


def run(*args):
    return subprocess.check_output(args, text=True, timeout=8).strip()


def telemetry(log, tag):
    accepted = (json.loads(line) for line in log.splitlines() if line.startswith('{'))
    return [row for row in accepted if row.get('type') == tag]


def capture(stage, trial):
    result = json.loads((trial/'result.json').read_bytes())
    require((stage/'smoke.exit').read_text().strip() == '0', 'smoke did not complete')
    require(sha((stage/'jwm-remote').read_bytes()) == result['binary_sha256'], 'production artifact changed')
    src = {name: pin for line in (stage/'source.sha256').read_text().splitlines()
           for pin, name in [line.split(maxsplit=1)]}
    require(all(sha(Path(name).read_bytes()) == pin for name, pin in src.items()), 'pinned input source changed')
    fixture = {Path(name).name: pin for line in (stage/'fixture.sha256').read_text().splitlines()
               for pin, name in [line.split(maxsplit=1)]}
    require(all(sha(path.read_bytes()) == fixture[path.name] for path in
                (*[stage/item for item in ('smoke.py','slow-rgb.c','slow-rgb.so','fail-encode.c','fail-encode.so')], PAINTER_BINARY)),
            'live stimulus or instrumentation changed')
    tests = {}
    for name, logfile in (('remote_library', 'core-test.log'), ('command_line', 'cli-test.log')):
        matches = re.findall(r'test result: ok\. (\d+) passed; 0 failed; (\d+) ignored', (stage/logfile).read_text())
        require(matches, 'build regression counts missing')
        tests[name] = dict(zip(('passed','ignored'), map(int, matches[-1])))
    result['manifest'] = {
        'head': run('git', 'rev-parse', 'HEAD'),
        'source_sha256': src,
        'fixture_sha256': fixture,
        'cpu': next(line.split(':', 1)[1].strip() for line in run('lscpu').splitlines() if line.startswith('Model name:')),
        'nvidia_device_and_driver': run('nvidia-smi','--query-gpu=name,driver_version','--format=csv,noheader'),
        'kernel': run('uname', '-r'), 'xvfb_package': run('dpkg-query', '-W', 'xvfb'),
        'profile': 'release --no-default-features --features remote-x11,remote-wayland,remote-h264',
        'regressions': tests,
        'network': 'authenticated IPv4 loopback TCP on one machine',
        'displays': 'owned 1280×800 Xvfb source and viewer, CPU RGB viewer scaling',
        'pressure': 'viewer-only sws_scale interposer adds 45 ms while gate file exists',
        'scope': 'functional H.264 NVENC tiers, source/geometry retirement, drawable pixels and XTEST coordinates',
    }
    diagnostic = Path((stage/'initial-diagnostic-dir.txt').read_text().strip())
    require((diagnostic/'smoke.exit').read_text().strip() == '1', 'initial recovery stall is absent')
    result['initial_cpu_upscale_diagnostic'] = {
        'binary_sha256': sha((diagnostic/'jwm-remote').read_bytes()),
        'controller_exit': 1, 'reason': 'viewer presentation stayed above the recovery threshold after decode recovered',
    }
    items = {'run.json': encode(result)}
    items['initial-diagnostic/host.log'] = (diagnostic/'run-v1/ladder/host.log').read_bytes()
    items['initial-diagnostic/viewer.log'] = (diagnostic/'run-v1/ladder/viewer.log').read_bytes()
    items['initial-diagnostic/controller.log'] = (diagnostic/'smoke.log').read_bytes()
    items['initial-diagnostic/source.sha256'] = (diagnostic/'source.sha256').read_bytes()
    for arm in CASES:
        for name in ('host.log','viewer.log','viewer.stdout','painter.stdout','painter.log'):
            items[f'observations/{arm}/{name}'] = (trial/arm/name).read_bytes()
    items['observations/scope-changes/post-switch-pixels.json'] = (trial/'scope-changes/post-switch-pixels.json').read_bytes()
    for name in ('smoke.py', 'slow-rgb.c', 'fail-encode.c', 'check-build.sh', 'publish.py'):
        items['fixture/'+name] = (stage/name).read_bytes()
    items['fixture/p09-workload.c'] = PAINTER_SOURCE.read_bytes()
    return items


def verify_chip(chip):
    raw = bytes.fromhex(chip['raw_bgrx'])
    require(len(raw) == 324, 'RGB sample changed size')
    rgb = [int(statistics.median(raw[axis::4])) for axis in (2, 1, 0)]
    require(rgb == chip['rgb'] and max(abs(a-b) for a,b in zip(rgb,chip['expected'])) <= 33,
            'drawable sample is not the expected source color')


def reconstruct(items):
    result = json.loads(items['run.json'])
    require([case['arm'] for case in result['cases']] == list(CASES), 'arms are missing')
    earlier = items['initial-diagnostic/host.log'].decode()
    require(TIER.findall(earlier) == [('75','Viewer'), ('50','Viewer')]
            and 'timed out waiting for resolution 75% Clear' in items['initial-diagnostic/controller.log'].decode(),
            'initial CPU scaling stall is missing')
    recovered_decoder = [list(map(float,row)) for row in VIEWER.findall(earlier) if float(row[1]) < 10]
    require(len(recovered_decoder) >= 4 and all(row[3] > 18.75 for row in recovered_decoder),
            'initial decoder recovered without persistent presentation pressure')
    result['initial_cpu_upscale_diagnostic']['recovered_decode_windows'] = recovered_decoder
    for case in result['cases']:
        arm = case['arm']
        expected = PLAN[arm]
        root = f'observations/{arm}/'
        host, viewer = [items[root+side+'.log'].decode() for side in ('host', 'viewer')]
        h_rows, v_rows = [telemetry(log, f'jwm_remote_{side}_stats') for log, side in ((host, 'host'), (viewer, 'viewer'))]
        require(h_rows and v_rows and len({row['session_id'] for row in h_rows+v_rows}) == 1, 'session identity differs')
        require(all(row['hevc444_frames'] == 0 and row['max_outstanding'] <= 2 for row in h_rows)
                and all(row['negotiated_codec'] == 'H.264' for row in v_rows)
                and (sum(row['jpeg_atlases'] for row in h_rows) > 0) == (arm == 'fallback'),
                'codec or credit coverage differs')
        require(FEEDBACK in host and FEEDBACK in viewer
                and 'hardware H.264 encoding active (NVENC)' in host, 'NVENC v36 markers are absent')
        h_ack = sum(row['drawn_acks'] for row in h_rows)
        v_ack = sum(row['acked'] for row in v_rows)
        require(h_ack == case['host_drawn_acks'] > 0 and v_ack == case['viewer_sent_drawn_acks']
                and 0 <= v_ack - h_ack <= (2 if arm == 'scope-changes' else 0),
                'drawn ACK counts outside credit bounds')
        require(RATE.findall(host) == expected['rates'] == [tuple(change) for change in case['rate_changes']],
                'fixed/FPS decisions did not match')
        changes = TIER.findall(host)
        require(changes == [tuple(change) for change in case['size_changes']]
                and len(changes) == len(expected['changes'])
                and all(size == expected_size and cause in (causes if isinstance(causes, tuple) else (causes,))
                        for (size,cause),(expected_size,causes) in zip(changes,expected['changes'])),
                'geometry decisions did not match')
        if arm == 'ladder':
            require(any(cause == 'ViewerRecovery' for _,cause in changes), 'CPU presentation recovery was not exercised')
        if arm == 'fallback':
            require(host.count('fixture: failed one NVENC submission at 960x600') == 1
                    and 'hardware encoding failed, switching to JPEG' in host
                    and 'host switched to JPEG video' in viewer
                    and case['marks'][-1]['viewer']['codec'] == case['marks'][-1]['host']['codec'] == 'JPEG',
                    'injected NVENC failure did not reach same-source JPEG')
        require(case['viewer_feedback'] == [list(map(float, feedback)) for feedback in VIEWER.findall(host)]
                and any(feedback[1] >= 45 for feedback in case['viewer_feedback']), 'viewer pressure was absent')
        for key, rows in (('last_sent_frame',h_rows), ('last_frame',v_rows)):
            geometry = [(row[key]['source_epoch'],row[key]['geometry_epoch']) for row in rows if row[key]]
            require(geometry == sorted(geometry), 'retired geometry or source reappeared in sampled endpoint windows')
        marks = case['marks']
        require([tuple(mark['viewer']['encoded_dimensions']) for mark in marks] == expected['sizes']
                and [mark['viewer']['source_epoch'] for mark in marks] == expected['sources'], 'captured scopes differ')
        epochs = [mark['viewer']['geometry_epoch'] for mark in marks]
        if arm != 'tiers-disabled':
            require(epochs == sorted(set(epochs)), 'geometry epoch was reused')
        for mark in marks:
            require(any(row['last_frame'] == mark['viewer'] and row['acked'] == mark['viewer_acked_window'] > 0 for row in v_rows)
                    and any(row['last_sent_frame'] == mark['host'] and row['drawn_acks'] == mark['host_drawn_acks_window'] > 0 for row in h_rows),
                    'marked geometry is missing from the original endpoint windows')
            require(all(mark['host'][field] == mark['viewer'][field] for field in
                    ('source_epoch', 'geometry_epoch', 'source_dimensions', 'encoded_dimensions')), 'endpoint scopes differ')
            for chip in mark['pixels']:
                verify_chip(chip)
        require(len(case['pointer_observations']) == expected['pointers'], 'expected XTEST proof is missing')
        for motion in case['pointer_observations']:
            require(max(abs(a-b) for a,b in zip(motion['expected_root_xy'], motion['x11_root_xy'])) <= 3,
                    'host pointer moved outside mapped pixel tolerance')
        events = [json.loads(line) for line in items[root+'viewer.stdout'].decode().splitlines() if line.startswith('{')]
        snaps = [event for event in events if event.get('event') == 'snapshot']
        require(snaps[-1]['state'] == 'closed' and case['host_exit'] == case['viewer_exit'] == 0, 'unclean shutdown')
        if arm == 'scope-changes':
            require(any((event.get('catalog') or {}).get('source_id') == 2 for event in snaps), 'new grant not observed')
            after = json.loads(items[root+'post-switch-pixels.json'])
            require(len(after) > 20, 'post-switch drawable read count is incomplete')
            for sample in after:
                require(len(sample) == 1 and sample[0]['source_xy'] == [444, 276], 'sample was outside expected source point')
                verify_chip(sample[0])
            case['post_switch_drawable_samples'] = len(after)
        for mark in marks:
            for chip in mark['pixels']:
                del chip['raw_bgrx']
    return result


def main():
    action, *args = sys.argv[1:]
    if action == 'publish':
        stage, trial, output = map(Path,args)
        items = capture(stage, trial)
        result = reconstruct(items)
        output.mkdir(mode=0o700)
        archive = output/(STEM+'-raw.zip')
        with ZipFile(archive, 'x', compression=ZIP_DEFLATED) as bundle:
            for name, data in sorted(items.items()):
                bundle.writestr(name, data)
        result['archive'] = {'sha256': sha(archive.read_bytes()), 'members': {name: sha(data) for name,data in items.items()}}
        (output/(STEM+'.json')).write_bytes(encode(result))
    else:
        require(action == 'replay', 'unknown action')
        report, archive = map(Path,args)
        expected = json.loads(report.read_bytes())
        manifest = expected.pop('archive')
        require(sha(archive.read_bytes()) == manifest['sha256'], 'archive fingerprint differs')
        with ZipFile(archive) as bundle:
            require(bundle.testzip() is None and sorted(bundle.namelist()) == sorted(manifest['members']), 'ZIP members differ')
            items = {path: bundle.read(path) for path in bundle.namelist()}
        require({name: sha(data) for name, data in items.items()} == manifest['members'], 'member fingerprints differ')
        require(reconstruct(items) == expected, 'independent reconstruction differs')
        print('Reproduced rates, geometry epochs, drawable samples, XTEST coordinates and ACK counts.')


if __name__ == '__main__':
    main()
