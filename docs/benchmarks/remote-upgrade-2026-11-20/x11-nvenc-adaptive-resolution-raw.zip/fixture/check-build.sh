#!/usr/bin/env bash
set -euo pipefail
stage=$(cd "$(dirname "$0")" && pwd)
cd /home/yj/projects/jwm
export CARGO_TARGET_DIR=/tmp/jwm-remote-plan-target CARGO_BUILD_JOBS=2
ffmpeg_lib=/tmp/jwm-remote-ffmpeg/usr/lib/x86_64-linux-gnu
export PKG_CONFIG_PATH="$ffmpeg_lib/pkgconfig" LD_LIBRARY_PATH="$ffmpeg_lib"
exec 9>/tmp/jwm-p08-p09-release/benchmark.lock
flock -n 9
sha256sum -c "$stage/source.sha256"
cargo +stable check --offline --locked --no-default-features --features remote-x11 --lib --bin jwm-remote > "$stage/x11-check.log" 2>&1
cargo +stable test --offline --locked --no-default-features --features remote-h264 --lib remote:: > "$stage/core-test.log" 2>&1
cargo +stable test --offline --locked --no-default-features --features remote-h264 --bin jwm-remote > "$stage/cli-test.log" 2>&1
cargo +stable build --release --offline --locked --no-default-features --features remote-x11,remote-wayland,remote-h264 --bin jwm-remote > "$stage/release.log" 2>&1
install -m 555 "$CARGO_TARGET_DIR/release/jwm-remote" "$stage/jwm-remote"
sha256sum "$stage/jwm-remote" > "$stage/binary.sha256"
