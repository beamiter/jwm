#define _GNU_SOURCE
#include <libavcodec/avcodec.h>
#include <dlfcn.h>
#include <errno.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

typedef int (*submit_fn)(AVCodecContext *, const AVFrame *);
static pthread_once_t lookup_once = PTHREAD_ONCE_INIT;
static _Atomic int injected;
static submit_fn submit;

static void resolve_submit(void)
{
    submit = (submit_fn)dlsym(RTLD_NEXT, "avcodec_send_frame");
    if (!submit)
        _exit(125);
}

int avcodec_send_frame(AVCodecContext *context, const AVFrame *frame)
{
    pthread_once(&lookup_once, resolve_submit);
    const char *gate = getenv("JWM_ADAPT_FIXTURE_FAIL_ENCODE");
    if (gate && frame && context && context->codec &&
        strcmp(context->codec->name, "h264_nvenc") == 0 &&
        access(gate, F_OK) == 0 && !atomic_exchange(&injected, 1)) {
        fprintf(stderr, "fixture: failed one NVENC submission at %dx%d\n",
                context->width, context->height);
        return AVERROR(EIO);
    }
    return submit(context, frame);
}
