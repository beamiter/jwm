#!/usr/bin/env python3
"""Drive the NVENC resolution ladder on private X servers and sample rendered pixels."""
from contextlib import ExitStack
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import statistics
import subprocess
import sys
import time

from Xlib import X, display

REPO = Path(os.environ.get('JWM_ADAPT_FIXTURE_REPO', '/home/yj/projects/jwm'))
PAINTER = Path(os.environ.get('JWM_ADAPT_FIXTURE_PAINTER', '/tmp/jwm-native-x11-resource-soak.6Wufhz33/run/observer'))
PAINTER_PIN = 'd981ba7314b92529941e9a24a6d90f36f738e9679bc5abd2f417c6d0df672416'
FFMPEG = os.environ.get('JWM_ADAPT_FIXTURE_FFMPEG', '/tmp/jwm-remote-ffmpeg/usr/lib/x86_64-linux-gnu')
RATE = re.compile(r'hardware rate target (\d+) fps, (\d+)% nominal bitrate \((\w+)\)')
TIER = re.compile(r'hardware resolution target (\d+)% \((\w+)\)')
VIEWER = re.compile(r'viewer rate feedback \((\d+) drawn frames, mean decode ([\d.]+) ms, queue ([\d.]+) ms, presentation ([\d.]+) ms\)')
FEEDBACK = 'viewer rate feedback negotiated (application v36)'
REGION = (288, 170, 896, 560)
RED = (239, 36, 52)
CYAN = (32, 214, 232)


def require(value, detail):
    if not value:
        raise RuntimeError(detail)
    return value


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return path.read_text(errors='replace')


def records(path, key, name):
    return [record for line in read(path).splitlines(keepends=True)
            if line.startswith('{') and line.endswith('\n')
            for record in [json.loads(line)] if record.get(key) == name]


def run_arm(fixture, helper, env, root, name, ordinal):
    host_log, view_log, events = root/'host.log', root/'viewer.log', root/'viewer.stdout'
    pressure, failure = root/'slow', root/'fail'
    host_stats = lambda: records(host_log, 'type', 'jwm_remote_host_stats')
    viewer_stats = lambda: records(view_log, 'type', 'jwm_remote_viewer_stats')
    snapshots = lambda: records(events, 'event', 'snapshot')

    with ExitStack() as cleanup:
        def start(name, args, *, changes=None, stdin=subprocess.DEVNULL):
            stdout = cleanup.enter_context((root/f'{name}.stdout').open('wb'))
            stderr = cleanup.enter_context((root/f'{name}.log').open('wb'))
            child = subprocess.Popen(args, env=env | (changes or {}), stdout=stdout, stderr=stderr, stdin=stdin)
            cleanup.callback(fixture.stop, child)
            return child

        source_server, source_display = fixture.fixture.launch()
        cleanup.callback(fixture.stop, source_server)
        viewer_server, viewer_display = fixture.fixture.launch()
        cleanup.callback(fixture.stop, viewer_server)
        key = root/'key'
        cleanup.callback(key.unlink, missing_ok=True)
        subprocess.run([helper, 'keygen', '--output', key], env=env, check=True,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5)
        source_rect = f'{REGION[2]}x{REGION[3]}+{REGION[0]}+{REGION[1]}'
        host_env = {'JWM_REMOTE_ADAPT_VIDEO': 'motion', 'JWM_REMOTE_CURSOR_WORKER': '1'}
        if name != 'tiers-disabled':
            host_env['JWM_REMOTE_ADAPT_RESOLUTION'] = '1'
        if name == 'fallback':
            host_env['LD_PRELOAD'] = str(helper.parent/'fail-encode.so')
            host_env['JWM_ADAPT_FIXTURE_FAIL_ENCODE'] = str(failure)
        host = start('host', [helper, 'host', '--display', source_display, '--listen', '127.0.0.1:0',
                              '--key-file', key, '--capture-source', 'root', '--allow-h264', '--allow-input',
                              '--share-region', source_rect, '--fps', '30', '--max-width', '1280',
                              '--scaling', 'auto', '--stats-json', '--once'], changes=host_env)
        listen = fixture.wait_for('owned NVENC listener', lambda: re.search(
            r'listening on (127\.0\.0\.1:\d+)', read(host_log)))
        painter = start('painter', [PAINTER, 'paint', '--display', source_display, '--width', '1280',
                       '--height', '800', '--fps', '60', '--seconds', '240' if name == 'ladder' else '150',
                       '--run-id', str(ordinal), '--seed', '7'])
        fixture.wait_for('owned source motion', lambda: 'p09_start' in read(root/'painter.stdout'))
        source_x11 = display.Display(source_display)
        cleanup.callback(source_x11.close)
        source_root = source_x11.screen().root
        for (x, y), (r, g, b) in (((80, 80), RED), ((396, 240), CYAN)):
            marker = source_root.create_window(x, y, 96, 72, 0, X.CopyFromParent,
                X.InputOutput, X.CopyFromParent, background_pixel=r << 16 | g << 8 | b,
                override_redirect=True)
            marker.map()
        source_x11.sync()

        pressure.touch(exist_ok=False)
        viewer = start('viewer', [helper, 'session', listen[1], '--display', viewer_display, '--key-file', key,
                                    '--control', '--window-size', '1280x800', '--scaling', 'cpu', '--stats-json'],
                       stdin=subprocess.PIPE, changes={'JWM_REMOTE_ADAPT_FEEDBACK': '1',
                       'LD_PRELOAD': str(helper.parent/'slow-rgb.so'), 'JWM_FEEDBACK_FIXTURE_DELAY': str(pressure)})
        cleanup.callback(viewer.stdin.close)
        actors = (host, viewer, painter)

        def wait(label, find, seconds=14):
            def checked():
                for child in actors:
                    require(child.poll() is None, f'actor exited before {label}: {child.args[0]} -> {child.poll()}')
                return find()
            return fixture.wait_for(label, checked, seconds)

        def command(request, action, **fields):
            msg = {'request': request, 'command': action, **fields}
            viewer.stdin.write(json.dumps(msg).encode()+b'\n')
            viewer.stdin.flush()
            if action == 'disconnect':
                return
            result = wait(action, lambda: next((event for event in records(events, 'event', 'command_result')
                                           if event['request'] == request), None))
            require(result['accepted'], f'rejected command {result}')

        wait('actual NVENC H.264', lambda: 'hardware H.264 encoding active (NVENC)' in read(host_log))
        wait('actual H.264 viewer', lambda: 'hardware H.264 decoding active' in read(view_log))
        require(FEEDBACK in read(host_log) and FEEDBACK in read(view_log), 'v36 feedback did not negotiate')
        require(('resolution adaptation active' in read(host_log)) == (name != 'tiers-disabled'),
                'tier opt-in did not match requested scope')
        local_env = env | {'DISPLAY': viewer_display}
        ids = wait('private viewer window', lambda: subprocess.run(
            ['xdotool', 'search', '--onlyvisible', '--name', 'JWM Remote'], env=local_env,
            capture_output=True, text=True, check=False, timeout=3).stdout.splitlines())
        xid, = ids
        viewer_x11 = display.Display(viewer_display)
        cleanup.callback(viewer_x11.close)
        window = viewer_x11.create_resource_object('window', int(xid))
        marks = []
        motions = []

        def observe_pixels(*, switched):
            area = REGION if switched else (0, 0, 1280, 800)
            geom = window.get_geometry()
            x0, y0, width, height = area
            scale = min(geom.width / width, geom.height / height)
            local_x = lambda x: round((geom.width-width*scale)/2+(x-x0)*scale)
            local_y = lambda y: round((geom.height-height*scale)/2+(y-y0)*scale)
            chips = ((444, 276, CYAN),) if switched else ((128, 116, RED), (444, 276, CYAN))
            got = []
            for x, y, wanted in chips:
                lx, ly = local_x(x), local_y(y)
                raw = window.get_image(lx-4, ly-4, 9, 9, X.ZPixmap, 0xffffffff).data
                require(len(raw) == 9 * 9 * 4, 'expected 32-bit pixels')
                rgb = [int(statistics.median(raw[axis::4])) for axis in (2, 1, 0)]
                if max(abs(a-b) for a, b in zip(rgb, wanted)) > 33:
                    return None
                got.append({'viewer_xy': [lx, ly], 'source_xy': [x, y], 'rgb': rgb,
                            'expected': wanted, 'raw_bgrx': raw.hex()})
            return got

        def frame(label, dims, *, source_epoch=1, min_epoch=0, seconds=16):
            def find():
                hosts = [row for row in host_stats() if row['drawn_acks'] and row['last_sent_frame']]
                viewers = [row for row in viewer_stats() if row['acked'] and row['last_frame']]
                for row in reversed(viewers):
                    scope = row['last_frame']
                    if (scope['source_epoch'] != source_epoch or scope['geometry_epoch'] <= min_epoch
                            or scope['encoded_dimensions'] != list(dims)):
                        continue
                    for peer in reversed(hosts):
                        wire = peer['last_sent_frame']
                        if (wire['source_epoch'], wire['geometry_epoch'], wire['encoded_dimensions']) == (
                                source_epoch, scope['geometry_epoch'], list(dims)):
                            return row, peer
            row, peer = wait(label, find, seconds)
            pixels = wait(label + ' pixel samples', lambda: observe_pixels(switched=source_epoch == 2), 4)
            scope = row['last_frame']
            expected_source = list(REGION[2:]) if source_epoch == 2 else [1280, 800]
            require(scope['source_dimensions'] == peer['last_sent_frame']['source_dimensions'] == expected_source,
                    'capture raster does not describe the selected source')
            mark = {'label': label, 'viewer': scope, 'host': peer['last_sent_frame'],
                    'viewer_acked_window': row['acked'], 'host_drawn_acks_window': peer['drawn_acks'],
                    'pixels': pixels}
            marks.append(mark)
            print(name, label, scope['geometry_epoch'], dims, flush=True)
            return scope['geometry_epoch']

        def pointer(label, *, switched, x, y):
            geom = window.get_geometry()
            x0, y0, w, h = REGION if switched else (0, 0, 1280, 800)
            scale = min(geom.width/w, geom.height/h)
            lx = round((geom.width-w*scale)/2+(x-x0)*scale)
            ly = round((geom.height-h*scale)/2+(y-y0)*scale)
            subprocess.run(['xdotool', 'windowfocus', '--sync', xid, 'mousemove', '--window', xid, str(lx-30), str(ly-30), 'click', '1'],
                           env=local_env, check=True, timeout=4)
            def pulled():
                subprocess.run(['xdotool', 'mousemove', '--window', xid, str(lx), str(ly)],
                               env=local_env, check=True, timeout=4)
                pointer = source_root.query_pointer()
                measured = (pointer.root_x, pointer.root_y)
                return measured if max(abs(measured[0]-x), abs(measured[1]-y)) <= 3 else None
            measured = wait(label, pulled, 6)
            motions.append({'label': label, 'viewer_xy': [lx, ly], 'expected_root_xy': [x, y],
                            'x11_root_xy': measured})

        def tier(percent, causes, *, count=1, seconds=46):
            if isinstance(causes, str):
                causes = (causes,)
            wait(f'resolution {percent}% {causes}', lambda: sum(
                size == str(percent) and cause in causes for size,cause in TIER.findall(read(host_log))) >= count, seconds)

        first = frame('initial', (1280, 800))
        wait('24 FPS under viewer pressure', lambda: ('24', '100', 'Viewer') in RATE.findall(read(host_log)), 35)
        wait('NVENC actual reopen at 24 FPS', lambda: 'NVENC opened 24 fps at 100% nominal bitrate' in read(host_log))
        if name == 'tiers-disabled':
            wait('two additional windows show sustained pressure', lambda: len([
                row for row in VIEWER.findall(read(host_log)) if float(row[1]) >= 45]) >= 8, 45)
            require(not TIER.findall(read(host_log)), 'disabled arm changed resolution')
            frame('still at ordinary size', (1280, 800))
        else:
            tier(75, 'Viewer')
            small = frame('75% under pressure', (960, 600), min_epoch=first)
            if name == 'ladder':
                tier(50, 'Viewer')
                half = frame('50% under pressure', (640, 400), min_epoch=small)
                pointer('host input on half raster', switched=False, x=700, y=446)
                pressure.unlink()
                tier(75, ('ViewerRecovery', 'Clear'))
                up = frame('75% recovered', (960, 600), min_epoch=half)
                tier(100, ('ViewerRecovery', 'Clear'))
                frame('100% recovered', (1280, 800), min_epoch=up)
                wait('28 FPS after restoring size', lambda: ('28', '100', 'Clear') in RATE.findall(read(host_log)), 42)
                wait('30 FPS after restoring size', lambda: ('30', '100', 'Clear') in RATE.findall(read(host_log)), 42)
                wait('NVENC reopened at recovered 30 FPS', lambda: read(host_log).count(
                    'NVENC opened 30 fps at 100% nominal bitrate') >= 2)
            elif name == 'fallback':
                pressure.unlink()
                failure.touch()
                wait('one bounded injected encoder submit fault', lambda:
                     'failed one NVENC submission at 960x600' in read(host_log))
                wait('host selected same-source JPEG', lambda: 'hardware encoding failed, switching to JPEG' in read(host_log))
                wait('viewer accepted JPEG', lambda: 'host switched to JPEG video' in read(view_log))
                frame('full source following NVENC fallback', (1280, 800), min_epoch=small)
                require(marks[-1]['viewer']['codec'] == marks[-1]['host']['codec'] == 'JPEG',
                        'full fallback marker did not describe JPEG')
                pointer('host input after full-raster fallback', switched=False, x=700, y=446)
            else:
                window.configure(width=1120, height=700)
                viewer_x11.sync()
                resized = frame('ordinary size after viewport request', (1120, 700), min_epoch=small)
                tier(75, 'Viewer', count=2)
                reduced = frame('75% of new viewport', (840, 525), min_epoch=resized)
                catalog = wait('initial managed source', lambda: next((row['catalog'] for row in snapshots()
                    if row['state'] == 'viewing' and row.get('catalog')), None))
                other, = [entry['source_id'] for entry in catalog['entries'] if entry['source_id'] != catalog['source_id']]
                pressure.unlink()
                command(1, 'select_source', selection={key: catalog[key] for key in ('session_id', 'source_epoch')}
                        | {'source_id': other})
                frame('full size of authorized region', (896, 560), source_epoch=2, min_epoch=reduced)
                pointer('host input includes region origin', switched=True, x=760, y=480)
                after = time.monotonic()+2
                samples = []
                while time.monotonic() < after:
                    samples.append(require(observe_pixels(switched=True), 'old-source or stale geometry pixels reappeared'))
                    time.sleep(.025)
                (root/'post-switch-pixels.json').write_text(json.dumps(samples)+'\n')
                require(any((row.get('catalog') or {}).get('source_id') == other for row in snapshots()),
                        'catalog did not select the authorized region')

        command(2, 'disconnect')
        viewer_exit, host_exit = viewer.wait(timeout=10), host.wait(timeout=10)
        require((viewer_exit, host_exit) == (0, 0), f'session exits: {viewer_exit}, {host_exit}')
        require(snapshots()[-1]['state'] == 'closed', 'managed session did not close cleanly')
        hosts, viewers = host_stats(), viewer_stats()
        require(len({row['session_id'] for row in hosts+viewers}) == 1, 'mixed authenticated sessions')
        jpeg = sum(row['jpeg_atlases'] for row in hosts)
        require(all(row['hevc444_frames'] == 0 for row in hosts) and (jpeg > 0) == (name == 'fallback'),
                'codec path differed from the requested fault arm')
        require(all(row['max_outstanding'] <= 2 and row['outstanding'] <= 2 for row in hosts), 'credit bound breached')
        h_ack = sum(row['drawn_acks'] for row in hosts)
        v_ack = sum(row['acked'] for row in viewers)
        # SourceChanged retires up to two prior-source credits. The viewer can
        # legitimately send a drawn ACK for one of those before seeing the barrier.
        allowed_retirement = 2 if name == 'scope-changes' else 0
        require(h_ack > 0 and 0 <= v_ack - h_ack <= allowed_retirement, 'drawn ACK counts outside credit bounds')
        for rows, key in ((hosts, 'last_sent_frame'), (viewers, 'last_frame')):
            frames = [row[key] for row in rows if row[key]]
            scopes = [(item['source_epoch'], item['geometry_epoch']) for item in frames]
            require(scopes == sorted(scopes), 'source or geometry epoch moved backwards')
        return {'arm': name, 'marks': marks, 'pointer_observations': motions,
                'rate_changes': RATE.findall(read(host_log)), 'size_changes': TIER.findall(read(host_log)),
                'viewer_feedback': [list(map(float, row)) for row in VIEWER.findall(read(host_log))],
                'host_drawn_acks': h_ack, 'viewer_sent_drawn_acks': v_ack, 'host_exit': host_exit, 'viewer_exit': viewer_exit}


def main():
    helper, output = (Path(arg).resolve() for arg in sys.argv[1:3])
    selected = sys.argv[3:] or ['ladder', 'scope-changes', 'tiers-disabled', 'fallback']
    output.mkdir(mode=0o700)
    require(sha(PAINTER) == PAINTER_PIN, 'paint tool hash differs')
    env = {key: value for key, value in os.environ.items() if not key.startswith('JWM_REMOTE_') and key not in
           ('DISPLAY', 'XAUTHORITY', 'WAYLAND_DISPLAY', 'WAYLAND_SOCKET', 'LD_PRELOAD', 'JWM_FEEDBACK_FIXTURE_DELAY')}
    env.update(LD_LIBRARY_PATH=FFMPEG, XDG_RUNTIME_DIR=str(output))
    spec = importlib.util.spec_from_file_location('recovery_fixture', REPO/'scripts/test-remote-recovery-window.py')
    fixture = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(fixture)
    results = []
    for ordinal, name in enumerate(selected, 60):
        directory = output/name
        directory.mkdir(mode=0o700)
        results.append(run_arm(fixture, helper, env, directory, name, ordinal))
        (output/'result.json').write_text(json.dumps({'cases': results, 'binary_sha256': sha(helper)}, indent=2)+'\n')
        print('complete', name, results[-1]['host_drawn_acks'], flush=True)


if __name__ == '__main__':
    main()
