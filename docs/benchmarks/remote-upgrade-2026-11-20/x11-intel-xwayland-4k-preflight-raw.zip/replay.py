#!/usr/bin/env python3
"""Replay the matching device, private display and terminal preflight evidence."""
import hashlib
import json
from pathlib import Path
import re


def require(condition, detail):
    if not condition:
        raise RuntimeError(detail)


def report(root):
    scope = json.loads((root / 'preflight.json').read_text())
    checked = json.loads((root / 'evidence/dri3.json').read_text())
    require(checked == scope['dri3'], 'DRI3 opened-device record differs')
    require((checked['major'], checked['minor']) == (226, 128), 'unexpected opened DRI3 device')
    require(scope['render_node'] == checked['path'] == '/dev/dri/renderD128', 'mismatched render node')
    require(scope['pci_device'] == '0000:00:02.0', 'unexpected PCI identity')
    compositor = (root / 'evidence/smithay.log').read_text()
    require('JWM_NATIVE_WAYLAND_RENDERER=' + scope['smithay_renderer'] in compositor and
            'Intel' in scope['smithay_renderer'], 'missing actual Intel GBM renderer')
    require(re.search(r'test result: ok\. 1 passed; 0 failed; 0 ignored;', compositor),
            'exact owned fixture did not exit successfully')
    native = scope['owned_output_first_draw']
    require(native['size'] == scope['screen_size'] == [3840, 2160] and native['dmabuf_draws'] >= 1,
            'the actual native 4K compositor draw was not observed')
    require((native['render_node_device'] >> 8) == 226 and (native['render_node_device'] & 255) == 128,
            'same render-device encoding changed')
    require(scope['owned_output_final']['dmabuf_draws'] >= native['dmabuf_draws'] and
            scope['compositor_exit'] == 0 and scope['launcher_exit'] == 0, 'owned exits/draws were not retained')
    screen = (root / 'evidence/xdpyinfo-selected.log').read_text()
    for proof in (r'dimensions:\s+3840x2160 pixels', r'depth of root window:\s+24 planes',
                  r'^\s+DRI3\s*$', r'^\s+DAMAGE\s*$'):
        require(re.search(proof, screen, re.MULTILINE), 'missing actual X11 screen evidence: ' + proof)
    doctor = (root / 'evidence/doctor-selected.log').read_text()
    require('GPU present: VA-API NV12 rendered with GLES to an X11 DRI3 pixmap on /dev/dri/renderD128 '
            '(251x247 crop, four CPU reference colors matched)' in doctor,
            'actual production doctor pixel proof is missing')
    return scope


def main():
    root = Path(__file__).resolve().parent
    members = json.loads((root / 'members.sha256.json').read_text())
    for name, digest in members.items():
        require(hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, 'archive member changed: ' + name)
    print(json.dumps(report(root), indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
