"""Replay two local blocked-readback input trials from extracted evidence. Python 3 only."""
import json
from pathlib import Path
import sys

SIZE = (640, 480)
BACKGROUND = 0x204060
NEXT_BACKGROUND = 0x9a3d50
HOLD_NS = 3_000_000_000
HOLD_TOLERANCE_NS = 75_000_000
WATCHDOG_NS = 600_000_000
RELEASED = "input released - click to control"
GRABBED = "grabbed - Ctrl+Super+F12 to release"



def rgb_close(actual, want, margin=7):
    return all(abs((actual >> shift & 255) - (want >> shift & 255)) <= margin
               for shift in (0,8,16))


def expect(condition, reason):
    if not condition:
        raise RuntimeError(reason)


def pixels_match(pixels, frame, cursor):
    white = lambda position: rgb_close(pixels[position], 0xffffff, 2)
    other = "target_cursor" if cursor == "old_cursor" else "old_cursor"
    return rgb_close(pixels["frame"], frame) and white(cursor) and not white(other)


def validate_gate(readback, entries, worker):
    """Replay non-focus cancellation and matched scheduling evidence from existing records."""
    def single(name, **filters):
        matches = [item for item in entries if item["event"] == name
                   and all(item.get(key) == value for key, value in filters.items())]
        expect(len(matches) == 1, f"expected precisely one {name} with {filters}")
        return matches[0]

    start, end = readback["start_ns"], readback["release_ns"]
    expect((readback["opcode"], readback["width"], readback["height"]) == (73, *SIZE),
           "blocked X11 request was not full-frame core GetImage")
    actual = end - start
    expect(abs(actual - HOLD_NS) <= HOLD_TOLERANCE_NS, "scheduled gate hold missed its fixture tolerance")
    request = single("gate_release_requested")
    expect(request["deadline_ns"] == start + HOLD_NS
           and request["deadline_ns"] <= request["at_ns"] <= end, "early/unscheduled gate release")
    source_pixels = single("gated_pixels")
    cursor = "target_cursor" if worker else "old_cursor"
    expect(pixels_match(source_pixels["rgb"], BACKGROUND, cursor), "incorrect cursor or video while gate held")
    pair = single("f7_pair", phase="gated")
    expect(start < pair["local_down_ns"] <= pair["source_down_ns"] < pair["local_up_ns"]
           <= pair["source_up_ns"] <= pair["at_ns"] < end, "real F7 round trip was outside gate")
    before, after, proof = (single(name) for name in ("cancel_before", "cancel_after", "cancel_proof"))
    physical = single("viewer_key", key="F8", edge="up", phase="cancel_physical_cleanup")
    expect(start < source_pixels["at_ns"] < pair["local_down_ns"] < proof["local_down_ns"]
           <= proof["source_down_ns"] <= before["at_ns"] < proof["chord_ns"]
           <= proof["source_up_ns"] <= after["at_ns"] <= proof["at_ns"] <= physical["at_ns"] < end,
           "held F8 did not release in response to the local chord before physical keyup and gate release")
    expect(after["at_ns"] - proof["local_down_ns"] < WATCHDOG_NS,
           "held-key cleanup was not witnessed before the host watchdog could release it")
    expect(GRABBED in before["title"] and RELEASED in after["title"], "local grab state did not change")
    expect(before["keys"]["F8"] == {"source": True, "viewer": True}
           and after["keys"]["F8"] == {"source": False, "viewer": True},
           "source server F8 did not clear independently of the viewer server F8")
    expect(not any(pair["source"] for pair in after["keys"].values()),
           "source server retained one of the chord/held keys")
    f8_down = single("viewer_key", key="F8", edge="down", phase="cancel")
    chord = single("viewer_key", key="F12", edge="down", phase="cancel")
    expect(f8_down["at_ns"] == proof["local_down_ns"] and chord["at_ns"] == proof["chord_ns"],
           "cancellation summary does not match raw local key edges")
    for name in ("Control_L", "Super_L"):
        modifier = single("viewer_key", key=name, edge="down", phase="cancel")
        expect(before["at_ns"] < modifier["at_ns"] < chord["at_ns"], "escape chord missed a modifier")
    expect(all(after["keys"][name]["viewer"] for name in ("Control_L", "Super_L", "F12")),
           "viewer server did not see the complete physical chord")
    for focus in ("source_focus", "viewer_focus", "focus_change_count"):
        expect(before[focus] == after[focus], "focus assignment changed during cancellation")
    for proof_item, key in ((pair, "F7"), (proof, "F8")):
        for edge in ("down", "up"):
            timestamp = proof_item[f"source_{edge}_ns"]
            matches = [entry for entry in entries if entry["event"] == "source_key" and entry["key"] == key
                       and entry["edge"] == edge and entry["at_ns"] == timestamp]
            expect(len(matches) == 1 and matches[0]["window"] == before["source_focus"]
                   and not matches[0]["synthetic_send_event"], f"missing real source receiver edge for {key} {edge}")
    return {"actual_gate_hold_ms": actual / 1e6,
            "f7_press_local_to_source_ms": (pair["source_down_ns"] - pair["local_down_ns"]) / 1e6,
            "f7_release_local_to_source_ms": (pair["source_up_ns"] - pair["local_up_ns"]) / 1e6,
            "f8_local_chord_to_source_release_ms": (proof["source_up_ns"] - proof["chord_ns"]) / 1e6,
            "f8_local_press_to_source_clear_witness_ms": (after["at_ns"] - proof["local_down_ns"]) / 1e6,
            "preflight_and_cancel_focus": [before["source_focus"], before["viewer_focus"]],
            "source_keymap_cleared_while_viewer_F8_held": True}


def compare(results):
    good = len(results) == 2 and all(result["status"] == "pass" for result in results)
    difference = None
    if good:
        difference = abs(results[0]["actual_gate_hold_ms"] - results[1]["actual_gate_hold_ms"])
    return {"status": "pass" if good and difference <= HOLD_TOLERANCE_NS / 1e6 else "failed",
            "same_target_hold_ms": HOLD_NS / 1e6, "gate_difference_ms": difference,
            "hold_validation_tolerance_ms": HOLD_TOLERANCE_NS / 1e6, "arms": results}


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def replay(batch):
    results = []
    for arm, worker in (("capture-loop", False), ("independent", True)):
        directory = batch / arm
        result = read(directory / "result.json")
        expect(result["status"] == "pass" and result["arm"] == arm,
               f"{arm} failed live; see {directory}")
        gate, = read(directory / "gate.json")
        entries = [json.loads(line) for line in (directory / "events.jsonl").read_text().splitlines()]
        measured = validate_gate(gate, entries, worker)
        expect(result["core_readback"] == gate and all(result.get(key) == value for key, value in measured.items()),
               f"{arm} summary differs from raw gate and events")
        startup, = [entry for entry in entries if entry["event"] == "owned_displays"]
        expect(startup["source_pid"] != startup["viewer_pid"]
               and startup["source_display"] != startup["viewer_display"], "endpoints were not separate Xvfb servers")
        focus, = [entry for entry in entries if entry["event"] == "preflight_focus"]
        expect([focus["source_focus"], focus["viewer_focus"]] == measured["preflight_and_cancel_focus"],
               "focus changed between preflight and cancellation")
        pixels, = [entry for entry in entries if entry["event"] == "post_gate_pixels"]
        close, = [entry for entry in entries if entry["event"] == "viewer_wm_delete_after_gate"]
        exited, = [entry for entry in entries if entry["event"] == "session_exited"]
        cleared, = [entry for entry in entries if entry["event"] == "post_shutdown_keys"]
        expect(gate["release_ns"] < pixels["at_ns"] < close["at_ns"] < exited["at_ns"] < cleared["at_ns"],
               f"{arm} shutdown or resumed capture is outside its evidence scope")
        expect(pixels_match(pixels["rgb"], NEXT_BACKGROUND, "target_cursor"), "new frame did not reach the viewer")
        expect((exited["viewer_status"], exited["host_status"]) == (0, 0), "host/viewer exit was not clean")
        expect(not any(state["source"] or state["viewer"] for state in cleared["keys"].values()),
               "server keymap was not clear after shutdown")
        host_log = (directory / "host.log").read_text(errors="replace")
        expect(("independent X11 cursor sampler active" in host_log) == worker, "host cursor mode mismatched")
        expect("core GetImage" in host_log or "core-getimage" in host_log, "missing core readback provenance")
        expect("with input held; releasing keys and buttons" not in host_log, "watchdog release appeared in host log")
        results.append(result)
    summary = compare(results)
    expect(summary["status"] == "pass" and summary == read(batch / "summary.json"), "invalid arm comparison")
    return summary


def recorded_event(rows, name):
    event, = [row for row in rows if row["event"] == name]
    return event


def typed_stats(arm_path, role):
    log = (arm_path / f"{role}.log").read_text()
    frames = [json.loads(line) for line in log.splitlines() if line.startswith("{")]
    matches = [frame for frame in frames if frame.get("type") == f"jwm_remote_{role}_stats"]
    frame, = matches
    scope = frame["last_sent_frame" if role == "host" else "last_frame"]
    expect(scope["codec"] == "JPEG" and scope["source_dimensions"] == list(SIZE)
           and scope["encoded_dimensions"] == list(SIZE), "wrong final frame scope")
    return frame, log


def read_arms(batch, replayed):
    evidence = []
    for arm_proof in replayed["arms"]:
        arm_name = arm_proof["arm"]
        arm_path = batch / arm_name
        rows = [json.loads(line) for line in (arm_path / "events.jsonl").read_text().splitlines()]
        row = lambda event: recorded_event(rows, event)
        host, host_log = typed_stats(arm_path, "host")
        viewer, viewer_log = typed_stats(arm_path, "viewer")
        expect(host["session_id"] and host["session_id"] == viewer["session_id"],
               "host and viewer authenticated session mismatch")
        expect("core-getimage" in host["mode"] and host["mode"].startswith("root/"),
               "host did not use core root readback")
        expect(viewer["viewer_backend"] == "x11" and viewer["input_mode"] == "x11-keyboard-pointer"
               and viewer["final"] and "session ended" in viewer_log,
               "wrong viewer mode or missing final viewer telemetry")
        expect("authenticated session started (screen + pointer + keyboard)" in host_log,
               "missing host permission negotiation")
        before, after = row("cancel_before"), row("cancel_after")
        proof = row("cancel_proof")
        expect(not any(event["event"] == "focus_event" and event["assignment"]
                       and proof["local_down_ns"] <= event["at_ns"] <= after["at_ns"] for event in rows),
               "actual focus assignment during the observed held-key interval")
        gate = arm_proof["core_readback"]
        marker = row("gate_entered")
        expect((marker["opcode"], marker["width"], marker["height"], marker["at_ns"])
               == (gate["opcode"], gate["width"], gate["height"], gate["start_ns"]),
               "logged gate entry does not match exact blocked X11 request")
        f7, = [e for e in rows if e["event"] == "f7_pair" and e["phase"] == "gated"]
        exit_event, shutdown = row("session_exited"), row("post_shutdown_keys")
        old_raster, new_raster = row("gated_pixels"), row("post_gate_pixels")
        ownership = row("owned_displays")
        expect(len({ownership["source_pid"], ownership["viewer_pid"], row("host_started")["pid"],
                    row("viewer_started")["pid"]}) == 4, "endpoint process identities were not distinct")
        evidence.append({
            **arm_proof,
            "authenticated_session_id": host["session_id"],
            "core_readback_route": host["mode"],
            "source_key_receiver_xid": before["source_focus"],
            "viewer_window_xid": before["viewer_focus"],
            "focus_assignment_count_before_and_after": [before["focus_change_count"], after["focus_change_count"]],
            "grab_release_chord": "Ctrl+Super+F12",
            "viewer_grabbed_before_and_released_after": [GRABBED in before["title"], RELEASED in after["title"]],
            "f7_actual_source_press_and_release_ns": [f7["source_down_ns"], f7["source_up_ns"]],
            "f8_actual_source_press_and_release_ns": [proof["source_down_ns"], proof["source_up_ns"]],
            "x11_keymap_f8_before": before["keys"]["F8"],
            "x11_keymap_f8_after": after["keys"]["F8"],
            "source_keymap_clear_before_gate_forward_ms": (gate["release_ns"] - after["at_ns"]) / 1e6,
            "host_watchdog_reported": False,
            "gated_roi_rgb_hex": {key: f"{value:06x}" for key, value in old_raster["rgb"].items()},
            "resumed_roi_rgb_hex": {key: f"{value:06x}" for key, value in new_raster["rgb"].items()},
            "resumed_roi_after_gate_ms": (new_raster["at_ns"] - gate["release_ns"]) / 1e6,
            "shutdown": {"host_exit_status": exit_event["host_status"], "viewer_exit_status": exit_event["viewer_status"],
                         "viewer_close_to_endpoint_exits_ms": (exit_event["at_ns"] - row("viewer_wm_delete_after_gate")["at_ns"]) / 1e6,
                         "final_x11_keymap_of_test_keys": shutdown["keys"]},
        })
    expect(len({arm["authenticated_session_id"] for arm in evidence}) == len(evidence),
           "separate arms did not produce separate sessions")
    return evidence


def complete_replay(batch):
    summary = replay(batch)
    return {**summary, "arms": read_arms(batch, summary)}


if __name__ == "__main__":
    batch = Path(sys.argv[1]) if len(sys.argv) == 2 else Path(__file__).resolve().parent
    print(json.dumps(complete_replay(batch), indent=2))
