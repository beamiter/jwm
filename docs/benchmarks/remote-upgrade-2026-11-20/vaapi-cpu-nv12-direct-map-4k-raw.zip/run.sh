#!/usr/bin/env bash
set -euo pipefail
umask 077
base=$(cd "$(dirname "$0")" && pwd)
if [[ $# != 3 ]]; then
    printf '%s\n' 'Usage: bash run.sh FFMPEG_INCLUDE_DIR FFMPEG_LIB_DIR RENDER_NODE' >&2
    exit 2
fi
include=$1
lib=$2
node=$3
if [[ -n ${JWM_VAAPI_PROBE_LOCK:-} ]]; then
    exec 9>>"$JWM_VAAPI_PROBE_LOCK"
    flock -x 9
fi
(cd "$base/raw" && sha256sum --check packet.sha256)
build=$(mktemp -d)
trap 'rm -f -- "$build/preflight"; rmdir -- "$build"' EXIT
cc -std=c11 -O2 -Wall -Wextra -Werror -I "$include" "$base/preflight.c" \
    -L "$lib" -Wl,-rpath-link,"$lib" -lavcodec -lavutil -lswscale -o "$build/preflight"
export LD_LIBRARY_PATH="$lib"
unset DISPLAY WAYLAND_DISPLAY WAYLAND_SOCKET
status=0
for case_name in testsrc2 smptehdbars; do
    printf '%s\n' "$case_name transfer-first"
    timeout --signal=TERM --kill-after=2s 20s "$build/preflight" "$node" "$base/raw/$case_name.h264" || status=1
    printf '%s\n' "$case_name map-first"
    timeout --signal=TERM --kill-after=2s 20s "$build/preflight" "$node" "$base/raw/$case_name.h264" --map-first || status=1
done
exit "$status"
