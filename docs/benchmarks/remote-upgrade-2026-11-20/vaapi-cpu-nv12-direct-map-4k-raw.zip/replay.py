#!/usr/bin/env python3
"""Replay the terminal 4K VA-API compatibility evidence without device access."""

from hashlib import sha256
import json
from pathlib import Path
import re


SIZE = [3840, 2160]
CROP = [3839, 2159]
PACKET_PINS = {
    'testsrc2': '05f987caf29cdc4ecb07e09472628eb10ada85528c1cdf8908420604217be36e',
    'smptehdbars': '69702756f0f14d433626899cb869e3656a791a261e8546c2c2f347e6a2168c15',
}
COLORS = {
    'testsrc2': ('smpte170m', 'tv', 6, 1),
    'smptehdbars': ('bt709', 'pc', 1, 2),
}
ABI = {'libavcodec': '60.31.102', 'libavutil': '58.29.100', 'libswscale': '7.5.100'}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def parse_pairs(path):
    return dict(line.split(maxsplit=1) for line in path.read_text().splitlines())


def parse_digest_file(path):
    return {Path(name).name: digest for digest, name in
            (line.split(maxsplit=1) for line in path.read_text().splitlines())}


def verify(root):
    run = root / 'raw'
    require((run / 'controller.exit').read_text() == '0\n',
            'the complete locked controller did not finish successfully')
    platform = parse_pairs(run / 'device.txt')
    require(platform['vendor'] == '0x8086' and platform['device'] == '0x7d67'
            and platform['driver'] == 'i915', 'a different recorded Intel device ran the probe')
    require(parse_pairs(run / 'ffmpeg-abi.txt') == ABI, 'recorded FFmpeg ABI differs')
    provenance = json.loads((root / 'provenance.json').read_bytes())
    pins = provenance['source_and_tool_sha256']
    require(digest(root / 'invocations.json') == provenance['invocations_sha256'],
            'sanitized invocation digest differs')
    arguments = json.loads((root / 'invocations.json').read_bytes())
    require(digest(root / 'preflight.c') == pins['preflight.c'], 'C source digest differs')
    require(digest(root / 'run.sh') == provenance['portable_launcher_sha256'],
            'portable launcher digest differs')
    require(provenance['ffmpeg_library_sonames'] == {
        name: f'{name}.so.{version.split(".")[0]}' for name, version in ABI.items()},
        'recorded FFmpeg loader ABI differs')
    for prefix in ('build', 'ffmpeg-version', 'cc-version', 'generate-testsrc2',
                   'generate-smptehdbars', 'stream-testsrc2', 'stream-smptehdbars'):
        require((run / f'{prefix}.exit').read_text() == '0\n', f'{prefix} did not complete')
    report = {
        'scope': 'Local exact-4K Intel VA-API read-only direct CPU NV12 compatibility',
        'platform': platform,
        'kernel_release': (run / 'kernel.txt').read_text().strip(),
        'ffmpeg_abi': ABI,
        'source_and_tool_sha256': pins,
        'binary_sha256': provenance['executed_probe_sha256'],
        'provenance': provenance,
        'phases': [],
        'performance_measured': False,
    }
    packet_pins = parse_digest_file(run / 'packet.sha256')
    distinct = []
    for pattern, pin in PACKET_PINS.items():
        name = f'{pattern}.h264'
        packet = (run / name).read_bytes()
        require(digest(run / name) == packet_pins[name] == pin and 0 < len(packet) <= 1024*1024,
                f'{pattern} packet digest or size differs')
        nal_types = [unit[0] & 31 for unit in re.split(rb'\x00\x00\x00?\x01', packet) if unit]
        require(nal_types.count(5) == 1 and 7 in nal_types and 8 in nal_types and 1 not in nal_types,
                f'{pattern} is not one Annex B SPS/PPS/IDR access unit')
        stream, = json.loads((run / f'stream-{pattern}.log').read_bytes())['streams']
        space, color_range, surface_space, surface_range = COLORS[pattern]
        invocation = arguments[f'generate-{pattern}']['argv']
        require(invocation[invocation.index('-colorspace') + 1] == space
                and invocation[invocation.index('-color_range') + 1] == color_range,
                f'{pattern} recorded generator arguments differ')
        require(stream['codec_name'] == 'h264' and stream['profile'] == 'Constrained Baseline'
                and (stream['color_space'], stream['color_range']) == (space, color_range)
                and [stream['width'],stream['height']] == [stream['coded_width'],stream['coded_height']] == SIZE,
                f'{pattern} parsed SPS scope differs')
        cases = []
        for lane, order in (('transfer-first', 'download-first'), ('map-first', 'map-first')):
            stem = f'{pattern}-{lane}'
            require((run / f'{stem}.exit').read_text() == '0\n', f'{stem} did not finish successfully')
            record = json.loads((run / f'{stem}.log').read_bytes())
            require(record['status'] == 'pass' and record['decoder'] == 'h264/vaapi'
                    and record['map'] == 'cpu-nv12-read-direct' and record['order'] == order
                    and record['decoded_size'] == record['coded_size'] == record['frame_pool_size'] == SIZE
                    and record['tested_crop'] == CROP and record['performance_measured'] is False
                    and (record['surface_colorspace'],record['surface_color_range']) == (surface_space,surface_range),
                    f'{stem} decode/layout conditions differ')
            require((record['nv12_active_bytes_equal'],record['rgb_full_bytes_equal'],record['rgb_crop_bytes_equal'])
                    == (12441600,24883200,24865203), f'{stem} byte counts differ')
            require(len(record['mapped_planes']) == 2 and len(record['downloaded_planes']) == 2,
                    f'{stem} does not establish both NV12 planes')
            for index, span in enumerate((8294400,4147200)):
                mapped = record['mapped_planes'][index]
                copied = record['downloaded_planes'][index]
                require(mapped['stride'] == copied['stride'] == 3840
                        and mapped['active_span_bytes'] == copied['active_span_bytes'] == span
                        and mapped['reference_buffer_bytes'] is None and mapped['reference_bytes_after_active_span'] is None
                        and copied['reference_buffer_bytes'] == 12533888,
                        f'{stem} reported different backing-bound metadata')
            cases.append({'exit_code': 0, 'stdout_sha256': digest(run / f'{stem}.log'), 'result': record})
        left, right = (case['result'] for case in cases)
        require({**left, 'order': 'map-first'} == right, f'{pattern} results depend on access order')
        distinct.append([left[f'{kind}_adler32'] for kind in ('y','uv','rgb')])
        report['phases'].append({
            'pattern': pattern,
            'packet_bytes': len(packet),
            'packet_sha256': pin,
            'annex_b_nal_types': nal_types,
            'stream': stream,
            'declared_stream_color': {'matrix': space, 'range': color_range},
            'decoder_surface_color': {'matrix_av_enum': surface_space, 'range_av_enum': surface_range},
            'cases': cases,
        })
    require(all(a != b for a,b in zip(*distinct)), 'decoded Y, UV or RGB checksums did not distinguish the two patterns')
    report['outcome'] = 'all_four_hardware_cases_verified'
    report['mapped_allocation_span_verified'] = False
    report['limitations'] = [
        'The mapped frame did not expose a software AVBufferRef covering either plane. Stride and active spans are observed, but padding is unverified.',
        'RGB comparison uses separately aligned snapshots. No direct libswscale read of mapped storage was attempted.',
        'Same-surface accesses may share synchronization/cache costs; no timing, sequence throughput or product presentation claim is made.',
    ]
    return report


if __name__ == '__main__':
    print(json.dumps(verify(Path(__file__).resolve().parent), indent=2, sort_keys=True))
