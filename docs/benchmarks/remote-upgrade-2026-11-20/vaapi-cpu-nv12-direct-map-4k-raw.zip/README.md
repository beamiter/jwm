# Exact 4K VA-API direct CPU NV12 compatibility

Extract this archive and run `python3 -B replay.py`. Replay needs only Python's
standard library and checks terminal statuses, native decode dimensions, exact
packet and source pins, parsed SDR color metadata, strides, layout, and the
byte counts in the four real hardware results.

Both pinned H.264 IDRs decoded at an exact coded and visible 3840×2160 on Intel
PCI 8086:7d67 with i915. Testsrc2 used SMPTE 170M limited range. The SMPTE HD
bars used BT.709 full range. The stream and both orders of the decoder reported
the matching declared matrix and range. Each run verified 12,441,600 active
NV12 bytes, 24,883,200 full RGB24 bytes, and 24,865,203 RGB24 bytes in the
3839×2159 visible crop of the same output picture.

Both mapped NV12 strides were 3,840 bytes. The VA-API pool's 3840×2160 extent
and each active plane span were observed. Neither mapped plane had a covering
software AVBufferRef returned by FFmpeg, so the addressable mapped extent and
padding remain unknown. RGB conversion used owned aligned staging. A stride or
copied-frame buffer bound does not certify mapped padding for direct libswscale
reads. The first operation on a shared decoded surface can pay hardware
synchronization for the second. These are compatibility checks with no timing.

The optional local hardware reproduction uses the already pinned packets:

```sh
bash run.sh "$FFMPEG_INCLUDE_DIR" "$FFMPEG_LIB_DIR" /dev/dri/renderD128
```

Set `JWM_VAAPI_PROBE_LOCK` to the existing shared lock file if using the shared
lab. The launcher builds only the standalone C probe, checks the packets and
runs four DRM-only cases. `provenance.json` records the exact original build,
FFmpeg ABI and digests. Original invocation arguments are retained in
`invocations.json` with local staging locations replaced by placeholders.
