/* Hardware H.264 VA-API CPU mapping correctness probe using one pinned IDR. */
#include <errno.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include <libavcodec/avcodec.h>
#include <libavcodec/version.h>
#include <libavutil/adler32.h>
#include <libavutil/error.h>
#include <libavutil/frame.h>
#include <libavutil/hwcontext.h>
#include <libavutil/version.h>
#include <libswscale/swscale.h>
#include <libswscale/version.h>

#define WIDTH 3840
#define HEIGHT 2160
#define CROP_WIDTH 3839
#define CROP_HEIGHT 2159
#define MAX_PACKET_SIZE (1024 * 1024)
#define ROUND_64(value) (((value) + 63) & ~63)

enum ExitCode {
    SETUP_FAILED = 2,
    HARDWARE_DECODE_FAILED = 3,
    DIRECT_MAP_UNAVAILABLE = 4,
    CONTENT_CHECK_FAILED = 5,
};

static void report_error(const char *where, int error)
{
    char message[AV_ERROR_MAX_STRING_SIZE];
    if (av_strerror(error, message, sizeof(message)) < 0)
        snprintf(message, sizeof(message), "FFmpeg error %d", error);
    fprintf(stderr, "%s: %s (%d)\n", where, message, error);
}

static enum AVPixelFormat choose_vaapi(AVCodecContext *context,
                                       const enum AVPixelFormat *formats)
{
    (void)context;
    for (; *formats != AV_PIX_FMT_NONE; ++formats)
        if (*formats == AV_PIX_FMT_VAAPI)
            return *formats;
    return AV_PIX_FMT_NONE;
}

static bool has_vaapi(const AVCodec *codec)
{
    if (!codec)
        return false;
    for (int index = 0;; ++index) {
        const AVCodecHWConfig *config = avcodec_get_hw_config(codec, index);
        if (!config)
            return false;
        if (config->device_type == AV_HWDEVICE_TYPE_VAAPI &&
            config->pix_fmt == AV_PIX_FMT_VAAPI &&
            (config->methods & AV_CODEC_HW_CONFIG_METHOD_HW_DEVICE_CTX))
            return true;
    }
}

static int read_packet(AVPacket *packet, const char *path)
{
    FILE *source = fopen(path, "rb");
    if (!source)
        return AVERROR(errno);
    if (fseek(source, 0, SEEK_END) != 0) {
        int result = AVERROR(errno);
        fclose(source);
        return result;
    }
    long size = ftell(source);
    if (size <= 0 || size > MAX_PACKET_SIZE || fseek(source, 0, SEEK_SET) != 0) {
        fclose(source);
        return AVERROR_INVALIDDATA;
    }
    int result = av_new_packet(packet, (int)size);
    if (result == 0 && (fread(packet->data, 1, (size_t)size, source) != (size_t)size ||
                        fgetc(source) != EOF || ferror(source)))
        result = AVERROR_INVALIDDATA;
    fclose(source);
    return result;
}

static void set_frame_layout(AVFrame *frame, enum AVPixelFormat format)
{
    frame->format = format;
    frame->width = WIDTH;
    frame->height = HEIGHT;
}

static bool valid_nv12(const AVFrame *frame)
{
    return frame->format == AV_PIX_FMT_NV12 && frame->width == WIDTH &&
           frame->height == HEIGHT && frame->data[0] && frame->data[1] &&
           frame->linesize[0] >= WIDTH && frame->linesize[1] >= WIDTH;
}

static int copy_active_nv12(AVFrame *destination, const AVFrame *source)
{
    if (!valid_nv12(source))
        return AVERROR_INVALIDDATA;
    set_frame_layout(destination, AV_PIX_FMT_NV12);
    int result = av_frame_get_buffer(destination, 32);
    if (result < 0)
        return result;
    for (int plane = 0; plane < AV_NUM_DATA_POINTERS; ++plane)
        if (destination->buf[plane])
            memset(destination->buf[plane]->data, 0, destination->buf[plane]->size);
    for (int plane = 0; plane < 2; ++plane) {
        int rows = plane == 0 ? HEIGHT : HEIGHT / 2;
        for (int y = 0; y < rows; ++y)
            memcpy(destination->data[plane] + (size_t)y * destination->linesize[plane],
                   source->data[plane] + (size_t)y * source->linesize[plane], WIDTH);
    }
    return 0;
}

static int compare_rows(const AVFrame *a, const AVFrame *b, int plane,
                        int width_bytes, int rows, const char *label)
{
    for (int y = 0; y < rows; ++y) {
        const uint8_t *pa = a->data[plane] + (size_t)y * a->linesize[plane];
        const uint8_t *pb = b->data[plane] + (size_t)y * b->linesize[plane];
        if (memcmp(pa, pb, (size_t)width_bytes) == 0)
            continue;
        for (int x = 0; x < width_bytes; ++x) {
            if (pa[x] == pb[x])
                continue;
            fprintf(stderr, "%s differs at row %d byte %d: %u vs %u\n",
                    label, y, x, (unsigned)pa[x], (unsigned)pb[x]);
            return AVERROR_INVALIDDATA;
        }
    }
    return 0;
}

static int color_matrix(enum AVColorSpace color)
{
    switch (color) {
    case AVCOL_SPC_BT709: return SWS_CS_ITU709;
    case AVCOL_SPC_FCC: return SWS_CS_FCC;
    case AVCOL_SPC_SMPTE240M: return SWS_CS_SMPTE240M;
    case AVCOL_SPC_BT2020_NCL: return SWS_CS_BT2020;
    default: return SWS_CS_DEFAULT;
    }
}

static int convert_rgb(const AVFrame *nv12, const AVFrame *surface, AVFrame *output)
{
    set_frame_layout(output, AV_PIX_FMT_RGB24);
    int result = av_frame_get_buffer(output, 32);
    if (result < 0)
        return result;
    struct SwsContext *scale = sws_getContext(WIDTH, HEIGHT, AV_PIX_FMT_NV12,
        WIDTH, HEIGHT, AV_PIX_FMT_RGB24, SWS_FAST_BILINEAR, NULL, NULL, NULL);
    if (!scale)
        return AVERROR(ENOMEM);
    const int *coefficients = sws_getCoefficients(color_matrix(surface->colorspace));
    if (!coefficients) {
        sws_freeContext(scale);
        return AVERROR_INVALIDDATA;
    }
    result = sws_setColorspaceDetails(scale, coefficients, surface->color_range == AVCOL_RANGE_JPEG,
                                     coefficients, 1, 0, 1 << 16, 1 << 16);
    if (result >= 0) {
        const uint8_t *planes[4] = {nv12->data[0], nv12->data[1], NULL, NULL};
        result = sws_scale(scale, planes, nv12->linesize, 0, HEIGHT, output->data, output->linesize);
        if (result >= 0 && result != HEIGHT)
            result = AVERROR_INVALIDDATA;
    }
    sws_freeContext(scale);
    return result < 0 ? result : 0;
}

struct PlaneLayout {
    int stride;
    size_t active_span_bytes;
    bool reference_span_known;
    size_t reference_buffer_bytes;
    size_t reference_bytes_after_active_span;
};

static struct PlaneLayout plane_layout(const AVFrame *frame, int plane)
{
    int rows = plane == 0 ? HEIGHT : HEIGHT / 2;
    struct PlaneLayout layout = {
        .stride = frame->linesize[plane],
        .active_span_bytes = (size_t)(rows - 1) * frame->linesize[plane] + WIDTH,
    };
    AVBufferRef *buffer = av_frame_get_plane_buffer(frame, plane);
    if (buffer) {
        uintptr_t begin = (uintptr_t)buffer->data;
        uintptr_t pixels = (uintptr_t)frame->data[plane];
        if (pixels >= begin && pixels - begin <= buffer->size &&
            layout.active_span_bytes <= buffer->size - (pixels - begin)) {
            layout.reference_span_known = true;
            layout.reference_buffer_bytes = buffer->size;
            layout.reference_bytes_after_active_span =
                buffer->size - (pixels - begin) - layout.active_span_bytes;
        }
    }
    return layout;
}

static void print_plane_layout(struct PlaneLayout layout)
{
    printf("{\"stride\":%d,\"active_span_bytes\":%zu,\"reference_buffer_bytes\":",
           layout.stride, layout.active_span_bytes);
    if (layout.reference_span_known)
        printf("%zu,\"reference_bytes_after_active_span\":%zu}",
               layout.reference_buffer_bytes, layout.reference_bytes_after_active_span);
    else
        printf("null,\"reference_bytes_after_active_span\":null}");
}

static unsigned active_adler(const AVFrame *frame, int plane, int width, int rows)
{
    AVAdler sum = 1;
    for (int row = 0; row < rows; ++row)
        sum = av_adler32_update(sum, frame->data[plane] + (size_t)row * frame->linesize[plane],
                                (size_t)width);
    return (unsigned)sum;
}

static int map_snapshot(const AVFrame *surface, AVFrame *snapshot, struct PlaneLayout layout[2])
{
    AVFrame *mapped = av_frame_alloc();
    if (!mapped) {
        report_error("allocating direct map target", AVERROR(ENOMEM));
        return DIRECT_MAP_UNAVAILABLE;
    }
    mapped->format = AV_PIX_FMT_NV12;
    int result = av_hwframe_map(mapped, surface, AV_HWFRAME_MAP_READ | AV_HWFRAME_MAP_DIRECT);
    if (result < 0) {
        report_error("direct CPU NV12 mapping unavailable on this VA-API device", result);
        av_frame_free(&mapped);
        return DIRECT_MAP_UNAVAILABLE;
    }
    if (!valid_nv12(mapped)) {
        fputs("direct mapping did not return the expected CPU NV12 frame and plane strides\n", stderr);
        av_frame_free(&mapped);
        return DIRECT_MAP_UNAVAILABLE;
    }
    layout[0] = plane_layout(mapped, 0);
    layout[1] = plane_layout(mapped, 1);
    /* Keep only active bytes, then unmap before a second access to the same
     * driver surface. This correctness probe never passes unknown mapped
     * padding to libswscale's potentially overreading SIMD kernels. */
    result = copy_active_nv12(snapshot, mapped);
    av_frame_free(&mapped);
    if (result < 0) {
        report_error("copying active rows from mapped frame", result);
        return CONTENT_CHECK_FAILED;
    }
    return 0;
}

int main(int argc, char **argv)
{
    bool map_first = argc == 4 && strcmp(argv[3], "--map-first") == 0;
    if (argc != 3 && !map_first) {
        fprintf(stderr, "usage: %s DEVICE PINNED_PACKET [--map-first]\n", argv[0]);
        return SETUP_FAILED;
    }
    if (avcodec_version() != LIBAVCODEC_VERSION_INT || avutil_version() != LIBAVUTIL_VERSION_INT ||
        swscale_version() != LIBSWSCALE_VERSION_INT) {
        fputs("FFmpeg header/runtime version mismatch\n", stderr);
        return SETUP_FAILED;
    }
    int result = 0;
    int status = SETUP_FAILED;
    struct PlaneLayout mapped_layout[2] = {0};
    AVCodecContext *context = NULL;
    AVPacket *packet = av_packet_alloc();
    AVFrame *surface = av_frame_alloc();
    AVFrame *extra = av_frame_alloc();
    AVFrame *download = av_frame_alloc();
    AVFrame *aligned_download = av_frame_alloc();
    AVFrame *aligned_map = av_frame_alloc();
    AVFrame *rgb_download = av_frame_alloc();
    AVFrame *rgb_map = av_frame_alloc();
    if (!(packet && surface && extra && download && aligned_download && aligned_map &&
          rgb_download && rgb_map)) {
        report_error("allocating probe frames", AVERROR(ENOMEM));
        goto done;
    }
    result = read_packet(packet, argv[2]);
    if (result < 0) {
        report_error("reading pinned Annex B H.264 packet", result);
        goto done;
    }
    status = HARDWARE_DECODE_FAILED;
    const AVCodec *codec = avcodec_find_decoder(AV_CODEC_ID_H264);
    if (!has_vaapi(codec)) {
        fputs("FFmpeg H.264 decoder has no VA-API device mode\n", stderr);
        goto done;
    }
    context = avcodec_alloc_context3(codec);
    if (!context) {
        report_error("allocating H.264 decoder", AVERROR(ENOMEM));
        goto done;
    }
    context->get_format = choose_vaapi;
    context->flags |= AV_CODEC_FLAG_LOW_DELAY;
    context->err_recognition = AV_EF_EXPLODE;
    context->thread_count = 1;
    context->max_pixels = (int64_t)ROUND_64(WIDTH) * ROUND_64(HEIGHT);
    context->width = WIDTH;
    context->height = HEIGHT;
    result = av_hwdevice_ctx_create(&context->hw_device_ctx, AV_HWDEVICE_TYPE_VAAPI, argv[1], NULL, 0);
    if (result < 0) {
        report_error("opening the requested VA-API render node", result);
        goto done;
    }
    if ((result = avcodec_open2(context, codec, NULL)) < 0 ||
        (result = avcodec_send_packet(context, packet)) < 0 ||
        (result = avcodec_receive_frame(context, surface)) < 0) {
        report_error("decoding the pinned H.264 packet on VA-API", result);
        goto done;
    }
    if (surface->format != AV_PIX_FMT_VAAPI || !surface->hw_frames_ctx ||
        surface->width != WIDTH || surface->height != HEIGHT || !(surface->flags & AV_FRAME_FLAG_KEY) ||
        context->coded_width != WIDTH || context->coded_height != HEIGHT ||
        avcodec_receive_frame(context, extra) != AVERROR(EAGAIN)) {
        fprintf(stderr, "expected one coded and visible 3840x2160 VA-API IDR, got coded %dx%d, visible %dx%d\n",
                context->coded_width, context->coded_height, surface->width, surface->height);
        goto done;
    }
    const AVHWFramesContext *pool = (const AVHWFramesContext *)surface->hw_frames_ctx->data;
    if (!pool || pool->format != AV_PIX_FMT_VAAPI || pool->sw_format != AV_PIX_FMT_NV12 ||
        pool->width < WIDTH || pool->height < HEIGHT ||
        pool->width > ROUND_64(WIDTH) || pool->height > ROUND_64(HEIGHT)) {
        fputs("unexpected VA-API frame-pool layout for NV12\n", stderr);
        goto done;
    }
    if (map_first && (status = map_snapshot(surface, aligned_map, mapped_layout)) != 0)
        goto done;
    status = HARDWARE_DECODE_FAILED;
    download->format = AV_PIX_FMT_NV12;
    result = av_hwframe_transfer_data(download, surface, 0);
    if (result < 0) {
        report_error("baseline VA-API NV12 download unavailable", result);
        goto done;
    }
    if (!valid_nv12(download)) {
        fputs("baseline download did not return valid 3840x2160 NV12 planes\n", stderr);
        goto done;
    }
    if (!map_first && (status = map_snapshot(surface, aligned_map, mapped_layout)) != 0)
        goto done;
    status = CONTENT_CHECK_FAILED;
    if (compare_rows(download, aligned_map, 0, WIDTH, HEIGHT, "active NV12 Y") < 0 ||
        compare_rows(download, aligned_map, 1, WIDTH, HEIGHT / 2, "active NV12 UV") < 0)
        goto done;
    if ((result = copy_active_nv12(aligned_download, download)) < 0 ||
        (result = convert_rgb(aligned_download, surface, rgb_download)) < 0 ||
        (result = convert_rgb(aligned_map, surface, rgb_map)) < 0) {
        report_error("producing RGB24 with the original surface's color metadata", result);
        goto done;
    }
    if (compare_rows(rgb_download, rgb_map, 0, WIDTH * 3, HEIGHT, "full visible RGB24") < 0 ||
        compare_rows(rgb_download, rgb_map, 0, CROP_WIDTH * 3, CROP_HEIGHT, "odd visible RGB24 crop") < 0)
        goto done;
    printf("{\"status\":\"pass\",\"decoder\":\"h264/vaapi\",\"map\":\"cpu-nv12-read-direct\","
           "\"order\":\"%s\",\"decoded_size\":[%d,%d],\"coded_size\":[%d,%d],"
           "\"frame_pool_size\":[%d,%d],\"tested_crop\":[%d,%d],"
           "\"nv12_active_bytes_equal\":%d,\"rgb_full_bytes_equal\":%d,\"rgb_crop_bytes_equal\":%d,"
           "\"y_adler32\":\"%08x\",\"uv_adler32\":\"%08x\",\"rgb_adler32\":\"%08x\","
           "\"surface_colorspace\":%d,\"surface_color_range\":%d,\"performance_measured\":false,"
           "\"mapped_planes\":[",
           map_first ? "map-first" : "download-first", surface->width, surface->height,
           context->coded_width, context->coded_height, pool->width, pool->height, CROP_WIDTH, CROP_HEIGHT,
           WIDTH * HEIGHT * 3 / 2, WIDTH * HEIGHT * 3, CROP_WIDTH * CROP_HEIGHT * 3,
           active_adler(download, 0, WIDTH, HEIGHT), active_adler(download, 1, WIDTH, HEIGHT / 2),
           active_adler(rgb_download, 0, WIDTH * 3, HEIGHT), surface->colorspace, surface->color_range);
    print_plane_layout(mapped_layout[0]);
    putchar(',');
    print_plane_layout(mapped_layout[1]);
    printf("],\"downloaded_planes\":[");
    print_plane_layout(plane_layout(download, 0));
    putchar(',');
    print_plane_layout(plane_layout(download, 1));
    puts("]}");
    status = 0;

done:
    av_frame_free(&rgb_map);
    av_frame_free(&rgb_download);
    av_frame_free(&aligned_map);
    av_frame_free(&aligned_download);
    av_frame_free(&download);
    av_frame_free(&extra);
    av_frame_free(&surface);
    av_packet_free(&packet);
    avcodec_free_context(&context);
    return status;
}
