#!/usr/bin/env python3
"""Replay a privacy-filtered matched CBR/lossless Firefox endpoint pair."""
from hashlib import sha256
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'fixture'))
from align import count_source_exact, read_raster, source_reference
from hevc_evidence import CODEC, SIZE, assess, matching_frame_scope, static_stillness
from score import MEASURE_SECONDS, REQUESTED_FPS, SECOND, TAIL_SECONDS, WARM_SECONDS, score_pixels

PHASES = ('static','motion')
SIDES = {'host':'source','viewer':'viewer'}
ROLL = ('cbr','lossless')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_json(path):
    return json.loads(path.read_text())


def rows(path):
    return [json.loads(line) for line in path.read_bytes().splitlines()]


def phase_score(directory, role, phase):
    scope = read_json(directory / f'{phase}-scope.json')
    a,b,c,d,e = (scope[key+'_monotonic_ns'] for key in
                 ('phase_start','score_start','score_end','telemetry_phase_end','observer_end'))
    require(scope['phase'] == phase and (b-a,c-b,d-c) == tuple(
        t*SECOND for t in (WARM_SECONDS,MEASURE_SECONDS,TAIL_SECONDS)) and e >= d, 'phase interval changed')
    raw_pixels = rows(directory / f'{phase}-pixels.jsonl')
    side = SIDES[role]
    require(a <= raw_pixels[0]['start_monotonic_ns'] < b < c < raw_pixels[-1]['end_monotonic_ns'] <= e and
            all(x['side'] == side and x['start_monotonic_ns'] <= x['end_monotonic_ns'] for x in raw_pixels)
            and all(x['end_monotonic_ns'] < y['end_monotonic_ns'] for x,y in zip(raw_pixels,raw_pixels[1:])),
            'missing independent raster coverage')
    raster = score_pixels(raw_pixels,b,c)
    require(scope['samples'] == {side:raster}, 'original timing score failed to replay')
    raw = rows(directory / f'{role}-clocked-telemetry.jsonl')
    selected = [x['record'] for x in raw if x['record']['window_seconds']>0 and
                b <= x['end_monotonic_ns']-round(x['record']['window_seconds']*SECOND) < x['end_monotonic_ns'] <= d]
    require(selected == rows(directory / f'{phase}-{role}.jsonl'), 'whole telemetry cuts differ')
    sessions = sorted({x['session_id'] for x in selected})
    frames = [value for x in selected if (value := x.get('last_sent_frame' if role=='host' else 'last_frame'))]
    duration = sum(x['window_seconds'] for x in selected)
    require(len(sessions)==1 and duration>=MEASURE_SECONDS and all(matching_frame_scope(x) for x in frames)
            and (phase=='static' or bool(frames)) and all(x['type']==f'jwm_remote_{role}_stats' for x in selected),
            'missing native frame scope, session or score window')
    require(scope['telemetry']['session_ids']==sessions and scope['telemetry']['whole_windows']==len(selected)
            and scope['telemetry']['frame_scopes_observed']==len(frames), 'retained telemetry summary differs')
    key = 'mode' if role=='host' else 'last_presentation_path'
    expected = 'root/xrender/shm/no-damage/cursor-events' if role=='host' else 'rgb'
    require({x.get(key) for x in selected if x.get(key)} == {expected}, 'actual path changed')
    if role=='viewer':
        require({x['viewer_backend'] for x in selected}=={'x11'}, 'viewer backend changed')
    return scope, raster, (sum(x['bytes'] for x in selected)*8/duration/1e6 if role=='host' else None)


def replay_trial(trial, mode, manifest):
    identity=read_json(trial/'identity.json')
    require(identity['distinct_endpoints_verified'] and identity['host']['rate_control']==mode,
            'host run identity or actual opts lost')
    for role in SIDES:
        endpoint=identity[role]
        require(endpoint['release_sha256']==endpoint['endpoint_executable_sha256']==manifest['pins'][role]
                and endpoint['drawable_size']==list(SIZE), 'runtime executable or resolution differs')
    require(identity['host']['firefox_sha256']==manifest['pins']['firefox'], 'source app pin differs')
    require(read_json(trial/'shutdown.json')=={'peer_exit':0,'host_exit':0,'viewer_disconnect_event':True},
            'endpoint teardown unsuccessful')
    scopes={phase:{} for phase in PHASES}
    motion={}
    mbps={}
    sessions=set()
    for role in SIDES:
        directory=trial if role=='host' else trial/'viewer'
        geometry=read_json(directory/'geometry-guard.json')
        for phase in PHASES:
            scope, raster, payload=phase_score(directory,role,phase)
            scopes[phase][role]=scope
            sessions.update(scope['telemetry']['session_ids'])
            if phase=='motion': motion[role]=raster
            if role=='host': mbps[phase]=payload
            left,right=geometry[f'before_{phase}'],geometry[f'after_{phase}']
            require(left['geometry']==right['geometry'] and left['drawable_xid']==right['drawable_xid']
                    and left['structure_notify_events']==right['structure_notify_events']==0
                    and left['monotonic_ns']<=scope['phase_start_monotonic_ns']
                    <scope['observer_end_monotonic_ns']<=right['monotonic_ns'], 'fixed drawable changed during score')
        require(scopes['static'][role]['observer_end_monotonic_ns']<=scopes['motion'][role]['phase_start_monotonic_ns'],
                'local phase overlap')
    require(len(sessions)==1, 'phase session mismatch')
    hardware=assess(trial,sorted(sessions),mode)
    require(hardware['verified'], 'missing real encoder or decoder including chosen mode')
    source, sk, s0, s1, _=read_raster(trial/'static-pixels.jsonl', trial/'static-scope.json', 'source')
    viewer, vk, v0, v1, _=read_raster(trial/'viewer'/'static-pixels.jsonl', trial/'viewer'/'static-scope.json', 'viewer')
    require(sk==vk and s1-s0==v1-v0==MEASURE_SECONDS*SECOND, 'static source and viewer score scope differs')
    exact=count_source_exact(viewer,vk,v0,v1,source_reference(source,sk,s0,s1))
    source_motion=motion['host']
    visible=motion['viewer']
    source_qualified=source_motion['unique_content_fps']>=REQUESTED_FPS and source_motion['scroll_changes_seen']>=MEASURE_SECONDS
    motion_met=visible['unique_content_fps']>=0.9*REQUESTED_FPS and visible['scroll_changes_seen']>=MEASURE_SECONDS
    stop_met=static_stillness(scopes) and exact['valid_samples']==exact['source_exact_samples']==5400
    output={'rate_control':mode,'static_source_exact':exact,'source_motion_fps':source_motion['unique_content_fps'],
            'viewer_motion_fps':visible['unique_content_fps'],'viewer_motion_gap_ms':visible['gap_ms'],
            'mean_video_payload_mbps':mbps,'viewer_motion_gate_met':motion_met if source_qualified else None,
            'diagnostic_motion_and_static_met':source_qualified and motion_met and stop_met}
    recorded=read_json(trial/'controller-metrics.json')
    require(recorded==output,'raw replay did not reproduce original metrics')
    return output


def replay(root=ROOT):
    manifest=read_json(root/'manifest.json')
    require(manifest['dimensions']==list(SIZE) and manifest['requested_codec']==CODEC and manifest['transport']=='dual'
            and manifest['hardware_rate_order']==list(ROLL) and manifest['requested_trials']==2
            and (manifest['warm_seconds'],manifest['score_seconds'],manifest['telemetry_tail_seconds'])==(WARM_SECONDS,MEASURE_SECONDS,TAIL_SECONDS)
            and manifest['requested_fps']==REQUESTED_FPS, 'pair manifest changed')
    for name in ('align.py','hevc_evidence.py','score.py','fixture-manifest.json'):
        require(sha256((root/'fixture'/name).read_bytes()).hexdigest()==manifest['pins']['fixtures'][name], 'fixture changed')
    require(read_json(root/'fixture'/'fixture-manifest.json')==manifest['workload'],'workload manifest changed')
    link=read_json(root/'icmp-link.json')
    require(set(link)=={'before','after'} and all(row['transmitted']==8 and 0<=row['received']<=8
            and 0<=row['loss_percent']<=100 for row in link.values()), 'missing endpoint ICMP sampling')
    outcomes=read_json(root/'outcomes.json')
    run_status=read_json(root/'terminal.json')
    require(len(outcomes)==2 and run_status['exit']==int(any(x['status']!='completed' for x in outcomes)),
            'pair trial or exit status changed')
    observed=[]
    for i, mode in enumerate(ROLL,1):
        row=outcomes[i-1]
        require((row['trial'],row['rate_control'])==(i,mode),'matched pair order differs')
        trial=root/f'trial-{i:02}'
        if row['status']=='completed':
            observed.append(row | {'result':replay_trial(trial,mode,manifest)})
        else:
            require(isinstance(row.get('failure'),str) and bool(row['failure']), 'failed slot lacks scope/reason')
            observed.append(row)
    return observed


if __name__=='__main__':
    print(json.dumps(replay(),sort_keys=True,indent=2))
