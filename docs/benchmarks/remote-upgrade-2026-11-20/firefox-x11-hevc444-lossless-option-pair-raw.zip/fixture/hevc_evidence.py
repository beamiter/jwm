"""Qualify actual HEVC 4:4:4 on the pinned Firefox endpoint pair."""

import json
from pathlib import Path


CODEC = 'HEVC 4:4:4'
SIZE = (1920, 1080)
HOST_ACTIVE = 'jwm-remote: hardware HEVC 4:4:4 encoding active (NVENC)'
HOST_NEGOTIATED = 'jwm-remote: HEVC 4:4:4 NVENC negotiated'
VIEWER_NVDEC = 'jwm-remote: HEVC 4:4:4 hardware decoder active (NVDEC)'
VIEWER_ACTUAL = 'jwm-remote: hardware HEVC 4:4:4 decoding active (1920x1080)'
EXPECTED_LINES = {'host': (HOST_NEGOTIATED, HOST_ACTIVE), 'viewer': (VIEWER_NVDEC, VIEWER_ACTUAL)}


def active_log(role, messages, rate_control='cbr'):
    expected = EXPECTED_LINES[role]
    if role == 'host' and rate_control == 'lossless':
        expected = (HOST_NEGOTIATED,
                    'jwm-remote: hardware HEVC 4:4:4 encoding active (NVENC, lossless constant QP 0)')
    if role == 'host' and any('hardware video adaptation active' in line for line in messages):
        return False
    return all(message in messages for message in expected)


def matching_frame_scope(frame, dimensions=SIZE):
    return (frame.get('codec') == CODEC and frame.get('source_dimensions') == list(dimensions)
            and frame.get('encoded_dimensions') == list(dimensions)
            and type(frame.get('source_epoch')) is int and frame['source_epoch'] > 0
            and type(frame.get('geometry_epoch')) is int and frame['geometry_epoch'] > 0)


def read_jsonl(path):
    return [json.loads(line) for line in path.read_bytes().splitlines()]


def observations(record, stage):
    return record.get('stages', {}).get(stage, {}).get('observations', 0)


def assess(run, sessions, rate_control):
    """Check all recorded codec evidence, and demand activity in both retained phases."""
    errors = []
    scopes = set()
    phase_counts = {name: {} for name in ('static', 'motion')}
    records_seen = {}
    for role, directory in (('host', Path(run)), ('viewer', Path(run) / 'viewer')):
        content = (directory / f'{role}.log').read_text().splitlines()
        messages = [line for line in content if not line.startswith('{')]
        if not active_log(role, messages, rate_control):
            errors.append(f'{role} did not report the required negotiated and actual hardware path')
        if any('switching to JPEG' in line or 'hardware H.264 encoding active' in line
               or 'hardware H.264 decoding active' in line for line in messages):
            errors.append(f'{role} logged a codec fallback or another actual hardware codec')
        records = [json.loads(line) for line in content if line.startswith('{')]
        records = [record for record in records if record.get('type') == f'jwm_remote_{role}_stats']
        records_seen[role] = len(records)
        if not records or sorted({record.get('session_id', '') for record in records}) != sessions:
            errors.append(f'{role} records did not retain the single authenticated session')
        frame_key = 'last_sent_frame' if role == 'host' else 'last_frame'
        frames = [record[frame_key] for record in records if record.get(frame_key)]
        if not frames or any(not matching_frame_scope(frame) for frame in frames):
            errors.append(f'{role} did not retain actual native-size HEVC 4:4:4 frame scopes')
        scopes.update((frame.get('source_epoch'), frame.get('geometry_epoch')) for frame in frames)
        if role == 'host':
            forbidden_counts = ('h264_frames', 'jpeg_atlases', 'png_atlases')
            if any(record.get(key) != 0 for key in forbidden_counts for record in records):
                errors.append('host reported a non-HEVC encode or lacked per-codec encoding counts')
        elif any(record.get('negotiated_codec') != CODEC for record in records):
            errors.append('viewer reported a different codec negotiation')
        for phase in phase_counts:
            selected = read_jsonl(directory / f'{phase}-{role}.jsonl')
            if role == 'host':
                counts = {'host_hevc_encodes': sum(record.get('hevc444_frames', 0) for record in selected),
                          'host_sent': sum(record['sent'] for record in selected)}
            else:
                counts = {'viewer_hardware_decodes': sum(observations(record, 'hardware_decode_ms')
                                                         for record in selected),
                          'viewer_drawn': sum(record['drawn'] for record in selected)}
            if not all(value > 0 for value in counts.values()):
                errors.append(f'{role} had no actual hardware frame evidence in retained {phase} windows')
            phase_counts[phase].update(counts)
    if len(scopes) != 1:
        errors.append('session did not preserve a single source and geometry epoch')
    return {
        'verified': not errors,
        'errors': errors,
        'records_examined': records_seen,
        'matching_source_geometry_epoch': list(next(iter(scopes))) if len(scopes) == 1 else None,
        'retained_activity': phase_counts,
    }


def static_stillness(scopes):
    host = scopes['static']['host']['samples']['source']
    viewer = scopes['static']['viewer']['samples']['viewer']
    return all(row['unique_tile_changes'] == row['scroll_changes_seen'] == 0
               and row['distinct_scroll_signatures'] == 1
               and row['invalid_tile_reads'] == row['invalid_scroll_reads'] == 0
               for row in (host, viewer))
