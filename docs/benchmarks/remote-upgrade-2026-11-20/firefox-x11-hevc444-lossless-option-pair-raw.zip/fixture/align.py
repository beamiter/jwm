"""Join local raster observations to authenticated sent IDRs and X11 copy fences."""
import argparse
from bisect import bisect_left, bisect_right
from collections import Counter
import json
from pathlib import Path
from statistics import median

TYPE = 'jwm_remote_hardware_frame_trace'


def frame(row):
    return tuple(row[key] for key in ('source_epoch', 'geometry_epoch', 'sequence'))


def read_trace(path, endpoint):
    batches = []
    for line in path.read_text().splitlines():
        if not line.startswith('{'):
            continue
        row = json.loads(line)
        if row.get('type') == TYPE:
            batches.append(row)
    if not batches or [batch['final'] for batch in batches] != [False] * (len(batches) - 1) + [True]:
        raise ValueError('missing or misplaced terminal trace record')
    if any(batch['endpoint'] != endpoint or batch['clock'] != 'CLOCK_MONOTONIC'
           or batch['schema_version'] != 1 for batch in batches):
        raise ValueError('unexpected trace endpoint, schema, or clock')
    session, = {batch['session_id'] for batch in batches}
    rows = [event for batch in batches for event in batch['events']]
    final = batches[-1]
    if any(batch['dropped_total'] for batch in batches) or final['events']:
        raise ValueError('trace capture overflow or unavailable clock')
    if final['seen_total'] != len(rows) or any(event['ordinal'] != i for i, event in enumerate(rows)):
        raise ValueError('best-effort trace lost records')
    if any(a['monotonic_ns'] >= b['monotonic_ns'] for a,b in zip(rows, rows[1:])):
        raise ValueError('endpoint trace clock or event order is ambiguous')
    return session, rows


MASK_FIELDS = ('scroll_signature', 'scroll_text')


def raster_mask_field(rows, lane=None):
    candidates = [field for field in MASK_FIELDS if all(field in row for row in rows)]
    if not rows or len(candidates) != 1 or any(
        other in row for row in rows for other in MASK_FIELDS if other not in candidates
    ):
        raise ValueError('expected one consistent XTerm or Firefox raster mask field')
    if lane is not None and any(row['side'] != lane for row in rows):
        raise ValueError('raster lane does not match the selected endpoint')
    if any(row['start_monotonic_ns'] > row['end_monotonic_ns'] for row in rows) or any(
        a['end_monotonic_ns'] >= b['start_monotonic_ns'] for a, b in zip(rows, rows[1:])
    ):
        raise ValueError('raster clock or sample order is ambiguous')
    return candidates[0]


def read_raster(path, scope_path, lane):
    with path.open() as source:
        raster = [json.loads(line) for line in source]
    scope = json.loads(scope_path.read_text())
    if scope.get('phase') != 'static':
        raise ValueError('IDR mask attribution requires the static phase')
    first, last = (scope[f'score_{edge}_monotonic_ns'] for edge in ('start', 'end'))
    if first >= last:
        raise ValueError('invalid static score interval')
    return raster, raster_mask_field(raster, lane), first, last, scope


def source_reference(raster, mask_field, first, last):
    masks = {row[mask_field] for row in raster
             if first <= row['start_monotonic_ns'] <= row['end_monotonic_ns'] < last}
    if len(masks) != 1 or None in masks:
        raise ValueError('independently observed source mask was missing, invalid or unstable')
    return masks.pop()


def count_source_exact(raster, mask_field, first, last, reference):
    # Clip warm-up, invalid reads, and the partial burst at the left boundary.
    previous = None
    exact_samples = 0
    onsets = []
    states = Counter()
    for row in raster:
        stamp = row['end_monotonic_ns']
        if not first <= row['start_monotonic_ns'] <= stamp < last:
            continue
        mask = row[mask_field]
        if mask is None:
            previous = None
            continue
        states[mask] += 1
        exact_samples += mask == reference
        if previous is not None and previous != reference and mask == reference:
            onsets.append(stamp)
        previous = mask
    intervals = [(b - a) / 1e6 for a, b in zip(onsets, onsets[1:])]
    dominant, count = states.most_common(1)[0] if states else (None, 0)
    return {'valid_samples': sum(states.values()), 'source_exact_samples': exact_samples,
            'source_exact_observed_onsets': len(onsets),
            'source_exact_onset_interval_median_ms': median(intervals) if intervals else None,
            'dominant_viewer_mask_samples': count,
            'dominant_viewer_mask_matches_source': dominant == reference if dominant is not None else None}


def align(host, viewer, raster, start, end, reference=None):
    mask_field = raster_mask_field(raster)
    sent = {}
    for row in host:
        key = frame(row)
        if row['event'] != 'sent' or key in sent or type(row['idr']) is not bool:
            raise ValueError('ambiguous authenticated host frame')
        sent[key] = row
    if len({row['codec'] for row in sent.values()}) != 1:
        raise ValueError('host did not report one hardware codec')
    ticks = [row['monotonic_ns'] for row in viewer]
    pending = {}
    stable = []
    last_from_host = None
    for row in viewer:
        key, revision = frame(row), row['viewport_revision']
        if row['event'] == 'submit_started':
            if key in pending:
                raise ValueError('duplicate viewer submission')
            pending[key] = revision
            last_from_host = None
        elif row['event'] == 'presented':
            if pending.get(key) != revision:
                raise ValueError('viewer completion has no exact submission')
            # X11 may supersede an earlier incomplete copy. A newer submitted
            # copy still overlaps the current completion until it is drained.
            pending = {candidate: rev for candidate, rev in pending.items()
                       if candidate[-1] > key[-1]}
            last_from_host = key if not pending else None
        else:
            raise ValueError('unexpected viewer trace event')
        stable.append(last_from_host)
    reasons, changes = Counter(), Counter()
    exact_entries, exact_exits = Counter(), Counter()
    seen_viewport_revisions = set()
    previous = None
    for sample in raster:
        a, b = (sample[key] for key in ('start_monotonic_ns', 'end_monotonic_ns'))
        if not start <= b < end:
            continue
        index = bisect_left(ticks, a) - 1
        crossed = bisect_right(ticks, b) > index + 1
        key = stable[index] if index >= 0 else None
        if a < start or crossed:
            reason = 'sample_crosses_trace_boundary'
        elif key is None:
            reason = 'copy_not_certifiably_stable'
        elif key not in sent:
            reason = 'viewer_frame_has_no_matching_hardware_send'
        elif sample[mask_field] is None:
            reason = 'invalid_glyph_mask'
        else:
            reason = 'usable'
        reasons[reason] += 1
        if reason == 'usable':
            seen_viewport_revisions.add(viewer[index]['viewport_revision'])
        mask = sample[mask_field]
        if previous is not None and mask is not None:
            old_mask, old_reason, old_index = previous
            if old_mask != mask:
                attribution = 'unassignable'
                if old_reason == reason == 'usable':
                    if old_index == index:
                        attribution = 'same_completed_copy'
                    elif [row['event'] for row in viewer[old_index + 1:index + 1]] == ['submit_started', 'presented']:
                        attribution = 'idr' if sent[key]['idr'] else 'non_idr'
                changes[attribution] += 1
                if reference is not None and mask == reference:
                    exact_entries[attribution] += 1
                if reference is not None and old_mask == reference:
                    exact_exits[attribution] += 1
        previous = (mask, reason, index) if mask is not None and a >= start else None
    if len(seen_viewport_revisions) > 1:
        raise ValueError('drawable changed local viewport revision')
    if not reasons['usable']:
        raise ValueError('no stable X11 completion matched a hardware send in the scored raster')
    result = {'qualified_trace': True, 'host_sent_hardware_frames': len(sent),
              'host_sent_idrs': sum(row['idr'] for row in sent.values()),
              'raster_mask_field': mask_field, 'raster_samples': dict(reasons), 'mask_changes': dict(changes)}
    if reference is not None:
        result['source_reference'] = count_source_exact(raster, mask_field, start, end, reference) | {
            'mask_transitions_to_source_exact': dict(exact_entries),
            'mask_transitions_from_source_exact': dict(exact_exits),
        }
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('host_log', 'viewer_log', 'viewer_pixels', 'viewer_scope'):
        parser.add_argument(name, type=Path)
    parser.add_argument('--source-pixels', type=Path)
    parser.add_argument('--source-scope', type=Path)
    args = parser.parse_args()
    if (args.source_pixels is None) != (args.source_scope is None):
        parser.error('pass both source raster inputs when checking source-exact masks')
    try:
        host_id, host = read_trace(args.host_log, 'host')
        viewer_id, viewer = read_trace(args.viewer_log, 'viewer')
        if host_id != viewer_id:
            raise ValueError('different authenticated sessions')
        raster, mask_field, first, last, scope = read_raster(args.viewer_pixels, args.viewer_scope, 'viewer')
        if scope['telemetry']['session_ids'] != [viewer_id]:
            raise ValueError('viewer raster scope does not match the trace session')
        reference = None
        if args.source_pixels is not None:
            source, source_field, s0, s1, source_scope = read_raster(args.source_pixels, args.source_scope, 'source')
            if source_field != mask_field or source_scope['telemetry']['session_ids'] != [host_id] or s1 - s0 != last - first:
                raise ValueError('source reference uses a different raster format, session or score duration')
            reference = source_reference(source, source_field, s0, s1)
        result = align(host, viewer, raster, first, last, reference)
    except (OSError, ValueError, KeyError) as error:
        # A cut or dropped trace cannot establish a negative IDR relation.
        result = {'qualified_trace': False, 'mask_changes_unassignable': True, 'reason': str(error)}
    print(json.dumps(result, indent=2))
    return 0 if result['qualified_trace'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
