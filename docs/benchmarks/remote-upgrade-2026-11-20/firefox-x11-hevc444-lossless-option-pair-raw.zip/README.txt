Run python3 -I -B replay.py after extraction. Each role uses its own monotonic clock.
The archive retains both attempted slots and only typed control, route and hashed pixel observations.
GPU probing, Xvfb, SSH and Firefox are needed to rerun the live fixture.
