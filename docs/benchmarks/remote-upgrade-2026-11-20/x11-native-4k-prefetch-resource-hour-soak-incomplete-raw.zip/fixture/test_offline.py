"""Parser and gate tests with fake clocks and plain temporary files only."""
import io
import json
from pathlib import Path
import tempfile
import unittest

from prior_resources import Identity
from sampler import (BURN, MEASURE, INTERVAL, SECOND, BURN_SLOTS, MEASURE_SLOTS,
                     SLOTS, capture, collect_drm, parse_drm, summarize)
from soak_evidence import telemetry


def read(trace):
    return [json.loads(row) for row in trace.getvalue().splitlines()]


class FakeClock:
    def __init__(self):
        self.now = 33*SECOND

    def get(self):
        return self.now

    def sleep(self, seconds):
        self.now += round(seconds*SECOND)


def synthetic_capture(*, missing=None, death=None):
    clock=FakeClock()
    anchor=clock.get()
    trace=io.StringIO()

    def sample(_identity):
        slot=(clock.now-anchor)//(INTERVAL*SECOND)
        if slot==missing:
            raise PermissionError('synthetic endpoint access loss')
        return {'rss_kib':4000+slot,'rss_anon_kib':2900+slot,
                'rss_file_kib':1000,'rss_shmem_kib':100,'threads':7,'fds':23,'cpu_user_ticks':2*slot,
                'cpu_system_ticks':slot,'drm':{'status':'no_standard_drm_client_export',
                'clients':[],'unlinked':[],'scan_issues':{}}}

    def health():
        if death is not None and clock.now>=anchor+death*INTERVAL*SECOND:
            raise RuntimeError('synthetic actor exit')

    try:
        capture(trace,'viewer',Identity(1,233,4,5),anchor,health,clock=clock.get,sleep=clock.sleep,
                read_sample=sample,read_mapping=lambda _: {'Anonymous':2900},clock_ticks=100)
    except RuntimeError:
        if death is None:
            raise
    return read(trace)


class SoakTests(unittest.TestCase):
    def test_absolute_slots_and_drift(self):
        rows=synthetic_capture()
        result=summarize(rows,'viewer')
        self.assertEqual((result['measurement_seconds'],result['valid_measured_samples'],
                          result['max_sample_gap_seconds']), (3600,720,5.0))
        self.assertEqual([p['elapsed_seconds'] for p in result['mapping_checkpoints']],
                         [0, 900, 1800, 2700, 3600])
        self.assertEqual(result['process_resources']['rss_shmem_kib']['equal_final_observed_seconds'], 3595)
        self.assertEqual(result['cpu_cores_in_use_between_samples']['median'],.006)
        self.assertEqual(result['process_resources']['fds']['median_delta'],0)
        self.assertEqual(result['drm_samples_by_status'],{'no_standard_drm_client_export':720})

    def test_process_read_error_preserved_but_not_qualified(self):
        rows=synthetic_capture(missing=47)
        self.assertEqual(rows[48]['status'],'error')
        self.assertEqual(rows[48]['failure_type'],'PermissionError')
        self.assertEqual(rows[-1]['status_counts'],{'valid':SLOTS-1,'error':1})
        with self.assertRaisesRegex(ValueError,'lost measured resource samples'):
            summarize(rows,'viewer')

    def test_actor_exit_preserves_unreached_slots(self):
        rows=synthetic_capture(death=71)
        self.assertEqual(rows[-1]['status_counts'],{'valid':71,'unreached':SLOTS-71})
        with self.assertRaisesRegex(ValueError,'complete resource interval'):
            summarize(rows,'viewer')

    def test_pending_resources_do_not_change_expected_schedule(self):
        rows=synthetic_capture()
        rows[BURN_SLOTS+1]['scheduled_ns']+=1
        with self.assertRaisesRegex(ValueError,'invalid resource sample phase or schedule'):
            summarize(rows,'viewer')

    def test_standard_drm_values_duplicate_and_unsupported(self):
        template = ('drm-driver:\ti915\ndrm-pdev: 0000:00:02.0\ndrm-client-id: 7\n'
                    'drm-total-system: 64 MiB\ndrm-resident-system: 42 KiB\n'
                    'drm-shared-system: 5 KiB\ndrm-total-cycles-render: 78\n'
                    'drm-active-system: 3 bananas\n')
        parsed=parse_drm(template)
        self.assertEqual(parsed['memory_bytes_by_key'],{'drm-total-system':64*1048576,
                         'drm-resident-system':42*1024,'drm-shared-system':5*1024})
        self.assertEqual(parsed['unrecognized_memory_keys'],['drm-active-system'])
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary)
            fd=root/'fdinfo'
            fd.mkdir()
            (fd/'3').write_text(template)
            (fd/'4').write_text(template.replace('64 MiB','65 MiB'))
            (fd/'5').write_text(template.replace('drm-client-id: 7\n',''))
            (fd/'6').write_text('pos: 0\nflags: 244\n')
            info=collect_drm(root)
            self.assertEqual(info['status'],'partial_counters')
            self.assertEqual(len(info['clients']),1)
            self.assertEqual(info['clients'][0]['memory_bytes_by_key']['drm-total-system'],64*1048576)
            self.assertEqual(len(info['unlinked']),1)
            self.assertEqual(info['scan_issues'],{'duplicate_client_values_changed':1})
        self.assertIsNone(parse_drm('pos: 0\nflags: 244\n'))

    def test_retained_telemetry_uses_own_clock_and_progress(self):
        start=333*SECOND
        scope={'measurement_start_ns':start,'measurement_end_ns':start+MEASURE*SECOND}
        windows = [{'arrived_monotonic_ns':start+slot*5*SECOND,
                    'record':{'window_seconds':5.,'acked':40 if slot else 0}}
                   for slot in range(MEASURE_SLOTS+1)]
        with tempfile.TemporaryDirectory() as temporary:
            path=Path(temporary)/'raw.jsonl'
            def dump():
                path.write_text(''.join(json.dumps(item)+'\n' for item in windows))
            dump()
            whole, retained, covered, progress = telemetry(path,scope,'acked')
            self.assertEqual((len(whole),len(retained),covered,sum(progress)),(721,720,3600.,28800))
            for row in windows[96:108]:
                row['record']['acked']=0
            dump()
            with self.assertRaisesRegex(RuntimeError,'sustained drawn ACK progress'):
                telemetry(path,scope,'acked')


if __name__=='__main__':
    unittest.main()
