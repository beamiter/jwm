#define main workload_entry
#include "p09-workload.c"
#undef main

#include <assert.h>

int main(void)
{
    XImage crop = {0};
    uint32_t pixels[MARKER_SIZE * MARKER_SIZE];
    crop.bytes_per_line = MARKER_SIZE * sizeof(uint32_t);
    crop.data = (char *)pixels;
    unsigned frames[] = {1, 65535, 65536, 131072, 223800, MARKER_FRAME_MAX};
    const unsigned run = 41;
    for (size_t i = 0; i < sizeof(frames) / sizeof(frames[0]); ++i) {
        const uint32_t word = marker(run, frames[i]);
        assert(word >> (MARKER_FRAME_BITS + 8) == run);
        assert(((word >> 8) & MARKER_FRAME_MAX) == frames[i]);
        const uint64_t pair = ((uint64_t)(uint32_t)~word << 32) | word;
        for (unsigned y = 0; y < MARKER_SIZE; ++y) {
            for (unsigned x = 0; x < MARKER_SIZE; ++x) {
                unsigned cell = y / MARKER_CELL * 8 + x / MARKER_CELL;
                pixels[y * MARKER_SIZE + x] = pair & (UINT64_C(1) << cell) ? 0xffffff : 0;
            }
        }
        assert(read_marker(&crop) == word);
        for (unsigned y = 0; y < MARKER_CELL; ++y)
            for (unsigned x = 0; x < MARKER_CELL; ++x)
                pixels[y * MARKER_SIZE + x] ^= 0xffffff;
        assert(read_marker(&crop) == 0);
    }
    puts("18-bit marker decodes across prior wrap points and rejects damaged complementary words");
    return 0;
}
