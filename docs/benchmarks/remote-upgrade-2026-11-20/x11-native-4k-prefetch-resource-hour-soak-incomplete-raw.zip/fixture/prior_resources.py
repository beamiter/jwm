"""Bounded Linux process sampling and presentation-credit summaries."""
from collections import Counter
from dataclasses import asdict, dataclass
import json
import os
from pathlib import Path
from statistics import median
import threading
import time

SECOND = 1_000_000_000
MIN_MEASURE_SECONDS = 900
MAX_MEASURE_SECONDS = 960
BURN_SECONDS = 60
MAX_RESOURCE_SAMPLES = 206
MAX_TELEMETRY_WINDOWS = 800
KINDS = {"host": "jwm_remote_host_stats", "viewer": "jwm_remote_viewer_stats"}
RSS_FIELDS = {"VmRSS": "rss_kib", "RssAnon": "rss_anon_kib",
              "RssFile": "rss_file_kib", "RssShmem": "rss_shmem_kib"}
RESOURCE_FIELDS = (*RSS_FIELDS.values(), "threads", "fds")


@dataclass(frozen=True)
class Identity:
    pid: int
    start_ticks: int
    exe_device: int
    exe_inode: int


def start_ticks(stat_line, pid):
    head, separator, fields = stat_line.rpartition(") ")
    fields = fields.split()
    if not separator or not head.startswith(f"{pid} (") or len(fields) < 20 or fields[0] in {"Z", "X"}:
        raise RuntimeError(f"PID {pid} has no live Linux stat record")
    return int(fields[19])


def read_identity(pid, proc=Path("/proc")):
    base = proc / str(pid)
    first = start_ticks((base / "stat").read_text(), pid)
    exe = (base / "exe").stat()
    if start_ticks((base / "stat").read_text(), pid) != first:
        raise RuntimeError(f"PID {pid} identity changed while opening its executable")
    return Identity(pid, first, exe.st_dev, exe.st_ino)


def track(pid, binary, proc=Path("/proc")):
    identity = read_identity(pid, proc)
    exe = binary.stat()
    if (identity.exe_device, identity.exe_inode) != (exe.st_dev, exe.st_ino):
        raise RuntimeError(f"PID {pid} is a different executable")
    return identity


def resources(identity, proc=Path("/proc")):
    pid = identity.pid
    if read_identity(pid, proc) != identity:
        raise RuntimeError(f"PID {pid} changed before sampling")
    base = proc / str(pid)
    values = {}
    for line in (base / "status").read_text().splitlines():
        name, _, text = line.partition(":")
        if name in RSS_FIELDS:
            amount, unit = text.split()
            if unit != "kB":
                raise RuntimeError("Linux VmRSS unit changed")
            values[RSS_FIELDS[name]] = int(amount)
        elif name == "Threads":
            values["threads"] = int(text)
    with os.scandir(base / "fd") as descriptors:
        values["fds"] = sum(entry.name.isdecimal() for entry in descriptors)
    if read_identity(pid, proc) != identity:
        raise RuntimeError(f"PID {pid} changed during sampling")
    if any(values.get(field, -1) < 0 for field in RESOURCE_FIELDS) or values["threads"] < 1:
        raise RuntimeError(f"PID {pid} has incomplete resource accounting")
    return values


def write_row(output, row):
    output.write(json.dumps(row, separators=(",", ":")) + "\n")
    output.flush()


@dataclass(frozen=True)
class Plan:
    measured_seconds: int = MIN_MEASURE_SECONDS
    interval_seconds: int = 5

    def __post_init__(self):
        if not MIN_MEASURE_SECONDS <= self.measured_seconds <= MAX_MEASURE_SECONDS:
            raise ValueError("measured duration must be 900 to 960 seconds")
        if self.interval_seconds not in (5, 10, 15, 30):
            raise ValueError("sampling interval must be 5, 10, 15 or 30 seconds")

    def bounds(self, anchor):
        return anchor + BURN_SECONDS * SECOND, anchor + (BURN_SECONDS + self.measured_seconds) * SECOND


def sleep_until(deadline, health, clock=time.monotonic_ns, sleep=time.sleep):
    while True:
        health()
        remaining = deadline - clock()
        if remaining <= 0:
            return
        sleep(min(remaining / SECOND, .25))


def collect(output, role, identity, plan, anchor, health, *,
            clock=time.monotonic_ns, sleep=time.sleep, sample=resources):
    start, end = plan.bounds(anchor)
    interval = plan.interval_seconds * SECOND
    write_row(output, {"type": "p09_soak_start", "role": role, "identity": asdict(identity),
                       "anchor_ns": anchor, "measurement_start_ns": start, "measurement_end_ns": end,
                       "sample_interval_seconds": plan.interval_seconds})
    emitted = skipped = 0
    due = anchor
    while due < end:
        sleep_until(due, health, clock, sleep)
        observed = clock()
        next_index = min((observed - due) // interval, (end - 1 - due) // interval)
        skipped += next_index
        due += next_index * interval
        if observed >= end:
            skipped += 1
            break
        started = clock()
        values = sample(identity)
        finished = clock()
        if emitted >= MAX_RESOURCE_SAMPLES:
            raise RuntimeError("sample count exceeds the fixed trial bound")
        phase = "burn_in" if finished < start else "measured" if finished < end else "tail"
        write_row(output, {"type": "p09_soak_sample", "role": role, "scheduled_ns": due,
                          "sample_start_ns": started, "sample_ns": finished, "phase": phase, **values})
        emitted += 1
        due += interval
    sleep_until(end, health, clock, sleep)
    write_row(output, {"type": "p09_soak_end", "role": role, "monotonic_ns": clock(),
                       "samples": emitted, "missed_sample_slots": skipped})


class TelemetryRelay:
    def __init__(self, process, role, diagnostic, telemetry):
        self.process = process
        self.role = role
        self.diagnostic = diagnostic
        self.telemetry = telemetry
        self.anchor = None
        self.error = None
        self.windows = 0
        self.worker = threading.Thread(target=self.relay, daemon=True)
        self.worker.start()

    def relay(self):
        try:
            for line in iter(self.process.stderr.readline, b""):
                now = time.monotonic_ns()
                self.diagnostic.write(line)
                self.diagnostic.flush()
                if not line.startswith(b"{"):
                    continue
                record = json.loads(line)
                if record.get("type") != KINDS[self.role]:
                    continue
                self.windows += 1
                if self.windows > MAX_TELEMETRY_WINDOWS:
                    self.error = RuntimeError(f"too many {self.role} telemetry windows")
                    continue
                write_row(self.telemetry, {"arrived_monotonic_ns": now, "record": record})
                active = record.get("h264_frames", record.get("drawn", 0)) > 0
                acked = record.get("drawn_acks", record.get("acked", 0)) > 0
                if self.anchor is None and active and acked and record.get("session_id")                         and record.get("window_seconds", 0) >= 5 and not record.get("final"):
                    self.anchor = now
        except (OSError, ValueError) as error:
            self.error = error

    def check(self, *, alive=True):
        if self.error is not None:
            raise RuntimeError(f"{self.role} telemetry relay failed: {self.error}")
        if alive and self.process.poll() is not None:
            raise RuntimeError(f"{self.role} process ended early ({self.process.returncode})")

    def finish(self):
        self.worker.join(timeout=5)


def read_rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def describe(values):
    return {"min": min(values), "median": median(values), "peak": max(values)}


def summarize_resources(rows, role):
    initial, *samples, final = rows
    if initial["type"] != "p09_soak_start" or final["type"] != "p09_soak_end"             or any(row["role"] != role for row in rows):
        raise ValueError(f"incomplete {role} resource trace")
    start, end = initial["measurement_start_ns"], initial["measurement_end_ns"]
    if end - start < MIN_MEASURE_SECONDS * SECOND or final["monotonic_ns"] < end             or final["samples"] != len(samples) or len(samples) > MAX_RESOURCE_SAMPLES:
        raise ValueError(f"{role} did not finish its measured interval")
    times = [row["sample_ns"] for row in samples]
    if any(b <= a for a, b in zip(times, times[1:])):
        raise ValueError(f"{role} sample timestamps are out of order")
    measured = [row for row in samples if start <= row["sample_ns"] < end]
    first = [row for row in measured if row["sample_ns"] < start + BURN_SECONDS * SECOND]
    last = [row for row in measured if row["sample_ns"] >= end - BURN_SECONDS * SECOND]
    if not first or not last:
        raise ValueError(f"{role} missed both-end trend coverage")
    bounds = [start, *(row["sample_ns"] for row in measured), end]
    stats = {}
    for field in RESOURCE_FIELDS:
        values = [row[field] for row in measured]
        early = median(row[field] for row in first)
        late = median(row[field] for row in last)
        stats[field] = describe(values) | {"first_minute_median": early,
                                          "last_minute_median": late, "median_delta": late - early}
    return {
        "identity": initial["identity"], "anchor_ns": initial["anchor_ns"],
        "measurement_start_ns": start, "measurement_end_ns": end,
        "measurement_seconds": (end - start) / SECOND,
        "resource_samples": len(measured), "burn_in_samples": len(samples) - len(measured)
        - sum(row["sample_ns"] >= end for row in samples),
        "missed_sample_slots": final["missed_sample_slots"],
        "max_gap_between_samples_or_boundary_seconds": max(b - a for a, b in zip(bounds, bounds[1:])) / SECOND,
        "resources": stats,
    }


def summarize_video(rows, role, resource, width, height):
    start, end = resource["measurement_start_ns"], resource["measurement_end_ns"]
    scope = [row for row in rows if row["record"].get("window_seconds", 0) >= 5
             and not row["record"].get("final")
             and start + round(row["record"]["window_seconds"] * SECOND) <= row["arrived_monotonic_ns"] <= end]
    records = [row["record"] for row in scope]
    sessions = {row["session_id"] for row in records}
    if len(sessions) != 1 or not next(iter(sessions), None):
        raise ValueError(f"{role} lacks one authenticated session in measured telemetry")
    size = [width, height]
    for row in records:
        if role == "host":
            if row["hevc444_frames"] or row["jpeg_atlases"] or row["png_atlases"]:
                raise ValueError("host changed codec during the measured soak")
            expected_sizes = (row["source_dimensions"], row["encoded_dimensions"])
            if row["captured"] and expected_sizes != (size, size):
                raise ValueError(f"host changed capture geometry: {expected_sizes}")
        elif row["negotiated_codec"] != "H.264" or (row["last_frame"] and
                (row["last_frame"]["codec"] != "H.264" or row["last_frame"]["encoded_dimensions"] != size)):
            raise ValueError("viewer changed codec or geometry during the measured soak")
    coverage = sum(row["window_seconds"] for row in records)
    report = {"session_id": sessions.pop(), "completed_telemetry_windows": len(records),
              "covered_telemetry_seconds": coverage,
              "head_coverage_gap_seconds": (scope[0]["arrived_monotonic_ns"]
                                             - round(records[0]["window_seconds"] * SECOND) - start) / SECOND,
              "tail_coverage_gap_seconds": (end - scope[-1]["arrived_monotonic_ns"]) / SECOND}
    if role == "host":
        report |= {
            "h264_frames": sum(row["h264_frames"] for row in records),
            "drawn_acks": sum(row["drawn_acks"] for row in records),
            "zero_sent_windows": sum(row["sent"] == 0 for row in records),
            "outstanding_credits_at_window_end": dict(Counter(row["outstanding"] for row in records)),
            "peak_reported_outstanding_credits": max(row["max_outstanding"] for row in records),
            "peak_sampled_end_outstanding_credits": max(row["outstanding"] for row in records),
            "max_window_credit_wait_p99_ms": max((x for row in records
                if (x := row["stages"]["credit_wait_ms"]["quantiles"]["p99_ms"]) is not None), default=None),
            "bytes": sum(row["bytes"] for row in records),
        }
        if not report["h264_frames"] or not report["drawn_acks"]:
            raise ValueError("no active hardware video in sustained host windows")
    else:
        report |= {
            "received": sum(row["received"] for row in records),
            "drawn": sum(row["drawn"] for row in records), "acked": sum(row["acked"] for row in records),
            "zero_drawn_windows": sum(row["drawn"] == 0 for row in records),
            "max_decode_queue_records": max(row["decode_queue_max_sampled_at_dequeue"]["records"]
                                             for row in records),
        }
        if not report["drawn"] or not report["acked"]:
            raise ValueError("no active hardware video in sustained viewer windows")
    return report, scope
