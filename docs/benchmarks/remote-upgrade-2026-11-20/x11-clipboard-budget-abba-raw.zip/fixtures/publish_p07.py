#!/usr/bin/env python3
"""Independently replay and publish a terminal private X11 clipboard ABBA batch."""
import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import platform
import re
import statistics
import tempfile
import zipfile

PROFILES = {"rate-10000": 10000, "rate-6000": 6000}
BINARY_SHA = "5e1951ed8bbc23f41db5b5918931d91a37baa1e9fa213c8ef9067a214a1511e5"
FILE_BYTES, START_BYTES = 12 << 20, 256 << 10
SHAPE_BYTES, PROXY_CHUNK = 1_250_000, 16384
JSON_NAME = "x11-clipboard-budget-abba.json"
ZIP_NAME = "x11-clipboard-budget-abba-raw.zip"
SESSION = re.compile(r"[0-9a-f]{32}")
JSON_FIELDS_TO_REMOVE = {"upstream_port", "listen_port"}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def json_bytes(data):
    return (json.dumps(data, indent=2, sort_keys=True) + "\n").encode()


def load(path):
    return json.loads(path.read_bytes())


def lines(rows):
    return b"".join((json.dumps(row, sort_keys=True) + "\n").encode() for row in rows)


def time_ms(start, end):
    require(type(start) is int and type(end) is int and 0 <= start <= end, "invalid issue/receipt clock order")
    return (end - start) / 1_000_000


def recompute_edges(edges, pairs, offered, completed=None):
    phase = "idle" if completed is None else "under upload"
    require(len(edges) == pairs * 2, f"{phase} did not observe each press and release")
    starts, received, progress, releases = [], [], [], []
    for number, edge in enumerate(edges):
        require(set(edge) == {"type", "keycode", "issue_ns", "received_ns", "staged_bytes", "latency_ms"},
                "unexpected edge record")
        require(edge["type"] == ("release" if number % 2 else "press"), "edge orientation differs")
        require(edge["keycode"] == edges[number - number % 2]["keycode"], "release key mismatch")
        starts.append(edge["issue_ns"])
        received.append(edge["received_ns"])
        progress.append(edge["staged_bytes"])
        computed = time_ms(starts[-1], received[-1])
        require(computed == edge["latency_ms"], f"{phase} delay does not replay from monotonic sample")
        if number % 2:
            releases.append(computed)
    require(starts == sorted(set(starts)) and received == sorted(received), "sampled input ordering differs")
    require(len({edge["keycode"] for edge in edges}) == 3, "expected the three probed X11 keys")
    if completed is None:
        require(all(n == 0 for n in progress) and received[-1] < offered, "idle edges overlap the file offer")
    else:
        require(offered <= starts[0] and received[-1] <= completed, "active edges overlap transfer boundaries")
        require(progress == sorted(progress) and START_BYTES <= progress[0] < progress[-1] < FILE_BYTES,
                "probes did not see increasing staged file data within the upload")
    return releases


def ranks(releases):
    ordered = sorted(releases)
    return {"count": len(ordered), "median_ms": statistics.median(ordered),
            "p95_ms": ordered[math.ceil(.95 * len(ordered)) - 1],
            "p99_ms": ordered[math.ceil(.99 * len(ordered)) - 1], "max_ms": ordered[-1]}


def collect_telemetry(path, rate, chunk, window, row):
    proxy = load(path / "proxy.log")
    config = proxy["config"]
    require(proxy["schema_version"] == 1 and proxy["listening"][0] == config["listen_host"]
            == config["upstream_host"] == "127.0.0.1", "proxy did not listen on loopback")
    require(config["c2s_bytes_per_second"] == SHAPE_BYTES and config["s2c_bytes_per_second"] == 0
            and config["chunk_bytes"] == PROXY_CHUNK and config["max_connections"] == 1, "unexpected rate shape")
    require(all(config[k] in (None, 0) for k in (
        "session_seconds", "c2s_latency_ms", "c2s_pause_after", "c2s_pause_seconds", "c2s_disconnect_after",
        "s2c_latency_ms", "s2c_pause_after", "s2c_pause_seconds", "s2c_disconnect_after")), "uncontrolled proxy shaping")
    evidence = {"proxy-policy.json": json_bytes({
        key: value for key, value in config.items() if key not in JSON_FIELDS_TO_REMOVE
    })}
    logs = {}
    notable = (
        "sharing the whole", "clipboard file/image budget", "authenticated session started",
        "authenticated; waiting", "clipboard sharing enabled", "clipboard update queued",
        "jwm-remote: sharing 1 file", "jwm-remote: shared 1 file", "jwm-remote: session ended",
        "XRender downscale", "MIT-SHM", "restriction confirmed", "restriction applied",
        "jwm-remote: remote protocol I/O error", "jwm-remote: Session: remote protocol I/O error",
    )
    for role in ("host", "viewer"):
        raw = (path / f"{role}.log").read_bytes().splitlines()
        telemetry = [json.loads(line) for line in raw if line.startswith(b"{")]
        require(telemetry and all(item["type"] == f"jwm_remote_{role}_stats" for item in telemetry),
                f"missing valid {role} telemetry")
        evidence[f"{role}-stats.jsonl"] = b"\n".join(line for line in raw if line.startswith(b"{")) + b"\n"
        messages = [line.decode() for line in raw if not line.startswith(b"{")]
        evidence[f"{role}-selected-events.jsonl"] = lines(
            {"message": line} for line in messages if any(event in line for event in notable))
        logs[role] = messages, telemetry
    host, host_stats = logs["host"]
    viewer, viewer_stats = logs["viewer"]
    require(any("authenticated session started (screen + pointer + keyboard)" in msg for msg in host)
            and any("authenticated; waiting for the first desktop frame" in msg for msg in viewer)
            and any(f"rate={rate} kbit/s chunk={chunk} bytes window={window} bytes" in msg for msg in viewer)
            and any("sharing the whole 1280x800 root" in msg for msg in host),
            "authentication, input, root or negotiated budget diagnostic missing")
    sessions = {entry["session_id"] for entry in (*host_stats, *viewer_stats)}
    require(len(sessions) == 1 and SESSION.fullmatch(next(iter(sessions)))
            and all(entry["negotiated_codec"] == "JPEG" and entry["viewer_backend"] == "x11" for entry in viewer_stats)
            and all(entry["mode"].startswith("root/") and not entry["h264_frames"] and not entry["hevc444_frames"]
                    for entry in host_stats), "recorded endpoint scope changed")
    projected = [{
        "session_id": item["session_id"], "window_seconds": item["window_seconds"], "final": item["final"],
        "sender_depth": item["sender_max_sampled_at_dequeue"],
        "sender_stages": {k: v for k, v in item["stages"].items() if k.startswith("sender_")},
    } for item in viewer_stats]
    require(projected == row["sender_telemetry"], "sender telemetry does not replay from raw stats")
    return evidence, host, viewer, viewer_stats, next(iter(sessions))


def check_trial(path, row, payload_sha):
    profile, op = row["profile"], row["operation"]
    rate = PROFILES[profile]
    chunk, window = rate * 25 // 8, rate * 60 // 8
    require(row["sha256"] == payload_sha and row["upload_bytes"] == FILE_BYTES
            and (row["configured_rate_kbit_per_second"], row["chunk_bytes"], row["window_bytes"],
                 row["uplink_configured_bytes_per_second"]) == (rate, chunk, window, SHAPE_BYTES),
            "fixture payload or negotiated budget differs")
    offered, active = row["offered_ns"], row["active_start_ns"]
    require(offered < active and START_BYTES <= row["active_started_bytes"] < FILE_BYTES,
            "transfer did not reach the staged input start")
    idle = recompute_edges(row["idle_edges"], 8, offered)
    require(ranks(idle) == row["idle"], "idle release ranks differ")
    evidence, host, viewer, stats, session = collect_telemetry(path, rate, chunk, window, row)
    release = []
    if op == "complete":
        completed = row["completion_observed_ns"]
        release = recompute_edges(row["under_upload_edges"], 48, active, completed)
        require(ranks(release) == row["under_upload"] and row["host_clipboard_uri_matches_staged_file"]
                and any("clipboard update queued" in msg for msg in host)
                and any(msg.startswith("jwm-remote: shared 1 file") for msg in viewer),
                "completion, exact landed file or active release ranks do not replay")
        require(row["throughput_file_mbit_per_sec"] == FILE_BYTES * 8_000 / (completed - offered)
                and row["active_staged_mbit_per_sec"] == (FILE_BYTES - row["active_started_bytes"]) * 8_000 /
                    (completed - active), "file throughput does not replay")
    elif op == "fault":
        issue, down, cut, up = (row[field] for field in ("held_issue_ns", "remote_key_down_ns",
                                                        "fault_ns", "remote_key_up_ns"))
        require(active <= issue <= down <= cut <= up and row["fault_to_release_ms"] == time_ms(cut, up)
                and START_BYTES <= row["partial_bytes_at_fault"] < FILE_BYTES
                and all(row[field] is True for field in ("host_keymap_clear", "partial_removed",
                    "incomplete_clipboard_offer_removed", "viewer_local_keyboard_ungrabbed"))
                and row["host_exit"] == row["viewer_exit"] == 1
                and any(msg.startswith("jwm-remote: remote protocol I/O error") for msg in host)
                and any(msg.startswith("jwm-remote: Session: remote protocol I/O error") for msg in viewer),
                "cut did not produce the expected cleanup, key release and both I/O exits")
    else:
        require(active <= row["restriction_chord_ns"] <= row["restriction_confirmed_ns"]
                and row["restriction_confirmation_ms"] == time_ms(row["restriction_chord_ns"],
                                                                   row["restriction_confirmed_ns"])
                and START_BYTES <= row["partial_bytes_at_restriction"] < FILE_BYTES
                and all(row[field] is True for field in ("partial_removed", "new_file_refused", "retained_text_verified"))
                and any("restriction applied (revision 1, content mask 3)" in msg for msg in host)
                and any("restriction confirmed: text + images, to host" in msg for msg in viewer)
                and sum(msg.startswith("jwm-remote: sharing 1 file") for msg in viewer) == 1,
                "restriction/file cleanup/continued text scope did not pass")
    if op != "fault":
        require(row["host_exit"] == row["viewer_exit"] == 0 and stats[-1]["final"]
                and viewer[-1] == "jwm-remote: session ended", "missing normal endpoint shutdown")
    return evidence, idle, release, session


def expected_rows(block):
    if block == "restriction":
        return [(1, "restrict", profile) for profile in PROFILES]
    profiles = list(PROFILES)
    return [(trial, op, profile) for trial in range(1, 5) for op in ("complete", "fault")
            for profile in (profiles if trial % 2 else profiles[::-1])]


def row_key(row):
    return (row["trial"], row.get("operation", row.get("mode")), row["profile"])


def publish(lab, live, pid, repo, binary):
    proc = Path("/proc") / str(pid)
    try:
        argv = (proc / "cmdline").read_bytes().strip(b"\0")
    except FileNotFoundError:
        argv = b""
    require(not argv, "recorded batch controller PID still owns a running process")
    batch = Path((lab / "active-batch").read_text().strip()).resolve(strict=True)
    require(batch.parent == lab and batch.name.startswith("comparison."), "unexpected active batch")
    require(sha(binary.read_bytes()) == BINARY_SHA, "retained default binary differs from pinned experiment")
    reports = {name: load(batch / name / "result.json") for name in ("ab-ba-ab-ba", "restriction")}
    raw_controller = [json.loads(line) for line in live.read_text().splitlines() if line.startswith("{")]
    complete_trials, errors, sessions, payloads = [], [], set(), set()
    idle = {profile: [] for profile in PROFILES}
    active = {profile: [] for profile in PROFILES}
    throughputs = {profile: [] for profile in PROFILES}
    fixtures = {"p07.py": lab / "p07.py", "remote-fault-proxy.py": repo / "scripts/remote-fault-proxy.py",
                "test-remote-viewer-e2e.py": repo / "scripts/test-remote-viewer-e2e.py",
                "publish_p07.py": Path(__file__).resolve()}
    members = {f"fixtures/{name}": path.read_bytes() for name, path in fixtures.items()}
    pointer = 0
    for block, report in reports.items():
        require(report["binary_sha256"] == BINARY_SHA, "reported binary lacks the pinned SHA-256")
        require(report["bulk_policy"] == {
            label: {"rate_kbit_per_second": rate, "chunk_bytes": rate * 25 // 8, "window_bytes": rate * 60 // 8}
            for label, rate in PROFILES.items()}, "bulk policy differs from trial controls")
        good, bad = ({row_key(row): row for row in report[k]} for k in ("runs", "errors"))
        expected = expected_rows(block)
        require(not set(good).intersection(bad) and set(good).union(bad) == set(expected)
                and len(good) + len(bad) == len(report["runs"]) + len(report["errors"]),
                f"missing or duplicate terminal outcomes in {block}")
        require(list(good) == [key for key in expected if key in good], "trial order does not match both ABBA blocks")
        for key in expected:
            trial, op, profile = key
            name = f"{block}/{trial}-{op}-{profile}"
            stdout = raw_controller[pointer]
            pointer += 1
            if key in bad:
                row = bad[key]
                require(row == stdout, f"{name} controller error differs")
                error = {"trial": trial, "operation": op, "profile": profile,
                         "error_type": row["message"].split("(")[0], "error_sha256": sha(row["message"].encode())}
                errors.append(error)
                members[f"{name}/fixture-error.json"] = json_bytes(error)
                continue
            row = good[key]
            require({k: v for k, v in row.items() if not k.endswith("_edges") and k != "sender_telemetry"} == stdout,
                    f"{name} terminal controller line differs")
            payloads.add(row["sha256"])
            evidence, idles, releases, session = check_trial(batch / name, row, row["sha256"])
            require(session not in sessions, "an authenticated session was reused across separate attempts")
            sessions.add(session)
            members.update({f"{name}/{label}": data for label, data in evidence.items()})
            members[f"{name}/raw-fixture-trace.json"] = json_bytes(row)
            rec = {k: v for k, v in row.items() if not k.endswith("_edges") and k != "sender_telemetry"}
            rec.update({"authenticated_session_id": session, "trace": name})
            complete_trials.append(rec)
            if op == "complete":
                idle[profile].extend(idles)
                active[profile].extend(releases)
                throughputs[profile].append(row["throughput_file_mbit_per_sec"])
    require(pointer == len(raw_controller) and len(payloads) <= 1
            and all(re.fullmatch(r"[0-9a-f]{64}", digest) for digest in payloads),
            "batch does not have the same synthetic transfer across all attempts")
    summary = {profile: {"trials": len(throughputs[profile]), "idle": ranks(idle[profile]),
                         "under_upload": ranks(active[profile]), "per_trial_throughput_mbit_per_sec": throughputs[profile],
                         "median_throughput_mbit_per_sec": statistics.median(throughputs[profile])}
               for profile in PROFILES if throughputs[profile]}
    require(summary == reports["ab-ba-ab-ba"]["summary"], "aggregated release ranks or throughput do not replay")
    counts = Counter(row["operation"] for row in complete_trials)
    fault = [row["fault_to_release_ms"] for row in complete_trials if row["operation"] == "fault"]
    report = {
        "schema_version": 1,
        "experiment": "P07 keyboard release and throughput under an active clipboard file upload",
        "controller": {"terminal": True, "expected": {"complete": 8, "fault": 8, "restrict": 2},
                       "observed": dict(counts), "fixture_errors": errors},
        "scope": {
            "machine": "one local Linux machine, separate owned host and viewer Xvfb servers",
            "kernel": platform.release(), "binary_sha256": BINARY_SHA,
            "input_timing": "local monotonic XTEST injection to actual target X11 event receipt",
            "capture": "static 1280x800 Xvfb root, 640x400 JPEG viewer, 15 FPS scheduling",
            "upload_direction": "viewer to host", "uplink_proxy_nominal_mbit_per_sec": 10,
            "uplink_proxy_bytes_per_sec": SHAPE_BYTES, "proxy_chunk_bytes": PROXY_CHUNK,
            "downlink_rate_shaped": False, "added_delay_ms": 0, "clipboard_file_bytes": FILE_BYTES,
            "synthetic_payload_sha256": next(iter(payloads), None),
            "minimum_staged_bytes_for_active_probes": START_BYTES,
            "policy_order_per_operation": ["rate-10000", "rate-6000", "rate-6000", "rate-10000"] * 2,
            "budget": reports["ab-ba-ab-ba"]["bulk_policy"],
            "rank_policy": "median and nearest-rank p95/p99 on raw keyboard releases pooled per budget",
            "throughput_policy": "full verified file bytes divided by offer-to-completion observation time",
        },
        "interpretation_limits": ["10 Mb/s nominal shaped local loopback uplink", "X11 event receipt timing",
                                  "No hardware input or physical display latency measurement"],
        "summary": summary,
        "fault_cleanup": {"verified": len(fault), "cut_to_release_min_ms": min(fault, default=None),
                          "cut_to_release_max_ms": max(fault, default=None)},
        "restrictions_verified": counts["restrict"],
        "attempts": complete_trials,
    }
    if len(summary) == 2:
        a, b = summary["rate-10000"], summary["rate-6000"]
        report["within_shape_comparison"] = {
            "release_p95_change_ms": b["under_upload"]["p95_ms"] - a["under_upload"]["p95_ms"],
            "median_file_throughput_change_mbit_per_sec":
                b["median_throughput_mbit_per_sec"] - a["median_throughput_mbit_per_sec"],
        }
    members["validated-batch.json"] = json_bytes(report)
    for name, data in members.items():
        require(not name.endswith((".bin", "/key")) and not re.search(rb"-----BEGIN [A-Z ]*PRIVATE KEY-----", data),
                "unsafe archive member")
        if not name.startswith("fixtures/"):
            require(not re.search(rb'127\.0\.0\.1:\d+|"(?:private_key|listen_port|upstream_port|boot_id)"\s*:|/tmp/[^"\s]+',
                                data), f"{name} has a private runtime or credential field")
    dest = repo / "docs/benchmarks/remote-upgrade-2026-11-20"
    require(not (dest / JSON_NAME).exists() and not (dest / ZIP_NAME).exists(), "publication already exists")
    with tempfile.TemporaryDirectory(prefix=".p07-publish.", dir=dest) as work:
        archive = Path(work) / ZIP_NAME
        with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as packed:
            for name, data in sorted(members.items()):
                packed.writestr(name, data)
        with zipfile.ZipFile(archive) as packed:
            require(packed.testzip() is None
                    and all(packed.read(name) == data for name, data in members.items()), "ZIP integrity failure")
        report["archive"] = {"file": ZIP_NAME, "sha256": sha(archive.read_bytes()),
                             "member_sha256": {name: sha(data) for name, data in sorted(members.items())}}
        report_file = Path(work) / JSON_NAME
        report_file.write_bytes(json_bytes(report))
        archive.replace(dest / ZIP_NAME)
        report_file.replace(dest / JSON_NAME)
    print(json.dumps({k: report[k] for k in ("controller", "summary", "fault_cleanup",
                                            "restrictions_verified", "within_shape_comparison")}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lab", type=Path, required=True)
    parser.add_argument("--live-log", type=Path, required=True)
    parser.add_argument("--pid", type=int, required=True)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--binary", type=Path, required=True)
    args = parser.parse_args()
    publish(args.lab.resolve(strict=True), args.live_log, args.pid, args.repo.resolve(strict=True), args.binary)
