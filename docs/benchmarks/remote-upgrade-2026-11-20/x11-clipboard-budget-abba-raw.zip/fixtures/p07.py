#!/usr/bin/env python3
"""Measure owned Xvfb client-to-host input edges while uploading a clipboard file."""
import argparse
from contextlib import ExitStack
import hashlib
import json
import math
import os
from pathlib import Path
import random
import re
import runpy
import select
import statistics
import subprocess
import time
from urllib.parse import unquote, urlsplit

from Xlib import X, XK, display
from Xlib.ext import xtest
from Xlib.protocol import event


UPLINK_BYTES_PER_SECOND = 1_250_000
BULK_KBIT = {'rate-10000': 10000, 'rate-6000': 6000}
INPUT_MASK = X.KeyPressMask | X.KeyReleaseMask | X.ButtonPressMask | X.ButtonReleaseMask
EDGE_TYPES = {X.KeyPress, X.KeyRelease, X.ButtonPress, X.ButtonRelease}
FILE_NAME = 'clipboard-fixture.bin'


def stop(process):
    if process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=4)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=4)


def wait_for(label, predicate, *children, timeout=12):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        for child in children:
            if child.poll() is not None:
                raise RuntimeError(f'{label}: child exited with status {child.returncode}')
        result = predicate()
        if result:
            return result
        time.sleep(.01)
    raise RuntimeError(f'timed out waiting for {label}')


def read(path):
    return path.read_text(encoding='utf-8', errors='replace')


def make_payload(path, count):
    rng = random.Random(24877)
    digest = hashlib.sha256()
    with path.open('wb') as stream:
        while count:
            block = rng.randbytes(min(count, 1 << 20))
            stream.write(block)
            digest.update(block)
            count -= len(block)
    return digest.hexdigest()


def file_hash(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def owned_app(connection, *, mask=0):
    screen = connection.screen()
    root = screen.root
    window = root.create_window(0, 0, screen.width_in_pixels, screen.height_in_pixels, 0,
                                screen.root_depth, X.InputOutput, X.CopyFromParent,
                                background_pixel=0x284050, event_mask=mask)
    window.set_wm_name('P07 isolated input receiver')
    window.map()
    window.set_input_focus(X.RevertToParent, X.CurrentTime)
    connection.sync()
    return window


def viewer_window(connection):
    name_atom = connection.intern_atom('_NET_WM_NAME')
    for window in connection.screen().root.query_tree().children:
        prop = window.get_full_property(name_atom, X.AnyPropertyType)
        name = prop.value.decode(errors='replace') if prop and isinstance(prop.value, bytes) else window.get_wm_name()
        if isinstance(name, str) and ' - JWM Remote' in name:
            return window
    return None


def inject(connection, event_type, detail=0, *, x=0, y=0):
    issued = time.monotonic_ns()
    xtest.fake_input(connection, event_type, detail, x=x, y=y)
    connection.flush()
    return issued


def pending_edges(connection, receiver):
    while connection.pending_events():
        event = connection.next_event()
        when = time.monotonic_ns()
        if event.type in EDGE_TYPES:
            if event.window.id != receiver.id:
                raise RuntimeError('XTEST event reached a window outside the owned receiver')
            yield event.type, event.detail, when


def input_schedule(client, server, receiver, count, bytes_so_far, *, minimum=0, maximum=0):
    keys = [client.keysym_to_keycode(keysym) for keysym in (XK.XK_F7, XK.XK_F8, XK.XK_F9)]
    records = []
    sequence = []
    for i in range(count):
        code = keys[i % len(keys)]
        sequence.extend(((X.KeyPress, code, 0), (X.KeyRelease, code, .021)))
    sent = received = 0
    next_send = time.monotonic() + .02
    deadline = next_send + count * .18 + 8
    while time.monotonic() < deadline:
        now = time.monotonic()
        if sent < len(sequence) and now >= next_send:
            typ, code, _ = sequence[sent]
            progress = bytes_so_far()
            if maximum and not minimum <= progress < maximum:
                raise RuntimeError(f'input probe outside active file upload: {progress} bytes')
            issue = inject(client, typ, code)
            records.append({'type': 'press' if typ == X.KeyPress else 'release',
                            'keycode': code, 'issue_ns': issue, 'staged_bytes': progress})
            sent += 1
            if sent < len(sequence):
                next_send = now + (sequence[sent][2] if sent % 2 else .057 + .008 * ((sent // 2) % 5))
        for typ, code, observed in pending_edges(server, receiver):
            if received >= sent or sequence[received][:2] != (typ, code):
                raise RuntimeError(f'out-of-order or unmatched key {typ}/{code} at edge {received}')
            record = records[received]
            record['received_ns'] = observed
            record['latency_ms'] = (observed - record['issue_ns']) / 1_000_000
            received += 1
        if received == len(sequence):
            return records
        until = next_send if sent < len(sequence) else deadline
        select.select([server.fileno()], [], [], max(0, min(.01, until - time.monotonic())))
    raise RuntimeError(f'expected {len(sequence)} input edges, sent {sent}, observed {received}')


def compact(edges):
    releases = sorted(row['latency_ms'] for row in edges if row['type'] == 'release')
    rank = lambda p: releases[math.ceil(p * len(releases)) - 1]
    return {'count': len(releases), 'median_ms': statistics.median(releases),
            'p95_ms': rank(.95), 'p99_ms': rank(.99), 'max_ms': releases[-1]}


def run(args, directory, source, digest, profile, mode):
    xvfb_launch = runpy.run_path(str(args.repo / 'scripts/test-remote-viewer-e2e.py'))['launch']
    with ExitStack() as cleanup:
        xhost, host_display = xvfb_launch()
        cleanup.callback(stop, xhost)
        xviewer, viewer_display = xvfb_launch()
        cleanup.callback(stop, xviewer)
        host_conn = display.Display(host_display)
        cleanup.callback(host_conn.close)
        viewer_conn = display.Display(viewer_display)
        cleanup.callback(viewer_conn.close)
        for connection in (host_conn, viewer_conn):
            assert connection.has_extension('XTEST')
            connection.change_keyboard_control(auto_repeat_mode=X.AutoRepeatModeOff)
            connection.sync()
        receiver = owned_app(host_conn, mask=INPUT_MASK)
        env = os.environ.copy()
        for name in ('DISPLAY', 'WAYLAND_DISPLAY', 'WAYLAND_SOCKET', 'XAUTHORITY',
                     'JWM_REMOTE_CLIPBOARD_BULK_KBIT', 'JWM_REMOTE_READ_AHEAD',
                     'JWM_REMOTE_KEEP_WINDOW', 'JWM_REMOTE_X11_REGIONS', 'JWM_REMOTE_GPU_CAPTURE',
                     'JWM_REMOTE_GPU_PRESENT'):
            env.pop(name, None)
        host_cache, viewer_cache = directory / 'host-cache', directory / 'viewer-cache'
        for cache in (host_cache, viewer_cache):
            cache.mkdir(mode=0o700)
        host_env = env | {'XDG_CACHE_HOME': str(host_cache)}
        viewer_env = env | {'XDG_CACHE_HOME': str(viewer_cache)}
        configured_rate = BULK_KBIT[profile]
        viewer_env['JWM_REMOTE_CLIPBOARD_BULK_KBIT'] = str(configured_rate)
        key = directory / 'key'
        subprocess.run([args.binary, 'keygen', '--output', key], env=env, check=True,
                       stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, timeout=6)

        def start(name, command, process_env, *, stdin=None):
            log = directory / (name + '.log')
            output = cleanup.enter_context(log.open('wb'))
            proc = subprocess.Popen(command, env=process_env, stdout=output, stderr=subprocess.STDOUT,
                                    stdin=subprocess.DEVNULL if stdin is None else stdin)
            cleanup.callback(stop, proc)
            return proc, log

        host, host_log = start('host', [args.binary, 'host', '--display', host_display,
                                       '--capture-source', 'root', '--once', '--listen', '127.0.0.1:0',
                                       '--key-file', key, '--fps', '15', '--stats-json',
                                       '--allow-input', '--allow-clipboard', '--clipboard-direction', 'to-host',
                                       '--clipboard-file-limit', str(args.bytes)], host_env)
        port = wait_for('authenticated host listener', lambda: re.search(r'listening on 127\.0\.0\.1:(\d+)',
                                                                         read(host_log)), host)[1]
        proxy_args = ['python3', args.repo / 'scripts/remote-fault-proxy.py', '--upstream-host', '127.0.0.1',
                      '--upstream-port', port, '--max-connections', '1', '--chunk-bytes', '16384',
                      '--c2s-bytes-per-second', str(UPLINK_BYTES_PER_SECOND)]
        proxy, proxy_log = start('proxy', proxy_args, env)
        listener = wait_for('private shaped proxy listener', lambda: read(proxy_log).splitlines(), proxy)
        proxy_port = json.loads(listener[0])['listening'][1]
        viewer, viewer_log = start('viewer', [args.binary, 'connect', f'127.0.0.1:{proxy_port}',
                                              '--display', viewer_display, '--window-size', '640x400', '--jpeg',
                                              '--key-file', key, '--grab-input', '--clipboard',
                                              '--clipboard-direction', 'to-host', '--stats-json',
                                              '--clipboard-file-limit', str(args.bytes)] +
                                             (['--escape-key', 'Pause'] if mode == 'restrict' else []), viewer_env)
        wait_for('viewer connected', lambda: 'connected;' in read(viewer_log), host, viewer)
        chunk = configured_rate * 25 // 8
        window = configured_rate * 60 // 8
        if f'rate={configured_rate} kbit/s chunk={chunk} bytes window={window} bytes' not in read(viewer_log):
            raise RuntimeError('viewer did not apply the intended clipboard chunk/window')
        win = wait_for('private viewer window', lambda: viewer_window(viewer_conn), host, viewer)
        win.set_input_focus(X.RevertToParent, X.CurrentTime)
        geometry = win.get_geometry()
        inject(viewer_conn, X.MotionNotify, x=geometry.x + geometry.width // 2, y=geometry.y + geometry.height // 2)
        inject(viewer_conn, X.ButtonPress, 1)
        time.sleep(.075)
        inject(viewer_conn, X.ButtonRelease, 1)
        time.sleep(.2)
        list(pending_edges(host_conn, receiver))
        preflight = input_schedule(viewer_conn, host_conn, receiver, args.idle_samples, lambda: 0)

        def offer(name, target, value):
            owner, _ = start(name, ['xclip', '-quiet', '-display', viewer_display, '-selection',
                                    'clipboard', '-t', target, '-i'], viewer_env, stdin=subprocess.PIPE)
            owner.stdin.write(value)
            owner.stdin.close()
            return owner

        def paste(target):
            return subprocess.check_output(['xclip', '-display', host_display, '-selection',
                                            'clipboard', '-t', target, '-o'],
                                           env=host_env, timeout=8, text=True)

        def close_session(result):
            close = event.ClientMessage(window=win, client_type=viewer_conn.intern_atom('WM_PROTOCOLS'),
                                        data=(32, [viewer_conn.intern_atom('WM_DELETE_WINDOW'), 0, 0, 0, 0]))
            win.send_event(close)
            viewer_conn.flush()
            result['viewer_exit'] = viewer.wait(timeout=8)
            result['host_exit'] = host.wait(timeout=8)
            if result['viewer_exit'] or result['host_exit']:
                raise RuntimeError('session did not close cleanly')

        staging = host_cache / 'jwm' / 'remote-clipboard'
        upload_start_ns = time.monotonic_ns()
        uri = (source.as_uri() + '\r\n').encode()
        owner = offer('xclip', 'text/uri-list', uri)
        host_clip = host_conn.intern_atom('CLIPBOARD')

        def staged_file():
            copies = list(staging.rglob(FILE_NAME)) if staging.exists() else []
            if len(copies) > 1:
                raise RuntimeError('unexpected duplicate staged file')
            return copies[0] if copies else None

        def staged_size():
            path = staged_file()
            if path is not None:
                try:
                    return path.stat().st_size
                except FileNotFoundError:
                    pass
            return 0

        def progress():
            size = staged_size()
            return size if args.start_bytes <= size < args.bytes and host_conn.get_selection_owner(host_clip) else None

        await_bytes = wait_for('partial file staged by the host', progress, host, viewer, owner, timeout=14)
        active_start_ns = time.monotonic_ns()
        result = {'profile': profile, 'operation': mode, 'upload_bytes': args.bytes, 'sha256': digest,
                  'configured_rate_kbit_per_second': configured_rate,
                  'chunk_bytes': chunk, 'window_bytes': window,
                  'uplink_configured_bytes_per_second': UPLINK_BYTES_PER_SECOND, 'active_started_bytes': await_bytes,
                  'idle': compact(preflight), 'idle_edges': preflight, 'offered_ns': upload_start_ns,
                  'active_start_ns': active_start_ns}
        if mode == 'complete':
            edges = input_schedule(viewer_conn, host_conn, receiver, args.samples, staged_size,
                                   minimum=args.start_bytes, maximum=args.bytes)
            result['under_upload'] = compact(edges)
            result['under_upload_edges'] = edges
            completed = wait_for('host completed clipboard stream',
                                 lambda: 'clipboard update queued' in read(host_log) and staged_size() == args.bytes,
                                 host, viewer, owner, timeout=args.bytes / UPLINK_BYTES_PER_SECOND + 12)
            assert completed
            end = time.monotonic_ns()
            landed = staged_file()
            assert landed.stat().st_size == args.bytes and file_hash(landed) == digest
            pasted = paste('text/uri-list')
            offered = [urlsplit(line) for line in pasted.splitlines() if line and not line.startswith('#')]
            assert len(offered) == 1 and offered[0].scheme == 'file'
            assert Path(unquote(offered[0].path)).resolve() == landed.resolve()
            result['completion_observed_ns'] = end
            result['throughput_file_mbit_per_sec'] = args.bytes * 8_000 / (end - upload_start_ns)
            result['active_staged_mbit_per_sec'] = (args.bytes - await_bytes) * 8_000 / (end - active_start_ns)
            result['host_clipboard_uri_matches_staged_file'] = True
            close_session(result)
        elif mode == 'fault':
            keycode = viewer_conn.keysym_to_keycode(XK.XK_F10)
            held_start = inject(viewer_conn, X.KeyPress, keycode)

            def match_edge(expected):
                for typ, code, when in pending_edges(host_conn, receiver):
                    if (typ, code) != (expected, keycode):
                        raise RuntimeError(f'expected held key {expected}/{keycode}, got {typ}/{code}')
                    return when
                return None

            held = wait_for('remote application to actually receive held key', lambda: match_edge(X.KeyPress), host, viewer)
            partial = staged_size()
            assert args.start_bytes <= partial < args.bytes
            fault = time.monotonic_ns()
            proxy.terminate()
            released = wait_for('host release of remotely held key after proxy disconnect',
                                lambda: match_edge(X.KeyRelease), timeout=10)
            query = host_conn.query_keymap()
            assert not (query[keycode // 8] & (1 << (keycode % 8)))
            result.update({'held_issue_ns': held_start, 'remote_key_down_ns': held, 'fault_ns': fault,
                           'remote_key_up_ns': released, 'fault_to_release_ms': (released - fault) / 1_000_000,
                           'partial_bytes_at_fault': partial, 'host_keymap_clear': True,
                           'host_exit': host.wait(timeout=10), 'viewer_exit': viewer.wait(timeout=10)})
            proxy.wait(timeout=4)
            assert not staged_file() and not host_conn.get_selection_owner(host_clip)
            assert source.stat().st_size == args.bytes
            result['partial_removed'] = True
            result['incomplete_clipboard_offer_removed'] = True
            result['viewer_local_keyboard_ungrabbed'] = True
            local = owned_app(viewer_conn)
            status = local.grab_keyboard(False, X.GrabModeAsync, X.GrabModeAsync, X.CurrentTime)
            assert status == X.GrabSuccess
            viewer_conn.ungrab_keyboard(X.CurrentTime)
            inject(viewer_conn, X.KeyRelease, keycode)
            viewer_conn.sync()
        else:
            partial = staged_size()
            assert args.start_bytes <= partial < args.bytes
            codes = [viewer_conn.keysym_to_keycode(keysym) for keysym in
                     (XK.XK_Control_L, XK.XK_Super_L, XK.XK_Alt_L, XK.XK_Pause)]
            for code in codes:
                chord_ns = inject(viewer_conn, X.KeyPress, code)
                time.sleep(.008)
            for code in reversed(codes):
                inject(viewer_conn, X.KeyRelease, code)
                time.sleep(.008)
            wait_for('viewer restriction confirmation', lambda: 'clipboard restriction confirmed' in read(viewer_log),
                     host, viewer, timeout=10)
            confirmed = time.monotonic_ns()
            wait_for('partial staging removal', lambda: not staged_file(), host, viewer, timeout=6)
            forbidden = directory / 'forbidden-after-restriction.bin'
            forbidden.write_bytes(b'P07 distinct synthetic clipboard file')
            next_file = offer('xclip-after-restrict', 'text/uri-list', (forbidden.as_uri() + '\r\n').encode())
            time.sleep(.7)
            assert next_file.poll() is None and not staged_file() and not list(staging.rglob(forbidden.name))
            assert read(viewer_log).count('sharing 1 file') == 1
            ordinary = 'p07-restricted-text-remains-authorized'
            text_owner = offer('xclip-text', 'UTF8_STRING', ordinary.encode())
            def retained_text():
                if not host_conn.get_selection_owner(host_clip):
                    return False
                try:
                    return paste('UTF8_STRING') == ordinary
                except subprocess.CalledProcessError:
                    return False

            wait_for('fresh authorized text after restriction', retained_text, host, viewer, text_owner)
            result.update({'partial_bytes_at_restriction': partial,
                           'restriction_chord_ns': chord_ns, 'restriction_confirmed_ns': confirmed,
                           'restriction_confirmation_ms': (confirmed - chord_ns) / 1_000_000,
                           'partial_removed': True, 'new_file_refused': True, 'retained_text_verified': True})
            close_session(result)
        windows = []
        for line in read(viewer_log).splitlines():
            if line.startswith('{'):
                report = json.loads(line)
                if report.get('type') == 'jwm_remote_viewer_stats':
                    windows.append({'session_id': report['session_id'],
                                    'window_seconds': report['window_seconds'], 'final': report['final'],
                                    'sender_depth': report['sender_max_sampled_at_dequeue'],
                                    'sender_stages': {name: value for name, value in report['stages'].items()
                                                      if name.startswith('sender_')}})
        if not windows or len({row['session_id'] for row in windows}) != 1:
            raise RuntimeError('viewer sender telemetry missing or shows a replacement session')
        result['sender_telemetry'] = windows
        return result


def summary(runs):
    result = {}
    for profile in BULK_KBIT:
        completed = [row for row in runs if row['profile'] == profile and row['operation'] == 'complete']
        if completed:
            result[profile] = {
                'trials': len(completed),
                'idle': compact([edge for row in completed for edge in row['idle_edges']]),
                'under_upload': compact([edge for row in completed for edge in row['under_upload_edges']]),
                'per_trial_throughput_mbit_per_sec': [row['throughput_file_mbit_per_sec'] for row in completed],
                'median_throughput_mbit_per_sec': statistics.median(
                    row['throughput_file_mbit_per_sec'] for row in completed),
            }
    return result


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('binary', type=lambda path: Path(path).resolve())
    cli.add_argument('--repo', type=lambda path: Path(path).resolve(), required=True)
    cli.add_argument('--out', type=lambda path: Path(path).resolve(), required=True)
    cli.add_argument('--profile', choices=(*BULK_KBIT, 'both'), default='both')
    cli.add_argument('--mode', choices=('complete', 'fault', 'restrict', 'both'), default='both')
    cli.add_argument('--bytes', type=int, default=12 << 20)
    cli.add_argument('--start-bytes', type=int, default=256 << 10)
    cli.add_argument('--samples', type=int, default=32)
    cli.add_argument('--idle-samples', type=int, default=6)
    cli.add_argument('--trials', type=int, default=1)
    args = cli.parse_args()
    assert args.bytes > args.start_bytes >= 32768 and args.samples > 0 and args.idle_samples > 0 and args.trials > 0
    args.out.mkdir(mode=0o700)
    payload = args.out / FILE_NAME
    digest = make_payload(payload, args.bytes)
    profiles = tuple(BULK_KBIT) if args.profile == 'both' else (args.profile,)
    modes = ('complete', 'fault') if args.mode == 'both' else (args.mode,)
    report = {'binary_sha256': file_hash(args.binary), 'runs': [], 'errors': [],
              'instrument': 'owned-viewer XTEST issue to actual target-window X11 event on one monotonic clock',
              'proxy_scope': 'client-to-host user-space TCP transfer only, nominal 1,250,000 bytes/s',
              'clipboard_direction': 'to-host',
              'host_video': 'static owned Xvfb root, 15 FPS capture scheduling, JPEG',
              'bulk_policy': {profile: {'rate_kbit_per_second': rate, 'chunk_bytes': rate * 25 // 8,
                                        'window_bytes': rate * 60 // 8}
                              for profile, rate in BULK_KBIT.items()}}
    for index in range(args.trials):
        for mode in modes:
            for profile in (profiles if index % 2 == 0 else profiles[::-1]):
                directory = args.out / f'{index + 1}-{mode}-{profile}'
                directory.mkdir(mode=0o700)
                try:
                    row = run(args, directory, payload, digest, profile, mode)
                except Exception as error:
                    report['errors'].append({'trial': index + 1, 'profile': profile, 'mode': mode,
                                             'message': repr(error)})
                    (args.out / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
                    print(json.dumps(report['errors'][-1]), flush=True)
                    continue
                row['trial'] = index + 1
                report['runs'].append(row)
                report['summary'] = summary(report['runs'])
                (args.out / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
                print(json.dumps({k: v for k, v in row.items() if not k.endswith('_edges') and k != 'sender_telemetry'}), flush=True)
    if report['errors']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
