import os
import re
import selectors
import subprocess
import time

def wait_for(process, predicate, seconds=15):
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        if (result := predicate()) is not None:
            return result
        if process.poll() is not None:
            break
        time.sleep(.04)
    raise RuntimeError(f"readiness event missing for {process.args[0]} (status {process.poll()})")

def get_display(process):
    with selectors.DefaultSelector() as selector:
        selector.register(process.stdout, selectors.EVENT_READ)
        if not selector.select(10):
            raise RuntimeError("private Xvfb did not announce its display")
        line = process.stdout.readline().strip()
    if not re.fullmatch(rb"[0-9]+", line):
        raise RuntimeError("invalid private Xvfb display")
    return ":" + line.decode()

def start_display(width, height, stderr):
    return subprocess.Popen(
        ["Xvfb", "-displayfd", "1", "-screen", "0", f"{width}x{height}x24",
         "-nolisten", "tcp", "-ac", "-noreset"],
        stdout=subprocess.PIPE, stderr=stderr, stdin=subprocess.DEVNULL)

def stop(process, natural=False):
    if process.stdin and not process.stdin.closed:
        process.stdin.close()
    if process.poll() is not None:
        return
    if natural:
        try:
            process.wait(timeout=4)
            return
        except subprocess.TimeoutExpired:
            pass
    process.terminate()
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=5)

def clean_env():
    return {key: value for key, value in os.environ.items()
            if key not in {"DISPLAY", "WAYLAND_DISPLAY", "WAYLAND_SOCKET"} and not key.startswith("JWM_REMOTE_")}
