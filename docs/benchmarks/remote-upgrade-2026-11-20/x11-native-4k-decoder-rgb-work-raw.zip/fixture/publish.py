import hashlib
import json
from pathlib import Path
import runpy
from zipfile import ZIP_DEFLATED, ZipFile


REPO = Path('/home/yj/projects/jwm')
EVIDENCE = REPO / 'docs/benchmarks/remote-upgrade-2026-11-20'
LAB = Path(__file__).resolve().parent
REPORT_SCRIPT = REPO / 'scripts/remote-workload-report.py'


def sha256(path):
    with path.open('rb') as data:
        return hashlib.file_digest(data, 'sha256').hexdigest()


def archive(stem, report, entries):
    destination = EVIDENCE / f'{stem}-raw.zip'
    temp = destination.with_suffix('.zip.tmp')
    digests = {name: sha256(path) for name, path in entries.items()}
    assert all(Path(name).name not in ('key', 'tunnel.log', 'fixture.key') for name in entries)
    with ZipFile(temp, 'w', compression=ZIP_DEFLATED, compresslevel=9) as writer:
        for member, path in entries.items():
            writer.write(path, member)
    with ZipFile(temp) as reader:
        assert reader.testzip() is None
        assert {name: hashlib.sha256(reader.read(name)).hexdigest() for name in reader.namelist()} == digests
    temp.replace(destination)
    report['archive'] = {'path': destination.name, 'sha256': sha256(destination), 'entries': digests}
    output = EVIDENCE / f'{stem}.json'
    staged = output.with_suffix('.json.tmp')
    staged.write_text(json.dumps(report, indent=2) + '\n')
    staged.replace(output)
    print(output.name, len(entries), 'verified members')


def hardware_evidence():
    report = runpy.run_path(REPORT_SCRIPT)
    build = Path('/tmp/jwm-p09-metered-viewer')
    local_hash = (build / 'binary-sha256.txt').read_text().split()[0]
    assert local_hash == sha256(build / 'jwm-remote')
    entries = {f'fixture/{name}': LAB / name for name in ('benchmark.py', 'processes.py', 'run.sh', 'publish.py')}
    entries['fixture/remote-workload-report.py'] = REPORT_SCRIPT
    entries['build/source-sha256.txt'] = build / 'source-sha256.txt'
    entries['build/local-verification.log'] = Path('/tmp/jwm-p09-metered-verification-live.log')
    entries['build/ubuntu-verification.log'] = build / 'ubuntu-verification.log'
    trials = {}
    for route, copy in (('full', 'full_frame'), ('banded', 'banded')):
        scope = f'metered-rgb-{route}-01-treatment'
        trial = LAB / scope
        result = json.loads((trial / 'result.json').read_text())
        assert result['viewer_binary_sha256'] == local_hash
        assert result['source_and_encoded_dimensions'] == [3840, 2160]
        assert result['packed_rgb_diagnostic'] == (route == 'banded') and result['candidate_path_verified']
        work = result['hardware_rgb_work']['totals']
        frames = work['copy'][f'{copy}_copies']
        assert work['copy'][f'{copy}_bytes'] == frames * 3840 * 2160 * 3
        assert frames == sum(work['download'].values())
        assert frames == work['pool']['fitting_checkouts'] + work['pool']['fresh_reserves'] + work['pool']['growth_reserves']
        actual_viewer = report['read_viewer_windows'](trial / 'viewer.log')
        assert {row['session_id'] for row in actual_viewer} == {result['session_id']}
        assert actual_viewer[-1]['final']
        result['first_viewer_window_rgb_work'] = actual_viewer[0]['hardware_rgb_work']
        result['whole_session_rgb_work'] = report['summarize_viewer'](actual_viewer, [])['hardware_rgb_work']
        print(route, 'first', result['first_viewer_window_rgb_work'])
        print(route, 'retained', result['hardware_rgb_work']['totals'])
        print(route, 'whole', result['whole_session_rgb_work']['totals'])
        for name in ('result.json', 'retained-host.jsonl', 'retained-viewer.jsonl', 'retained-markers.jsonl',
                     'observed.jsonl', 'remote/paint.jsonl', 'viewer.log'):
            entries[f'{scope}/{name}'] = trial / name
        trials[route] = result
    archive('x11-native-4k-decoder-rgb-work', {
        'schema_version': 1,
        'status': 'two isolated unscored hardware sessions',
        'host_binary_sha256': (LAB / 'host-binary-sha256').read_text().strip(),
        'viewer_binary_sha256': local_hash,
        'scope': ('Native 3840×2160 NVENC H.264 over uncapped SSH from Ubuntu and Intel VA-API download '
                  'on the local X11 viewer. Two short fixed-geometry runs validate materialization and byte '
                  'counters. The same viewer build selects each RGB route. Whole-session work includes '
                  'initialization and the final partial window. Retained observer windows are also reported.'),
        'trials': trials,
    }, entries)


def firefox_evidence():
    recovery = Path('/tmp/jwm-firefox-browser-recovery.Tty09B')
    baseline = Path('/tmp/jwm-firefox-browser-baseline.AQt8OcMI')
    raw = baseline / 'scored.x92fzxo8'
    report = json.loads((recovery / 'diagnosis.json').read_text())
    entries = {
        'fixture/original-runner.py': baseline / 'run_baseline.py',
        'fixture/recovery-runner.py': recovery / 'run_baseline.py',
        'fixture/browser-original.html': recovery / 'browser-original.html',
        'fixture/browser-trial.html': recovery / 'browser-trial.html',
        'fixture/manifest.json': recovery / 'fixture-manifest.json',
    }
    for row in report['trials']:
        trial = raw / row['trial']
        assert 'wait_for(firefox, motion_seen, 5)' in (trial / 'failure.log').read_text()
        assert sha256(trial / 'static-pixels.jsonl') == row['raster_trace_sha256']
        for name in ('failure.log', 'static-pixels.jsonl', 'static-scope.json', 'source-static.json',
                     'host-clocked-telemetry.jsonl', 'viewer-clocked-telemetry.jsonl'):
            entries[f'trace/{row["trial"]}/{name}'] = trial / name
    archive('firefox-x11-initial-run-diagnosis', report, entries)


if __name__ == '__main__':
    hardware_evidence()
    firefox_evidence()
