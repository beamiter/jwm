#!/usr/bin/env bash
set -euo pipefail
lab=$(cd "$(dirname "$0")" && pwd)
viewer=/tmp/jwm-p09-metered-viewer
repo=/home/yj/projects/jwm
python3 - <<'PY'
import os
from pathlib import Path
import select

pid = 836928
expected = b"/tmp/jwm-p09-candidate.CJJg2I/verify-metered-rgb.sh"
try:
    descriptor = os.pidfd_open(pid)
except ProcessLookupError:
    pass
else:
    try:
        try:
            arguments = Path(f"/proc/{pid}/cmdline").read_bytes().split(b"\0")
        except FileNotFoundError:
            arguments = []
        if arguments and expected not in arguments:
            raise RuntimeError("unexpected metered viewer verification controller")
        print("Waiting for metered local viewer verification", flush=True)
        waiter = select.poll()
        waiter.register(descriptor, select.POLLIN)
        if not waiter.poll(3600000):
            raise RuntimeError("metered local viewer verification still live")
    finally:
        os.close(descriptor)
PY
export CARGO_TARGET_DIR=/tmp/jwm-remote-plan-check
export RUSTUP_TOOLCHAIN=stable CARGO_NET_OFFLINE=true CARGO_BUILD_JOBS=4
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_INCREMENTAL=0
export PKG_CONFIG_PATH=/tmp/jwm-remote-ffmpeg/usr/lib/x86_64-linux-gnu/pkgconfig
export LD_LIBRARY_PATH=/tmp/jwm-remote-ffmpeg/usr/lib/x86_64-linux-gnu
unset PKG_CONFIG_SYSROOT_DIR

metered_pilots() {
    rg -q 'Metered local viewer passed and was staged' /tmp/jwm-p09-metered-verification-live.log || return
    local expected_host actual_host remote viewer_hash
    expected_host=$(cat "$lab/host-binary-sha256")
    actual_host=$(ssh -n -o BatchMode=yes -o ConnectTimeout=5 ubuntu@192.168.0.78 \
        'sha256sum /tmp/jwm-p09-resolution-candidate/jwm-remote' | cut -d' ' -f1) || return
    if [[ "$actual_host" != "$expected_host" ]]; then
        printf '%s\n' 'Ubuntu host binary differs from its pin' >&2
        return 1
    fi
    sha256sum --check "$viewer/binary-sha256.txt" || return
    viewer_hash=$(cut -d' ' -f1 "$viewer/binary-sha256.txt")
    remote=$(cat "$lab/remote-dir")
    local common=(--remote-dir "$remote" --pilot --seconds 36 --arms treatment --width 3840 --height 2160
                  --fps 30 --paint-fps 60 --capture-scaling auto --feature-flag JWM_REMOTE_PARALLEL_YUV420
                  --viewer-binary "$viewer/jwm-remote" --viewer-sha256 "$viewer_hash")
    local run_status=0
    if ! python3 -B -u "$lab/benchmark.py" "${common[@]}" --label metered-rgb-full --enable-at host; then run_status=1; fi
    if ! python3 -B -u "$lab/benchmark.py" "${common[@]}" --label metered-rgb-banded --enable-at both \
        --expected-packed-rgb; then run_status=1; fi
    return "$run_status"
}

status=0
if ! metered_pilots; then status=1; fi
printf '%s\n' 'Starting owned native 4K Wayland smoke'
if ! flock /tmp/jwm-p08-p09-release/benchmark.lock "$repo/scripts/test-remote-wayland-cli.sh" \
    --gpu-viewer-4k /dev/dri/renderD128 > "$lab/wayland-4k.log" 2>&1; then status=1; fi
tail -n 30 "$lab/wayland-4k.log"
exit "$status"
