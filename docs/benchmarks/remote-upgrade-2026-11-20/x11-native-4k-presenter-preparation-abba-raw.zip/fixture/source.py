import argparse
from contextlib import ExitStack
import json
from pathlib import Path
import re
import select
import subprocess
import sys

from processes import clean_env, get_display, sha256, start_display, stop, wait_for

lab = Path(__file__).parent
release = Path("/tmp/jwm-p08-p09-release/jwm-remote")
parser = argparse.ArgumentParser()
parser.add_argument("trial")
parser.add_argument("--arm", choices=("fixed", "adaptive"), required=True)
for flag in ("width", "height", "fps", "paint-fps", "seconds", "run-id", "cap", "send-buffer"):
    parser.add_argument("--" + flag, type=int, required=True)
parser.add_argument("--recv-buffer", type=int, default=0)
parser.add_argument("--host-scaling", choices=("cpu", "auto"), required=True)
parser.add_argument("--host-binary-sha256", required=True)
parser.add_argument("--painter-sha256", required=True)
args = parser.parse_args()
run = lab / args.trial
run.mkdir(mode=0o700)
painter_bin = lab / "p09-workload"
host_hash = sha256(release)
painter_hash = sha256(painter_bin)
(run/"binaries.json").write_text(json.dumps({"host_binary_sha256": host_hash,
                                            "painter_sha256": painter_hash,
                                            "host_scaling_policy": args.host_scaling}) + "\n")
if host_hash != args.host_binary_sha256 or painter_hash != args.painter_sha256:
    raise RuntimeError("source release or painter binary does not match its pinned SHA-256")
key = sys.stdin.buffer.readline(4096)
if not key or not key.endswith(b"\n"):
    raise RuntimeError("missing private key line")

with ExitStack() as stack:
    diag = stack.enter_context((run / "xvfb.log").open("wb"))
    xvfb = start_display(args.width, args.height, diag)
    stack.callback(stop, xvfb)
    display = get_display(xvfb)

    host_path = run / "host.log"
    host_log = stack.enter_context(host_path.open("wb"))
    host_env = clean_env()
    if args.arm == "adaptive":
        host_env["JWM_REMOTE_ADAPT_VIDEO"] = "desktop"
    if args.send_buffer:
        host_env["LD_PRELOAD"] = str(lab / "accept-buffers.so")
        host_env["P09_SEND_BUFFER"] = str(args.send_buffer)
    host = subprocess.Popen(
        [str(release), "host", "--display", display, "--capture-source", "root", "--scaling", args.host_scaling, "--max-width", "0",
         "--listen", "127.0.0.1:0", "--key-stdin", "--once", "--stats-json", "--allow-h264",
         "--fps", str(args.fps)],
        env=host_env, stdin=subprocess.PIPE, stdout=host_log, stderr=host_log)
    stack.callback(stop, host, natural=True)
    host.stdin.write(key)
    host.stdin.flush()
    port = int(wait_for(host, lambda: re.search(r"listening on 127\.0\.0\.1:(\d+)",
                                                host_path.read_text()), 15).group(1))

    if args.cap:
        proxy_file = run / "proxy.log"
        proxy_log = stack.enter_context(proxy_file.open("wb"))
        proxy_env = clean_env()
        if args.recv_buffer:
            proxy_env["P09_PROXY_RCVBUF"] = str(args.recv_buffer)
        proxy = subprocess.Popen(
            [sys.executable, str(lab / "proxy-compat.py"),
             "--upstream-host", "127.0.0.1", "--upstream-port", str(port),
             "--max-connections", "1", "--session-seconds", str(args.seconds + 35),
             "--s2c-bytes-per-second", str(args.cap),
             "--chunk-bytes", "4096" if args.recv_buffer else "16384"],
            env=proxy_env, stdin=subprocess.DEVNULL, stdout=proxy_log, stderr=proxy_log)
        stack.callback(stop, proxy)

        def proxy_port():
            for line in proxy_file.read_text().splitlines():
                if line.startswith("{") and line.endswith("}"):
                    return json.loads(line)["listening"][1]
            return None

        port = wait_for(proxy, proxy_port)

    paint_path = run / "paint.jsonl"
    paint_log = stack.enter_context(paint_path.open("wb"))
    paint_diag = stack.enter_context((run / "paint-stderr.log").open("wb"))
    painter = subprocess.Popen(
        [str(painter_bin), "paint", "--display", display,
         "--width", str(args.width), "--height", str(args.height), "--fps", str(args.paint_fps),
         "--seconds", str(args.seconds + 55), "--run-id", str(args.run_id), "--seed", "7"],
        env=clean_env(), stdin=subprocess.DEVNULL, stdout=paint_log, stderr=paint_diag)
    stack.callback(stop, painter)
    wait_for(painter, lambda: re.search(r'"type":"p09_start"',paint_path.read_text()), 10)
    print(json.dumps({"upstream_port": port}), flush=True)

    while host.poll() is None:
        if painter.poll() is not None:
            raise RuntimeError("source painter ended during the benchmark")
        if select.select([sys.stdin], [], [], .1)[0] and not sys.stdin.read(1):
            raise RuntimeError("controller disconnected before the benchmark ended")
    if host.returncode:
        raise RuntimeError(f"real host exited with code {host.returncode}")
