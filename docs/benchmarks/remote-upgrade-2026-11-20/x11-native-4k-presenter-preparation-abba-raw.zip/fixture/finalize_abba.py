#!/usr/bin/env python3
"""Recompute the fixed X11 readback ABBA from typed retained evidence."""
import json
import math

from stages import STAGES, bounded_read, bounds, lines, load, markers, stage_rollup

EXPECTED_SIZE = [3840, 2160]
PIN_FIELDS = ("host_binary_sha256", "viewer_binary_sha256", "observer_sha256", "painter_sha256")


def analyze_trial(folder, policy, run_id, expected_size=EXPECTED_SIZE):
    result = load(bounded_read(folder / "result.json"))
    host = lines(bounded_read(folder / "retained-host.jsonl"))
    viewer = lines(bounded_read(folder / "retained-viewer.jsonl"))
    observed = lines(bounded_read(folder / "retained-markers.jsonl"))
    if (result["pilot"] or result["arm"] != "fixed" or result["host_scaling_policy"] != policy
            or result["viewer_scaling_policy"] != "cpu" or result["requested_fps"] != 30
            or result["configured_cap_bytes_per_second"] != 0 or result["send_buffer_bytes_requested"] != 0
            or result["host_rate_targets"] or result["host_nvenc_applies"]):
        raise ValueError("unexpected experimental configuration")
    if result["source_and_encoded_dimensions"] != expected_size or result["codec"] != "H.264"             or result["ffmpeg_encoder"] != "h264_nvenc":
        raise ValueError("expected fixed native-size H.264 NVENC")
    if result["observer_window_seconds"] != 60 or (
        result["viewer_observer_end_ns"] - result["viewer_observer_start_ns"] != 60_000_000_000
    ):
        raise ValueError("observer scoring interval is not exactly 60 seconds")
    observed_span, replayed_source_fps = replay_timing(folder, result, host, viewer, observed, run_id, expected_size)
    unique_fps = len(observed) / 60
    if (not math.isclose(unique_fps, result["observer_unique_frames_per_second"], abs_tol=1e-9)
            or result["uncapped_unique_fps_gate_met"] is not (unique_fps >= 27)):
        raise ValueError("unique FPS differs from the observer marks")
    if not result["session_id"] or {row["session_id"] for row in host + viewer} != {result["session_id"]}:
        raise ValueError("retained windows do not describe the same authenticated session")
    durations = {role: sum(row["window_seconds"] for row in rows)
                 for role, rows in (("host", host), ("viewer", viewer))}
    if len(host) < 12 or len(viewer) < 12 or min(durations.values()) < 60:
        raise ValueError("insufficient whole telemetry windows")
    if not math.isclose(durations["host"], result["host_window_seconds"], abs_tol=1e-7):
        raise ValueError("host telemetry seconds differ from the retained result")
    route = {}
    for name in ("core_readback_ms", "shm_readback_ms", "cpu_resize_ms"):
        route[name] = sum(row.get("x11_capture", {}).get("stages", {}).get(name, {}).get("observations", 0)
                          for row in host)
    expected, other = ("core_readback_ms", "shm_readback_ms") if policy == "cpu" else (
                      "shm_readback_ms", "core_readback_ms")
    if not route[expected] or route[other] or route["cpu_resize_ms"]:
        raise ValueError("actual host counters do not establish the expected native-size readback path")
    for row in host:
        stages = row.get("x11_capture", {}).get("stages", {})
        if row["captured"] and (not stages.get(expected, {}).get("observations")
                               or row["encoded_dimensions"] != expected_size
                               or row["source_dimensions"] != expected_size):
            raise ValueError("active host window changed route or geometry")
        scope = row.get("last_sent_frame")
        if scope and (scope["codec"] != "H.264" or scope["encoded_dimensions"] != expected_size
                      or scope["source_dimensions"] != expected_size):
            raise ValueError("a host frame changed codec or geometry")
        if row["hevc444_frames"] or row["jpeg_atlases"] or row["png_atlases"]:
            raise ValueError("host switched codec")
    presentations = set()
    for row in viewer:
        scope = row.get("last_frame")
        if row["viewer_backend"] != "x11" or row["negotiated_codec"] != "H.264":
            raise ValueError("viewer changed negotiated codec or backend")
        if scope and (scope["codec"] != "H.264" or scope["encoded_dimensions"] != expected_size
                      or scope["source_dimensions"] != expected_size):
            raise ValueError("a viewer frame changed codec or geometry")
        if row.get("last_presentation_path"):
            presentations.add(row["last_presentation_path"])
    if presentations != {"rgb"}:
        raise ValueError(f"viewer route changed: {sorted(presentations)}")

    case = {"name": folder.name, "host": host, "viewer": viewer}
    pins = {field: result["binary_pins"][field] for field in PIN_FIELDS}
    capture = stage_rollup([case], "host", STAGES["host"]["capture"])
    readback = stage_rollup([case], "host", f"x11_capture.stages.{expected}")
    stats = {
        "observer_run_seconds": observed_span,
        "source_replayed_submit_fps": replayed_source_fps,
        "clean_close_from_controller": True,
        "authenticated_session_id": result["session_id"],
        "case": folder.name, "host_scaling_policy": policy, "binary_pins": pins,
        "observer_invalid_reads_full_session": result["viewer_observer_summary"]["invalid"],
        "observation_seconds": 60, "telemetry_seconds": durations, "unique_fps": unique_fps,
        "p95_gap_ms": result["observer_gap_ms"]["p95"], "max_gap_ms": result["observer_gap_ms"]["max"],
        "longest_observer_gaps": markers(result, observed), "capture": capture, "readback": readback,
        "actual_route_observations": route, "capture_mode_labels": sorted({row["mode"] for row in host}),
        "host_zero_frame_windows": result["host_zero_frame_windows"],
        "viewer_zero_drawn_windows": result["viewer_zero_drawn_windows"],
        "payload_mbps": result["host_payload_mbps"],
        "source_submit_fps": result["source_observed_submit_fps"],
        "source_deadline_skips": result["source_summary"]["deadline_skips"],
        "existing_27_fps_gate_met": unique_fps >= 27,
    }
    return case, stats


def rollup(tested):
    stats = [stat for _, stat in tested]
    return {
        "trial_count": len(stats),
        "trial_unique_fps": bounds([row["unique_fps"] for row in stats]),
        "trial_observer_gap_p95_ms": bounds([row["p95_gap_ms"] for row in stats]),
        "trial_observer_longest_gap_ms": bounds([row["max_gap_ms"] for row in stats]),
        "trial_capture_window_p50_medians_ms": bounds([row["capture"]["window_p50_ms"]["median"]
                                                       for row in stats]),
        "trial_readback_window_p50_medians_ms": bounds([row["readback"]["window_p50_ms"]["median"]
                                                        for row in stats]),
        "trials_meeting_existing_27_unique_fps_target": sum(row["existing_27_fps_gate_met"] for row in stats),
        "stages": {
            role: {name: stage_rollup([case for case, _ in tested], role, path)
                   for name, path in list_definitions.items()}
            for role, list_definitions in STAGES.items()
        },
    }


def require(condition, message):
    if not condition:
        raise ValueError(message)


def keep_windows(rows):
    warmup = 0.0
    measured = 0.0
    kept = []
    for row in rows:
        duration = row["window_seconds"] * 1000
        require(math.isfinite(duration) and duration > 0, "invalid telemetry duration")
        if warmup < 30_000:
            warmup += duration
        else:
            kept.append(row)
            measured += duration
            if measured >= 60_000:
                return kept
    raise ValueError("insufficient whole telemetry after 30 seconds of warmup")


def replay_timing(folder, result, host, viewer, marks, run_id, size):
    def read(name):
        return lines(bounded_read(folder / name))

    observed = read("observed.jsonl")
    start, end = observed[0], observed[-1]
    draw_start, draw_end = start["monotonic_ns"], end["monotonic_ns"]
    score_start = draw_start + 30_000_000_000
    score_end = score_start + 60_000_000_000
    require(start["type"] == "p09_start" and end["type"] == "p09_end" and
            start["role"] == end["role"] == "observer" and start["clock"] == "monotonic" and
            start["run_id"] == end["run_id"] == run_id and start["seconds"] == 105 and
            [start["width"], start["height"]] == size and draw_end - draw_start >= 105_000_000_000 and
            score_start == result["viewer_observer_start_ns"] and score_end == result["viewer_observer_end_ns"],
            "marker observer duration, geometry, identity, or 30+60 second scope differs")
    require(end == result["viewer_observer_summary"] and
            not any(end[name] for name in ("wrong_run", "reordered", "interrupted", "target_lost")),
            "observer lost its owned drawable or source identity")
    all_marks = observed[1:-1]
    require(all(row["type"] == "p09_frame" and row["run_id"] == run_id and
                draw_start <= row["monotonic_ns"] <= draw_end for row in all_marks) and
            len(all_marks) == end["unique"], "observer source marks or continuity differ")
    require(marks == [row for row in all_marks if score_start <= row["monotonic_ns"] < score_end],
            "retained marks differ from exact 60 second scoring selection")

    source_start, source_end = read("remote/paint.jsonl")
    require(source_start["type"] == "p09_start" and source_end["type"] == "p09_end" and
            source_start["role"] == source_end["role"] == "source" and
            source_start["run_id"] == source_end["run_id"] == run_id and
            source_start["seed"] == 7 and source_start["fps"] == 60 and source_start["seconds"] == 160 and
            [source_start["width"], source_start["height"]] == size and
            source_end == result["source_summary"], "source painter trace differs from declared workload")
    source_span = (source_end["last_submit_ns"] - source_end["first_submit_ns"]) / 1e9
    require(source_span >= 105, "source painter submitted for fewer than 105 seconds")
    source_fps = (source_end["submitted"] - 1) / source_span
    require(source_fps >= 30 and math.isclose(source_fps, result["source_observed_submit_fps"], abs_tol=1e-9),
            "source submit count or duration differs from preserved score")

    all_host = [row for row in read("remote/host-telemetry.jsonl")
                if row["type"] == "jwm_remote_host_stats" and not row.get("final") and row["window_seconds"] >= 4.999]
    all_viewer = [row for row in read("viewer-telemetry.jsonl")
                  if row["type"] == "jwm_remote_viewer_stats" and not row.get("final")]
    arrivals = [row["end_ns"] for row in read("viewer-clock.jsonl")]
    require(len(all_viewer) == len(arrivals) and all(a < b for a, b in zip(arrivals, arrivals[1:])),
            "viewer arrivals do not pair with original authenticated windows")
    for row, arrival in zip(all_viewer, arrivals):
        row["end_ns"] = arrival
        row["start_ns"] = arrival - round(row["window_seconds"] * 1e9)
    all_viewer = [row for row in all_viewer if row["start_ns"] >= draw_start and row["end_ns"] <= draw_end]
    require(host == keep_windows(all_host) and viewer == keep_windows(all_viewer),
            "retained windows differ from their independently replayed warmup and selection")
    require(sum(row["h264_frames"] for row in host) == result["host_h264_frames"] > 0 and
            sum(row["drawn_acks"] for row in host) == result["host_drawn_acks"] > 0 and
            sum(row["drawn"] for row in viewer) == result["viewer_drawn_frames"] > 0 and
            sum(row["h264_frames"] == 0 for row in host) == result["host_zero_frame_windows"] and
            sum(row["drawn"] == 0 for row in viewer) == result["viewer_zero_drawn_windows"],
            "retained endpoint counters differ from result")

    stats = load(bounded_read(folder / "diagnostics.json"))
    require(stats["host"]["matches"]["nvenc_negotiated"] and
            not stats["host"]["matches"]["hardware_encode_failed"] and
            stats["viewer"]["matches"]["vaapi_active"] and
            stats["viewer"]["matches"]["session_ended"] and
            not stats["viewer"]["matches"]["jpeg_switch"],
            "fixed hardware encode/decode and clean viewer close diagnostics are incomplete")
    remote = load(bounded_read(folder / "remote/binaries.json"))
    pins = result["binary_pins"]
    require(all(remote[key] == pins[key] for key in ("host_binary_sha256", "painter_sha256", "host_scaling_policy"))
            and remote["host_scaling_policy"] == result["host_scaling_policy"],
            "runtime source binary and policy pins differ from the result")
    return (draw_end - draw_start) / 1e9, source_fps


