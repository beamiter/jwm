#!/usr/bin/env python3
"""Read retained NVENC windows and observer marks from bench folders or raw archives."""
import argparse
from contextlib import contextmanager
import json
import math
from pathlib import Path, PurePosixPath
import re
from statistics import median
import zipfile

SELECT = r"^(abba-clear-1080p|native-1440p-30|native-4k-30)-\d+-fixed$"
MAX_FILE_BYTES = 2_000_000
FILES = ("result.json", "retained-host.jsonl", "retained-viewer.jsonl", "retained-markers.jsonl")
STAGES = {
    "host": {
        "capture": "stages.capture_ms",
        "core_getimage": "x11_capture.stages.core_readback_ms",
        "shm_getimage": "x11_capture.stages.shm_readback_ms",
        "x11_rgb_conversion": "x11_capture.stages.pixel_conversion_ms",
        "x11_cpu_resize": "x11_capture.stages.cpu_resize_ms",
        "mailbox_age": "stages.mailbox_age_ms",
        "h264_total": "stages.h264_ms",
        "nvenc_rgb_copy": "hardware_encode_stages.rgb_copy_ms",
        "nvenc_rgb_to_yuv": "hardware_encode_stages.conversion_ms",
        "nvenc_submit": "hardware_encode_stages.submit_ms",
        "nvenc_output": "hardware_encode_stages.output_ms",
        "writer_lock": "stages.writer_wait_ms",
        "socket_write": "stages.socket_write_ms",
        "credit_wait": "stages.credit_wait_ms",
        "send_to_ack": "stages.send_to_ack_ms",
        "capture_to_ack": "stages.capture_start_to_ack_ms",
    },
    "viewer": {
        "decode_path_total": "stages.decode_ms",
        "vaapi_decode_call": "stages.hardware_decode_ms",
        "vaapi_download": "stages.hardware_download_ms",
        "x11_cpu_prepare": "stages.x11_cpu_prepare_ms",
        "x11_presenter_submit": "stages.x11_presenter_submit_ms",
        "yuv_to_rgb": "stages.hardware_conversion_ms",
        "rgb_copy": "stages.hardware_rgb_copy_ms",
        "decode_queue": "stages.decode_queue_ms",
        "presentation_queue": "stages.presentation_queue_ms",
        "presentation_completion": "stages.presentation_completion_ms",
        "native_submit": "stages.native_preparation_and_submit_ms",
    },
}


def load(text):
    return json.loads(text)


def lines(text):
    return [load(line) for line in text.splitlines()]


def bounded_read(file):
    with file.open("rb") as source:
        contents = source.read(MAX_FILE_BYTES + 1)
    if len(contents) > MAX_FILE_BYTES:
        raise ValueError(f"input exceeds bound: {file.name}")
    return contents


@contextmanager
def input_cases(path, select):
    if path.is_dir():
        def directory():
            for folder in sorted(path.iterdir()):
                if folder.is_dir() and select.fullmatch(folder.name) and (folder / FILES[0]).is_file():
                    yield folder.name, {file: bounded_read(folder / file) for file in FILES}
        yield directory()
        return

    with zipfile.ZipFile(path) as archive:
        def members():
            for name in sorted(archive.namelist()):
                member = PurePosixPath(name)
                if member.name != FILES[0] or not select.fullmatch(member.parent.name):
                    continue
                files = {}
                for file in FILES:
                    info = archive.getinfo(str(member.parent / file))
                    if info.file_size > MAX_FILE_BYTES:
                        raise ValueError(f"input exceeds bound: {info.filename}")
                    files[file] = archive.read(info)
                yield member.parent.name, files
        yield members()


def bounds(values):
    return {"minimum": min(values), "median": median(values), "maximum": max(values)} if values else None


def value_at(row, path):
    item = row
    for part in path.split("."):
        item = item.get(part, {})
    return item.get("quantiles", {})


def stage_rollup(cases, role, path):
    measured = []
    for case in cases:
        for index, row in enumerate(case[role], 1):
            quantiles = value_at(row, path)
            if quantiles.get("samples", 0) > 0:
                measured.append((case["name"], index, quantiles))
    return {
        "windows_with_samples": len(measured),
        "recent_samples_in_windows": sum(q["samples"] for _, _, q in measured),
        "window_p50_ms": bounds([q["p50_ms"] for _, _, q in measured]),
        "window_p95_ms": bounds([q["p95_ms"] for _, _, q in measured]),
        "largest_window_p99": max(
            ({"case": name, "window": index, "p99_ms": q["p99_ms"]} for name, index, q in measured),
            key=lambda largest: largest["p99_ms"], default=None),
    }


def markers(result, rows):
    start = result["viewer_observer_start_ns"]
    end = result["viewer_observer_end_ns"]
    if len(rows) != result["observer_unique_source_frames"] or not rows:
        raise ValueError("retained observer marks do not match the preserved result")
    if any(not start <= row["monotonic_ns"] <= end for row in rows):
        raise ValueError("out-of-window observer marker")
    if any(right["monotonic_ns"] <= left["monotonic_ns"] or right["source_frame"] <= left["source_frame"]
           for left, right in zip(rows, rows[1:])):
        raise ValueError("duplicated or out-of-order observer marker")
    route = [(start, None), *((row["monotonic_ns"], row["source_frame"]) for row in rows), (end, None)]
    gaps = sorted(({
        "gap_ms": (right[0] - left[0]) / 1e6,
        "measured_start_offset_ms": (left[0] - start) / 1e6,
        "from_marker": left[1], "to_marker": right[1],
    } for left, right in zip(route, route[1:])), key=lambda gap: gap["gap_ms"], reverse=True)
    reported = result["observer_gap_ms"]
    nearest_p95 = gaps[len(gaps) - math.ceil(.95 * len(gaps))]["gap_ms"]
    if not math.isclose(gaps[0]["gap_ms"], reported["max"], abs_tol=.000001) or not math.isclose(
        nearest_p95, reported["p95"], abs_tol=.000001
    ):
        raise ValueError("observer gaps differ from the preserved scorer")
    return gaps[:3]


def parse_case(name, files, include_pilots):
    result = load(files[FILES[0]])
    if result["pilot"] and not include_pilots:
        return None
    if result["configured_cap_bytes_per_second"] != 0 or result["arm"] != "fixed":
        raise ValueError(f"{name}: expected uncapped fixed NVENC")
    if result["codec"] != "H.264" or result["ffmpeg_encoder"] != "h264_nvenc":
        raise ValueError(f"{name}: expected the same H.264 NVENC codec")
    hosts, viewers, observed = (lines(files[file]) for file in FILES[1:])
    if not hosts or not viewers or {row["session_id"] for row in hosts + viewers} != {result["session_id"]}:
        raise ValueError(f"{name}: retained telemetry does not describe one session")
    size = result["source_and_encoded_dimensions"]
    for row in hosts:
        if row["encoded_dimensions"] != size or row["source_dimensions"] != size:
            raise ValueError(f"{name}: capture was not native-size")
        if row["hevc444_frames"] or row["jpeg_atlases"] or row["png_atlases"]:
            raise ValueError(f"{name}: host codec fallback in retained windows")
    for row in viewers:
        last = row["last_frame"]
        if row["viewer_backend"] != "x11" or row["negotiated_codec"] != "H.264" or (
                last and (last["codec"] != "H.264" or last["encoded_dimensions"] != size or last["source_dimensions"] != size)):
            raise ValueError(f"{name}: viewer size, backend or codec differs")
    modes = sorted({row["mode"] for row in hosts})
    presentations = sorted({row["last_presentation_path"] for row in viewers if row["last_presentation_path"]})
    gaps = markers(result, observed)
    return {"name": name, "result": result, "group": (tuple(size), tuple(modes), tuple(presentations), result["pilot"]),
            "host": hosts, "viewer": viewers, "largest_gaps": gaps}


def report_group(key, cases):
    size, modes, presentations, pilot = key
    results = [case["result"] for case in cases]
    return {
        "dimensions": size, "host_capture_modes": modes, "viewer_presentation_paths": presentations,
        "measurement_kind": "pilot" if pilot else "scored",
        "scored": [case["name"] for case in cases if not case["result"]["pilot"]],
        "unscored": [case["name"] for case in cases if case["result"]["pilot"]],
        "facts": [{
            "name": case["name"], "exact_observer_seconds": case["result"]["observer_window_seconds"],
            "unique_fps": case["result"]["observer_unique_frames_per_second"],
            "kept_host_seconds": case["result"]["host_window_seconds"],
            "viewer_gap_summary_ms": case["result"]["observer_gap_ms"],
            "largest_observed_gaps": case["largest_gaps"],
            "host_payload_mbps": case["result"]["host_payload_mbps"],
            "source_observed_submit_fps": case["result"].get("source_observed_submit_fps"),
            "source_deadline_skips": case["result"].get("source_summary", {}).get("deadline_skips"),
            "host_zero_frame_windows": case["result"]["host_zero_frame_windows"],
            "viewer_zero_drawn_windows": case["result"]["viewer_zero_drawn_windows"],
        } for case in cases],
        "unique_fps": bounds([r["observer_unique_frames_per_second"] for r in results]),
        "trial_gap_p95_ms": bounds([r["observer_gap_ms"]["p95"] for r in results]),
        "trial_longest_gap_ms": bounds([r["observer_gap_ms"]["max"] for r in results]),
        "stages": {role: {name: stage_rollup(cases, role, path) for name, path in stages.items()}
                   for role, stages in STAGES.items()},
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("inputs", type=Path, nargs="+", help="trial parent directories or versioned ZIP archives")
    parser.add_argument("--select", default=SELECT, help="full regex for included case names")
    parser.add_argument("--include-pilots", action="store_true")
    args = parser.parse_args()
    groups, seen = {}, set()
    for path in args.inputs:
        with input_cases(path, re.compile(args.select)) as trials:
            for name, files in trials:
                case = parse_case(name, files, args.include_pilots)
                if case is None:
                    continue
                if name in seen:
                    raise ValueError(f"duplicate input trial: {name}")
                seen.add(name)
                groups.setdefault(case["group"], []).append(case)
    if not groups:
        parser.error("no matching trials")
    print(json.dumps({
        "method": "Each stage summarizes p50/p95 across retained reporting windows. Values describe recent samples "
                  "within windows and cannot reconstruct whole-run quantiles. Stages can overlap. Raw observer "
                  "gaps use exact local monotonic times and include measurement boundary gaps.",
        "groups": [report_group(key, cases) for key, cases in sorted(groups.items())],
    }, indent=2))


if __name__ == "__main__":
    main()
