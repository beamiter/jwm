#!/usr/bin/env python3
"""Publish/replay the fixed native-size 4K X11 presenter preparation comparison."""

import argparse
import json
from pathlib import Path
import re
import tempfile
from zipfile import ZIP_DEFLATED, ZipFile

from build_provenance import BUILD_MEMBER, collect_build_evidence, replay_build_evidence
from fixture_4k import UNSET_ALTERNATIVES
from preparation_stats import COUNTERS, STAGES as OBSERVATION_COUNTERS, check_viewer, ready_to_completion
from evidence_io import (
    IP4, RAW_FIELDS, digest, encoded, failure_summary, link_summary, route_diagnostics, write,
)
from finalize_abba import analyze_trial, require, rollup
from run_abba import EXPECTED, LABEL, ORDERS
from stages import STAGES, bounded_read, stage_rollup


STEM = "x11-native-4k-presenter-preparation"
SIZE = [3840, 2160]
SOURCES = ("fixture_4k.py", "source.py", "processes.py", "p09-workload.c", "run_abba.py")
REPLAYER = ("build_provenance.py", "preparation_stats.py", "evidence_io.py", "finalize_abba.py", "stages.py", "publish_preparation.py")
COUNT_FIELDS = (*COUNTERS, *OBSERVATION_COUNTERS, "active_draw_windows", "windows_with_prepared_submissions", "drawn")


def case_name(label, index, mode):
    return f"{label}-{index:02}-{mode}-fixed"


def all_names(protocol):
    label, order = protocol["label"], protocol["order"]
    return [case_name(label, index, mode) + suffix for index, mode in enumerate(order, 1)
            for suffix in ("", "-retry")]


def quality_evidence(path):
    # The optional witness is independent of marker cadence and may come
    # from owned-drawable pixel checks in a separate validation run.
    raw = bounded_read(path)
    record = json.loads(raw)
    allowed = {"schema_version", "scope", "dimensions", "case", "regions"}
    require(type(record) is dict and set(record) == allowed and record["schema_version"] == 1 and
            record["scope"] in {"owned_drawable_pixel_check", "owned_fixture_pixel_check"} and
            record["dimensions"] == SIZE and type(record["case"]) is str and
            re.fullmatch(r"[a-z0-9-]{1,64}", record["case"]), "optional quality witness schema differs")
    keys = {"pixels_compared", "different_pixels", "expected_rgb_sha256", "observed_rgb_sha256"}
    regions = record["regions"]
    require(type(regions) is list and bool(regions) and all(
        type(row) is dict and set(row) == keys and type(row["pixels_compared"]) is int and
        type(row["different_pixels"]) is int and 0 <= row["different_pixels"] <= row["pixels_compared"] and
        row["pixels_compared"] > 0 and all(type(row[name]) is str and re.fullmatch(r"[0-9a-f]{64}", row[name])
                                           for name in ("expected_rgb_sha256", "observed_rgb_sha256"))
        for row in regions
    ), "optional quality witness lacks typed per-region pixel comparison")
    return record | {"original_sha256": digest(raw)}


def collection(stage, controller_log=None, quality=None, build_dir=None):
    entries = {}
    protocol = json.loads(bounded_read(stage / "protocol.json"))
    entries["run/protocol.json"] = encoded(protocol)
    exit_status = int((stage / "live.exit").read_text().strip())
    entries["run/terminal.json"] = encoded({"exit_status": exit_status})
    for name in SOURCES + REPLAYER:
        local = bounded_read(Path(__file__).with_name(name))
        if name in SOURCES:
            require(digest(local) == protocol["fixture_sources_sha256"][name], "staged fixture source differs: " + name)
        entries["fixture/" + name] = IP4.sub(b"<private-peer>", local)
    # Record a digest for every archived source form and separately keep the
    # pre-stage copies' exact hashes in the protocol.
    entries["fixture/source-archive-sha256.json"] = encoded({
        name: digest(entries["fixture/" + name]) for name in SOURCES + REPLAYER
    })
    for name in all_names(protocol):
        folder = stage / name
        if folder.is_dir():
            for relative in RAW_FIELDS + ("viewer-control.json",):
                path = folder / relative
                if path.is_file():
                    entries[f"run/{name}/{relative}"] = bounded_read(path)
            diagnostics = route_diagnostics(folder, name, entries)
            for relative in ("observer-stderr.log", "remote/paint-stderr.log", "disconnect.log", "remote-copy-error.log"):
                path = folder / relative
                if path.is_file():
                    data = bounded_read(path)
                    diagnostics[relative] = {"bytes": len(data), **failure_summary(data)}
            entries[f"run/{name}/diagnostics.json"] = encoded(diagnostics)
        error = stage / f"{name}-error.log"
        if error.is_file():
            entries[f"run/{name}-error.json"] = encoded(failure_summary(bounded_read(error)))
    if controller_log is not None:
        data = bounded_read(controller_log)
        text = data.decode(errors="replace")
        starts = re.findall(r"^started ([a-z0-9-]+)$", text, re.M)
        failures = re.findall(r"^failed ([a-z0-9-]+):", text, re.M)
        known = set(all_names(protocol))
        entries["run/controller.json"] = encoded({
            **failure_summary(data),
            "reported_starts": [name for name in starts if name in known],
            "reported_failures": [name for name in failures if name in known],
        })
    for phase in ("before", "after"):
        ping = stage / f"link-{phase}.txt"
        if ping.is_file():
            entries[f"run/link-{phase}.json"] = encoded(link_summary(ping))
    if quality is not None:
        entries["quality/owned-pixels.json"] = encoded(quality_evidence(quality))
    if build_dir is not None:
        entries[BUILD_MEMBER] = collect_build_evidence(build_dir)
    return entries


def verify_protocol(protocol, entries):
    study = protocol["study"]
    require(study in ORDERS and protocol["order"] == list(ORDERS[study]) and
            re.fullmatch(rf"{LABEL}-{study}-[a-z0-9]{{1,14}}", protocol["label"]),
            "order or label differs from the declared cadence study")
    for field, expected in {
        "schema_version": 1,
        "dimensions": SIZE, "requested_fps": 30, "source_requested_fps": 60,
        "host_scaling_policy": "auto", "viewer_scaling_policy": "cpu",
        "warmup_seconds": 30, "score_seconds": 60, "observer_seconds": 105,
    }.items():
        require(protocol[field] == expected, "unexpected fixed acquisition protocol: " + field)
    pins = protocol["binary_pins"]
    require(pins == EXPECTED | {"viewer_binary_sha256": pins["viewer_binary_sha256"]} and
            re.fullmatch(r"[0-9a-f]{64}", pins["viewer_binary_sha256"]),
            "pinned endpoint or fixture binary differs")
    source_bytes = json.loads(entries["fixture/source-archive-sha256.json"])
    require(source_bytes == {name: digest(entries["fixture/" + name]) for name in SOURCES + REPLAYER},
            "archived validator or fixture source differs")
    return pins


def candidate_result(folder, mode, index, pins):
    case, stats = analyze_trial(folder, "auto", index, SIZE)
    control = json.loads(bounded_read(folder / "viewer-control.json"))
    require(control == {
        "viewer_mode": mode,
        "viewer_environment_opt_in": "1" if mode == "on" else None,
        "viewer_binary_sha256": pins["viewer_binary_sha256"],
        "viewer_scaling_policy": "cpu",
        "other_route_flags": dict.fromkeys(UNSET_ALTERNATIVES),
    } and stats["binary_pins"] == pins, "actual selected viewer binary/mode differs from declared arm")
    diagnostics = json.loads(bounded_read(folder / "diagnostics.json"))
    viewer = diagnostics["viewer"]["matches"]
    require(viewer["direct_shm_activated"] == viewer["read_ahead_activated"] == 0,
            "a disallowed viewer option became active")
    stats["x11_cpu_preparation"] = check_viewer(case["viewer"], mode)
    stats["decoded_ready_to_completion"] = ready_to_completion(case["viewer"])
    for name in ("x11_cpu_prepare", "x11_presenter_submit", "presentation_completion"):
        stats[name] = stage_rollup([case], "viewer", STAGES["viewer"][name])
    require(stats["x11_presenter_submit"]["window_p95_ms"] and
            stats["presentation_completion"]["window_p95_ms"],
            "viewer has no measured presenter draw or X11 completion windows")
    return case, stats


def arm_summary(cases):
    counts = [stats["x11_cpu_preparation"] for _, stats in cases]
    return rollup(cases) | {"preparation_and_presenter_totals": {key: sum(item[key] for item in counts)
                                                               for key in COUNT_FIELDS}}


def pairs(accepted, order):
    result = []
    for index in range(0, len(accepted), 2):
        pair = accepted[index:index+2]
        scope = {"slots": [index + 1, index + 2], "execution_order": list(order[index:index+2])}
        if None in pair:
            result.append(scope | {"status": "incomplete"})
            continue
        selected = {mode: row for mode, row in zip(order[index:index+2], pair)}
        off, on = selected["off"], selected["on"]
        result.append(scope | {
            "status": "valid",
            "on_minus_off_unique_fps": on["unique_fps"] - off["unique_fps"],
            "on_minus_off_observer_gap_p95_ms": on["p95_gap_ms"] - off["p95_gap_ms"],
            "on_minus_off_observer_max_gap_ms": on["max_gap_ms"] - off["max_gap_ms"],
            "on_minus_off_median_window_presenter_draw_p95_ms":
                on["x11_presenter_submit"]["window_p95_ms"]["median"] -
                off["x11_presenter_submit"]["window_p95_ms"]["median"],
            "on_minus_off_mean_decoded_ready_to_completion_ms":
                on["decoded_ready_to_completion"]["mean_ms"] - off["decoded_ready_to_completion"]["mean_ms"],
            "on_minus_off_median_window_presentation_completion_p95_ms":
                on["presentation_completion"]["window_p95_ms"]["median"] -
                off["presentation_completion"]["window_p95_ms"]["median"],
        })
    return result


def trial_report(root, protocol, pins):
    trials = []
    chosen = []
    tokens = set()
    lanes = {"off": [], "on": []}
    for index, mode in enumerate(protocol["order"], 1):
        name = case_name(protocol["label"], index, mode)
        attempts = []
        accepted = None
        for attempt in (name, name + "-retry"):
            folder = root / attempt
            fail = root / f"{attempt}-error.json"
            present = folder.is_dir()
            if not (present or fail.is_file() or attempt == name):
                continue
            item = {"name": attempt, "raw_directory": attempt if present else None}
            if fail.is_file():
                item |= {"status": "failed", "failure": json.loads(bounded_read(fail))}
            elif not (folder / "result.json").is_file():
                item["status"] = "incomplete_attempt" if present else "missing_attempt"
            else:
                try:
                    require(attempt == name or protocol["retry_failed_trial"] is True, "unplanned retry attempt")
                    case, stats = candidate_result(folder, mode, index, pins)
                    require(stats["authenticated_session_id"] not in tokens, "authenticated session reused between slots")
                except (OSError, ValueError, TypeError, KeyError, IndexError) as error:
                    item |= {"status": "invalid_evidence",
                             "error": str(error) if type(error) is ValueError else type(error).__name__}
                else:
                    item |= {"status": "valid", "metrics": stats}
                    if accepted is None:
                        accepted = item
                        lanes[mode].append((case, stats))
                        tokens.add(stats["authenticated_session_id"])
            attempts.append(item)
        chosen.append(accepted["metrics"] if accepted is not None else None)
        trials.append({
            "block": (index - 1) // 4 + 1, "slot": index, "mode": mode,
            "accepted_case": accepted["name"] if accepted is not None else None, "attempts": attempts,
        })
    return trials, chosen, lanes


def reconstruct(entries):
    protocol = json.loads(entries["run/protocol.json"])
    pins = verify_protocol(protocol, entries)
    terminal = json.loads(entries["run/terminal.json"])["exit_status"]
    require(type(terminal) is int, "invalid terminal status")
    allowed = set(all_names(protocol))
    with tempfile.TemporaryDirectory(prefix="jwm-4k-preparation-replay.") as name:
        root = Path(name)
        for member, data in entries.items():
            path = Path(member)
            require(not path.is_absolute() and ".." not in path.parts, "unsafe archive member")
            if len(path.parts) >= 2 and path.parts[0] == "run":
                candidate = path.parts[1].removesuffix("-error.json")
                if candidate in allowed:
                    write(root.joinpath(*path.parts[1:]), data)
        trials, chosen, lanes = trial_report(root, protocol, pins)
    complete = terminal == 0 and None not in chosen
    activated = complete and all(row["x11_cpu_preparation"]["candidate_path_observed"] for _, row in lanes["on"])
    meets = complete and all(row["existing_27_fps_gate_met"] for _, row in lanes["on"])
    comparisons = pairs(chosen, protocol["order"])
    presenter_tail_reduced = (activated and all(
        pair["on_minus_off_median_window_presenter_draw_p95_ms"] < 0 for pair in comparisons
    ))
    report = {
        "schema_version": 1, "protocol": protocol, "controller_exit": terminal,
        "status": "complete" if complete else "controller_failed" if terminal != 0 else "incomplete_evidence",
        "independent_arm_summaries": {arm: arm_summary(values) for arm, values in lanes.items()},
        "trials": trials, "adjacent_pairs": comparisons,
        "all_on_trials_show_prepared_frames_submitted": activated,
        "all_pairs_reduce_median_window_presenter_draw_p95": presenter_tail_reduced,
        "all_on_trials_meet_27_unique_fps": meets,
        "candidate_27_fps_qualification": protocol["study"] == "abba" and activated and meets,
        "formal_abba": protocol["study"] == "abba",
        "link": {phase: json.loads(entries[f"run/link-{phase}.json"])
                 for phase in ("before", "after") if f"run/link-{phase}.json" in entries},
        "controller": json.loads(entries["run/controller.json"]) if "run/controller.json" in entries else {},
        "method": (
            "One pinned Ubuntu fixed H.264 NVENC host uses native MIT-SHM readback. A single pinned Mint "
            "viewer uses VA-API download and CPU X11 RGB. Only JWM_REMOTE_X11_PREPARE changes. "
            "Worker native preparation and presenter whole draw-call time are separate software measurements. "
            "Worker timings are recorded when the UI receives the completed job, including obsolete or failed jobs. "
            "Prepared counts successful packing, submitted counts valid prepared draws, and fallback counts a synchronous "
            "draw after failed or obsolete viewport preparation. Stale counts discarded source or geometry work. "
            "These events can cross reporting windows. "
            "Existing completion includes X11 events and upload/copy fences; quantiles summarize whole windows. "
            "Each visible marker score uses 60 seconds after 30 seconds warmup. The pair is diagnostic. "
            "These view-only trials measure cadence and presenter work; software input response is outside their scope."
        ),
    }
    if BUILD_MEMBER in entries:
        report["viewer_build"] = replay_build_evidence(entries[BUILD_MEMBER], pins["viewer_binary_sha256"])
    if "quality/owned-pixels.json" in entries:
        witness = json.loads(entries["quality/owned-pixels.json"])
        report["optional_owned_pixel_witness"] = witness | {
            "matched_all_regions": all(row["different_pixels"] == 0 and
                                       row["expected_rgb_sha256"] == row["observed_rgb_sha256"]
                                       for row in witness["regions"]),
        }
    return json.loads(encoded(report))


def replay(summary, archive):
    expected = json.loads(summary.read_bytes())
    index = expected.pop("archive")
    require(index["path"] == archive.name and index["sha256"] == digest(archive.read_bytes()), "raw ZIP identity changed")
    with ZipFile(archive) as reader:
        names = reader.namelist()
        require(len(set(names)) == len(names) and set(names) == set(index["entries"]), "raw ZIP inventory changed")
        entries = {name: reader.read(name) for name in names}
    require({name: digest(data) for name, data in entries.items()} == index["entries"], "raw ZIP entry changed")
    require(reconstruct(entries) == expected, "offline score and qualification differ")
    return expected


def publish(entries, out):
    report = reconstruct(entries)
    out.mkdir(parents=True, exist_ok=True)
    stem = f"{STEM}-{report['protocol']['study']}"
    summary = out / f"{stem}.json"
    archive = out / f"{stem}-raw.zip"
    require(not summary.exists() and not archive.exists(), "use a fresh publication directory")
    with ZipFile(archive, "x", compression=ZIP_DEFLATED, compresslevel=7) as writer:
        for name, data in sorted(entries.items()):
            writer.writestr(name, data)
    report["archive"] = {"path": archive.name, "sha256": digest(archive.read_bytes()),
                         "entries": {name: digest(data) for name, data in entries.items()}}
    with summary.open("xb") as output:
        output.write(encoded(report))
    replay(summary, archive)
    print(report["status"], summary, archive)


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    commands = cli.add_subparsers(dest="command", required=True)
    pack = commands.add_parser("publish")
    pack.add_argument("--run", required=True, type=Path)
    pack.add_argument("--out", required=True, type=Path)
    pack.add_argument("--controller-log", type=Path)
    pack.add_argument("--build-dir", type=Path, help="Optional exact staged release build records")
    pack.add_argument("--quality-witness", type=Path, help="Optional standalone typed owned-drawable pixel comparison")
    verify = commands.add_parser("replay")
    verify.add_argument("summary", type=Path)
    verify.add_argument("archive", type=Path)
    args = cli.parse_args()
    if args.command == "publish":
        if not (args.run / "live.exit").is_file():
            cli.error("no terminal controller status; leave running trial data untouched")
        publish(collection(args.run, args.controller_log, args.quality_witness, args.build_dir), args.out)
    else:
        print(replay(args.summary, args.archive)["status"], "reproduced from", args.archive)


if __name__ == "__main__":
    main()
