"""Retain proven release build pins without associating later worktree tests."""

import hashlib
import json
import re
import subprocess

from evidence_io import digest, encoded
from finalize_abba import require
from stages import bounded_read


BUILD_MEMBER = "build/viewer.json"
SOURCE_FILES = {"Cargo.toml", "Cargo.lock", "src/remote/client.rs", "src/remote/frame.rs",
                "src/remote/x11_viewer.rs", "src/remote/h264.rs"}
BUILD_FILES = ("binary.sha256", "source.sha256", "rustc.txt", "build.exit", "build.log",
               "remote-test.exit", "remote-test.log")
SHA256 = re.compile(r"[0-9a-f]{64}")
FINISH = re.compile(r"Finished `release` profile \[optimized\] target\(s\) in [0-9ms. ]+")
RUST = re.compile(r"rustc [0-9]+\.[0-9]+\.[0-9]+ \([0-9a-f]+ [0-9-]+\)")
RUN = re.compile(r"running ([0-9]+) tests?")
TEST = re.compile(r"test result: ok\. ([0-9]+) passed; ([0-9]+) failed; ([0-9]+) ignored; "
                  r"([0-9]+) measured; ([0-9]+) filtered out; finished in ([0-9.]+)s")
ABI = ("libavcodec.so.60", "libavutil.so.58", "libswscale.so.7")


def collect_build_evidence(directory):
    files = {name: bounded_read(directory / name) for name in BUILD_FILES}
    binary = re.fullmatch(r"([0-9a-f]{64})  [^\r\n]*jwm-remote\n?", files["binary.sha256"].decode())
    viewer = directory / "jwm-remote"
    with viewer.open("rb") as handle:
        actual = hashlib.file_digest(handle, "sha256").hexdigest()
    require(binary is not None and binary[1] == actual, "release manifest differs from its staged viewer")
    source = {}
    for line in files["source.sha256"].decode().splitlines():
        pair = re.fullmatch(r"([0-9a-f]{64})  ([A-Za-z0-9_./-]+)", line)
        require(pair is not None and pair[2] not in source, "invalid build source manifest")
        source[pair[2]] = pair[1]
    test_log = [line.strip() for line in files["remote-test.log"].decode().splitlines()]
    starts = [line for line in test_log if RUN.fullmatch(line)]
    results = [line for line in test_log if TEST.fullmatch(line)]
    release = [line.strip() for line in files["build.log"].decode().splitlines() if FINISH.fullmatch(line.strip())]
    require(starts and results and len(release) == 1, "compiled viewer or outer test terminal record missing")
    elf = subprocess.run(["readelf", "-d", str(viewer)], check=True, timeout=5, capture_output=True).stdout.decode()
    libs = [lib for lib in re.findall(r"Shared library: \[([^\]]+)\]", elf)
            if lib.startswith(("libavcodec.so.", "libavutil.so.", "libswscale.so."))]
    result = {
        "binary_sha256": actual, "binary_bytes": viewer.stat().st_size,
        "rustc": files["rustc.txt"].decode().strip(),
        "source_sha256": source, "release_exit": int(files["build.exit"]),
        "release_terminal_line": release[0],
        "test_exit": int(files["remote-test.exit"]),
        "test_start": starts[0], "test_final": results[-1],
        "ffmpeg_sonames": sorted(libs),
        "other_files_sha256_before_omission": {name: digest(data) for name, data in files.items()},
    }
    return encoded(result)


def replay_build_evidence(data, viewer_pin):
    build = json.loads(data)
    require(SHA256.fullmatch(viewer_pin) and build["binary_sha256"] == viewer_pin and
            type(build["binary_bytes"]) is int and build["binary_bytes"] > 0, "viewer build pin differs from trial")
    sources = build["source_sha256"]
    require(sources.keys() == SOURCE_FILES and all(SHA256.fullmatch(pin) for pin in sources.values()),
            "recorded release source pin scope differs")
    require(RUST.fullmatch(build["rustc"]) and build["release_exit"] == 0 and
            FINISH.fullmatch(build["release_terminal_line"]) and build["ffmpeg_sonames"] == list(ABI),
            "release toolchain, status or linked FFmpeg ABI differs")
    start = RUN.fullmatch(build["test_start"])
    terminal = TEST.fullmatch(build["test_final"])
    require(start and terminal and build["test_exit"] == 0, "remote aggregate test record missing")
    tests = dict(zip(("passed", "failed", "ignored", "measured", "filtered_out"), map(int, terminal.groups()[:5])))
    require(tests["failed"] == 0 and tests["passed"] > 0 and
            sum(tests[field] for field in ("passed", "failed", "ignored", "measured")) == int(start[1]),
            "outer remote test counts do not match")
    original = build["other_files_sha256_before_omission"]
    require(original.keys() == set(BUILD_FILES) and all(SHA256.fullmatch(pin) for pin in original.values()),
            "invalid original build record digests")
    return {
        "viewer_binary_sha256": viewer_pin, "viewer_binary_bytes": build["binary_bytes"],
        "release_profile": "optimized", "release_exit": build["release_exit"], "rustc": build["rustc"],
        "ffmpeg_sonames": build["ffmpeg_sonames"], "source_sha256": sources,
        "remote_library_test": tests | {"exit_status": build["test_exit"], "seconds": float(terminal[6])},
        "scope": (
            "SHA manifest recorded for the benchmark release binary. Cargo tests ran in separate test executables. "
            "The source pins describe the recorded build and exclude subsequent worktree test changes."
        ),
    }
