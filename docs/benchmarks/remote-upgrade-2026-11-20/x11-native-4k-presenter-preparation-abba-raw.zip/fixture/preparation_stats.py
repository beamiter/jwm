"""Validate actual presenter preparation and CPU X11 RGB telemetry."""

import math

from finalize_abba import require


COUNTERS = ("scheduled", "prepared", "submitted", "fallbacks", "stale")
STAGES = {
    "worker_observations": "x11_cpu_prepare_ms",
    "presenter_draw_observations": "x11_presenter_submit_ms",
    "download_observations": "hardware_download_ms",
    "conversion_observations": "hardware_conversion_ms",
}


def count(data, key):
    value = data[key]
    require(type(value) is int and value >= 0, f"invalid viewer count for {key}")
    return value


def observations(row, stage):
    return count(row["stages"][stage], "observations")


def check_viewer(windows, mode):
    retained = []
    for index, row in enumerate(windows, 1):
        require(count(row, "native_presented") == 0 and
                (not row["drawn"] or row["last_presentation_path"] == "rgb") and
                observations(row, "native_preparation_and_submit_ms") == 0,
                "viewer escaped CPU X11 RGB presentation")
        delta = {name: count(row["x11_cpu_preparation"], name) for name in COUNTERS}
        samples = {name: observations(row, field) for name, field in STAGES.items()}
        vaapi = row.get("hardware_rgb_work", {}).get("vaapi_map")
        if vaapi is not None:
            require(all(count(vaapi, field) == 0 for field in ("mapped_frames", "fallback_frames", "staged_bytes")),
                    "VA-API map option appeared in the fixed download route")
        require(samples["download_observations"] == samples["conversion_observations"],
                "VA-API download and CPU conversion observations changed route")
        if mode == "off":
            require(not any(delta.values()) and samples["worker_observations"] == 0,
                    "OFF arm used X11 preparation worker")
        retained.append({
            "window": index, "seconds": row["window_seconds"], "drawn": count(row, "drawn"),
            **delta, **samples,
        })
    keys = (*COUNTERS, *STAGES, "drawn")
    totals = {field: sum(row[field] for row in retained) for field in keys}
    require(totals["drawn"] and totals["presenter_draw_observations"] and totals["download_observations"],
            "no active matched CPU presenter and VA-API download scope")
    # Producer and consumer work can cross a reporting boundary. Validate the
    # route from observed totals and keep individual window counts intact.
    return {
        **totals,
        "active_draw_windows": sum(window["drawn"] > 0 for window in retained),
        "windows_with_prepared_submissions": sum(window["submitted"] > 0 for window in retained),
        "candidate_path_observed": all(totals[key] > 0 for key in
                                       ("scheduled", "prepared", "submitted", "worker_observations")),
        "windows": retained,
    }



def ready_to_completion(windows):
    counted = 0
    queue_total = completion_total = 0.0
    for window in windows:
        queue = window["stages"]["presentation_queue_ms"]
        completion = window["stages"]["presentation_completion_ms"]
        n = count(queue, "observations")
        require(n == count(completion, "observations") == count(window, "drawn"),
                "queue and presentation completion timings do not cover the same draws")
        if n:
            require(all(type(stage["mean"]) in (int, float) and math.isfinite(stage["mean"]) and stage["mean"] >= 0
                        for stage in (queue, completion)), "invalid presentation timing mean")
            counted += n
            queue_total += n * queue["mean"]
            completion_total += n * completion["mean"]
    require(counted > 0, "no draws with both presentation timestamps")
    return {
        "same_observations": counted, "mean_queue_ms": queue_total / counted,
        "mean_completion_ms": completion_total / counted, "mean_ms": (queue_total + completion_total) / counted,
        "scope": "Observation-weighted sum of queue and completion means from the same recorded draws.",
    }
