#!/usr/bin/env python3
"""Run pinned 4K X11 presenter preparation comparisons on private displays."""

import argparse
import fcntl
import json
from pathlib import Path
import re
import shutil
import subprocess
import traceback

import fixture_4k
from processes import sha256


LABEL = "x11-prepare-4k"
ORDERS = {"pair": ("off", "on"), "abba": ("off", "on", "on", "off") * 2}
LOCK = Path("/tmp/jwm-p08-p09-release/benchmark.lock")
EXPECTED = {
    "host_binary_sha256": fixture_4k.HOST_PIN,
    "painter_sha256": fixture_4k.PAINTER_PIN,
    "observer_sha256": fixture_4k.OBSERVER_PIN,
}


def copy_pinned(source, target, digest):
    # Every trial dispatches the same private file even if the caller replaces
    # the original candidate path after staging.
    source = source.resolve(strict=True)
    with target.open("xb") as output, source.open("rb") as read:
        shutil.copyfileobj(read, output)
    target.chmod(0o500)
    if sha256(target) != digest:
        raise ValueError(f"copied {target.name} SHA-256 does not match the declared pin")
    return target


def store_json(path, value):
    with path.open("x") as output:
        json.dump(value, output, indent=2)
        output.write("\n")


def link_snapshot(out, phase):
    with (out / f"link-{phase}.txt").open("xb") as output:
        endpoint = fixture_4k.remote.split("@", 1)[1]
        try:
            subprocess.run(["ping", "-q", "-c", "8", "-i", "0.25", "-W", "1", endpoint],
                           stdout=output, stderr=subprocess.STDOUT, timeout=8, check=False)
        except (OSError, subprocess.TimeoutExpired) as error:
            output.write(f"link observation unavailable: {type(error).__name__}\n".encode())


def run_trials(opts):
    opts.out.mkdir(mode=0o700)
    order = ORDERS[opts.study]
    label = f"{LABEL}-{opts.study}-{opts.tag}"
    protocol = {
        "schema_version": 1,
        "label": label,
        "study": opts.study,
        "order": order,
        "scenario": "4K native-size X11 CPU viewer pixel preparation",
        "dimensions": [3840, 2160],
        "requested_fps": 30,
        "source_requested_fps": 60,
        "host_scaling_policy": "auto",
        "viewer_scaling_policy": "cpu",
        "warmup_seconds": 30,
        "score_seconds": 60,
        "observer_seconds": 105,
        "retry_failed_trial": opts.retry_failed_trial,
        "binary_pins": EXPECTED | {"viewer_binary_sha256": opts.viewer_binary_sha256},
        "fixture_sources_sha256": {name: sha256(Path(__file__).with_name(name))
                                   for name in ("fixture_4k.py", "source.py", "processes.py", "p09-workload.c",
                                                "run_abba.py")},
    }
    store_json(opts.out / "protocol.json", protocol)
    opts.viewer_bin = copy_pinned(opts.viewer_bin, opts.out / "private-viewer", opts.viewer_binary_sha256)
    opts.observer_bin = copy_pinned(fixture_4k.painter_bin, opts.out / "private-observer", fixture_4k.OBSERVER_PIN)
    opts.width, opts.height, opts.fps, opts.paint_fps, opts.seconds = 3840, 2160, 30, 60, 105
    opts.cap = opts.send_buffer = opts.recv_buffer = 0
    opts.host_scaling, opts.arm, opts.pilot = "auto", "fixed", False
    opts.host_binary_sha256 = EXPECTED["host_binary_sha256"]
    opts.observer_sha256 = EXPECTED["observer_sha256"]
    opts.painter_sha256 = EXPECTED["painter_sha256"]
    failures = []
    with LOCK.open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        link_snapshot(opts.out, "before")
        for index, mode in enumerate(order, 1):
            opts.viewer_mode = mode
            name = f"{label}-{index:02}-{mode}-fixed"
            attempts = (name, name + "-retry") if opts.retry_failed_trial else (name,)
            for attempt in attempts:
                print(f"started {attempt}", flush=True)
                try:
                    fixture_4k.run_trial(opts, attempt, index)
                except (OSError, RuntimeError, subprocess.SubprocessError, ValueError, KeyError) as error:
                    print(f"failed {attempt}: {error}", flush=True)
                    (opts.out / f"{attempt}-error.log").write_text(traceback.format_exc())
                    if attempt == attempts[-1]:
                        failures.append(attempt)
                else:
                    break
        link_snapshot(opts.out, "after")
    return 1 if failures else 0


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--viewer-bin", required=True, type=Path)
    cli.add_argument("--viewer-binary-sha256", required=True)
    cli.add_argument("--remote-dir", required=True, help="Existing private Ubuntu source.py/processes.py/painter directory")
    cli.add_argument("--out", required=True, type=Path, help="New private scratch run directory")
    cli.add_argument("--study", choices=ORDERS, default="pair")
    cli.add_argument("--tag", required=True, help="Unique lower-case campaign suffix for the existing remote stage")
    cli.add_argument("--retry-failed-trial", action="store_true")
    args = cli.parse_args()
    if not re.fullmatch(r"[0-9a-f]{64}", args.viewer_binary_sha256):
        cli.error("the same viewer binary for both arms requires a predeclared SHA-256")
    if not re.fullmatch(r"[a-z0-9]{1,14}", args.tag):
        cli.error("use a unique campaign tag of 1 to 14 lower-case alphanumeric characters")
    if not re.fullmatch(r"/tmp/jwm-p09-stage-ab\.[A-Za-z0-9]+", args.remote_dir):
        cli.error("expected the existing private Ubuntu stage-ab source directory")
    args.out = args.out.resolve()
    if args.out.exists() or not args.out.parent.is_dir():
        cli.error("select a new run directory beneath an existing private scratch parent")
    try:
        result = run_trials(args)
    except (KeyboardInterrupt, OSError, ValueError):
        traceback.print_exc()
        result = 1
    if (args.out / "protocol.json").is_file():
        with (args.out / "live.exit").open("x") as output:
            print(result, file=output)
    return result


if __name__ == "__main__":
    raise SystemExit(main())
