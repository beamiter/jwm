#!/usr/bin/env python3
"""Run the pinned dual Firefox raster fixture on two private Mint displays."""

import argparse
from contextlib import ExitStack
import fcntl
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import tempfile
import traceback
import uuid

import dual_browser as baseline


HERE = Path(__file__).resolve().parent
RELEASE = Path('/tmp/jwm-p08-p09-release/jwm-remote')
FIREFOX = Path('/usr/bin/firefox')
FIREFOX_BINARY = Path('/usr/lib/firefox/firefox-bin')
FFMPEG_LIBS = Path('/tmp/jwm-remote-ffmpeg/usr/lib/x86_64-linux-gnu')
RELEASE_SHA = '5e1951ed8bbc23f41db5b5918931d91a37baa1e9fa213c8ef9067a214a1511e5'
FIREFOX_SHA = 'ddf58d7cb36bd35e8e9dab7bc70ce31e17340ce87fc7c0fe81e495ccbd863965'
FIREFOX_METADATA = {'Version': '152.0.5', 'BuildID': '20260706120035'}
FIXTURE_SHA = {
    'dual_browser.py': '536dcdba618644b8954fd3adeaf13cd6581b7a4a311e8ad54cc04f8c60935d62',
    'run_baseline.py': '5bd348c562da0f6381ca45aca1072a1765d5e8f33b257d0647721e6e87825d46',
    'processes.py': 'b1628dc5f7ec4ae82b98f1c18fc9415a5435d7f6d1fc3a7083a6421a3c78b494',
    'score.py': '15f9e47b05e2fc90c12df8ee34ec0a20c643b4e4bd963856b0015c7f56d144d3',
    'browser-trial.html': '3a104c1d365f224f07c388c66478d843ea29e56dfd52cde5b10b4acd51038c2c',
    'firefox-profile-user.js': '5b6d7fa4a2fae76978dddd3835bf9ed330e53e125a5d20ad5d67e2817c7bd771',
    'fixture-manifest.json': 'b3ad4bac6df43044599c5399a08c47f8bffa5a0a19debf51f121ba25c3a923d7',
}
SCOPE = ('1080p Firefox/JPEG software raster diagnostic on two owned Xvfb displays '
         'on Mint, over an authenticated IPv4 loopback connection.')


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def firefox_metadata(executable):
    application_ini = Path(executable).with_name('application.ini')
    return dict(re.findall(r'^(Version|BuildID)=(.+)$', application_ini.read_text(), re.M))


def preflight():
    for name, expected in FIXTURE_SHA.items():
        require(baseline.sha256(HERE / name) == expected, f'pinned fixture changed: {name}')
    require(baseline.sha256(RELEASE) == RELEASE_SHA, 'pinned Mint release changed')
    require(baseline.sha256(FIREFOX_BINARY) == FIREFOX_SHA
            and firefox_metadata(FIREFOX_BINARY) == FIREFOX_METADATA, 'pinned Firefox changed')
    require(FIREFOX.is_file() and os.access(FIREFOX, os.X_OK), 'missing original Firefox launcher')
    require(FFMPEG_LIBS.is_dir(), 'missing the original Mint runtime library directory')
    require(all(shutil.which(name) for name in ('Xvfb', 'xwininfo', 'xdotool', 'ss', 'dbus-run-session')),
            'the original X11 fixture tools are unavailable')
    require((baseline.SIZE, baseline.REQUESTED_FPS, baseline.WARM_SECONDS,
             baseline.MEASURE_SECONDS, baseline.TAIL_SECONDS) == ((1920, 1080), 30, 30, 60, 8),
            'the clean fixture dimensions or phase timings changed')
    return {
        'scope': SCOPE,
        'diagnostic_batch': True,
        'same_machine': True,
        'transport': 'Direct authenticated TCP on 127.0.0.1',
        'source': 'Original pinned Mint Firefox and private X11 root capture',
        'viewer': 'Original pinned Mint release, private X11 RGB viewer with a 1:1 drawable',
        'dimensions': baseline.SIZE,
        'requested_fps': baseline.REQUESTED_FPS,
        'warm_seconds': baseline.WARM_SECONDS,
        'score_seconds': baseline.MEASURE_SECONDS,
        'telemetry_tail_seconds': baseline.TAIL_SECONDS,
        'codec': 'JPEG',
        'jpeg_quality': 85,
        'fixed_jpeg_quality': True,
        'host_release_sha256': RELEASE_SHA,
        'viewer_release_sha256': RELEASE_SHA,
        'firefox_sha256': FIREFOX_SHA,
        'firefox_metadata': FIREFOX_METADATA,
        'fixture_sha256': FIXTURE_SHA,
        'local_runner_sha256': baseline.sha256(__file__),
        'workload': json.loads((HERE / 'fixture-manifest.json').read_bytes()),
    }


def close_viewer_worker(worker):
    # EOF lets the reused viewer worker unwind both child processes itself.
    # If the worker is wedged, only its own new process group is terminated.
    if not worker.stdin.closed:
        worker.stdin.close()
    try:
        worker.wait(timeout=6)
    except subprocess.TimeoutExpired:
        baseline.stop_group(worker)
    worker.stdout.close()


def running_endpoint_pins(source, viewer, worker):
    require(viewer['boot_id'] == source['boot_id'] and viewer['hostname'] == source['hostname'],
            'loopback endpoints do not identify the same machine')
    require(viewer['display'] != source['display'] and viewer['xvfb']['pid'] != source['xvfb']['pid'],
            'loopback endpoints did not use distinct owned Xvfb displays')
    children_file = Path(f'/proc/{worker.pid}/task/{worker.pid}/children')
    children = set(map(int, children_file.read_text().split()))
    require({viewer['endpoint_process']['pid'], viewer['xvfb']['pid']} <= children,
            'viewer or Xvfb does not belong to the local fixture worker')
    for endpoint in (source, viewer):
        process = endpoint['endpoint_process']
        require(baseline.process_identity(process['pid']) == process,
                f'{endpoint["role"]} changed process identity')
        running_sha = baseline.sha256(f'/proc/{process["pid"]}/exe')
        require(running_sha == endpoint['release_sha256'] == RELEASE_SHA,
                f'{endpoint["role"]} is not the pinned Mint release')
        endpoint['endpoint_executable_sha256'] = running_sha


def run_trial(run):
    run_id = uuid.uuid4().hex
    width, height = baseline.SIZE
    with ExitStack() as stack:
        env, xvfb, display = baseline.runtime(stack, run)
        browser, pixels, placement = baseline.source_setup(
            stack, argparse.Namespace(firefox=str(FIREFOX)), run, env, display)
        origin_x, tile_top, header_top = placement
        firefox = baseline.firefox_identity(browser, run / 'firefox-profile')
        metadata = firefox_metadata(firefox['exe'])
        require(firefox['sha256'] == FIREFOX_SHA and metadata == FIREFOX_METADATA,
                'the owned running Firefox does not match the original trial')
        key = run / 'key'
        stack.callback(key.unlink, missing_ok=True)
        subprocess.run([str(RELEASE), 'keygen', '--output', str(key)], env=env,
                       stdout=subprocess.DEVNULL, timeout=8, check=True)
        host = subprocess.Popen(
            [str(RELEASE), 'host', '--display', display, '--capture-source', 'root',
             '--scaling', 'auto', '--once', '--listen', '127.0.0.1:0', '--key-file', str(key),
             '--stats-json', '--fps', str(baseline.REQUESTED_FPS), '--jpeg-quality', '85',
             '--fixed-jpeg-quality'], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        stack.callback(baseline.stop, host)
        monitor, errors = baseline.monitor_stderr(host, 'host', run)

        def listen_port():
            log = run / 'host.log'
            if not log.exists():
                return None
            match = re.search(r'listening on 127\.0\.0\.1:(\d+)', log.read_text())
            return int(match.group(1)) if match else None

        port = baseline.wait_for(host, listen_port)
        worker_env = baseline.clean_env()
        worker_env.pop('LD_PRELOAD', None)
        worker = subprocess.Popen(
            [sys.executable, '-B', '-u', str(HERE / 'dual_browser.py'), 'viewer',
             '--run-dir', str(run / 'viewer'), '--run-id', run_id, '--port', str(port),
             '--origin-x', str(origin_x), '--tile-top', str(tile_top), '--release', str(RELEASE)],
            env=worker_env, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=stack.enter_context((run / 'viewer-worker.log').open('wb')), start_new_session=True)
        stack.callback(close_viewer_worker, worker)
        worker.stdin.write(key.read_bytes())
        worker.stdin.flush()
        events = baseline.Messages(worker.stdout, run / 'viewer-events.jsonl', 'viewer_disconnected')
        viewer = events.expect('viewer_ready', run_id, timeout=30)['identity']
        source = baseline.endpoint('host', RELEASE, display, xvfb, host)
        source['firefox_launcher'] = baseline.process_identity(browser)
        source['firefox'] = firefox
        source['installed_firefox_application'] = metadata
        running_endpoint_pins(source, viewer, worker)
        baseline.write_json(run / 'identity.json', {
            'run_id': run_id, 'host': source, 'viewer': viewer,
            'transport': 'IPv4 loopback', 'local_port': port,
        })

        lanes = {'source': (pixels, pixels.root)}
        processes = (browser, xvfb, host, worker, events)
        baseline.send(worker.stdin, 'static', run_id)
        events.expect('viewer_static_started', run_id)
        static = baseline.collect_phase('static', run, lanes, processes, width, tile_top)
        events.expect('viewer_static_done', run_id, timeout=baseline.PIPE_TIMEOUT)
        raster = baseline.verify_geometry(pixels, pixels.root)
        baseline.write_capture(run / 'source-static-end.ppm', raster)
        require(baseline.find_static_page(raster) == placement,
                'source browser layout changed before the motion click')

        initial = baseline.sample(pixels, pixels.root, width, tile_top)[1]
        baseline.send(worker.stdin, 'motion', run_id)
        events.expect('viewer_motion_armed', run_id)
        subprocess.run(['xdotool', 'mousemove', '80', str(header_top + 30), 'click', '1',
                        'mousemove', str(width - 5), str(height - 5)], env=dict(env, DISPLAY=display),
                       timeout=5, check=True)
        baseline.wait_motion(browser, pixels, pixels.root, (origin_x, tile_top), initial, 8)
        motion = baseline.collect_phase('motion', run, lanes, processes, width, tile_top)
        baseline.write_capture(run / 'source-motion-end.ppm', baseline.verify_geometry(pixels, pixels.root))
        events.expect('viewer_motion_done', run_id, timeout=baseline.PIPE_TIMEOUT)
        baseline.send(worker.stdin, 'disconnect', run_id)
        events.expect('viewer_disconnected', run_id, timeout=25)
        worker.stdin.close()
        viewer_status, host_status = worker.wait(timeout=8), host.wait(timeout=12)
        monitor.join(timeout=4)
        baseline.write_json(run / 'shutdown.json', {
            'host_exit': host_status, 'viewer_worker_exit': viewer_status,
            'viewer_disconnect_event': True, 'host_stats_finished': not monitor.is_alive(),
        })
        require(not viewer_status and not host_status and not monitor.is_alive() and not errors,
                f'owned endpoints did not close cleanly: host={host_status}, viewer={viewer_status}, {errors}')
        for phase in (static, motion):
            baseline.save_phase(run, phase, 'host')

    # Invoke the unchanged dual grader and relabel only the transport scope.
    result = baseline.summarize(run)
    result_path = run / 'result.json'
    full = json.loads(result_path.read_bytes())
    full.update(scope=SCOPE, diagnostic_only=True)
    baseline.write_json(result_path, full)
    return result | {'scope': SCOPE, 'diagnostic_only': True}


def stop_on_signal(number, _frame):
    raise KeyboardInterrupt(f'controller received signal {number}')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--trials', type=int, choices=(1, 3), default=1)
    parser.add_argument('--check-inputs', action='store_true', help='verify pins without starting a workload')
    args = parser.parse_args()
    try:
        manifest = preflight()
    except (RuntimeError, OSError) as error:
        parser.error(str(error))
    if args.check_inputs:
        print(json.dumps(manifest, indent=2, sort_keys=True))
        return 0

    os.environ.update(LD_LIBRARY_PATH=str(FFMPEG_LIBS), GIO_USE_VFS='local', GTK_USE_PORTAL='0')
    signal.signal(signal.SIGTERM, stop_on_signal)
    outcomes = []
    with open(baseline.LOCK, 'a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        batch = Path(tempfile.mkdtemp(prefix='loopback.', dir=HERE))
        print(batch, flush=True)
        baseline.write_json(batch / 'manifest.json', manifest | {'requested_trials': args.trials})
        for trial in range(1, args.trials + 1):
            run = batch / f'trial-{trial:02}'
            run.mkdir(mode=0o700)
            try:
                result = run_trial(run)
            except KeyboardInterrupt:
                (run / 'failure.log').write_text(traceback.format_exc())
                outcomes.append({'trial': trial, 'status': 'interrupted'})
                baseline.write_json(batch / 'outcomes.json', outcomes)
                raise
            except Exception as error:
                (run / 'failure.log').write_text(traceback.format_exc())
                outcomes.append({'trial': trial, 'status': 'failed', 'error': str(error)})
            else:
                outcomes.append({'trial': trial, 'status': 'completed', 'result': result})
            baseline.write_json(batch / 'outcomes.json', outcomes)
            print(json.dumps(outcomes[-1]), flush=True)
    return int(any(row['status'] != 'completed' for row in outcomes))


if __name__ == '__main__':
    raise SystemExit(main())
