"""Exact Firefox raster and whole-window telemetry replay shared with the dual-X11 verifier."""

import hashlib
import json
import math
import re
import sys
import tempfile
from pathlib import Path

DIMENSIONS = [1920, 1080]
SECOND = 1_000_000_000
WARM, SCORE, TAIL, FPS = 30, 60, 8, 30
PHASES = ("static", "motion")
ROLES = {"host": "source", "viewer": "viewer"}
PEER_EVENTS = ["viewer_ready", "viewer_static_started", "viewer_static_done",
               "viewer_motion_armed", "viewer_motion_done", "viewer_disconnected"]
VIEWER_EVENTS = ["static", "motion", "disconnect"]
SESSION_END = "jwm-remote: session ended"
SHA256 = re.compile(r"[0-9a-f]{64}")
UUID = re.compile(r"[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}")
RUN_ID = re.compile(r"[0-9a-f]{32}")
PIXEL_KEYS = {"side", "start_monotonic_ns", "end_monotonic_ns", "tile_x", "scroll_text"}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def from_json(path):
    return json.loads(path.read_bytes())


def json_lines(data):
    return [json.loads(line) for line in data.splitlines()]


def json_bytes(value):
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()


def line_bytes(rows):
    return b"".join((json.dumps(row, sort_keys=True) + "\n").encode() for row in rows)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def canonical_digest(value):
    return digest(json.dumps(value, sort_keys=True, separators=(",", ":")).encode())


def load_replay(fixture_dir):
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(fixture_dir))
    from run_baseline import select_telemetry
    from score import score_pixels
    return select_telemetry, score_pixels


def pixels(data, side):
    rows = json_lines(data)
    previous = -1
    for row in rows:
        start, end = row["start_monotonic_ns"], row["end_monotonic_ns"]
        require(set(row) == PIXEL_KEYS and row["side"] == side, "unexpected pixel record")
        require(type(start) is int and type(end) is int and previous <= start <= end,
                "pixel samples are not ordered on the local clock")
        tile, glyph = row["tile_x"], row["scroll_text"]
        require(tile is None or (type(tile) is int and 0 <= tile < DIMENSIONS[0]), "invalid tile position")
        require(glyph is None or re.fullmatch(r"[0-9a-f]{16}", glyph), "invalid glyph signature")
        previous = end
    return rows


def telemetry(data, role, clocked):
    rows = json_lines(data)
    previous = -1
    for row in rows:
        record = row
        if clocked:
            stamp, record = row["end_monotonic_ns"], row["record"]
            require(set(row) == {"end_monotonic_ns", "record"} and type(stamp) is int and stamp >= previous,
                    "telemetry arrival clocks are not ordered")
            previous = stamp
        require(record["type"] == f"jwm_remote_{role}_stats" and not record.get("final"),
                "unexpected continuous telemetry record")
        require(RUN_ID.fullmatch(record["session_id"]) and math.isfinite(record["window_seconds"])
                and record["window_seconds"] > 0, "invalid continuous telemetry")
    return rows


def files_for_trial(path, complete):
    files = {}
    for role, side in ROLES.items():
        prefix = "" if role == "host" else "viewer/"
        for name in ("static", "motion"):
            relative = f"{prefix}{name}-pixels.jsonl"
            source = path / relative
            if source.exists():
                data = source.read_bytes()
                pixels(data, side)
                files[relative] = data
            if complete:
                relative = f"{prefix}{name}-scope.json"
                files[relative] = (path / relative).read_bytes()
        for name in (f"{role}-clocked-telemetry", f"static-{role}", f"motion-{role}"):
            relative = f"{prefix}{name}.jsonl"
            source = path / relative
            if source.exists():
                data = source.read_bytes()
                telemetry(data, role, "clocked" in name)
                files[relative] = data
    return files


def check_role(files, role, replay):
    select_telemetry, score_pixels = replay
    prefix = "" if role == "host" else "viewer/"
    endpoint = ROLES[role]
    result = {}
    sessions, epochs = set(), set()
    previous = -1
    with tempfile.TemporaryDirectory(prefix="firefox-raster-replay.") as temp:
        work = Path(temp)
        trace = f"{role}-clocked-telemetry.jsonl"
        original_telemetry = files[prefix + trace]
        (work / trace).write_bytes(original_telemetry)
        for name in PHASES:
            scope = json.loads(files[f"{prefix}{name}-scope.json"])
            phase, start, end, tail, observer = (scope[f"{field}_monotonic_ns"] for field in (
                "phase_start", "score_start", "score_end", "telemetry_phase_end", "observer_end"
            ))
            require(scope["phase"] == name and previous <= phase
                    and (start - phase, end - start, tail - end) == (WARM * SECOND, SCORE * SECOND, TAIL * SECOND)
                    and observer >= tail, f"{role} {name} has invalid monotonic phase bounds")
            previous = observer
            samples = pixels(files[f"{prefix}{name}-pixels.jsonl"], endpoint)
            require(samples and phase <= samples[0]["start_monotonic_ns"] < start
                    and end < samples[-1]["end_monotonic_ns"] <= observer,
                    f"{role} {name} samples do not cover warmup, scoring and tail")
            raster = score_pixels(samples, start, end)
            require(scope["samples"] == {endpoint: raster} and raster["valid_and_invalid_sample_reads"] > SCORE,
                    f"{role} {name} pixel scores do not replay")
            selected = f"{name}-{role}.jsonl"
            stats = select_telemetry(work, scope, role, DIMENSIONS)
            recorded = scope["telemetry"]
            # Python 3.10 and 3.12 can sum identical received windows
            # with a one-ULP difference. Membership must remain byte exact.
            require({**stats, "window_seconds": recorded["window_seconds"]} == recorded
                    and math.isclose(stats["window_seconds"], recorded["window_seconds"], rel_tol=0, abs_tol=1e-10)
                    and files[f"{prefix}{selected}"] == (work / selected).read_bytes(),
                    f"{role} {name} whole-window telemetry does not replay")
            require(stats["window_seconds"] >= SCORE and len(stats["session_ids"]) == 1
                    and stats["frame_scopes_match_requested_jpeg"]
                    and (name == "static" or stats["frame_scopes_observed"] > 0),
                    f"{role} {name} has incomplete whole-window JPEG telemetry")
            rows = telemetry(files[f"{prefix}{selected}"], role, False)
            sessions.update(stats["session_ids"])
            for row in rows:
                if role == "host":
                    require(row["mode"].startswith("root/") and not row["h264_frames"] and not row["hevc444_frames"],
                            "unexpected host JPEG capture lane")
                    frame = row.get("last_sent_frame")
                else:
                    require(row["viewer_backend"] == "x11" and row["negotiated_codec"] == "JPEG"
                            and row["last_presentation_path"] == "rgb", "unexpected viewer JPEG presentation lane")
                    frame = row.get("last_frame")
                if frame:
                    epochs.add((frame["source_epoch"], frame["geometry_epoch"]))
            acknowledgements = sum(row["drawn_acks" if role == "host" else "acked"] for row in rows)
            summary = {key: value for key, value in raster.items() if key != "accepted_observations_monotonic_ns"}
            result[name] = {"local_phase_start_monotonic_ns": phase, "local_score_start_monotonic_ns": start,
                            "local_score_end_monotonic_ns": end, "local_observer_end_monotonic_ns": observer,
                            "raster": summary, "telemetry": recorded, "acknowledgements_in_whole_windows": acknowledgements}
            if name == "motion":
                require(acknowledgements > 0, f"{role} motion did not record any acknowledgements")
    require(len(sessions) == len(epochs) == 1, f"{role} session/source/surface epoch changed")
    return result, sessions.pop(), epochs.pop()


def check_controls(path, allowed, run_id):
    rows = json_lines(path.read_bytes())
    require([row["event"] for row in rows] == allowed and all(row["run_id"] == run_id for row in rows),
            "control events or run identity differ")
    return rows


def role_identity(raw, role):
    require(raw["role"] == role and raw["clock"] == "CLOCK_MONOTONIC" and raw["drawable_size"] == DIMENSIONS
            and SHA256.fullmatch(raw["release_sha256"]) and UUID.fullmatch(raw["boot_id"]),
            "endpoint identity does not describe the actual local observation lane")
    summary = {key: raw[key] for key in ("role", "kernel", "cpu", "drawable_size", "clock", "release_sha256")}
    summary["hostname_sha256"] = digest(raw["hostname"].encode())
    summary["boot_id_sha256"] = digest(raw["boot_id"].encode())
    for label in ("xvfb", "endpoint_process"):
        summary[f"{label}_identity_sha256"] = canonical_digest(raw[label])
    if role == "host":
        summary["firefox"] = {**raw["installed_firefox_application"],
                              "binary_sha256": raw["firefox"]["sha256"],
                              "process_identity_sha256": canonical_digest(raw["firefox"])}
    return summary
