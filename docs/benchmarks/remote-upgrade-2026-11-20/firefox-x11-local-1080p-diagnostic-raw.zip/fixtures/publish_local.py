#!/usr/bin/env python3
"""Verify and archive the completed one-machine 1080p Firefox loopback diagnostic."""

import argparse
import hashlib
import json
from pathlib import Path
import re
import tempfile
from zipfile import ZIP_DEFLATED, ZipFile

import exact_raster as r

NAME = 'firefox-x11-local-1080p-diagnostic'
FIXTURES = ('dual_browser.py', 'run_baseline.py', 'processes.py', 'score.py', 'browser-trial.html',
            'firefox-profile-user.js', 'fixture-manifest.json')
MEDIA = ('source-static.ppm', 'source-static-end.ppm', 'source-motion-end.ppm',
         'viewer/viewer-static.ppm', 'viewer/viewer-motion-end.ppm')
PUBLISHER = Path(__file__).resolve()
SHUTDOWN = {'host_exit': 0, 'viewer_worker_exit': 0, 'viewer_disconnect_event': True, 'host_stats_finished': True}


def file_digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def decode(data):
    return json.loads(data)


def verified_fixture(fixture_files, manifest):
    r.require(manifest['diagnostic_batch'] and manifest['same_machine'] and manifest['requested_trials'] == 1
              and manifest['transport'] == 'Direct authenticated TCP on 127.0.0.1'
              and manifest['dimensions'] == r.DIMENSIONS and manifest['requested_fps'] == r.FPS
              and (manifest['warm_seconds'], manifest['score_seconds'], manifest['telemetry_tail_seconds'])
                    == (r.WARM, r.SCORE, r.TAIL)
              and manifest['fixed_jpeg_quality'] and manifest['codec'] == 'JPEG' and manifest['jpeg_quality'] == 85,
              'the manifest no longer describes the pinned local diagnostic')
    r.require({name: r.digest(fixture_files[name]) for name in FIXTURES} == manifest['fixture_sha256']
              and r.digest(fixture_files['local_browser.py']) == manifest['local_runner_sha256'],
              'the local runner or fixture source pin differs')
    original, trial = (fixture_files[name] for name in ('browser-original.html', 'browser-trial.html'))
    workload = decode(fixture_files['fixture-manifest.json'])
    change = workload['sole_trial_change']
    old, new = change['before'].encode(), change['after'].encode()
    r.require(manifest['workload'] == workload and r.digest(original) == workload['original_sha256']
              and r.digest(trial) == workload['trial_sha256'] and original.count(old) == 1
              and original.replace(old, new) == trial,
              'the workload differs from the pinned original plus its sole duration change')


def copy_observed(trial):
    files = r.files_for_trial(trial, True)
    actual = r.from_json(trial / 'identity.json')
    run_id = actual['run_id']
    r.require(r.RUN_ID.fullmatch(run_id) and actual['transport'] == 'IPv4 loopback',
              'the trial did not identify a local authenticated session')
    returned = r.from_json(trial / 'viewer/identity.json')
    source, viewer = actual['host'], actual['viewer']
    r.require({k: v for k, v in viewer.items() if k != 'endpoint_executable_sha256'} == returned,
              'viewer worker identity does not match the live process pin')
    remote = r.check_controls(trial / 'viewer-events.jsonl', r.PEER_EVENTS, run_id)
    local = r.check_controls(trial / 'viewer/control-in.jsonl', r.VIEWER_EVENTS, run_id)
    r.require(remote[0]['identity'] == returned, 'the ready event belongs to another viewer identity')
    same_machine = source['hostname'] == viewer['hostname'] and source['boot_id'] == viewer['boot_id']
    distinct_displays = source['display'] != viewer['display'] and source['xvfb']['pid'] != viewer['xvfb']['pid']
    distinct_endpoints = source['endpoint_process']['pid'] != viewer['endpoint_process']['pid']
    r.require(same_machine and distinct_displays and distinct_endpoints, 'wrong fixture endpoint ownership')
    endpoints = {role: r.role_identity(actual[role], role)
                 | {'endpoint_executable_sha256': actual[role]['endpoint_executable_sha256']}
                 for role in r.ROLES}
    files['endpoints.json'] = r.json_bytes(
        {'run_id': run_id, 'transport': 'IPv4 loopback', 'one_machine': same_machine,
         'distinct_owned_xvfb_displays': distinct_displays, 'distinct_owned_endpoint_processes': distinct_endpoints,
         'endpoints': endpoints})
    for name, rows in (('viewer-events.jsonl', remote), ('viewer/control-in.jsonl', local)):
        files[name] = r.line_bytes({key: row[key] for key in ('event', 'run_id')} for row in rows)
    for name in ('result.json', 'shutdown.json', *MEDIA):
        files[name] = (trial / name).read_bytes()
    lines = (trial / 'viewer/viewer.log').read_text().splitlines()
    final = [decode(line) for line in lines if line.startswith('{') and decode(line).get('final')]
    r.require(lines[-1] == r.SESSION_END and len(final) == 1
              and (trial / 'viewer/disconnect.log').stat().st_size == 0
              and (trial / 'viewer-worker.log').stat().st_size == 0,
              'the owned viewer did not shut down normally')
    files['viewer/final-session.json'] = r.json_bytes(
        {'statistics': final[0], 'end_diagnostic': lines[-1], 'toggle_stderr_empty': True,
         'worker_stderr_empty': True})
    return files


class Photo:
    def __init__(self, raw):
        width, height = r.DIMENSIONS
        header = f'P6\n{width} {height}\n255\n'.encode()
        r.require(raw.startswith(header) and len(raw) == len(header) + width * height * 3,
                  'snapshot did not preserve true 1080p RGB')
        self.rgb = raw[len(header):]

    def crop(self, _xid, x, y, width, height):
        columns = r.DIMENSIONS[0]
        rows = []
        for scan in range(y, y + height):
            offset = (scan * columns + x) * 3
            rgb = self.rgb[offset:offset + width * 3]
            bgrx = bytearray(width * 4)
            bgrx[0::4], bgrx[1::4], bgrx[2::4] = rgb[2::3], rgb[1::3], rgb[0::3]
            rows.append(bgrx)
        return rows


def check_snapshots(files):
    from run_baseline import find_static_page, sample

    photos = {name: Photo(files[name]) for name in MEDIA}
    source = photos['source-static.ppm']
    placement = find_static_page(source.crop(0, 0, 0, *r.DIMENSIONS))
    r.require(placement, 'source fixture tile not present in initial screenshot')
    end = photos['source-static-end.ppm']
    r.require(find_static_page(end.crop(0, 0, 0, *r.DIMENSIONS)) == placement,
              'pre-motion fixture moved in the static endpoint snapshots')
    origin, top, header = placement
    points = {}
    for name, photo in photos.items():
        tile, scroll = sample(photo, 0, r.DIMENSIONS[0], top)
        r.require(tile is not None and scroll, 'snapshot has no valid glyph and tile')
        points[name] = {'tile_x': tile, 'glyph_signature': scroll, 'sha256': r.digest(files[name])}
    first, last = points['source-static.ppm'], points['source-static-end.ppm']
    viewer = points['viewer/viewer-static.ppm']
    r.require(first['tile_x'] == last['tile_x'] == origin
              and first['glyph_signature'] == last['glyph_signature']
              and abs(viewer['tile_x'] - origin) <= 4,
              'static snapshots do not establish the fixture layout')
    changed = sum(source.rgb[k:k+3] != end.rgb[k:k+3] for k in range(0, len(source.rgb), 3))
    return {'source_raster_placement_tile_x_tile_top_header_top': [origin, top, header],
            'source_static_start_to_end_full_raster_changed_pixels': changed, 'snapshots': points}


def evaluate(files, fixtures_path, manifest, outcomes):
    r.require(len(outcomes) == 1 and outcomes[0]['trial'] == 1 and outcomes[0]['status'] == 'completed',
              'one completed diagnostic outcome required')
    replay = r.load_replay(fixtures_path)
    host, h_session, h_epochs = r.check_role(files, 'host', replay)
    viewer, v_session, v_epochs = r.check_role(files, 'viewer', replay)
    recorded = decode(files['result.json'])
    r.require({key: value for key, value in recorded.items() if key != 'phases'} == outcomes[0]['result']
              and recorded['diagnostic_only'] and recorded['scope'] == manifest['scope']
              and recorded['source_and_requested_viewer_dimensions'] == r.DIMENSIONS
              and recorded['codec'] == 'JPEG' and recorded['jpeg_quality'] == 85
              and h_session == v_session and h_epochs == v_epochs
              and recorded['authenticated_session_ids'] == [h_session] and recorded['telemetry_complete'],
              'the complete control result or scope does not replay')
    for role, prefix in (('host', ''), ('viewer', 'viewer/')):
        for phase in r.PHASES:
            r.require(recorded['phases'][phase][role] == decode(files[f'{prefix}{phase}-scope.json']),
                      'trial and individual endpoint phase records disagree')
    ident = decode(files['endpoints.json'])
    r.require(ident['one_machine'] and ident['distinct_owned_xvfb_displays'] and ident['distinct_owned_endpoint_processes']
              and ident['transport'] == 'IPv4 loopback' and r.RUN_ID.fullmatch(ident['run_id']),
              'unexpected local endpoint identity')
    endpoints = ident['endpoints']
    r.require(all(endpoints['host'][key] == endpoints['viewer'][key]
              for key in ('boot_id_sha256', 'hostname_sha256', 'cpu', 'kernel'))
              and endpoints['host']['xvfb_identity_sha256'] != endpoints['viewer']['xvfb_identity_sha256']
              and endpoints['host']['endpoint_process_identity_sha256'] != endpoints['viewer']['endpoint_process_identity_sha256'],
              'display or host identity cannot be reproduced')
    for role in r.ROLES:
        row = endpoints[role]
        r.require(row['role'] == role and row['clock'] == 'CLOCK_MONOTONIC' and row['drawable_size'] == r.DIMENSIONS
                  and row['release_sha256'] == row['endpoint_executable_sha256'] == manifest[f'{role}_release_sha256'],
                  'recorded running binary or drawable scope differs')
    firefox = endpoints['host']['firefox']
    r.require(firefox['binary_sha256'] == manifest['firefox_sha256']
              and {key: firefox[key] for key in ('Version', 'BuildID')} == manifest['firefox_metadata'],
              'runtime Firefox pin differs')
    for name, expected in (('viewer-events.jsonl', r.PEER_EVENTS), ('viewer/control-in.jsonl', r.VIEWER_EVENTS)):
        controls = r.json_lines(files[name])
        r.require([event['event'] for event in controls] == expected
                  and all(set(event) == {'event', 'run_id'} and event['run_id'] == ident['run_id'] for event in controls),
                  'the exact motion and shutdown control sequence does not replay')
    final = decode(files['viewer/final-session.json'])
    stats = final['statistics']
    r.require(decode(files['shutdown.json']) == SHUTDOWN and final['end_diagnostic'] == r.SESSION_END
              and final['toggle_stderr_empty'] and final['worker_stderr_empty']
              and stats['type'] == 'jwm_remote_viewer_stats' and stats['final'] and stats['session_id'] == h_session,
              'recorded normal shutdown does not replay')
    still = [lane['static']['raster'] for lane in (host, viewer)]
    r.require(all(sample['unique_tile_changes'] == sample['scroll_changes_seen'] == 0
                  and sample['distinct_scroll_signatures'] == 1
                  and sample['invalid_tile_reads'] == sample['invalid_scroll_reads'] == 0 for sample in still),
              'static motion signals or sample validity changed')
    source_motion, viewer_motion = (role['motion']['raster'] for role in (host, viewer))
    qualified = source_motion['unique_content_fps'] >= r.FPS and source_motion['scroll_changes_seen'] >= r.SCORE
    gate = viewer_motion['unique_content_fps'] >= .9 * r.FPS and viewer_motion['scroll_changes_seen'] >= r.SCORE
    r.require((recorded['source_motion_fps'], recorded['viewer_motion_fps'],
               recorded['source_qualified'], recorded['viewer_motion_gate_met'])
              == (source_motion['unique_content_fps'], viewer_motion['unique_content_fps'], qualified, gate if qualified else None),
              'declared motion cadence or threshold does not replay')
    return {'recorded_controller_outcome': outcomes[0], 'source_epoch': h_epochs[0], 'geometry_epoch': h_epochs[1],
            'identity': ident, 'host': host, 'viewer': viewer, 'clean_shutdown': SHUTDOWN,
            'static_control': 'No marker or independent glyph changes in either scored static interval.',
            'raster_snapshots': check_snapshots(files)}


def replay(report_file, archive):
    report = r.from_json(report_file)
    r.require(file_digest(archive) == report['archive']['sha256'], 'archive digest differs')
    with ZipFile(archive) as bundle, tempfile.TemporaryDirectory(prefix='firefox-local-offline.') as temp:
        pins = report['archive']['members_sha256']
        r.require(bundle.testzip() is None and len(bundle.namelist()) == len(pins)
                  and set(bundle.namelist()) == set(pins), 'archive members or CRC differ')
        fixtures_path = Path(temp)
        fixtures, trace = {}, {}
        for name, checksum in pins.items():
            value = bundle.read(name)
            r.require(r.digest(value) == checksum, f'{name} member digest differs')
            if name.startswith('fixtures/'):
                safe = name.removeprefix('fixtures/')
                r.require('/' not in safe and safe not in ('.', '..'), 'unsafe fixture name')
                fixtures[safe] = value
                (fixtures_path / safe).write_bytes(value)
            if name.startswith('trial/'):
                trace[name.removeprefix('trial/')] = value
        manifest, ledger = (decode(bundle.read(name)) for name in ('manifest.json', 'outcomes.json'))
        r.require(manifest == report['manifest'], 'manifest contents differ')
        verified_fixture(fixtures, manifest)
        r.require(evaluate(trace, fixtures_path, manifest, ledger) == report['measurement'],
                  'archive artifacts do not reproduce report')
    print('Replayed local 1080p motion, static raster and typed JPEG telemetry')


def publish(batch, original, output):
    lab = batch.parent
    r.require((lab / 'live.exit').read_text().strip() == '0', 'fixture has not recorded clean terminal status')
    manifest, outcomes = (r.from_json(batch / name) for name in ('manifest.json', 'outcomes.json'))
    terminal = [decode(line) for line in (lab / 'live.log').read_text().splitlines() if line.startswith('{')]
    r.require(terminal == outcomes, 'actual controller log does not match saved outcome')
    fixtures = {name: (lab / name).read_bytes() for name in (*FIXTURES, 'local_browser.py')}
    fixtures['browser-original.html'] = original.read_bytes()
    fixtures[PUBLISHER.name] = PUBLISHER.read_bytes()
    fixtures['exact_raster.py'] = PUBLISHER.with_name('exact_raster.py').read_bytes()
    verified_fixture(fixtures, manifest)
    files = copy_observed(batch / 'trial-01')
    measurement = evaluate(files, lab, manifest, outcomes)
    r.require(output.resolve().is_relative_to(Path('/tmp')) and output.resolve() != Path('/tmp'),
              'publication must stay in a dedicated scratch directory')
    output.mkdir(mode=0o700, exist_ok=True, parents=True)
    index, raw = (output / f'{NAME}{suffix}' for suffix in ('.json', '-raw.zip'))
    r.require(not index.exists() and not raw.exists(), 'scratch publication already exists')
    members = {f'fixtures/{name}': content for name, content in fixtures.items()}
    members.update({f'trial/{name}': content for name, content in files.items()})
    members.update({'manifest.json': r.json_bytes(manifest), 'outcomes.json': r.json_bytes(outcomes),
                    'controller-outcome.jsonl': r.line_bytes(terminal)})
    for name, data in members.items():
        if not name.startswith('fixtures/') and not name.endswith('.ppm'):
            r.require(not re.search(rb'127\.0\.0\.1:[1-9]\d*|-----BEGIN [A-Z ]*PRIVATE KEY-----|'
                                    rb'"(?:boot_id|hostname|local_port|display|key_file)"\s*:', data),
                      f'{name} retained a private runtime field')
    report = {'schema_version': 1, 'manifest': manifest, 'measurement': measurement,
              'transport_scope': 'One Mint machine and two owned Xvfb servers over direct IPv4 loopback TCP.',
              'controller_exit_status': 0,
              'publication_limits': [
                  'One diagnostic replication. It does not contribute to the separate dual-machine Wi-Fi score.',
                  'Scoring describes the CSS tile and independent glyph region in the actual drawables.',
                  'Static screenshots compare endpoint instants. The marker and glyph controls do not assert whole-raster stillness.',
                  'The retained Firefox preferences are the static fixture source only.',
              ],
              'original_controller_log_sha256': file_digest(lab / 'live.log')}
    with tempfile.TemporaryDirectory(prefix='.publish.', dir=output) as work:
        temp = Path(work)
        with ZipFile(temp / raw.name, 'w', compression=ZIP_DEFLATED, compresslevel=6) as bundle:
            for name, data in sorted(members.items()):
                bundle.writestr(name, data)
        report['archive'] = {'file': raw.name, 'sha256': file_digest(temp / raw.name),
                             'members_sha256': {name: r.digest(content) for name, content in sorted(members.items())}}
        (temp / index.name).write_bytes(r.json_bytes(report))
        replay(temp / index.name, temp / raw.name)
        (temp / raw.name).replace(raw)
        (temp / index.name).replace(index)
    print(index)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_subparsers(dest='action', required=True)
    write = mode.add_parser('publish')
    for name in ('batch', 'original_html', 'output'):
        write.add_argument(name, type=Path)
    check = mode.add_parser('replay')
    for name in ('report', 'archive'):
        check.add_argument(name, type=Path)
    args = parser.parse_args()
    if args.action == 'publish':
        publish(args.batch, args.original_html, args.output)
    else:
        replay(args.report, args.archive)
