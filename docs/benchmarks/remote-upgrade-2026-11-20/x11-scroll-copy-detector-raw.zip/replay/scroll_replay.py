#!/usr/bin/env python3
"""Replay JWM's scroll-copy selection on raster-anchored XTerm transitions."""

import argparse
from dataclasses import dataclass
from hashlib import sha256
import json
from pathlib import Path
import sys


WIDTH, HEIGHT = 1920, 1080
HEADER = b'P6\n1920 1080\n255\n'
CHANNELS = 3
STRIDE = WIDTH * CHANNELS
CELL_WIDTH, CELL_HEIGHT = 10, 20
LINES = HEIGHT // CELL_HEIGHT
MARKER_CELLS = 40
PREAMBLE = 0xb2
MARKER_LIT = 229
TILE = 16
TOLERANCE = 4
MAX_DY = 64
GRID_WIDTH = (WIDTH + TILE - 1) // TILE
GRID_HEIGHT = (HEIGHT + TILE - 1) // TILE
TOTAL_TILES = GRID_WIDTH * GRID_HEIGHT
SAMPLE_ROWS = 64
PROBE_BYTE_OFFSETS = tuple(CHANNELS * x for x in (0, WIDTH // 2, WIDTH - 1))
FIXED_STARTS = (
    0, 1, 7, 45, 46, 47, 48, 49, 50, 51, 52, 53, 62, 95, 96, 97, 98,
    99, 100, 147, 447, 947, 948, 949, 950, 997, 998, 999, 1000,
)


@dataclass(frozen=True)
class Snapshot:
    contents: bytes
    rows: tuple[bytes, ...]
    tag: int
    sequence: int


def crc(data):
    result = 0
    for byte in data:
        result ^= byte
        for _ in range(8):
            result = ((result << 1) ^ (0x07 if result & 0x80 else 0)) & 0xff
    return result


def decode_marker(rows):
    marker = rows[9]
    center_x = range(CELL_WIDTH // 2, MARKER_CELLS * CELL_WIDTH, CELL_WIDTH)
    levels = [marker[x * CHANNELS] for x in center_x]
    if set(levels) - {0, MARKER_LIT}:
        raise ValueError('unexpected marker intensity')
    packet = bytes(sum((level == MARKER_LIT) << (7 - offset)
                       for offset, level in enumerate(levels[i:i + 8]))
                   for i in range(0, len(levels), 8))
    if packet[0] != PREAMBLE or packet[4] != crc(packet[:4]):
        raise ValueError('invalid marker preamble or CRC')
    return packet[1], int.from_bytes(packet[2:4], 'big')


def read_ppm(path):
    contents = path.read_bytes()
    if not contents.startswith(HEADER) or len(contents) != len(HEADER) + HEIGHT * STRIDE:
        raise ValueError(f'{path.name} must be the original 1920x1080 P6 capture')
    if set(contents[len(HEADER):]) - {0, MARKER_LIT, 255}:
        raise ValueError(f'{path.name} contains colors outside the fixture raster palette')
    rows = tuple(contents[i:i + STRIDE] for i in range(len(HEADER), len(contents), STRIDE))
    tag, sequence = decode_marker(rows)
    return Snapshot(contents, rows, tag, sequence)


class TerminalRaster:
    def __init__(self, static):
        self.tag = static.tag
        self.digits = {}
        cell_bytes = CELL_WIDTH * CHANNELS
        for line in range(1, LINES):
            rows = static.rows[line * CELL_HEIGHT:(line + 1) * CELL_HEIGHT]
            for index, digit in enumerate(f'{line:06d}'):
                begin = index * cell_bytes
                glyph = tuple(row[begin:begin + cell_bytes] for row in rows)
                if self.digits.setdefault(digit, glyph) != glyph:
                    raise ValueError(f'inconsistent template for digit {digit} on line {line}')
        if set(self.digits) != set('0123456789'):
            raise ValueError('static raster is missing decimal glyph templates')
        self.line_tails = {}
        for parity, line in ((1, 1), (0, 2)):
            rows = static.rows[line * CELL_HEIGHT:(line + 1) * CELL_HEIGHT]
            self.line_tails[parity] = tuple(row[6 * cell_bytes:] for row in rows)

    def rows(self, sequence):
        payload = bytes((PREAMBLE, self.tag)) + sequence.to_bytes(2, 'big')
        marker = payload + bytes((crc(payload),))
        marker_cells = b''.join(
            bytes((MARKER_LIT if byte & (1 << bit) else 0,)) * CELL_WIDTH * CHANNELS
            for byte in marker for bit in range(7, -1, -1)
        )
        marker_row = marker_cells + bytes(STRIDE - len(marker_cells))
        rows = [marker_row] * CELL_HEIGHT
        # Terminal setup writes lines 1..53 below the fixed marker. Each
        # scroll deletes the first text line and appends the next number.
        for line in range(sequence + 1, sequence + LINES):
            glyphs = [self.digits[digit] for digit in f'{line:06d}']
            tail = self.line_tails[line % 2]
            rows.extend(b''.join(glyph[y] for glyph in glyphs) + tail[y]
                        for y in range(CELL_HEIGHT))
        return tuple(rows)


def anchor(snapshot, model):
    rebuilt = HEADER + b''.join(model.rows(snapshot.sequence))
    if snapshot.contents != rebuilt:
        raise ValueError(f'raw PPM reconstruction did not match at marker {snapshot.sequence}')
    return {
        'marker_sequence': snapshot.sequence,
        'ppm_bytes': len(snapshot.contents),
        'pixel_bytes': HEIGHT * STRIDE,
        'source_ppm_sha256': sha256(snapshot.contents).hexdigest(),
        'reconstructed_ppm_sha256': sha256(rebuilt).hexdigest(),
        'byte_equal': True,
    }


def dirty_tiles(previous, current):
    dirty = set()
    tile_bytes = TILE * CHANNELS
    for y, (before, after) in enumerate(zip(previous, current)):
        if before == after:
            continue
        for column, x in enumerate(range(0, STRIDE, tile_bytes)):
            position = (y // TILE, column)
            if position in dirty:
                continue
            left, right = before[x:x + tile_bytes], after[x:x + tile_bytes]
            # The validated source palette has a minimum nonzero difference
            # of 26, so bytes unequal here are also unequal at tolerance 4.
            if left != right:
                dirty.add(position)
    return dirty


def sampled_scores(previous, current, *, full_row):
    scores = []
    for magnitude in range(1, min(HEIGHT // 2, MAX_DY) + 1):
        for dy in (magnitude, -magnitude):
            first = magnitude if dy < 0 else 0
            rows = HEIGHT - magnitude
            count = min(rows, SAMPLE_ROWS)
            longest = run = 0
            for sample in range(count):
                y = first + sample * rows // count
                before, after = previous[y + dy], current[y]
                matched = (before == after if full_row else
                           all(before[x:x + CHANNELS] == after[x:x + CHANNELS]
                               for x in PROBE_BYTE_OFFSETS))
                run = run + 1 if matched else 0
                longest = max(longest, run)
            scores.append((dy, longest))
    return scores


def full_proof(previous, current, dy, dirty):
    magnitude = abs(dy)
    first = magnitude if dy < 0 else 0
    dest = run = longest = 0
    for y in range(first, first + HEIGHT - magnitude):
        run = run + 1 if previous[y + dy] == current[y] else 0
        if run > longest:
            dest, longest = y + 1 - run, run
    required = (HEIGHT + 1) // 2
    if longest < required:
        return {
            'longest_exact_row_run': longest,
            'minimum_exact_row_run': required,
            'proof_valid': False,
            'repair_tiles': None,
        }
    top = dest - magnitude if dy < 0 else dest
    bottom = dest + longest + (magnitude if dy > 0 else 0)
    copied_end = dest + longest
    exposed_tiles = 0
    outside_dirty = 0
    for row, y0 in enumerate(range(0, HEIGHT, TILE)):
        y1 = min(y0 + TILE, HEIGHT)
        if y0 >= dest and y1 <= copied_end:
            continue
        if y0 < bottom and y1 > top:
            exposed_tiles += GRID_WIDTH
        else:
            outside_dirty += sum((row, col) in dirty for col in range(GRID_WIDTH))
    repair = exposed_tiles + outside_dirty
    return {
        'longest_exact_row_run': longest,
        'minimum_exact_row_run': required,
        'proof_valid': True,
        'band_top': top,
        'band_bottom_exclusive': bottom,
        'copy_destination_first_row': dest,
        'copy_source_first_row': dest + dy,
        'exposed_or_boundary_tiles': exposed_tiles,
        'ordinary_dirty_tiles_outside_band': outside_dirty,
        'repair_tiles': repair,
        'net_tile_savings': len(dirty) - repair,
    }


def selection(previous, current, dirty, *, full_row):
    scores = sampled_scores(previous, current, full_row=full_row)
    # Stable sort reproduces Rust's first strictly improving winner. A tie
    # therefore prefers the earliest magnitude, positive before negative.
    ranked = sorted(scores, key=lambda item: -item[1])
    dy, score = ranked[0]
    winner = dy if score > 0 else None
    proof = full_proof(previous, current, dy, dirty) if winner is not None else None
    gated = len(dirty) * 2 > TOTAL_TILES
    emitted = bool(gated and proof and proof['proof_valid'] and proof['net_tile_savings'] > 0)
    return {
        'winning_sampled_dy_px': winner,
        'winning_sampled_score': score,
        'runner_up_sampled_score': ranked[1][1],
        'tied_best_sampled_dy_px': [shift for shift, value in ranked if value == score],
        'proof': proof,
        'would_emit_scroll_copy': emitted,
        'transmitted_dirty_tiles': proof['repair_tiles'] if emitted else len(dirty),
    }


def replay(static, motion, static_end=None):
    if static.sequence != 0 or static.tag != motion.tag:
        raise ValueError('anchor inputs must share the fixture tag and start at marker zero')
    model = TerminalRaster(static)
    anchors = {'static': anchor(static, model), 'motion_end': anchor(motion, model)}
    if static_end is not None:
        if static.contents != static_end.contents:
            raise ValueError('static-end PPM differs from static PPM')
        anchors['static_end'] = anchor(static_end, model)
    starts = (*FIXED_STARTS, *range(motion.sequence - 4, motion.sequence + 1))
    if len(starts) != 34 or len(set(starts)) != 34 or starts != tuple(sorted(starts)):
        raise ValueError('motion-end marker is too early for the fixed 34-transition schedule')
    for start in starts:
        if start + 3 > 65535:
            raise ValueError('transition schedule would overflow the marker')
    groups = {dy: [] for dy in (20, 40, 60)}
    retained = {0: static.rows, motion.sequence: motion.rows}
    for start in starts:
        previous = retained.get(start) or model.rows(start)
        for dy, transitions in groups.items():
            end = start + dy // CELL_HEIGHT
            current = retained.get(end) or model.rows(end)
            dirty = dirty_tiles(previous, current)
            transitions.append({
                'previous_marker': start,
                'current_marker': end,
                'baseline_dirty_tiles': len(dirty),
                'dirty_gate_eligible': len(dirty) * 2 > TOTAL_TILES,
                'stock_three_pixel_samples': selection(previous, current, dirty, full_row=False),
                'exact_full_row_samples': selection(previous, current, dirty, full_row=True),
            })
    return {
        'schema_version': 1,
        'model': {
            'encoded_dimensions': [WIDTH, HEIGHT],
            'terminal_cell_dimensions': [CELL_WIDTH, CELL_HEIGHT],
            'tile_edge_px': TILE,
            'tile_grid': [GRID_WIDTH, GRID_HEIGHT],
            'total_tiles': TOTAL_TILES,
            'dirty_pixel_tolerance': TOLERANCE,
            'minimum_dirty_tiles_to_try_copy': TOTAL_TILES // 2 + 1,
            'max_scroll_displacement_px': MAX_DY,
            'max_sampled_rows_per_displacement': SAMPLE_ROWS,
            'minimum_exact_overlap_rows': (HEIGHT + 1) // 2,
            'scope': ('Offline reconstruction of consecutive uniform XTerm scroll advances. '
                      'The source RGB reference models the prior committed picture. '
                      'Scanner rankings are included even when the dirty gate excludes a transition.'),
        },
        'raw_ppm_anchors': anchors,
        'displacements': [summarize(dy, transitions) for dy, transitions in groups.items()],
    }


def summarize(dy, transitions):
    stock = [row['stock_three_pixel_samples'] for row in transitions]
    candidate = [row['exact_full_row_samples'] for row in transitions]
    count = [row['baseline_dirty_tiles'] for row in transitions]
    confirmed = [row['proof']['repair_tiles'] for row in candidate
                 if row['proof'] is not None and row['proof']['proof_valid']]
    return {
        'modeled_upward_displacement_px': dy,
        'transition_count': len(transitions),
        'baseline_dirty_tiles_min_max': [min(count), max(count)],
        'dirty_gate_eligible_count': sum(row['dirty_gate_eligible'] for row in transitions),
        'stock_scroll_copy_count': sum(row['would_emit_scroll_copy'] for row in stock),
        'full_row_sample_correct_unique_count': sum(
            row['tied_best_sampled_dy_px'] == [dy] for row in candidate),
        'full_row_sample_scroll_copy_count': sum(row['would_emit_scroll_copy'] for row in candidate),
        'full_row_proof_repair_tiles_min_max': [min(confirmed), max(confirmed)] if confirmed else None,
        'transitions': transitions,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-static', type=Path, required=True)
    parser.add_argument('--source-motion-end', type=Path, required=True)
    parser.add_argument('--source-static-end', type=Path)
    args = parser.parse_args()
    try:
        report = replay(read_ppm(args.source_static), read_ppm(args.source_motion_end),
                        read_ppm(args.source_static_end) if args.source_static_end else None)
    except (ValueError, OSError) as error:
        parser.error(str(error))
    json.dump(report, sys.stdout, indent=2, sort_keys=True)
    print()


if __name__ == '__main__':
    main()
