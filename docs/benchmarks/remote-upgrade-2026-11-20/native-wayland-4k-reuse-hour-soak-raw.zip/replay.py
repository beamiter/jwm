"""Replay the completed 30+3600 s owned viewer resource diagnostic."""
import contextlib
import io
import json
from math import ceil
from pathlib import Path
from statistics import linear_regression, median
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent / 'fixture'))
from validate_reuse import write_diagnostic
from viewer_resources import write_report

SECOND = 10**9


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def load(path):
    return json.loads(path.read_text())


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line]


def metrics(values):
    ticks, measurements = zip(*values)
    trend = (linear_regression([(t - ticks[0]) / (60 * SECOND) for t in ticks], measurements).slope
             if len(values) > 1 else None)
    return {'samples': len(values), 'first': measurements[0], 'last': measurements[-1],
            'minimum': min(measurements), 'median': median(measurements), 'maximum': max(measurements),
            'last_minus_first': measurements[-1] - measurements[0],
            'least_squares_units_per_minute': round(trend, 5) if trend is not None else None}


def check_interval(resource_rows, start, end, declared):
    selected = [row for row in resource_rows if start <= row['monotonic_ns'] < end]
    ticks = [row['monotonic_ns'] for row in selected]
    gaps = [y - x for x,y in zip([start, *ticks], [*ticks, end])]
    bins = {(tick - start) // SECOND for tick in ticks}
    require(len(bins) >= (end - start) // SECOND - 2 and max(gaps) <= 3 * SECOND,
            'resource observation has insufficient sample coverage')
    require(declared['samples'] == len(selected)
            and declared['one_second_bins_with_a_sample'] == len(bins)
            and declared['maximum_sample_gap_seconds_including_boundaries'] == max(gaps) / SECOND
            and declared['coverage_sufficient'], 'resource coverage does not replay')
    measurements = {}
    for name in ('rss_kib', 'rss_anon_kib', 'rss_shmem_kib', 'threads', 'fds', 'acquisition_ns'):
        series = [(row['monotonic_ns'], row[name]) for row in selected]
        require(all(type(value) is int and (value >= 0 if name == 'rss_shmem_kib' else value > 0) for _, value in series),
                f'invalid {name} values')
        measurements[name] = metrics(series)
    for name in ('drm_fds', 'fdinfo_readable'):
        measurements[name] = metrics([(row['monotonic_ns'], row['drm'][name]) for row in selected])
    drm = {}
    for row in selected:
        data = row['drm']
        require(0 <= data['fdinfo_readable'] <= data['drm_fds'] <= row['fds'],
                'DRM sample counts differ from viewer FD extent')
        for client, counters in data['client_memory_bytes'].items():
            require(client.startswith('drm-client-'), 'DRM client ID was not anonymized')
            for counter, value in counters.items():
                require(type(value) is int and value >= 0, 'invalid DRM memory counter')
                drm.setdefault(client, {}).setdefault(counter, []).append((row['monotonic_ns'], value))
    measurements['drm_clients_reported'] = {client: {name: metrics(series) for name, series in counters.items()}
                                             for client, counters in drm.items()}
    for name, value in measurements.items():
        require(declared[name] == value, f'{name} does not replay')
    require(declared['fdinfo_observable_samples'] == sum(row['drm']['fdinfo_readable'] > 0 for row in selected),
            'fdinfo coverage differs')


def replay_motion(evidence, result, start, end):
    observed = rows(evidence / 'viewer/observed.jsonl')
    first, = [row for row in observed if row['type'] == 'p09_start']
    final, = [row for row in observed if row['type'] == 'p09_end']
    markers = [row for row in observed if row['type'] == 'p09_frame' and row['scored']]
    require(first['scope'] == result['observer_start']['scope']
            and final == result['observer_end']
            and final['wrong_run'] == final['reordered'] == 0,
            'wrong run or reordered visible marker')
    for classification in ('invalid', 'wrong_run', 'reordered'):
        require(final[classification] == sum(row.get('classification') == classification for row in observed),
                f'{classification} marker count does not replay')
    require(all(row['run_id'] == 11 and row['wayland_feedback'] == 'presented'
                and start <= row['monotonic_ns'] < end for row in markers),
            'unrelated or out-of-window marker')
    frames = [row['source_frame'] for row in markers]
    require(frames[-1] > 196608 and all(a < b for a, b in zip(frames, frames[1:])),
            '20-bit marker sequence did not cross the 16-bit rollover points')
    ticks = [row['monotonic_ns'] for row in markers]
    require(all(a < b for a, b in zip(ticks, ticks[1:])),
            'marker clocks did not increase')
    gaps = [b - a for a, b in zip([start, *ticks], [*ticks, end])]
    require(len(ticks) == final['scored_unique'] and max(gaps) == final['longest_scored_gap_ns'],
            'marker count or maximum gap does not replay')
    fps = len(ticks) * SECOND / (end - start)
    require(fps == result['unique_markers_per_second'], 'cadence does not replay')
    minute_counts = [0] * 60
    for tick in ticks:
        minute_counts[(tick - start) // (60 * SECOND)] += 1
    paint = rows(evidence / 'source/paint.jsonl')
    painting, = [row for row in paint if row['type'] == 'p09_end']
    source_fps = (painting['submitted'] - 1) * SECOND / (painting['last_submit_ns'] - painting['first_submit_ns'])
    require(source_fps == result['source_submitted_frames_per_second'], 'source cadence does not replay')
    return {
        'visible_unique_frames': len(ticks), 'visible_unique_fps': fps,
        'p95_visible_gap_ms': sorted(gaps)[ceil(.95 * len(gaps)) - 1] / 1e6,
        'longest_visible_gap_ms': max(gaps) / 1e6,
        'elapsed_minute_visible_counts': minute_counts, 'source_submitted_fps': source_fps,
        'last_source_frame': frames[-1], 'wrong_run_reads': final['wrong_run'],
        'invalid_reads': final['invalid'], 'reordered_reads': final['reordered'],
    }


def replay(root):
    evidence = root / 'evidence'
    phase = load(evidence / 'phase-diagnostic.json')
    resource = load(evidence / 'resource-diagnostic.json')
    result = load(evidence / 'result.json')
    terminal = load(evidence / 'terminal-proof.json')
    require(terminal['controller_pid_ended'] and terminal['terminal_viewer_state'] == 'closed'
            and terminal['temporary_key_absent'] and terminal['observer_test_passed']
            and terminal['viewer_stderr_relay_drained'], 'missing actual run completion')
    events = rows(evidence / 'viewer/viewer-events.jsonl')
    require(events[-1]['state'] == 'closed' and not any(row.get('state') == 'failed' for row in events),
            'managed viewer did not close cleanly')

    with contextlib.redirect_stdout(io.StringIO()):
        replayed_phase = write_diagnostic(evidence)
        write_report(evidence, replayed_phase)
    replayed_resource = load(evidence / 'resource-diagnostic.json')
    require(phase == replayed_phase and resource == replayed_resource,
            'phase or resource validator did not reproduce the original diagnostic')
    require(phase['hardware_rgb_download_observations_all_raw_windows'] == 0
            and phase['rgb_backing_reuse']['confirmed_activation']
            and resource['complete'] and resource['diagnostic_only'], 'missing reuse or no-download proof')
    pins = load(evidence / 'binary-pins.json')
    require(all(pins[role] == phase[f'{role}_binary_sha256'] == resource[f'{role}_binary_sha256']
                for role in ('host', 'viewer', 'observer')), 'pinned binaries differ across evidence')

    resources = rows(evidence / 'viewer/viewer-resources.jsonl')
    require(resources[0]['type'] == 'identity' and resources[-1]['type'] == 'end'
            and all(row['type'] == 'sample' for row in resources[1:-1])
            and all(x['monotonic_ns'] < y['monotonic_ns'] for x,y in zip(resources, resources[1:])),
            'unexpected resource sampler lifecycle')
    warm, start, end = (result['observer_start'][key] for key in
                        ('monotonic_ns','score_start_ns','score_end_ns'))
    require(start - warm == 30 * SECOND and end - start == 3600 * SECOND
            and resources[0]['monotonic_ns'] < warm and end <= resources[-1]['monotonic_ns'],
            'owned sampler did not span the observer interval')
    check_interval(resources[1:-1], warm, start, resource['warmup'])
    check_interval(resources[1:-1], start, end, resource['observation'])

    live = load(evidence / 'live-process-witness.json')
    lineage = live['process_lineage']
    require(live['viewer_identity'] == resources[0] == resource['viewer_identity']
            and start <= live['monotonic_ns'] < end
            and live['viewer_exec_matches_pinned_file_device_inode']
            and live['observer_exec_matches_pinned_file_device_inode']
            and lineage[0]['pid'] == resources[0]['pid']
            and lineage[0]['start_ticks'] == resources[0]['start_ticks']
            and lineage[-1]['pid'] == live['controller_pid'] == terminal['controller_pid']
            and all(a['parent_pid'] == b['pid'] for a,b in zip(lineage,lineage[1:])),
            'independent live procfs witness did not match the owned viewer/controller')
    return {
        'complete': True, 'warmup_seconds': 30, 'observation_seconds': 3600,
        'runtime_identity': resource['viewer_identity'], 'controller': terminal,
        'motion': replay_motion(evidence, result, start, end),
        'warmup': resource['warmup'], 'observation': resource['observation'],
        'native_evidence': {
            'codec': phase['codec'], 'presentation': phase['presentation'], 'extent': phase['extent'],
            'host_binary_sha256': phase['host_binary_sha256'], 'viewer_binary_sha256': phase['viewer_binary_sha256'],
            'observer_binary_sha256': phase['observer_binary_sha256'],
            'matching_roi_markers_in_observation': phase['matching_scored_roi_markers'],
            'matched_whole_observer_windows': phase['matched_whole_observer_windows'],
            'hardware_rgb_download_observations': phase['hardware_rgb_download_observations_all_raw_windows'],
            'reuse': phase['rgb_backing_reuse'],
        },
    }


if __name__ == '__main__':
    print(json.dumps(replay(Path(sys.argv[1])), indent=2))
