#!/usr/bin/env bash
set -euo pipefail
if [[ $# -lt 2 ]]; then
  printf '%s\n' "Usage: $0 A_OR_B ACTUAL_VIEWER_BIN [LIB_TEST_BIN [--run-id N --warmup SECONDS --seconds SECONDS]]" >&2
  exit 2
fi
lab=$(cd "$(dirname "$0")" && pwd)
arm=$1
[[ $arm == A || $arm == B ]]
viewer=$(realpath "$2")
shift 2
observer=/tmp/jwm-p09-wayland-marker.tc5bn5aj/preflight-observer-pinned
if [[ $# -ge 1 && $1 != --* ]]; then observer=$(realpath "$1"); shift; fi
[[ -x $viewer && -x $observer ]]
exec 9>>/tmp/jwm-p08-p09-release/benchmark.lock
printf '%s\n' 'Waiting for exclusive native Wayland phase diagnostic lab time'
flock 9
export LD_LIBRARY_PATH=/tmp/jwm-remote-ffmpeg/usr/lib/x86_64-linux-gnu
digest() { sha256sum "$1" | cut -d' ' -f1; }
viewer_sha=$(digest "$viewer")
observer_sha=$(digest "$observer")
if [[ $observer == /tmp/jwm-p09-wayland-marker.tc5bn5aj/preflight-observer-pinned ]]; then
  [[ $observer_sha == 40cabdfb4d39c6e0cdc0036fa9f7d904930bd398142add3587897a4b7b9fa710 ]]
fi
# The real viewer is pinned and probed separately from the executable relay wrapper.
if ! help=$("$viewer" session --help) || [[ $help != *--stats-json* ]]; then
  printf '%s\n' 'Actual viewer must contain the session --stats-json option' >&2
  exit 1
fi
python3 -B "$lab/preflight.py" "$observer" "$viewer" \
  --arm "$arm" --viewer-sha256 "$viewer_sha" --observer-sha256 "$observer_sha" "$@"
