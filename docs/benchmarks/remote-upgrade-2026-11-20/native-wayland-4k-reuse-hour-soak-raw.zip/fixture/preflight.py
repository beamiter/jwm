import argparse
from contextlib import ExitStack
import hashlib
import json
from pathlib import Path
import re
import shlex
import socket
import subprocess
import tempfile
import time

from processes import clean_env, stop, wait_for
from viewer_resources import write_report as write_resource_report


LAB = Path(__file__).resolve().parent
TEST_DRIVER = LAB / 'test-remote-wayland-4k-marker.sh'
PEER = 'ubuntu@192.168.0.78'
SSH = ['ssh', '-4', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
       '-o', 'ControlMaster=no', '-o', 'ControlPath=none', '-o', 'ServerAliveInterval=5',
       '-o', 'Compression=no', '-o', 'ProxyJump=none', '-o', 'ProxyCommand=none',
       '-o', 'ForwardAgent=no', '-o', 'ForwardX11=no', '-o', 'StrictHostKeyChecking=yes']
HOST_BIN = '/tmp/jwm-p09-resolution-candidate/jwm-remote'


def digest(path):
    with path.open('rb') as data:
        return hashlib.file_digest(data, 'sha256').hexdigest()


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.startswith('{')]


def source_pins(remote_dir, expected):
    files = {'host': HOST_BIN, 'source_controller': f'{remote_dir}/source.py',
             'source_process_helpers': f'{remote_dir}/processes.py', 'painter': f'{remote_dir}/p09-workload'}
    command = shlex.join(['sha256sum', '--', *files.values()])
    output = subprocess.check_output(SSH + ['-n', PEER, command], text=True, timeout=15)
    observed = {name: checksum for checksum, name in (line.split(maxsplit=1) for line in output.splitlines())}
    actual = {key: observed[name] for key, name in files.items()}
    assert actual == {key: expected[key] for key in files}, 'remote source changed from the ABBA pins'
    return actual


def result(run, options, host_sha):
    observed = rows(run / 'viewer' / 'observed.jsonl')
    first, = [row for row in observed if row['type'] == 'p09_start']
    last, = [row for row in observed if row['type'] == 'p09_end']
    markers = [row for row in observed if row['type'] == 'p09_frame']
    assert first['run_id'] == last['run_id'] == options.run_id
    assert all(row['run_id'] == options.run_id for row in markers) and len(markers) >= 2
    assert all(a['source_frame'] < b['source_frame'] for a, b in zip(markers, markers[1:]))
    assert all(a['monotonic_ns'] < b['monotonic_ns'] for a, b in zip(markers, markers[1:]))
    start, end = (last[f'score_{edge}_ns'] for edge in ('start', 'end'))
    assert end - start == options.seconds * 1_000_000_000
    assert all(row['scored'] == (start <= row['monotonic_ns'] < end) for row in markers)
    scored = [row['monotonic_ns'] for row in markers if row['scored']]
    gaps = [b - a for a, b in zip([start, *scored], [*scored, end])]
    assert len(scored) == last['scored_unique'] and max(gaps) == last['longest_scored_gap_ns']
    paint = rows(run / 'source' / 'paint.jsonl')
    assert any(row.get('type') == 'p09_start' and row['run_id'] == options.run_id for row in paint)
    painting, = [row for row in paint if row.get('type') == 'p09_end']
    source_fps = ((painting['submitted'] - 1) * 1e9
                  / (painting['last_submit_ns'] - painting['first_submit_ns']))
    host = [row for row in rows(run / 'source' / 'host.log') if row.get('type') == 'jwm_remote_host_stats']
    active = [row for row in host if row['h264_frames']]
    assert active and any(row['drawn_acks'] for row in active)
    assert all(row['encoded_dimensions'] == row['source_dimensions'] == [3840, 2160] for row in active)
    assert all(not row['jpeg_atlases'] and not row['hevc444_frames'] for row in host)
    assert {row['session_id'] for row in host} == {first['scope']['session_id']}
    trace = (run / 'marker-test.log').read_text()
    assert re.search(r'test result: ok\. 1 passed; 0 failed;', trace)
    payload = {
        'source_artifact': 'P09 moving markers on an owned Ubuntu Xvfb',
        'scope': 'Isolated actual 4K H.264 native Intel Wayland with uncapped SSH',
        'diagnostic_only': True,
        'rgb_backing_reuse_arm': options.arm,
        'run_id': options.run_id, 'warmup_seconds': options.warmup,
        'requested_observe_seconds': options.seconds, 'unique_markers': len(markers),
        'scored_unique_markers': len(scored), 'unique_markers_per_second': len(scored) / options.seconds,
        'longest_gap_ms': max(gaps) / 1e6,
        'source_submitted_frames_per_second': source_fps,
        'source_qualified_for_30_fps_request': source_fps >= 30,
        'host_binary_sha256': host_sha, 'viewer_binary_sha256': digest(options.viewer_bin),
        'viewer_test_binary_sha256': digest(options.lib_bin),
        'observer_start': first, 'observer_end': last,
        'host_h264_frames': sum(row['h264_frames'] for row in active),
        'host_drawn_acks': sum(row['drawn_acks'] for row in host),
    }
    (run / 'result.json').write_text(json.dumps(payload, indent=2) + '\n')
    print(json.dumps(payload, indent=2), flush=True)


def run(options):
    if (options.arm, options.run_id, options.warmup, options.seconds) != ('B', 11, 30, 3600):
        raise ValueError('expected only run 11, opt-in arm B, 30 s warmup and 3600 s observation')
    pins = json.loads((LAB / 'pins.json').read_text())
    remote_dir = (LAB / 'remote-dir').read_text().strip()
    assert remote_dir == pins['remote_dir'] and re.fullmatch(r'/tmp/jwm-wayland-hour\.[A-Za-z0-9]+', remote_dir)
    assert options.viewer_sha256 == pins['sha256']['viewer'] and options.observer_sha256 == pins['sha256']['observer']
    assert Path(pins['render_node']).stat().st_rdev == pins['render_node_device']
    source_hashes = source_pins(remote_dir, pins['sha256'])
    host_sha = source_hashes['host']
    assert host_sha == (LAB / 'host-binary-sha256').read_text().strip()
    assert digest(options.viewer_bin) == options.viewer_sha256, 'actual viewer binary differs from its pin'
    assert digest(options.lib_bin) == options.observer_sha256, 'observer binary differs from its pin'
    run = Path(tempfile.mkdtemp(prefix=f'phase-{options.run_id:03d}.', dir=LAB))
    label = run.name
    print(f'Native Wayland phase diagnostic directory: {run}', flush=True)
    (run / 'source-pins.json').write_text(json.dumps(source_hashes, indent=2) + '\n')
    with ExitStack() as cleanup:
        def log(name):
            return cleanup.enter_context((run / name).open('wb'))

        key = run / 'key'
        cleanup.callback(key.unlink, missing_ok=True)
        env = clean_env()
        subprocess.run([options.viewer_bin, 'keygen', '--output', key], env=env, check=True, timeout=5,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        source_command = [
            'python3', '-u', f'{remote_dir}/source.py', label, '--arm', 'treatment',
            '--width', '3840', '--height', '2160', '--fps', '30', '--paint-fps', '60',
            '--seconds', str(options.warmup + options.seconds), '--run-id', str(options.run_id),
            '--cap', '0', '--send-buffer', '0', '--recv-buffer', '0', '--capture-scaling', 'auto',
            '--feature-flag', 'JWM_REMOTE_PARALLEL_YUV420', '--enable-at', 'host',
        ]
        ready_path = run / 'remote-ready.jsonl'
        source = subprocess.Popen(SSH + [PEER, shlex.join(source_command)], stdin=subprocess.PIPE,
                                  stdout=log(ready_path.name), stderr=log('remote-stderr.log'))
        cleanup.callback(stop, source, natural=True)
        source.stdin.write(key.read_bytes())
        source.stdin.flush()

        def port_announced():
            ready = rows(ready_path)
            return ready[0]['upstream_port'] if ready else None

        remote_port = wait_for(source, port_announced, 20)
        with socket.socket() as choose:
            choose.bind(('127.0.0.1', 0))
            local_port = choose.getsockname()[1]
        ssh_log = run / 'tunnel.log'
        tunnel = subprocess.Popen(SSH + ['-vN', '-o', 'ExitOnForwardFailure=yes', '-L',
                                          f'127.0.0.1:{local_port}:127.0.0.1:{remote_port}', PEER],
                                  stdin=subprocess.DEVNULL, stdout=log(ssh_log.name), stderr=subprocess.STDOUT)
        cleanup.callback(stop, tunnel)
        wait_for(tunnel, lambda: 'Local forwarding listening on 127.0.0.1 port' in ssh_log.read_text(), 12)
        print(f'Starting owned Wayland marker test {run}', flush=True)
        env.update(JWM_PHASE_REAL_VIEWER=str(options.viewer_bin), JWM_PHASE_EVIDENCE=str(run / 'viewer'),
                   JWM_PHASE_REUSE_ARM=options.arm, JWM_PHASE_VIEWER_SHA256=options.viewer_sha256)
        command = [TEST_DRIVER, options.lib_bin,
                   LAB / 'viewer-stats-wrapper.sh',
                   '/dev/dri/renderD128', f'127.0.0.1:{local_port}', key, str(options.run_id),
                   run / 'viewer', str(options.warmup), str(options.seconds)]
        outcome = subprocess.run(command, env=env, stdout=log('marker-test.log'), stderr=subprocess.STDOUT,
                                 timeout=options.warmup + options.seconds + 55)
        if outcome.returncode == 0:
            assert source.wait(timeout=15) == 0
    subprocess.run(['scp', '-Bqr', f'{PEER}:{remote_dir}/{label}', str(run / 'source')],
                   check=True, timeout=20, stderr=subprocess.PIPE)
    if outcome.returncode:
        raise RuntimeError(f'Wayland marker test exited {outcome.returncode}; see {run / "marker-test.log"}')
    assert digest(options.viewer_bin) == options.viewer_sha256, 'actual viewer binary changed during run'
    assert digest(options.lib_bin) == options.observer_sha256, 'observer binary changed during run'
    source_pins(remote_dir, pins['sha256'])
    wait_for_marker = run / 'viewer/viewer-stderr-relay-complete'
    if not wait_for_marker.is_file():
        # The private relay can still be joining the sampler after viewer EOF.
        until = time.monotonic() + 3
        while not wait_for_marker.is_file() and time.monotonic() < until:
            time.sleep(.02)
    result(run, options, host_sha)
    from validate_reuse import write_diagnostic
    phase = write_diagnostic(run)
    write_resource_report(run, phase)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('lib_bin', type=Path)
    parser.add_argument('viewer_bin', type=Path)
    parser.add_argument('--viewer-sha256', required=True)
    parser.add_argument('--observer-sha256', required=True)
    parser.add_argument('--arm', required=True, choices=('A', 'B'))
    parser.add_argument('--run-id', type=int, default=91, choices=range(1, 256))
    parser.add_argument('--warmup', type=int, default=6, choices=range(0, 121))
    parser.add_argument('--seconds', type=int, default=3600)
    run(parser.parse_args())
