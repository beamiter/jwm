"""Join native Wayland raw phase windows to managed metrics and real ROI markers."""
import argparse
import json
import math
from pathlib import Path
from statistics import median


SIZE = [3840, 2160]
SHARED_STAGES = ('decode_ms', 'hardware_download_ms', 'presentation_queue_ms',
                 'presentation_completion_ms', 'native_preparation_and_submit_ms')
NATIVE_STAGES = (
    'va_surface_wait_ms', 'va_frame_export_ms', 'rgb_target_allocation_ms',
    'egl_prepare_and_submit_ms', 'egl_fence_wait_ms', 'wayland_dmabuf_import_ms',
)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def records(path, mixed=False):
    with path.open() as trace:
        return [json.loads(line) for line in trace if not mixed or line.startswith('{')]


def keyed_window(record, raw):
    stages = record['stages'] if raw else record
    canonical = {
        'session_id': record['session_id'],
        'duration_ns': round(record['window_seconds'] * 1e9 if raw else record['window_ms'] * 1e6),
        'final': record['final'],
        'last_frame': record['last_frame' if raw else 'last_decoded_frame'],
        'drawn': record['drawn' if raw else 'presented_frames'],
        'acked': record['acked' if raw else 'acked_frames'],
        'native': record['native_presented' if raw else 'native_presented_frames'],
        'path': record['last_presentation_path'],
        'codec': record['negotiated_codec'],
        'common_stages': {stage: stages[stage] for stage in SHARED_STAGES},
    }
    require(canonical['duration_ns'] > 0, 'nonpositive viewer window duration')
    return json.dumps(canonical, sort_keys=True)


def valid_native(record, scope, raw):
    stages = record['stages'] if raw else record
    require(record['session_id'] == scope['session_id'], 'viewer session changed')
    require(record['negotiated_codec'] == 'H.264', 'viewer changed codec')
    require(stages['hardware_download_ms']['observations'] == 0, 'viewer downloaded a hardware frame')
    if raw:
        require(record['type'] == 'jwm_remote_viewer_stats' and record['schema_version'] == 1,
                'unknown raw viewer window schema')
        require(record['viewer_backend'] == 'wayland' and record['input_mode'] == 'view-only',
                'unexpected raw viewer backend or input route')
        require(all(stages[name]['observations'] == 0 for name in
                    ('hardware_conversion_ms', 'hardware_rgb_copy_ms')),
                'raw viewer records a CPU RGB conversion or copy')
        work = record['hardware_rgb_work']
        required_work = {'pool', 'download', 'copy'}
        require(required_work <= work.keys() <= required_work | {'vaapi_map'} and all(work.values()),
                'raw viewer CPU RGB work counter groups do not match the known schemas')
        if 'vaapi_map' in work:
            require(set(work['vaapi_map']) == {'mapped_frames', 'fallback_frames', 'staged_bytes'}
                    and stages['hardware_direct_map_ms']['observations'] == 0,
                    'VA-API mapped a frame through the CPU')
        require(all(type(value) is int and value == 0 for group in work.values()
                    for value in group.values()), 'raw viewer materialized a CPU RGB frame')
    drawn = record['drawn' if raw else 'presented_frames']
    require(record['native_presented' if raw else 'native_presented_frames'] == drawn,
            'viewer drew a frame through another route')
    if drawn:
        require(record['last_presentation_path'] == 'wayland-vaapi-dmabuf', 'unexpected viewer presentation path')
    frame = record['last_frame' if raw else 'last_decoded_frame']
    if frame is not None:
        require(frame['source_epoch'] == scope['source_epoch']
                and frame['geometry_epoch'] == scope['geometry_epoch']
                and frame['source_dimensions'] == frame['encoded_dimensions'] == SIZE
                and frame['codec'] == 'H.264', 'viewer changed frame scope or extent')


def marker_scope(run, result):
    observed = records(run / 'viewer' / 'observed.jsonl')
    first, = [row for row in observed if row['type'] == 'p09_start']
    end, = [row for row in observed if row['type'] == 'p09_end']
    scope = first['scope']
    require(first == result['observer_start'] and end == result['observer_end'],
            'marker observer interval differs from the trial result')
    require(scope == end['scope'] and first['run_id'] == end['run_id'] == result['run_id']
            and first['backend'] == 'private-wayland-dmabuf'
            and [first['width'], first['height']] == SIZE
            and first['roi'] == [16, 16, 96, 96] and first['roi_bytes'] == 96**2 * 4,
            '4K Wayland ROI marker interval is ineligible')
    require(end['wrong_run'] == end['reordered'] == 0 and not end['interrupted']
            and not end['target_lost'], 'marker observer did not finish on its original output')
    start_ns, end_ns = (first[f'score_{edge}_ns'] for edge in ('start', 'end'))
    require(start_ns - first['monotonic_ns'] == result['warmup_seconds'] * 10**9
            and end_ns - start_ns == result['requested_observe_seconds'] * 10**9
            and end['monotonic_ns'] >= end_ns, 'incomplete observer interval')
    markers = [row for row in observed if row['type'] == 'p09_frame' and row['scored']]
    require(len(markers) == end['scored_unique'] == result['scored_unique_markers'] >= 3,
            'missing distinct scored ROI markers')
    require(all(row['wayland_feedback'] == 'presented' and row['classification'] == 'new'
                and row['run_id'] == row['observed_run_id'] == result['run_id']
                and row['scope'] == scope and start_ns <= row['monotonic_ns'] < end_ns for row in markers),
            'ROI marker belongs to another session, run or time')
    require(all(a['source_frame'] < b['source_frame'] and a['compositor_sequence'] < b['compositor_sequence']
                and a['monotonic_ns'] < b['monotonic_ns'] for a, b in zip(markers, markers[1:])),
            'ROI marker or compositor completion order regressed')
    return scope, start_ns, end_ns, markers


def join_windows(raw_rows, events, managed_clocks, scope, start_ns, end_ns):
    require(bool(raw_rows), 'no --stats-json viewer windows captured')
    require(all(a['arrival_monotonic_ns'] < b['arrival_monotonic_ns']
                for a, b in zip(raw_rows, raw_rows[1:])), 'raw window arrivals are unordered')
    raw_by_key = {}
    for row in raw_rows:
        record = row['record']
        valid_native(record, scope, raw=True)
        key = keyed_window(record, raw=True)
        require(key not in raw_by_key, 'duplicate raw identity cannot be joined unambiguously')
        raw_by_key[key] = row
    require([row['record']['final'] for row in raw_rows] == [False] * (len(raw_rows) - 1) + [True],
            'raw stage telemetry does not close with one final window')

    require(any(event.get('state') == 'closed' for event in events)
            and not any(event.get('state') == 'failed' for event in events), 'managed viewer did not close')
    snapshots = [event['metrics'] for event in events if event.get('metrics')]
    require(len(snapshots) == len(managed_clocks), 'managed viewer and arrival clock counts differ')
    matched = {}
    for managed, clock in zip(snapshots, managed_clocks, strict=True):
        frame = managed['last_decoded_frame']
        sequence = frame['sequence'] if frame else None
        require((managed['session_id'], managed['window_ms'], managed['final'], sequence)
                == (clock['session_id'], clock['window_ms'], clock['final'], clock['last_decoded_sequence']),
                'managed snapshot and reader clock identity differ')
        valid_native(managed, scope, raw=False)
        key = keyed_window(managed, raw=False)
        require(key in raw_by_key, 'managed snapshot has no exactly matching raw window')
        matched.setdefault(key, clock['monotonic_ns'])
    require(matched and keyed_window(raw_rows[-1]['record'], raw=True) in matched,
            'final raw telemetry did not match a managed viewer snapshot')
    retained = []
    for key, row in raw_by_key.items():
        record = row['record']
        arrival = row['arrival_monotonic_ns']
        duration = round(record['window_seconds'] * 1e9)
        if not record['final'] and start_ns <= arrival - duration <= arrival <= end_ns:
            require(key in matched, 'measured raw telemetry window has no matching managed identity')
            retained.append(row | {'managed_arrival_monotonic_ns': matched[key],
                                   'raw_window_start_estimate_monotonic_ns': arrival - duration})
    require(retained and any(row['record']['drawn'] and row['record']['acked'] for row in retained),
            'no active matched whole raw stage window in the ROI interval')
    return snapshots, matched, retained


def stage_summary(retained, optional=()):
    grouped = {name: [] for name in NATIVE_STAGES}
    for row in retained:
        group = row['record'].get('native_wayland_stages', {})
        require(isinstance(group, dict) and group.keys() <= grouped.keys(), 'unknown native Wayland stage')
        for name, stage in group.items():
            count, quantiles = stage['observations'], stage['quantiles']
            values = [quantiles[key] for key in ('p50_ms', 'p95_ms', 'p99_ms')]
            require(type(count) is int and count > 0 and quantiles['samples'] == min(count, 128)
                    and all(isinstance(value, (int, float)) and math.isfinite(value) and value >= 0
                            for value in [stage['mean'], *values]) and values == sorted(values),
                    f'invalid native stage report: {name}')
            grouped[name].append(stage)
    require(all(stages or name in optional for name, stages in grouped.items()),
            'retained exact native window set did not exercise every required phase')
    return {
        name: {'windows': len(stages), 'observations': sum(stage['observations'] for stage in stages),
               'median_window_p50_ms': median(stage['quantiles']['p50_ms'] for stage in stages),
               'window_p95_range_ms': [min(stage['quantiles']['p95_ms'] for stage in stages),
                                       max(stage['quantiles']['p95_ms'] for stage in stages)]}
        for name, stages in grouped.items() if stages
    }


def write_diagnostic(run, optional_stages=(), additional_check=None):
    result = json.loads((run / 'result.json').read_text())
    require(result['diagnostic_only'] is True, 'must use the isolated phase runner')
    scope, start_ns, end_ns, markers = marker_scope(run, result)
    host = [row for row in records(run / 'source' / 'host.log', mixed=True)
            if row.get('type') == 'jwm_remote_host_stats']
    require(host and {row['session_id'] for row in host} == {scope['session_id']}
            and any(row['h264_frames'] and row['drawn_acks'] for row in host)
            and all(row['jpeg_atlases'] == row['hevc444_frames'] == 0 for row in host)
            and all(row['source_dimensions'] == row['encoded_dimensions'] == SIZE
                    for row in host if row['h264_frames']), 'host and native ROI do not share an exact H.264 session')
    viewer = run / 'viewer'
    require((viewer / 'viewer-stderr-relay-complete').is_file(), 'stderr relay did not drain to EOF')
    raw_rows = records(viewer / 'viewer-stage-windows.jsonl')
    snapshots, matched, retained = join_windows(
        raw_rows, records(viewer / 'viewer-events.jsonl'), records(viewer / 'viewer-clock.jsonl'),
        scope, start_ns, end_ns)
    stages = stage_summary(retained, optional_stages)
    with (run / 'matched-native-windows.jsonl').open('w') as output:
        for row in retained:
            print(json.dumps(row, separators=(',', ':')), file=output)
    report = {
        'diagnostic_only': True, 'marker_scope': scope, 'extent': SIZE,
        'codec': 'H.264', 'presentation': 'wayland-vaapi-dmabuf',
        'host_binary_sha256': result['host_binary_sha256'],
        'viewer_binary_sha256': result['viewer_binary_sha256'],
        'observer_binary_sha256': result['viewer_test_binary_sha256'],
        'matching_scored_roi_markers': len(markers),
        'observer_interval_monotonic_ns': [start_ns, end_ns],
        'raw_windows': len(raw_rows),
        'managed_metric_snapshots': len(snapshots), 'matched_distinct_raw_windows': len(matched),
        'matched_whole_observer_windows': len(retained),
        'matched_whole_coverage_seconds': sum(row['record']['window_seconds'] for row in retained),
        'hardware_rgb_download_observations_all_raw_windows': 0,
        'native_wayland_stages': stages,
        'scope_note': ('Raw viewer and managed clock arrivals belong to the observer machine. '
                       'Whole-window boundaries are estimated from viewer stderr receipt and the reported '
                       'duration. No timestamp subtraction across endpoints. Stage quantiles describe '
                       'the recent samples in each raw viewer window.'),
    }
    if additional_check is not None:
        report['rgb_backing_reuse'] = additional_check(run, result, raw_rows, retained)
    (run / 'phase-diagnostic.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2), flush=True)
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('run', type=Path)
    write_diagnostic(parser.parse_args().run)
