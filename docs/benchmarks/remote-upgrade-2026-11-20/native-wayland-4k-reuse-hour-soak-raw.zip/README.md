# Native Wayland 4K backing reuse hour soak

Run `python3 replay.py .` in the extracted directory to rescore motion and resources from the endpoint records. The phase validators correlate the viewer-local compositor observer with the viewer-local telemetry. The source frame rate uses the source clock. The logs preserve clock readings and anonymize the private session ID, temporary paths and loopback ports.

The 20-bit painter permits 60 FPS over the complete source interval. The test-only observer patch enables the hour trial. See the manifest for the tested build and per-fixture hashes. The pinned source controller and host binary are the same as in the preceding native-Wayland 4K ABBA trials.
