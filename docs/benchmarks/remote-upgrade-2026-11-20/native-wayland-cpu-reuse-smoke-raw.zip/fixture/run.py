#!/usr/bin/env python3
"""Private CLI/Wayland CPU-resize evidence. Does not build or use a live display."""
import argparse
from collections import Counter
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import select
import signal
import subprocess
import tempfile
import time

LAB = Path(__file__).resolve().parent
REPO = Path("/home/yj/projects/jwm")
BASELINE = "0631f2639676e6dc1cc4d1c81cdad8d0a2804e17"
LOCK = Path("/tmp/jwm-p08-p09-release/benchmark.lock")
RELEASE = Path("/tmp/jwm-p08-p09-release/jwm-remote")
TEST_BINARY = Path("/tmp/jwm-remote-plan-check/debug/deps/jwm-64949a02bb6a16d7")
PIXEL_CASE = (
    "remote::host::wayland_viewer_integration::host_control_integration::cli_process_integration::"
    "source_switching::native_cli_source_catalog_rebuilds_wayland_roles_and_retires_old_feedback"
)
UNIT_CASES = (
    "remote::wayland_capture::tests::xrgb_decoding_uses_native_endian_masks_not_cursor_or_alpha",
    "remote::triangle_patch::tests::full_resize_into_caller_storage_matches_triangle_after_geometry_changes",
)
NATIVE_SIZES = ((200, 150), (240, 180))
ENCODED_SIZE = (120, 90)


def identity(pid):
    try:
        return int(Path(f"/proc/{pid}/stat").read_text().rsplit(") ", 1)[1].split()[19])
    except FileNotFoundError:
        return None


def wait_for_pilot(pid, expected_ticks):
    if identity(pid) != expected_ticks:
        return "pilot-already-ended"
    try:
        descriptor = os.pidfd_open(pid)
    except ProcessLookupError:
        return "pilot-already-ended"
    try:
        if identity(pid) != expected_ticks:
            return "pilot-already-ended"
        ready = select.poll()
        ready.register(descriptor, select.POLLIN)
        ready.poll()
        return "waited-on-original-pilot-pidfd"
    finally:
        os.close(descriptor)


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as data:
        for chunk in iter(lambda: data.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def run_test(test_binary, case, output, env, *, ignored=False, timeout=12):
    arguments = [str(test_binary), case, "--exact", "--test-threads=1", "--show-output"]
    if ignored:
        arguments.append("--ignored")
    with output.open("wb") as log:
        child = subprocess.Popen(arguments, env=env, start_new_session=True, stdout=log, stderr=subprocess.STDOUT)
        try:
            status = child.wait(timeout=timeout)
        except BaseException:
            # The Rust test and the CLI/tee descendants are owned by this group.
            try:
                os.killpg(child.pid, signal.SIGTERM)
                child.wait(timeout=3)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
            except ProcessLookupError:
                pass
            raise
    text = output.read_text(errors="replace")
    if status or not re.search(r"^test result: ok\. 1 passed; 0 failed;", text, re.M):
        raise RuntimeError(f"test did not run and pass exactly once: {case}; see {output}")


def write_source_witness(run):
    name = "src/remote/wayland_capture.rs"
    baseline = subprocess.check_output(["git", "show", f"{BASELINE}:{name}"], cwd=REPO, text=True)
    current = (REPO / name).read_text()
    triangle = (REPO / "src/remote/triangle_patch.rs").read_text()
    recycler = (REPO / "src/remote/x11_capture.rs").read_text()

    def segment(text, start, stop):
        begin = text.index(start)
        return text[begin:text.index(stop, begin)]

    locations = {
        "baseline_pread_and_resize": segment(baseline, "        let mut pixels = Vec::new();\n        pixels.try_reserve_exact(bytes)?;", "        self.sync_until(deadline)?;"),
        "baseline_rgb_destination": segment(baseline, "fn decode_xrgb(bytes:", "\n}\n"),
        "current_reused_pread_and_resize": segment(current, "        let staging_grew = bytes > self.xrgb_staging.capacity();",
                                                  "        self.sync_until(deadline)?;"),
        "current_triangle_destination": segment(triangle, "    pub(super) fn resize_into(", "    fn render_into("),
        "current_two_buffer_spare_recycler": segment(recycler, "pub(crate) struct CaptureImageRecycler", "#[cfg(test)]\nfn decode_ximage"),
    }
    (run / "allocation-sites.json").write_text(json.dumps({"baseline_commit": BASELINE,
        "baseline_and_current_source": name, "sites": locations}, indent=2) + "\n")


def json_rows(path, kind=None):
    rows = []
    for line in path.read_text().splitlines():
        if not line.startswith("{"):
            continue
        row = json.loads(line)
        if kind is None or row.get("type") == kind:
            rows.append(row)
    return rows


def analyze(run, metadata):
    host = json_rows(run / "host.log", "jwm_remote_host_stats")
    viewer = json_rows(run / "viewer-events.jsonl")
    windows = [row for row in host if row.get("wayland_capture")]
    sessions = {row["session_id"] for row in windows}
    if len(sessions) != 1 or not next(iter(sessions), None):
        raise ValueError("expected one authenticated session with native capture telemetry")
    session_id = next(iter(sessions))
    stages = Counter()
    readback_bytes = staging_growths = 0
    records = []
    host_scopes = []
    for row in windows:
        capture = row["wayland_capture"]
        if "wayland-surface/" not in row["mode"] or "/shm/" not in row["mode"] or row["h264_frames"]:
            raise ValueError(f"capture was not the intended CPU Wayland SHM path: {row['mode']}")
        counts = {name: capture["stages"][name]["observations"] for name in
                  ("readback_ms", "conversion_ms", "resize_ms")}
        stages.update(counts)
        readback_bytes += capture["readback_bytes"]
        staging_growths += capture["staging_growths"]
        scope = row.get("last_sent_frame")
        if scope and (tuple(scope["source_dimensions"]) not in NATIVE_SIZES or
                      tuple(scope["encoded_dimensions"]) != ENCODED_SIZE or scope["codec"] != "JPEG"):
            raise ValueError(f"unexpected CPU-scaled frame scope: {scope}")
        if scope:
            host_scopes.append(scope)
        records.append({"window_seconds": row["window_seconds"], "mode": row["mode"],
                        "frame_scope": scope, "staging_growths": capture["staging_growths"],
                        "readback_bytes": capture["readback_bytes"], "stage_counts": counts})
    if not stages["resize_ms"] or stages["resize_ms"] != stages["conversion_ms"]             or stages["resize_ms"] != stages["readback_ms"]:
        raise ValueError("real Wayland CPU resize and its corresponding readback/conversion were not observed")
    if readback_bytes % 4:
        raise ValueError("SHM readback bytes do not match packed XRGB8888")
    viewer_frames = {}
    for row in viewer:
        if row.get("event") != "snapshot":
            continue
        metric = row.get("metrics") or {}
        if metric.get("session_id") != session_id or not (scope := metric.get("last_decoded_frame")):
            continue
        native = tuple(scope["source_dimensions"])
        if native in NATIVE_SIZES and tuple(scope["encoded_dimensions"]) == ENCODED_SIZE:
            if scope["codec"] != "JPEG":
                raise ValueError("viewer did not use JPEG for the scaled source")
            viewer_frames[scope["source_epoch"]] = scope
    if not host_scopes:
        raise ValueError("host did not report an authenticated, scaled JPEG frame")
    native_seen = {tuple(row["source_dimensions"]) for row in [*host_scopes, *viewer_frames.values()]}

    report = {
        "schema_version": 1, **metadata, "fixture": PIXEL_CASE, "session_id": session_id,
        "fixture_native_dimensions": NATIVE_SIZES, "native_dimensions_seen_in_frame_scopes": sorted(native_seen),
        "encoded_dimensions": ENCODED_SIZE,
        "host_windows": records, "viewer_scope_by_source_epoch": viewer_frames,
        "stage_observations": stages, "xrgb_staging_growth_events": staging_growths,
        "reuse_observed_across_capture": stages["readback_ms"] > staging_growths,
        "copy_scope": {"observed_shm_to_cpu_readback_bytes": readback_bytes,
                       "calculated_xrgb_to_rgb_destination_bytes": (readback_bytes // 4) * 3,
                       "calculated_resize_destination_bytes": stages["resize_ms"] * 120 * 90 * 3},
        "baseline_sites_estimated_for_same_stage_observations": {
            "fresh_xrgb_reserves": stages["readback_ms"],
            "fresh_rgb_destination_reserves": stages["conversion_ms"],
            "allocating_imageops_resize_calls": stages["resize_ms"]},
        "scope": "The existing private GL fixture samples both solid colors on the actual viewer buffers. "
                 "Current staging growth is a product capacity-increase counter. Baseline site counts and "
                 "destination byte counts are calculated from source and observed stage invocations. "
                 "This is not a malloc trace, network throughput trial, or physical KMS measurement.",
    }
    encoded = json.dumps(report, indent=2) + "\n"
    (run / "result.json").write_text(encoded)
    print(encoded, end="", flush=True)


def cli():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--after-pid", type=int, default=791257)
    parser.add_argument("--after-start-ticks", type=int, default=4853560)
    parser.add_argument("--remote-binary", type=Path, default=RELEASE)
    parser.add_argument("--test-binary", type=Path, default=TEST_BINARY)
    args = parser.parse_args()
    print(f"Waiting for owned pilot PID {args.after_pid} and the shared benchmark lock", flush=True)
    pilot_status = wait_for_pilot(args.after_pid, args.after_start_ticks)
    with LOCK.open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        started = time.time_ns()
        run = Path(tempfile.mkdtemp(prefix="run.", dir=LAB))
        private = run / "private"
        private.mkdir(mode=0o700)
        print(f"Private P04 evidence: {run}", flush=True)
        env = {key: value for key, value in os.environ.items()
               if not key.startswith("JWM_REMOTE_") and key not in
               {"DISPLAY", "WAYLAND_DISPLAY", "WAYLAND_SOCKET", "XAUTHORITY"}}
        env.update({
            "TMPDIR": str(private), "XDG_RUNTIME_DIR": str(private), "XDG_CONFIG_HOME": str(private),
            "XDG_CACHE_HOME": str(private), "JWM_REQUIRE_HEADLESS_GL": "1",
            "EGL_PLATFORM": "surfaceless", "LIBGL_ALWAYS_SOFTWARE": "1", "LP_NUM_THREADS": "2",
            "JWM_REMOTE_CLI_TEST_BIN": str(LAB / "cli-probe"),
            "P04_REMOTE_BINARY": str(args.remote_binary.resolve()), "P04_ARTIFACTS": str(run),
        })
        runtime = Path("/tmp/jwm-remote-ffmpeg/usr/lib/x86_64-linux-gnu")
        if runtime.is_dir():
            previous = env.get("LD_LIBRARY_PATH")
            env["LD_LIBRARY_PATH"] = f"{runtime}:{previous}" if previous else str(runtime)
        for label, test in zip(("xrgb-reuse", "triangle-resize"), UNIT_CASES):
            run_test(args.test_binary, test, run / f"{label}.log", env)
        write_source_witness(run)
        run_test(args.test_binary, PIXEL_CASE, run / "cli-fixture.log", env, ignored=True, timeout=35)
        analyze(run, {"pilot_wait": pilot_status, "started_after_lock_unix_ns": started,
                      "finished_capture_unix_ns": time.time_ns(),
                      "remote_binary_sha256": sha256(args.remote_binary),
                      "test_binary_sha256": sha256(args.test_binary)})


if __name__ == "__main__":
    cli()
