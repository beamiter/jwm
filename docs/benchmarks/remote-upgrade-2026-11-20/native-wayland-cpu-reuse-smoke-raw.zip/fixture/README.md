# P04 Wayland CPU resize smoke

The fixture reuses the built private Smithay CLI source-catalog integration.
It runs the real host and viewer CLI against two private Wayland compositors
with surfaceless software GL. The test checks actual viewer pixels for both
authorized source colors before and after source transitions. It uses
authenticated loopback TCP and private Unix sockets.

The host's public `--max-width` option starts at 320 pixels. The fixture's
native surfaces are 200×150 and 240×180. The shim therefore adds
`--frame-max-width 120 --frame-max-height 90` and `--stats-json` only to the
view-only Wayland host command. The negotiated encoded limit is applied at
`HostCapture::set_frame_limits`. The native SHM API still captures the source
size; the product path converts XRGB and calls its CPU Triangle resize before
JPEG encoding. No native application resize or input grant is involved.

## Operator command

```sh
python3 -u /tmp/jwm-p04-cpu-resize/run.py
```

The default waits for the named pilot, PID 791257 with the recorded Linux
start ticks 4853560, using a pidfd. It then takes the shared
`/tmp/jwm-p08-p09-release/benchmark.lock` before running any workload. It waits
for the pilot before acquiring the lock, since the pilot itself may still
need the lock. A PID reuse is ignored when its start ticks differ. Existing
CLI and Rust test binaries are used directly, with options for explicit
replacement paths if the artifacts have moved. No Cargo build is required.

The runner executes two small reuse/resize checks and one exact ignored
private CLI smoke, with a 35-second cutoff for the latter. It retains the
run directory and raw data when a check fails. The latest output is a
`run.*` child of this directory. A real Wayland CPU resize is accepted only
when native Wayland SHM telemetry records corresponding readback, conversion
and resize observations and one authenticated scaled JPEG scope.

## Evidence accounting

- `cli-fixture.log` records the private GL pixel test.
- `host.log` and `viewer-events.jsonl` retain the actual CLI output. The
  final host window can contain all the resize samples, so its stats remain
  included. Viewer metrics are periodic and may cover only some source epochs.
- `allocation-sites.json` preserves the plan-pinned baseline allocation
  sites and current scratch/output sites. The baseline performs a new XRGB
  reserve and new RGB reserve for each corresponding stage and calls the
  allocating image resize API for every scaled frame.
- `result.json` reports current staging capacity-growth events and calculated
  corresponding baseline call counts. It preserves exact observed SHM read
  bytes and calculates the RGB conversion and resize destination bytes.
  These counts describe the named sites and omit other allocations and
  transfers, including encoder operations and graphics memory traffic.

This smoke does not measure physical scanout, machine-to-machine transport,
whole-process allocation behavior, or a performance delta. The only checks
performed while preparing it were syntax inspection and source review.
