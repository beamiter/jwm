#!/usr/bin/env python3
"""Replay a terminal dual-host Firefox X11 batch and publish a redacted archive."""

import argparse
import hashlib
import json
import math
from pathlib import Path
import re
import sys
import tempfile
import zipfile

DIMENSIONS = [1920, 1080]
TRIALS = 3
SECOND = 1_000_000_000
WARM, SCORE, TAIL, FPS = 30, 60, 8, 30
PHASES = ("static", "motion")
ROLES = {"host": "source", "viewer": "viewer"}
PEER_EVENTS = [
    "viewer_ready", "viewer_static_started", "viewer_static_done",
    "viewer_motion_armed", "viewer_motion_done", "viewer_disconnected",
]
VIEWER_EVENTS = ["static", "motion", "disconnect"]
SESSION_END = "jwm-remote: session ended"
FIXTURE_SCRIPTS = {"dual_browser.py", "run_baseline.py", "processes.py", "score.py"}
JSON_REPORT = "firefox-x11-dual-scored.json"
RAW_ARCHIVE = "firefox-x11-dual-scored-raw.zip"
SHA256 = re.compile(r"[0-9a-f]{64}")
UUID = re.compile(r"[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}")
RUN_ID = re.compile(r"[0-9a-f]{32}")
PIXEL_KEYS = {"side", "start_monotonic_ns", "end_monotonic_ns", "tile_x", "scroll_text"}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def from_json(path):
    return json.loads(path.read_bytes())


def json_lines(data):
    return [json.loads(line) for line in data.splitlines()]


def json_bytes(value):
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()


def line_bytes(rows):
    return b"".join((json.dumps(row, sort_keys=True) + "\n").encode() for row in rows)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def canonical_digest(value):
    return digest(json.dumps(value, sort_keys=True, separators=(",", ":")).encode())


def controller_terminal(pid, fixture_path):
    proc = Path("/proc") / str(pid)
    try:
        argv = (proc / "cmdline").read_bytes().split(b"\0")
    except FileNotFoundError:
        return "controller_exited"
    if str(fixture_path).encode() in argv:
        try:
            state = (proc / "stat").read_bytes().rsplit(b") ", 1)[1].split()[0]
        except FileNotFoundError:
            return "controller_exited"
        require(state == b"Z", "the exact recorded controller is still running")
        return "controller_zombie"
    require(not any(argv), "controller PID now identifies an unrelated process")
    return "controller_exited"


def verified_fixtures(root, original):
    manifest = from_json(root / "fixture-manifest.json")
    new, old = (root / "browser-trial.html").read_bytes(), original.read_bytes()
    require(digest(new) == manifest["trial_sha256"] and digest(old) == manifest["original_sha256"],
            "browser fixture digest differs")
    change = manifest["sole_trial_change"]
    before, after = change["before"].encode(), change["after"].encode()
    require(old.count(before) == 1 and old.replace(before, after) == new,
            "the single documented browser fixture change differs")
    provenance = {}
    for line in (root / "staged-source-sha256.txt").read_text().splitlines():
        sha, name = line.split()
        require(name in FIXTURE_SCRIPTS and name not in provenance, "unexpected fixture script")
        require(digest((root / name).read_bytes()) == sha, f"{name} differs from staged SHA-256")
        provenance[name] = sha
    require(set(provenance) == FIXTURE_SCRIPTS, "fixture provenance is incomplete")
    files = {
        f"fixtures/{name}": (root / name).read_bytes()
        for name in ("fixture-manifest.json", "browser-trial.html", "staged-source-sha256.txt", *sorted(FIXTURE_SCRIPTS))
    }
    files["fixtures/browser-original.html"] = old
    files["fixtures/publish_dual.py"] = Path(__file__).read_bytes()
    return manifest, provenance, files


def load_replay(fixture_dir):
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(fixture_dir))
    from run_baseline import select_telemetry
    from score import score_pixels
    return select_telemetry, score_pixels


def pixels(data, side):
    rows = json_lines(data)
    previous = -1
    for row in rows:
        start, end = row["start_monotonic_ns"], row["end_monotonic_ns"]
        require(set(row) == PIXEL_KEYS and row["side"] == side, "unexpected pixel record")
        require(type(start) is int and type(end) is int and previous <= start <= end,
                "pixel samples are not ordered on the local clock")
        tile, glyph = row["tile_x"], row["scroll_text"]
        require(tile is None or (type(tile) is int and 0 <= tile < DIMENSIONS[0]), "invalid tile position")
        require(glyph is None or re.fullmatch(r"[0-9a-f]{16}", glyph), "invalid glyph signature")
        previous = end
    return rows


def telemetry(data, role, clocked):
    rows = json_lines(data)
    previous = -1
    for row in rows:
        record = row
        if clocked:
            stamp, record = row["end_monotonic_ns"], row["record"]
            require(set(row) == {"end_monotonic_ns", "record"} and type(stamp) is int and stamp >= previous,
                    "telemetry arrival clocks are not ordered")
            previous = stamp
        require(record["type"] == f"jwm_remote_{role}_stats" and not record.get("final"),
                "unexpected continuous telemetry record")
        require(RUN_ID.fullmatch(record["session_id"]) and math.isfinite(record["window_seconds"])
                and record["window_seconds"] > 0, "invalid continuous telemetry")
    return rows


def files_for_trial(path, complete):
    files = {}
    for role, side in ROLES.items():
        prefix = "" if role == "host" else "viewer/"
        for name in ("static", "motion"):
            relative = f"{prefix}{name}-pixels.jsonl"
            source = path / relative
            if source.exists():
                data = source.read_bytes()
                pixels(data, side)
                files[relative] = data
            if complete:
                relative = f"{prefix}{name}-scope.json"
                files[relative] = (path / relative).read_bytes()
        for name in (f"{role}-clocked-telemetry", f"static-{role}", f"motion-{role}"):
            relative = f"{prefix}{name}.jsonl"
            source = path / relative
            if source.exists():
                data = source.read_bytes()
                telemetry(data, role, "clocked" in name)
                files[relative] = data
    return files


def check_role(files, role, replay):
    select_telemetry, score_pixels = replay
    prefix = "" if role == "host" else "viewer/"
    endpoint = ROLES[role]
    result = {}
    sessions, epochs = set(), set()
    previous = -1
    with tempfile.TemporaryDirectory(prefix="dual-replay.") as temp:
        work = Path(temp)
        trace = f"{role}-clocked-telemetry.jsonl"
        original_telemetry = files[prefix + trace]
        (work / trace).write_bytes(original_telemetry)
        for name in PHASES:
            scope = json.loads(files[f"{prefix}{name}-scope.json"])
            phase, start, end, tail, observer = (scope[f"{field}_monotonic_ns"] for field in (
                "phase_start", "score_start", "score_end", "telemetry_phase_end", "observer_end"
            ))
            require(scope["phase"] == name and previous <= phase
                    and (start - phase, end - start, tail - end) == (WARM * SECOND, SCORE * SECOND, TAIL * SECOND)
                    and observer >= tail, f"{role} {name} has invalid monotonic phase bounds")
            previous = observer
            samples = pixels(files[f"{prefix}{name}-pixels.jsonl"], endpoint)
            require(samples and phase <= samples[0]["start_monotonic_ns"] < start
                    and end < samples[-1]["end_monotonic_ns"] <= observer,
                    f"{role} {name} samples do not cover warmup, scoring and tail")
            raster = score_pixels(samples, start, end)
            require(scope["samples"] == {endpoint: raster} and raster["valid_and_invalid_sample_reads"] > SCORE,
                    f"{role} {name} pixel scores do not replay")
            selected = f"{name}-{role}.jsonl"
            stats = select_telemetry(work, scope, role, DIMENSIONS)
            recorded = scope["telemetry"]
            # Python 3.10 and 3.12 can sum identical received windows
            # with a one-ULP difference. Membership must remain byte exact.
            require({**stats, "window_seconds": recorded["window_seconds"]} == recorded
                    and math.isclose(stats["window_seconds"], recorded["window_seconds"], rel_tol=0, abs_tol=1e-10)
                    and files[f"{prefix}{selected}"] == (work / selected).read_bytes(),
                    f"{role} {name} whole-window telemetry does not replay")
            require(stats["window_seconds"] >= SCORE and len(stats["session_ids"]) == 1
                    and stats["frame_scopes_match_requested_jpeg"]
                    and (name == "static" or stats["frame_scopes_observed"] > 0),
                    f"{role} {name} has incomplete whole-window JPEG telemetry")
            rows = telemetry(files[f"{prefix}{selected}"], role, False)
            sessions.update(stats["session_ids"])
            for row in rows:
                if role == "host":
                    require(row["mode"].startswith("root/") and not row["h264_frames"] and not row["hevc444_frames"],
                            "unexpected host JPEG capture lane")
                    frame = row.get("last_sent_frame")
                else:
                    require(row["viewer_backend"] == "x11" and row["negotiated_codec"] == "JPEG"
                            and row["last_presentation_path"] == "rgb", "unexpected viewer JPEG presentation lane")
                    frame = row.get("last_frame")
                if frame:
                    epochs.add((frame["source_epoch"], frame["geometry_epoch"]))
            acknowledgements = sum(row["drawn_acks" if role == "host" else "acked"] for row in rows)
            summary = {key: value for key, value in raster.items() if key != "accepted_observations_monotonic_ns"}
            result[name] = {"local_phase_start_monotonic_ns": phase, "local_score_start_monotonic_ns": start,
                            "local_score_end_monotonic_ns": end, "local_observer_end_monotonic_ns": observer,
                            "raster": summary, "telemetry": recorded, "acknowledgements_in_whole_windows": acknowledgements}
            if name == "motion":
                require(acknowledgements > 0, f"{role} motion did not record any acknowledgements")
    require(len(sessions) == len(epochs) == 1, f"{role} session/source/surface epoch changed")
    return result, sessions.pop(), epochs.pop()


def check_controls(path, allowed, run_id):
    rows = json_lines(path.read_bytes())
    require([row["event"] for row in rows] == allowed and all(row["run_id"] == run_id for row in rows),
            "control events or run identity differ")
    return rows


def role_identity(raw, role):
    require(raw["role"] == role and raw["clock"] == "CLOCK_MONOTONIC" and raw["drawable_size"] == DIMENSIONS
            and SHA256.fullmatch(raw["release_sha256"]) and UUID.fullmatch(raw["boot_id"]),
            "endpoint identity does not describe the actual local observation lane")
    summary = {key: raw[key] for key in ("role", "kernel", "cpu", "drawable_size", "clock", "release_sha256")}
    summary["hostname_sha256"] = digest(raw["hostname"].encode())
    summary["boot_id_sha256"] = digest(raw["boot_id"].encode())
    for label in ("xvfb", "endpoint_process"):
        summary[f"{label}_identity_sha256"] = canonical_digest(raw[label])
    if role == "host":
        summary["firefox"] = {**raw["installed_firefox_application"],
                              "binary_sha256": raw["firefox"]["sha256"],
                              "process_identity_sha256": canonical_digest(raw["firefox"])}
    return summary


def summarize_completed(path, outcome, replay):
    raw_ends = from_json(path / "identity.json")
    run_id = raw_ends["run_id"]
    require(RUN_ID.fullmatch(run_id), "invalid control run identity")
    require(raw_ends["viewer"] == from_json(path / "viewer/identity.json"), "fetched viewer identity differs")
    remote = check_controls(path / "peer-events.jsonl", PEER_EVENTS, run_id)
    local = check_controls(path / "viewer/control-in.jsonl", VIEWER_EVENTS, run_id)
    require(remote[0]["identity"] == raw_ends["viewer"], "live ready endpoint differs from fetched endpoint")
    identities = {role: role_identity(raw_ends[role], role) for role in ROLES}
    require(all(identities["host"][key] != identities["viewer"][key]
                for key in ("hostname_sha256", "boot_id_sha256")),
            "the records do not identify distinct endpoints")
    identities["ssh_master_identity_sha256"] = canonical_digest(raw_ends["ssh_master"])
    files = files_for_trial(path, True)
    files["identity-digests.json"] = json_bytes(identities)
    for name, rows in (("peer-events-redacted.jsonl", remote), ("viewer/control-in-redacted.jsonl", local)):
        files[name] = line_bytes({"event": row["event"], "run_id": row["run_id"]} for row in rows)
    hosts, host_session, host_epochs = check_role(files, "host", replay)
    viewers, viewer_session, viewer_epochs = check_role(files, "viewer", replay)
    record = from_json(path / "result.json")
    require({key: value for key, value in record.items() if key != "phases"} == outcome["result"],
            "trial and controller outcomes differ")
    require(host_session == viewer_session and host_epochs == viewer_epochs
            and record["authenticated_session_ids"] == [host_session]
            and record["source_and_requested_viewer_dimensions"] == DIMENSIONS
            and record["codec"] == "JPEG" and record["jpeg_quality"] == 85 and record["telemetry_complete"],
            "endpoints did not observe the same JPEG session")
    for name in PHASES:
        for role in ROLES:
            relative = f"{'viewer/' if role == 'viewer' else ''}{name}-scope.json"
            require(json.loads(files[relative]) == record["phases"][name][role], "unmatched trial phase scope")

    # Controller's completed branch requires the host and SSH peer to exit with
    # 0, artifact transfer and monitor joins. Last peer event is reachable
    # only after the second toggle and tracked viewer itself both exited 0.
    viewer_log = (path / "viewer/viewer.log").read_text().splitlines()
    final = [json.loads(line) for line in viewer_log if line.startswith("{")]
    require(viewer_log[-1] == SESSION_END and final[-1]["final"]
            and final[-1]["session_id"] == host_session and final[-1]["acked"] > 0,
            "missing authenticated final viewer telemetry and normal session end")
    files["viewer/final-session.jsonl"] = line_bytes([final[-1]])
    files["viewer/session-ended.txt"] = (SESSION_END + "\n").encode()
    shutdown = {"viewer_control": VIEWER_EVENTS, "controller_events": PEER_EVENTS,
                "clean_controller_completion": True, "final_viewer_stats": True,
                "viewer_session_ended": True, "toggle_stderr_empty": (path / "viewer/disconnect.log").stat().st_size == 0}
    source, viewer = hosts["motion"]["raster"], viewers["motion"]["raster"]
    source_pass = source["unique_content_fps"] >= FPS and source["scroll_changes_seen"] >= SCORE
    gate = viewer["unique_content_fps"] >= 0.9 * FPS and viewer["scroll_changes_seen"] >= SCORE
    require((source["unique_content_fps"], viewer["unique_content_fps"], source_pass, gate if source_pass else None)
            == (record["source_motion_fps"], record["viewer_motion_fps"],
                record["source_qualified"], record["viewer_motion_gate_met"]),
            "fixed-lane FPS gate does not replay")
    summary = {"trial": outcome["trial"], "controller_status": "completed", "authenticated_session_id": host_session,
               "source_epoch": host_epochs[0], "geometry_epoch": host_epochs[1], "identities": identities,
               "shutdown": shutdown, "host": hosts, "viewer": viewers,
               "source_qualified": source_pass, "viewer_motion_gate_met": gate if source_pass else None}
    live_values = [raw_ends[role][key] for role in ROLES for key in ("boot_id", "hostname")]
    live_values = [value.encode() for value in live_values]
    live_values.extend(f"127.0.0.1:{raw_ends[label]}".encode() for label in ("local_port", "remote_port"))
    return summary, files, live_values


def summarize_failed(path, outcome):
    evidence = files_for_trial(path, False)
    failure = path / "failure.log"
    require(failure.is_file(), "failed attempt has no controller exception record")
    text = failure.read_text()
    categories = re.findall(r"^([A-Za-z]+(?:Error|Expired|Interrupt|Exit))[:\n]", text, re.MULTILINE)
    events = []
    stream = path / "peer-events.jsonl"
    if stream.is_file():
        for row in json_lines(stream.read_bytes()):
            if row["event"] in PEER_EVENTS and RUN_ID.fullmatch(row["run_id"]):
                events.append({"event": row["event"], "run_id": row["run_id"]})
        evidence["peer-events-redacted.jsonl"] = line_bytes(events)
    # Error messages and tracebacks can contain endpoint arguments or ports.
    summary = {"trial": outcome["trial"], "controller_status": "failed", "clean_controller_completion": False,
               "error_type": categories[-1] if categories else "unclassified",
               "last_controller_event": events[-1]["event"] if events else None,
               "failure_log_sha256": digest(text.encode()), "viewer_motion_gate_met": None}
    return summary, evidence, []


def run(args):
    batch = args.batch.resolve(strict=True)
    fixture = batch.parent
    if args.publish:
        terminal = controller_terminal(args.controller_pid, fixture / "dual_browser.py")
    manifest = from_json(batch / "manifest.json")
    fixtures, script_digests, members = verified_fixtures(fixture, args.original_fixture)
    require(manifest == {"workload": fixtures, "requested_trials": TRIALS, "diagnostic_batch": False,
                         "requested_fps": FPS, "dimensions": DIMENSIONS, "warm_seconds": WARM,
                         "score_seconds": SCORE, "telemetry_tail_seconds": TAIL,
                         "transport": "loopback-only OpenSSH -R",
                         "source": "Mint Firefox source and original X11 capture policy",
                         "target": "owned Ubuntu X11 viewer, JPEG at 1:1"}, "unexpected controlled scoring manifest")
    replay = load_replay(fixture)
    outcomes = from_json(batch / "outcomes.json")
    require([item["trial"] for item in outcomes] == list(range(1, len(outcomes) + 1)),
            "outcomes are missing or out of attempt order")
    if args.publish:
        require(len(outcomes) == TRIALS, "controller did not record all three terminal outcomes")
    summaries, sensitive = [], []
    for item in outcomes:
        label = f"trial-{item['trial']:02}"
        trial = batch / label
        require(item["status"] in ("completed", "failed"), f"{label} does not have terminal status")
        summary, files, private = (
            summarize_completed(trial, item, replay) if item["status"] == "completed" else summarize_failed(trial, item)
        )
        sensitive.extend(private)
        files["validated-attempt.json"] = json_bytes(summary)
        members.update({f"{label}/{name}": value for name, value in files.items()})
        summaries.append(summary)
        print(json.dumps({"trial": label, "status": item["status"],
                          "viewer_fps": summary.get("viewer", {}).get("motion", {}).get("raster", {}).get("unique_content_fps"),
                          "viewer_motion_gate_met": summary["viewer_motion_gate_met"]}))
    if not args.publish:
        return
    completed = [item for item in summaries if item["controller_status"] == "completed"]
    sessions = {item["authenticated_session_id"] for item in completed}
    require(len(sessions) == len(completed), "completed trials reused an authenticated session identity")
    for role in ROLES:
        for key in ("hostname_sha256", "boot_id_sha256", "release_sha256"):
            require(len({item["identities"][role][key] for item in completed}) <= 1,
                    f"{role} machine, boot or release changed within the repeated lane")
    passing = sum(item["viewer_motion_gate_met"] is True for item in summaries)
    report = {
        "manifest": manifest,
        "controller_terminal_state": terminal,
        "scope": "Real Firefox software raster on a Mint Xvfb source, production X11 JPEG viewer on Ubuntu Xvfb over loopback-only OpenSSH reverse forwarding.",
        "clock_policy": "Each endpoint used its own CLOCK_MONOTONIC for samples and telemetry selection. Elapsed times never subtract clocks across machines.",
        "measurement_limits": ["Raster changes in two Xvfb drawables", "No physical scanout measurement", "No input-to-photon measurement"],
        "gate": {"source_minimum_unique_fps": FPS, "viewer_minimum_unique_fps": 0.9 * FPS,
                 "minimum_independent_scroll_changes": SCORE, "requested_attempts": TRIALS,
                 "completed_attempts": len(completed), "passing_attempts": passing,
                 "all_attempts_passed": passing == TRIALS},
        "trials": summaries, "fixture_script_sha256": script_digests,
        "firefox_fixture_preferences_sha256": digest((fixture / "firefox-profile-user.js").read_bytes()),
    }
    members["run-manifest.json"] = json_bytes(manifest)
    members["validated-batch.json"] = json_bytes(report)
    for name, data in members.items():
        for pattern in (rb"-----BEGIN [A-Z ]*PRIVATE KEY-----", rb'"(?:boot_id|local_port|remote_port|private_key)"\s*:'):
            require(not re.search(pattern, data), f"{name} contains a disallowed sensitive field")
        if not name.startswith("fixtures/"):
            for value in sensitive:
                require(value not in data, f"{name} contains a live endpoint identifier")
    args.publish.mkdir(exist_ok=True, parents=True)
    destination = args.publish.resolve(strict=True)
    require(all(not (destination / name).exists() for name in (JSON_REPORT, RAW_ARCHIVE)),
            "publication already exists")
    with tempfile.TemporaryDirectory(prefix=".firefox-publish.", dir=destination) as temp:
        work = Path(temp)
        archive = work / RAW_ARCHIVE
        with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as stream:
            for name, data in sorted(members.items()):
                stream.writestr(name, data)
        with zipfile.ZipFile(archive) as stream:
            require(stream.testzip() is None
                    and all(stream.read(name) == data for name, data in members.items()), "ZIP validation failed")
        report["archive"] = {"file": RAW_ARCHIVE, "sha256": digest(archive.read_bytes()),
                             "members_sha256": {name: digest(data) for name, data in sorted(members.items())}}
        (work / JSON_REPORT).write_bytes(json_bytes(report))
        archive.replace(destination / RAW_ARCHIVE)
        (work / JSON_REPORT).replace(destination / JSON_REPORT)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--batch", required=True, type=Path)
    parser.add_argument("--original-fixture", required=True, type=Path)
    parser.add_argument("--controller-pid", type=int)
    parser.add_argument("--publish", type=Path)
    args = parser.parse_args()
    if args.publish and not args.controller_pid:
        parser.error("--publish requires --controller-pid")
    run(args)


if __name__ == "__main__":
    main()
