#!/usr/bin/env python3
"""Replay the isolated Firefox dialog observations from PPM and JSON traces."""
from collections import defaultdict
from itertools import groupby
import json
from pathlib import Path
import statistics
import sys

CENTER = (192, 44)
CONTEXT = (544, 168)
SCREEN = (960, 640)
SIDES = ('source', 'viewer')


def load(path):
    return json.loads(path.read_text())


def ppm(path, size):
    data = path.read_bytes()
    width, height = size
    header = f'P6\n{width} {height}\n255\n'.encode()
    if not data.startswith(header) or len(data) != len(header) + width * height * 3:
        raise ValueError(f'invalid raster geometry: {path.name}')
    return data[len(header):]


def button_runs(image, scan_y):
    width, _ = SCREEN
    row_start = scan_y * width * 3
    row = image[row_start:row_start + width * 3]
    pixels = zip(row[0::3], row[1::3], row[2::3])
    mask = (min(rgb) >= 210 and max(rgb) - min(rgb) <= 8 for rgb in pixels)
    spans = []
    for selected, group in groupby(enumerate(mask), key=lambda x: x[1]):
        if selected:
            positions = [i for i, _ in group]
            if len(positions) >= 30:
                spans.append([positions[0], positions[-1]])
    return spans


def measure_raster(image, reference):
    white = dark = changed = count = 0
    width, height = CENTER
    for y in range(0, height, 2):
        for x in range(0, width, 2):
            i = (y * width + x) * 3
            rgb = image[i:i+3]
            white += min(rgb) >= 215
            dark += max(rgb) <= 120
            changed += any(abs(a - b) > 18 for a, b in zip(rgb, reference[i:i+3]))
            count += 1
    fractions = {'bright_fraction': white / count, 'dark_pixels': dark,
                 'changed_fraction_from_closed': changed / count, 'sampled_pixels': count}
    return classify(fractions), fractions


def classify(metrics):
    if metrics['bright_fraction'] >= .56 and metrics['dark_pixels'] >= 8 and metrics['changed_fraction_from_closed'] >= .4:
        return 'open'
    return 'closed' if metrics['changed_fraction_from_closed'] <= .04 else 'transition'


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def replay(trace):
    result = load(trace / 'result.json')
    assert result['dimensions'] == list(SCREEN) and result['cycles_completed'] == 3
    button = load(trace / 'button-placement.json')
    source_image = ppm(trace / 'source-initial.ppm', SCREEN)
    ppm(trace / 'viewer-initial.ppm', SCREEN)
    scan = button['header_top'] + 18
    spans = button_runs(source_image, scan)
    require(scan == button['scan_y'] and spans == button['observed_grayscale_runs']
            and spans[:2] == [[13, 207], [219, 320]], 'source header button spans do not replay')
    click = [sum(spans[1]) // 2, scan]
    require(result['open_button_click'] == click, 'unexpected modal click location')
    references = {side: ppm(trace / f'{side}-closed-reference.ppm', CENTER) for side in SIDES}
    reads = defaultdict(list)
    count_rows = 0
    for line in (trace / 'center-reads.jsonl').read_text().splitlines():
        row = json.loads(line)
        require(row['read_start_monotonic_ns'] <= row['read_end_monotonic_ns'], 'reversed raster read interval')
        require(row['observed_state'] == classify(row), 'logged classification differs from the raster thresholds')
        reads[row.pop('phase'), row['side']].append(row)
        count_rows += 1
    replayed = []
    preceding_exit = 0
    for cycle in range(1, 4):
        for target in ('open', 'closed'):
            phase = f'cycle-{cycle:02}-{target}'
            transition = load(trace / f'{phase}.json')
            require(transition == result['transitions'][len(replayed)] and transition['target'] == target,
                    f'{phase}: result and transition record differ')
            action = (['mousemove', *map(str, click), 'click', '--delay', '0', '1'] if target == 'open'
                      else ['key', '--delay', '0', 'Escape'])
            require(transition['action'] == action, f'{phase}: unexpected source input command')
            launched, spawned, exited = (transition[f'xdotool_{k}_monotonic_ns'] for k in ('launch', 'spawned', 'exit_observed'))
            require(preceding_exit <= launched <= spawned <= exited <= launched + 5_000_000_000,
                    f'{phase}: invalid input timing bounds')
            preceding_exit = exited
            endpoints = {}
            for side in SIDES:
                rows = reads.pop((phase, side))
                require(all(spawned <= row['read_start_monotonic_ns'] <= row['read_end_monotonic_ns'] for row in rows)
                        and all(a['read_end_monotonic_ns'] <= b['read_start_monotonic_ns'] for a, b in zip(rows, rows[1:])),
                        f'{phase} {side}: non-monotonic observations')
                matched = next(i for i, (a, b) in enumerate(zip(rows, rows[1:]))
                               if a['observed_state'] == target and b['observed_state'] == target)
                first, second = rows[matched:matched+2]
                record = transition['observations'][side]
                prior = record['previous_nonmatching_observation']
                require(first == record['first_matching_observation'] and second == record['second_matching_observation'],
                        f'{phase} {side}: first consecutive matches differ')
                require(prior['observed_state'] != target and prior['read_end_monotonic_ns'] <= first['read_start_monotonic_ns']
                        and (prior == rows[matched-1] if matched else prior['read_end_monotonic_ns'] <= launched),
                        f'{phase} {side}: preceding observation does not bracket change')
                raster = {}
                for capture in ('before', 'first', 'last'):
                    observed, measures = measure_raster(ppm(trace / f'{phase}-{side}-{capture}.ppm', CENTER), references[side])
                    expected = ('closed' if target == 'open' else 'open') if capture == 'before' else target
                    require(observed == expected, f'{phase} {side} {capture}: preserved pixels do not show {expected}')
                    raster[capture] = {'state': observed, **measures}
                require(all(first[key] == value for key, value in raster['first'].items() if key != 'state'),
                        f'{phase} {side}: first PPM measures differ from sampled trace')
                context = ppm(trace / f'{phase}-{side}-dialog-area.ppm', CONTEXT)
                w, _ = CONTEXT
                center_x = result['scored_roi'][0] - result['dialog_context_roi'][0]
                center_y = result['scored_roi'][1] - result['dialog_context_roi'][1]
                projected_center = b''.join(context[(row * w + center_x) * 3:(row * w + center_x + CENTER[0]) * 3]
                                            for row in range(center_y, center_y + CENTER[1]))
                require(measure_raster(projected_center, references[side])[0] == target,
                        f'{phase} {side}: surrounding raster no longer shows {target}')
                delta = (first['read_end_monotonic_ns'] - launched) / 1e6
                require(delta == record['xdotool_launch_to_first_observation_ms'], f'{phase} {side}: launch delta differs')
                endpoints[side] = {'first_end_monotonic_ns': first['read_end_monotonic_ns'], 'launch_to_first_ms': delta,
                                   'previous_end_monotonic_ns': prior['read_end_monotonic_ns'], 'raster': raster}
            delta = (endpoints['viewer']['first_end_monotonic_ns'] - endpoints['source']['first_end_monotonic_ns']) / 1e6
            require(delta == transition['viewer_minus_source_first_observations_ms'], f'{phase}: pair timing differs')
            replayed.append({'phase': phase, 'cycle': cycle, 'target': target,
                             'viewer_minus_source_observations_ms': delta, 'endpoints': endpoints})
    require(not reads, 'unexpected trace reads remain')
    bounds = {}
    for state in ('open', 'closed'):
        values = [p['viewer_minus_source_observations_ms'] for p in replayed if p['target'] == state]
        bounds[state] = {'samples': len(values), 'min_ms': min(values), 'median_ms': statistics.median(values), 'max_ms': max(values)}
    return {'observations': count_rows, 'button_spans': spans, 'click': click, 'transitions': replayed,
            'viewer_minus_source_observations_ms': bounds}


if __name__ == '__main__':
    print(json.dumps(replay(Path(sys.argv[1])), indent=2))
