"""Raster helpers copied from the isolated Firefox calibration."""
from contextlib import suppress
import ctypes as C
import hashlib
import os
import re
import signal
import subprocess
from processes import wait_for


class Image(C.Structure):
    _fields_ = [(name, C.c_int) for name in ('width', 'height', 'xoffset', 'format')]
    _fields_ += [('data', C.c_void_p)]
    _fields_ += [(name, C.c_int) for name in (
        'byte_order', 'bitmap_unit', 'bitmap_bit_order', 'bitmap_pad', 'depth',
        'bytes_per_line', 'bits_per_pixel')]
    _fields_ += [(name, C.c_ulong) for name in ('red_mask', 'green_mask', 'blue_mask')]


class Pixels:
    def __init__(self, display):
        self.xlib = C.CDLL('libX11.so.6')
        for name, inputs, result in (
            ('XOpenDisplay', [C.c_char_p], C.c_void_p),
            ('XCloseDisplay', [C.c_void_p], C.c_int),
            ('XDefaultRootWindow', [C.c_void_p], C.c_ulong),
            ('XGetImage', [C.c_void_p, C.c_ulong, C.c_int, C.c_int, C.c_uint,
                           C.c_uint, C.c_ulong, C.c_int], C.POINTER(Image)),
            ('XDestroyImage', [C.POINTER(Image)], C.c_int),
        ):
            fn = getattr(self.xlib, name)
            fn.argtypes, fn.restype = inputs, result
        self.display = self.xlib.XOpenDisplay(display.encode())
        if not self.display:
            raise RuntimeError(f'could not open owned X display {display}')
        self.root = self.xlib.XDefaultRootWindow(self.display)

    def close(self):
        self.xlib.XCloseDisplay(self.display)

    def crop(self, xid, x, y, width, height):
        ptr = self.xlib.XGetImage(self.display, xid, x, y, width, height, C.c_ulong(-1), 2)
        if not ptr:
            raise RuntimeError('owned drawable did not return pixels')
        try:
            info = ptr.contents
            layout = (info.width, info.height, info.byte_order, info.bits_per_pixel,
                      info.red_mask, info.green_mask, info.blue_mask)
            if layout != (width, height, 0, 32, 0xff0000, 0xff00, 0xff):
                raise RuntimeError(f'unexpected owned Xvfb pixel format {layout}')
            packed = C.string_at(info.data, info.bytes_per_line * height)
            return tuple(packed[y:y + width * 4]
                         for y in range(0, len(packed), info.bytes_per_line))
        finally:
            self.xlib.XDestroyImage(ptr)


def tile_span(pixels):
    cyan = [i for i, (b, g, r) in enumerate(zip(pixels[0::4], pixels[1::4], pixels[2::4]))
            if r < 100 and g - r >= 70 and b - r >= 100]
    if not 51 <= len(cyan) <= 75 or not 56 <= cyan[-1] - cyan[0] + 1 <= 72:
        return None
    return cyan[1] - 1


def find_static_page(rows):
    # Locate the complete painted CSS tile in the captured drawable. The
    # browser viewport and its rendering child determine where it lands.
    last_x = None
    start = 0
    for y, row in enumerate((*rows, b'')):
        x = tile_span(row)
        if x == last_x:
            continue
        if last_x is not None and 56 <= y - start <= 72 and start >= 32:
            header_end = start - 8
            header_top = header_end
            header_bgr = bytes((0x20, 0x18, 0x10))
            while header_top and rows[header_top - 1][16:19] == header_bgr:
                header_top -= 1
            if header_end - header_top > 45:
                return last_x, start, header_top
        start, last_x = y, x
    return None


def write_capture(path, rows):
    with path.open('wb') as image:
        image.write(f'P6\n{len(rows[0]) // 4} {len(rows)}\n255\n'.encode())
        for row in rows:
            rgb = bytearray(len(row) // 4 * 3)
            rgb[0::3], rgb[1::3], rgb[2::3] = row[2::4], row[1::4], row[0::4]
            image.write(rgb)


def sample(pixels, xid, width, top):
    rows = pixels.crop(xid, 0, top + 28, width, 3)
    positions = sorted(pos for row in rows if (pos := tile_span(row)) is not None)
    x = positions[len(positions) // 2] if len(positions) >= 2 else None
    text = pixels.crop(xid, 0, top + 76, 33, 32)
    mask = bytes(g > 137 for row in text for g in row[1::4])
    signature = hashlib.blake2s(mask, digest_size=8).hexdigest() if sum(mask) >= 10 else None
    return x, signature


def wait_for_window(process, display, title, env, tree_log, seconds, geometry=None):
    pattern = rf'^ +(0x[0-9a-f]+) "[^"\n]*{re.escape(title)}[^"\n]*":'
    if geometry is not None:
        size = f'{geometry[0]}x{geometry[1]}+0+0'
        pattern += rf' [^\n]* {re.escape(size)}(?= |$)'
    tree = ''

    def inspect():
        nonlocal tree
        tree = subprocess.check_output(['xwininfo', '-display', display, '-root', '-tree'],
                                       env=env, text=True, timeout=4)
        matches = re.findall(pattern, tree, re.MULTILINE | re.IGNORECASE)
        if len(matches) > 1:
            raise RuntimeError(f'more than one owned drawable for {title!r}')
        return int(matches[0], 16) if matches else None

    try:
        return wait_for(process, inspect, seconds)
    finally:
        tree_log.write_text(tree)


def stop_group(process):
    with suppress(ProcessLookupError):
        os.killpg(process.pid, signal.SIGTERM)
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        with suppress(ProcessLookupError):
            os.killpg(process.pid, signal.SIGKILL)
        process.wait(timeout=5)
    with suppress(ProcessLookupError):
        os.killpg(process.pid, signal.SIGKILL)
