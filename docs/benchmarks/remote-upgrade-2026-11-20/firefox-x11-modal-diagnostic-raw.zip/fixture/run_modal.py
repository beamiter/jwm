#!/usr/bin/env python3
"""Exercise the original offline Firefox dialog on owned local Xvfb displays."""
import argparse
from contextlib import ExitStack
import fcntl
import hashlib
from itertools import groupby
import json
from pathlib import Path
import re
import subprocess
import tempfile
import time
import traceback

from processes import clean_env, get_display, start_display, stop, wait_for
from x11_pixels import (Pixels, find_static_page, sample, stop_group,
                        wait_for_window, write_capture)

HERE = Path(__file__).resolve().parent
RELEASE = '/tmp/jwm-p08-p09-release/jwm-remote'
HTML = HERE / 'browser.html'
FIXTURE_SHA256 = '13733ff044b7a86fd6b6033200bc51fafbba869cdabb8d6c8e3bfcdaaf387cbd'
WIDTH, HEIGHT = 960, 640
CENTER = (384, 298, 192, 44)
WIDE = (208, 236, 544, 168)
SECOND = 1_000_000_000
POLL_HZ = 100


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def neutral_spans(row):
    eligible = [min(b, g, r) >= 210 and max(b, g, r) - min(b, g, r) <= 8
                for b, g, r in zip(row[0::4], row[1::4], row[2::4])]
    runs = ([x for x, _ in run] for bright, run in groupby(enumerate(eligible), lambda item: item[1]) if bright)
    return [(run[0], run[-1]) for run in runs if len(run) >= 30]


def center_state(rows, reference):
    # Sample across the center ROI in the same raw image; the retained PPM
    # includes all pixels, including antialiased text that separates the pane.
    count = bright = dark = changed = 0
    for at in range(0, len(rows), 2):
        row, base = rows[at], reference[at]
        for pos in range(0, len(row), 8):
            b, g, r = row[pos:pos + 3]
            count += 1
            bright += b >= 215 and g >= 215 and r >= 215
            dark += b <= 120 and g <= 120 and r <= 120
            changed += max(abs(b - base[pos]), abs(g - base[pos + 1]), abs(r - base[pos + 2])) > 18
    fractions = {'bright_fraction': bright / count, 'dark_pixels': dark,
                 'changed_fraction_from_closed': changed / count, 'sampled_pixels': count}
    if bright / count >= .56 and dark >= 8 and changed / count >= .4:
        label = 'open'
    elif changed / count <= .04:
        label = 'closed'
    else:
        label = 'transition'
    return label, fractions


def observe(lanes, reference):
    for side, (pixels, xid) in lanes.items():
        begin = time.monotonic_ns()
        rows = pixels.crop(xid, *CENTER)
        stamp = time.monotonic_ns()
        label, metrics = center_state(rows, reference[side])
        yield side, rows, {'side': side, 'read_start_monotonic_ns': begin,
                           'read_end_monotonic_ns': stamp, 'observed_state': label, **metrics}


def transition(directory, cycle, target, button, lanes, reference, input_env, event_log):
    phase = f'cycle-{cycle:02}-{target}'
    ongoing = 'closed' if target == 'open' else 'open'
    before_action = {}
    for side, rows, event in observe(lanes, reference):
        write_capture(directory / f'{phase}-{side}-before.ppm', rows)
        before_action[side] = event
    if any(event['observed_state'] != ongoing for event in before_action.values()):
        raise RuntimeError(f'{phase}: the preceding state is not still visible at both ends')
    words = (['mousemove', str(button[0]), str(button[1]), 'click', '--delay', '0', '1']
             if target == 'open' else ['key', '--delay', '0', 'Escape'])
    launch = time.monotonic_ns()
    with (directory / f'{phase}-xdotool.log').open('wb') as launch_log:
        action = subprocess.Popen(['xdotool', *words], env=input_env, stdin=subprocess.DEVNULL,
                                  stdout=subprocess.DEVNULL, stderr=launch_log)
        deadline = launch + 5 * SECOND
        spawned = time.monotonic_ns()
        previous_reads = dict(before_action)
        last_rows = {}
        pending = {}
        confirmed = {}
        action_exited = None
        slot = 0
        try:
            while time.monotonic_ns() < deadline:
                status = action.poll()
                if status is not None and action_exited is None:
                    action_exited = time.monotonic_ns()
                    if status:
                        raise RuntimeError(f'{phase}: xdotool exited with status {status}')
                for side, rows, event in observe(lanes, reference):
                    last_rows[side] = rows
                    print(json.dumps({'phase': phase, **event}, separators=(',', ':')),
                          file=event_log, flush=True)
                    if side in confirmed:
                        continue
                    if event['observed_state'] == target:
                        if side in pending:
                            first, pixels, prior = pending.pop(side)
                            confirmed[side] = {
                                'previous_nonmatching_observation': prior,
                                'first_matching_observation': first,
                                'second_matching_observation': event,
                                'xdotool_launch_to_first_observation_ms': (first['read_end_monotonic_ns'] - launch) / 1e6,
                            }
                            write_capture(directory / f'{phase}-{side}-first.ppm', pixels)
                        else:
                            pending[side] = (event, rows, previous_reads[side])
                    else:
                        previous_reads[side] = event
                        pending.pop(side, None)
                if len(confirmed) == len(lanes) and action_exited is not None:
                    break
                slot = max(slot + 1, (time.monotonic_ns() - spawned) * POLL_HZ // SECOND + 1)
                due = min(deadline, spawned + slot * SECOND // POLL_HZ)
                time.sleep(max(0, (due - time.monotonic_ns()) / SECOND))
        finally:
            stop(action)
            for side, rows in last_rows.items():
                write_capture(directory / f'{phase}-{side}-last.ppm', rows)
            status = {'phase': phase, 'target': target, 'action': words,
                      'xdotool_launch_monotonic_ns': launch, 'xdotool_spawned_monotonic_ns': spawned,
                      'xdotool_exit_observed_monotonic_ns': action_exited, 'observations': confirmed}
            if len(confirmed) == len(lanes):
                status['viewer_minus_source_first_observations_ms'] = (
                    confirmed['viewer']['first_matching_observation']['read_end_monotonic_ns']
                    - confirmed['source']['first_matching_observation']['read_end_monotonic_ns']) / 1e6
            write_json(directory / f'{phase}.json', status)
        if len(confirmed) != len(lanes) or action_exited is None:
            raise RuntimeError(f'{phase}: missing xdotool completion or painted state at source/viewer')
    for side, (pixels, xid) in lanes.items():
        write_capture(directory / f'{phase}-{side}-dialog-area.ppm', pixels.crop(xid, *WIDE))
    return status


def verify_telemetry(directory):
    sessions = set()
    reports = {}
    for role in ('host', 'viewer'):
        parsed = [json.loads(line) for line in (directory / f'{role}.log').read_text().splitlines()
                  if line.startswith('{')]
        rows = [row for row in parsed if row.get('type') == f'jwm_remote_{role}_stats']
        key = 'last_sent_frame' if role == 'host' else 'last_frame'
        frames = [row[key] for row in rows if row.get(key)]
        if not rows or not frames or any(not row.get('session_id') for row in rows):
            raise RuntimeError(f'{role}: expected typed session records are missing')
        if any(frame.get('codec') != 'JPEG' or frame.get('source_dimensions') != [WIDTH, HEIGHT]
               or frame.get('encoded_dimensions') != [WIDTH, HEIGHT] for frame in frames):
            raise RuntimeError(f'{role}: scope differs from the 960×640 JPEG workload')
        if role == 'viewer' and any(row.get('negotiated_codec') != 'JPEG' or
                                    row.get('last_presentation_path') not in (None, 'rgb') for row in rows):
            raise RuntimeError('viewer media or presentation path changed')
        if role == 'host' and any(not row.get('mode', '').startswith('root/') for row in rows):
            raise RuntimeError('host did not capture the isolated X11 root')
        role_id = {row['session_id'] for row in rows}
        sessions.update(role_id)
        reports[role] = {'rows': len(rows), 'last_scoped_sequence': frames[-1]['sequence'],
                         'routes': sorted({row.get('mode' if role == 'host' else 'last_presentation_path')
                                           for row in rows} - {None})}
    if len(sessions) != 1:
        raise RuntimeError('host and viewer did not retain one authenticated session')
    return {'session_id': next(iter(sessions)), **reports}


def run(args, directory):
    profile, runtime = directory / 'firefox-profile', directory / 'runtime'
    profile.mkdir(mode=0o700)
    runtime.mkdir(mode=0o700)
    preferences = (HERE / 'firefox-profile-user.js').read_bytes()
    if b'user_pref("datareporting.policy.dataSubmissionEnabled", false);' not in preferences:
        raise RuntimeError('required isolated Firefox test profile policy is absent')
    (profile / 'user.js').write_bytes(preferences)
    env = clean_env()
    env.update(XDG_RUNTIME_DIR=str(runtime), XDG_SESSION_TYPE='x11')
    size = f'{WIDTH}x{HEIGHT}'
    with ExitStack() as stack:
        def log(name):
            return stack.enter_context((directory / name).open('wb'))

        displays = []
        for side in ('source', 'viewer'):
            x11 = start_display(WIDTH, HEIGHT, log(f'{side}-xvfb.log'))
            stack.callback(stop, x11)
            displays.append(get_display(x11))
        source_display, viewer_display = displays
        source_env = dict(env, DISPLAY=source_display)
        firefox_env = dict(source_env, GDK_BACKEND='x11', MOZ_NO_REMOTE='1', MOZ_ENABLE_WAYLAND='0',
                           LIBGL_ALWAYS_SOFTWARE='1', XDG_CACHE_HOME=str(profile / 'cache'),
                           XDG_CONFIG_HOME=str(profile / 'config'))
        firefox_env.pop('MOZ_HEADLESS', None)
        firefox = subprocess.Popen(['dbus-run-session', '--', args.firefox, '--new-instance', '--profile',
                                     str(profile), '--kiosk', HTML.as_uri()], env=firefox_env,
                                    stdout=subprocess.DEVNULL, stderr=log('firefox.log'), start_new_session=True)
        stack.callback(stop_group, firefox)
        title = 'JWM remote browser workload (offline)'
        source_id = wait_for_window(firefox, source_display, title, env, directory / 'source-window.log', 25)
        subprocess.run(['xdotool', 'windowmove', str(source_id), '0', '0', 'windowsize', str(source_id),
                        str(WIDTH), str(HEIGHT)], env=source_env, check=True, timeout=5)
        placed = wait_for_window(firefox, source_display, title, env, directory / 'source-positioned.log', 10,
                                 (WIDTH, HEIGHT))
        if source_id != placed:
            raise RuntimeError('Firefox replaced the window during geometry setup')
        subprocess.run(['xdotool', 'windowfocus', '--sync', str(source_id)], env=source_env, check=True, timeout=5)
        source_pixels = Pixels(source_display)
        stack.callback(source_pixels.close)
        source_rows = ()

        def page_ready():
            nonlocal source_rows
            source_rows = source_pixels.crop(source_pixels.root, 0, 0, WIDTH, HEIGHT)
            return find_static_page(source_rows)

        try:
            origin, tile_y, header_y = wait_for(firefox, page_ready, 10)
        finally:
            if source_rows:
                write_capture(directory / 'source-initial.ppm', source_rows)
        click_y = header_y + 18
        spans = neutral_spans(source_rows[click_y])
        write_json(directory / 'button-placement.json', {'header_top': header_y, 'scan_y': click_y,
                                                        'observed_grayscale_runs': spans})
        if spans[:2] != [(13, 207), (219, 320)]:
            raise RuntimeError(f'expected source page button shapes were absent at y={click_y}: {spans}')
        button = ((spans[1][0] + spans[1][1]) // 2, click_y)
        key = directory / 'key'
        stack.callback(key.unlink, missing_ok=True)
        subprocess.run([args.release, 'keygen', '--output', str(key)], env=env, stdout=subprocess.DEVNULL,
                       stderr=log('keygen.log'), check=True, timeout=8)
        host = subprocess.Popen([args.release, 'host', '--display', source_display, '--capture-source', 'root',
                                 '--scaling', 'auto', '--once', '--listen', '127.0.0.1:0', '--key-file', str(key),
                                 '--stats-json', '--fps', '30', '--jpeg-quality', '85', '--fixed-jpeg-quality'],
                                env=env, stdout=subprocess.DEVNULL, stderr=log('host.log'))
        stack.callback(stop, host)
        host_path = directory / 'host.log'

        def listening():
            match = re.search(r'listening on (127\.0\.0\.1:[0-9]+)', host_path.read_text())
            return match.group(1) if match else None

        address = wait_for(host, listening)
        viewer_args = [args.release, 'connect', address, '--display', viewer_display, '--view-only', '--jpeg',
                       '--window-size', size, '--window-position', '0,0', '--scaling', 'cpu', '--toggle',
                       '--stats-json', '--key-file', str(key)]
        viewer = subprocess.Popen(viewer_args, env=env, stdout=subprocess.DEVNULL, stderr=log('viewer.log'))
        stack.callback(stop, viewer)
        viewer_id = wait_for_window(viewer, viewer_display, f'{address} - JWM Remote', env,
                                    directory / 'viewer-window.log', 15, (WIDTH, HEIGHT))
        viewer_pixels = Pixels(viewer_display)
        stack.callback(viewer_pixels.close)

        def initial_viewer():
            tile, text = sample(viewer_pixels, viewer_id, WIDTH, tile_y)
            return tile if tile is not None and abs(tile - origin) <= 4 and text else None

        try:
            wait_for(viewer, initial_viewer)
        finally:
            write_capture(directory / 'viewer-initial.ppm', viewer_pixels.crop(viewer_id, 0, 0, WIDTH, HEIGHT))
        lanes = {'source': (source_pixels, source_pixels.root), 'viewer': (viewer_pixels, viewer_id)}
        reference = {side: pixels.crop(xid, *CENTER) for side, (pixels, xid) in lanes.items()}
        for side, rows in reference.items():
            write_capture(directory / f'{side}-closed-reference.ppm', rows)
            if center_state(rows, rows)[1]['bright_fraction'] > .25:
                raise RuntimeError(f'{side}: initial closed pane is too bright to classify safely')
        phases = []
        with (directory / 'center-reads.jsonl').open('w') as events:
            for cycle in range(1, 4):
                for target in ('open', 'closed'):
                    phases.append(transition(directory, cycle, target, button, lanes, reference, source_env, events))
                    time.sleep(.5)
        subprocess.run(viewer_args, env=env, stdout=subprocess.DEVNULL, stderr=log('disconnect.log'),
                       check=True, timeout=8)
        statuses = viewer.wait(timeout=10), host.wait(timeout=10)
        if any(statuses):
            raise RuntimeError(f'host/viewer did not exit successfully: {statuses}')
        firefox_ini = Path('/usr/lib/firefox/application.ini')
        if args.firefox == '/usr/bin/firefox' and firefox_ini.is_file():
            application_metadata = dict(re.findall(r'^(Version|BuildID)=(.+)$', firefox_ini.read_text(), re.MULTILINE))
        else:
            application_metadata = {}
        with open(args.release, 'rb') as binary:
            release_sha256 = hashlib.file_digest(binary, 'sha256').hexdigest()
        result = {'scope': 'local software X11 Firefox DOM dialog with private Xvfb source and viewer',
                  'fixture_sha256': FIXTURE_SHA256, 'original_html_unchanged': True,
                  'firefox_application_ini': application_metadata,
                  'software_webrender_seen': 'Renderer: Software WebRender' in (directory / 'firefox.log').read_text(),
                  'release_sha256': release_sha256,
                  'profile_extra_prefs': {'datareporting.policy.dataSubmissionEnabled': False},
                  'dimensions': [WIDTH, HEIGHT], 'codec': 'fixed JPEG 85', 'cycles_completed': 3,
                  'scored_roi': list(CENTER), 'dialog_context_roi': list(WIDE), 'open_button_click': list(button),
                  'observation_poll_hz_ceiling': POLL_HZ, 'timing_clock': 'local monotonic',
                  'telemetry': verify_telemetry(directory), 'transitions': phases}
        write_json(directory / 'result.json', result)
        print(json.dumps({'output': str(directory), 'cycles_completed': len(phases) // 2,
                          'viewer_minus_source_observations_ms': [x['viewer_minus_source_first_observations_ms'] for x in phases]}),
              flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--release', default=RELEASE)
    parser.add_argument('--firefox', default='/usr/bin/firefox')
    args = parser.parse_args()
    if hashlib.sha256(HTML.read_bytes()).hexdigest() != FIXTURE_SHA256:
        parser.error('browser modal page must match the original HTML exactly')
    args.release = str(Path(args.release).resolve(strict=True))
    args.firefox = str(Path(args.firefox).resolve(strict=True))
    with open('/tmp/jwm-p08-p09-release/benchmark.lock', 'a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        run_dir = Path(tempfile.mkdtemp(prefix='modal.', dir=HERE))
        print(f'Modal evidence: {run_dir}', flush=True)
        try:
            run(args, run_dir)
        except (OSError, RuntimeError, subprocess.SubprocessError, ValueError):
            (run_dir / 'failure.log').write_text(traceback.format_exc())
            raise
