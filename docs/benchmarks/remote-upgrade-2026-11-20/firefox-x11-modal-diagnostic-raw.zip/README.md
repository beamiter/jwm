# Isolated Firefox modal evidence

Run the offline verifier from the extracted archive with `python3 -B fixture/replay_modal.py trace`.
The trace includes one local, view-only 960x640 JPEG Q85 session and software
raster observations of three real DOM dialog opens and Escape closes. All PPMs
are the original raster bytes. A common monotonic origin was subtracted from
trace timestamps and the ephemeral authenticated session was assigned an alias.
The packaged preference template is fixture source for a fresh temporary profile.

For a new isolated run, invoke `python3 -B fixture/run_modal.py --release /absolute/path/to/jwm-remote`
after coordinating the shared benchmark lock. Firefox, Xvfb, xwininfo, xdotool,
dbus-run-session and libX11 must be available. The replay works offline.
