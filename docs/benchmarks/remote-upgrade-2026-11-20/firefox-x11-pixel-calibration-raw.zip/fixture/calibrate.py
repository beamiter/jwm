#!/usr/bin/env python3
"""Calibrate actual Firefox tile and scroll pixels on two owned Xvfb displays."""
import argparse
from contextlib import ExitStack, suppress
import ctypes as C
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import tempfile
import time

from processes import clean_env, get_display, start_display, stop, wait_for

HERE = Path(__file__).resolve().parent
RELEASE = Path('/tmp/jwm-p08-p09-release/jwm-remote')


class Image(C.Structure):
    _fields_ = [(name, C.c_int) for name in ('width', 'height', 'xoffset', 'format')]
    _fields_ += [('data', C.c_void_p)]
    _fields_ += [(name, C.c_int) for name in (
        'byte_order', 'bitmap_unit', 'bitmap_bit_order', 'bitmap_pad', 'depth',
        'bytes_per_line', 'bits_per_pixel')]
    _fields_ += [(name, C.c_ulong) for name in ('red_mask', 'green_mask', 'blue_mask')]


class Pixels:
    def __init__(self, display):
        self.xlib = C.CDLL('libX11.so.6')
        for name, inputs, result in (
            ('XOpenDisplay', [C.c_char_p], C.c_void_p),
            ('XCloseDisplay', [C.c_void_p], C.c_int),
            ('XDefaultRootWindow', [C.c_void_p], C.c_ulong),
            ('XGetImage', [C.c_void_p, C.c_ulong, C.c_int, C.c_int, C.c_uint,
                           C.c_uint, C.c_ulong, C.c_int], C.POINTER(Image)),
            ('XDestroyImage', [C.POINTER(Image)], C.c_int),
        ):
            fn = getattr(self.xlib, name)
            fn.argtypes, fn.restype = inputs, result
        self.display = self.xlib.XOpenDisplay(display.encode())
        if not self.display:
            raise RuntimeError(f'could not open owned X display {display}')
        self.root = self.xlib.XDefaultRootWindow(self.display)

    def close(self):
        self.xlib.XCloseDisplay(self.display)

    def crop(self, xid, x, y, width, height):
        ptr = self.xlib.XGetImage(self.display, xid, x, y, width, height, C.c_ulong(-1), 2)
        if not ptr:
            raise RuntimeError('owned drawable did not return pixels')
        try:
            info = ptr.contents
            layout = (info.width, info.height, info.byte_order, info.bits_per_pixel,
                      info.red_mask, info.green_mask, info.blue_mask)
            if layout != (width, height, 0, 32, 0xff0000, 0xff00, 0xff):
                raise RuntimeError(f'unexpected owned Xvfb pixel format {layout}')
            packed = C.string_at(info.data, info.bytes_per_line * height)
            return tuple(packed[y:y + width * 4]
                         for y in range(0, len(packed), info.bytes_per_line))
        finally:
            self.xlib.XDestroyImage(ptr)


def tile_span(pixels):
    cyan = [i for i, (b, g, r) in enumerate(zip(pixels[0::4], pixels[1::4], pixels[2::4]))
            if r < 100 and g - r >= 70 and b - r >= 100]
    if not 51 <= len(cyan) <= 75 or not 56 <= cyan[-1] - cyan[0] + 1 <= 72:
        return None
    return cyan[1] - 1


def find_static_page(rows):
    # Locate the complete painted CSS tile in the captured drawable. The
    # browser viewport and its rendering child determine where it lands.
    last_x = None
    start = 0
    for y, row in enumerate((*rows, b'')):
        x = tile_span(row)
        if x == last_x:
            continue
        if last_x is not None and 56 <= y - start <= 72 and start >= 32:
            header_end = start - 8
            header_top = header_end
            header_bgr = bytes((0x20, 0x18, 0x10))
            while header_top and rows[header_top - 1][16:19] == header_bgr:
                header_top -= 1
            if header_end - header_top > 45:
                return last_x, start, header_top
        start, last_x = y, x
    return None


def write_capture(path, rows):
    with path.open('wb') as image:
        image.write(f'P6\n{len(rows[0]) // 4} {len(rows)}\n255\n'.encode())
        for row in rows:
            rgb = bytearray(len(row) // 4 * 3)
            rgb[0::3], rgb[1::3], rgb[2::3] = row[2::4], row[1::4], row[0::4]
            image.write(rgb)


def sample(pixels, xid, width, top):
    rows = pixels.crop(xid, 0, top + 28, width, 3)
    positions = sorted(pos for row in rows if (pos := tile_span(row)) is not None)
    x = positions[len(positions) // 2] if len(positions) >= 2 else None
    text = pixels.crop(xid, 0, top + 76, 33, 32)
    mask = bytes(g > 137 for row in text for g in row[1::4])
    signature = hashlib.blake2s(mask, digest_size=8).hexdigest() if sum(mask) >= 10 else None
    return x, signature


def wait_for_window(process, display, title, env, tree_log, seconds, geometry=None):
    pattern = rf'^ +(0x[0-9a-f]+) "[^"\n]*{re.escape(title)}[^"\n]*":'
    if geometry is not None:
        size = f'{geometry[0]}x{geometry[1]}+0+0'
        pattern += rf' [^\n]* {re.escape(size)}(?= |$)'
    tree = ''

    def inspect():
        nonlocal tree
        tree = subprocess.check_output(['xwininfo', '-display', display, '-root', '-tree'],
                                       env=env, text=True, timeout=4)
        matches = re.findall(pattern, tree, re.MULTILINE | re.IGNORECASE)
        if len(matches) > 1:
            raise RuntimeError(f'more than one owned drawable for {title!r}')
        return int(matches[0], 16) if matches else None

    try:
        return wait_for(process, inspect, seconds)
    finally:
        tree_log.write_text(tree)


def stop_group(process):
    with suppress(ProcessLookupError):
        os.killpg(process.pid, signal.SIGTERM)
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        with suppress(ProcessLookupError):
            os.killpg(process.pid, signal.SIGKILL)
        process.wait(timeout=5)
    with suppress(ProcessLookupError):
        os.killpg(process.pid, signal.SIGKILL)


def summarize(rows, period):
    last = None
    accepted = []
    invalid = duplicates = 0
    for row in rows:
        current = row['tile_x']
        if current is None:
            invalid += 1
        elif last is None or 2 <= (current - last) % period <= period // 2:
            accepted.append(row['monotonic_ns'])
            last = current
        else:
            duplicates += 1
    gap_ms = [(after - before) / 1e6 for before, after in zip(accepted, accepted[1:])]
    return {'observed_changes': len(accepted), 'invalid_tile_reads': invalid,
            'duplicate_or_reverse_reads': duplicates,
            'distinct_scroll_signatures': len({row['scroll_text'] for row in rows if row['scroll_text']}),
            'max_internal_observed_gap_ms': max(gap_ms, default=None)}


def run(args):
    run_dir = Path(tempfile.mkdtemp(prefix='run.', dir=HERE))
    print(f'Calibration output: {run_dir}', flush=True)
    profile = run_dir / 'firefox-profile'
    runtime = run_dir / 'runtime'
    profile.mkdir(mode=0o700)
    runtime.mkdir(mode=0o700)
    (profile / 'user.js').write_text('''user_pref("browser.shell.checkDefaultBrowser", false);
user_pref("browser.startup.page", 0);
user_pref("browser.aboutwelcome.enabled", false);
user_pref("browser.newtabpage.enabled", false);
user_pref("gfx.webrender.software", true);
user_pref("network.proxy.type", 1);
user_pref("network.proxy.http", "127.0.0.1");
user_pref("network.proxy.http_port", 9);
user_pref("network.proxy.ssl", "127.0.0.1");
user_pref("network.proxy.ssl_port", 9);
''')
    env = clean_env()
    env.update(XDG_RUNTIME_DIR=str(runtime), XDG_SESSION_TYPE='x11')
    width, height = 960, 640
    size = f'{width}x{height}'
    with ExitStack() as cleanup:
        def log(name):
            return cleanup.enter_context((run_dir / name).open('wb'))

        displays = []
        for side in ('source', 'viewer'):
            display = start_display(width, height, log(f'{side}-xvfb.log'))
            cleanup.callback(stop, display)
            displays.append(get_display(display))
        source_display, viewer_display = displays
        firefox_env = dict(env, DISPLAY=source_display, GDK_BACKEND='x11',
                           MOZ_NO_REMOTE='1', MOZ_ENABLE_WAYLAND='0', LIBGL_ALWAYS_SOFTWARE='1',
                           XDG_CACHE_HOME=str(profile / 'cache'), XDG_CONFIG_HOME=str(profile / 'config'))
        firefox_env.pop('MOZ_HEADLESS', None)
        firefox = subprocess.Popen(
            ['dbus-run-session', '--', args.firefox, '--new-instance', '--profile', str(profile),
             '--kiosk', (HERE / 'browser.html').as_uri()], env=firefox_env,
            stdout=subprocess.DEVNULL, stderr=log('firefox.log'), start_new_session=True)
        cleanup.callback(stop_group, firefox)
        source_title = 'JWM remote browser workload (offline)'
        source_window = wait_for_window(firefox, source_display, source_title, env,
                                        run_dir / 'source-discovery-tree.log', 25)
        # Bare Xvfb has no window manager to apply Firefox's maximization
        # request. Size the owned XID directly, then verify its actual extent.
        subprocess.run(['xdotool', 'windowmove', str(source_window), '0', '0', 'windowsize',
                        str(source_window), str(width), str(height)],
                       env=dict(env, DISPLAY=source_display), check=True, timeout=5)
        placed_window = wait_for_window(firefox, source_display, source_title, env,
                                        run_dir / 'source-positioned-tree.log', 10, (width, height))
        if placed_window != source_window:
            raise RuntimeError('Firefox replaced the selected drawable while it was being sized')
        source_pixels = Pixels(source_display)
        cleanup.callback(source_pixels.close)
        source_rows = ()

        def inspect_page():
            nonlocal source_rows
            source_rows = source_pixels.crop(source_pixels.root, 0, 0, width, height)
            return find_static_page(source_rows)

        placement = None
        try:
            placement = wait_for(firefox, inspect_page, 10)
        finally:
            if source_rows:
                window_rows = source_pixels.crop(source_window, 0, 0, width, height)
                write_capture(run_dir / 'source-static-root.ppm', source_rows)
                write_capture(run_dir / 'source-static-window.ppm', window_rows)
                old_column_top = tile_span(b''.join(row[24 * 4:25 * 4] for row in window_rows))
                (run_dir / 'source-static.json').write_text(json.dumps({
                    'tile_x_y_and_header_top': placement,
                    'old_window_column_tile_top': old_column_top,
                    'root_and_window_active_pixels_equal': source_rows == window_rows,
                }, indent=2) + '\n')
        origin_x, top, header_top = placement
        if top < 50 or top + 108 >= height:
            raise RuntimeError(f'unexpected document tile location: y={top}')

        key = run_dir / 'key'
        cleanup.callback(key.unlink, missing_ok=True)
        subprocess.run([args.release, 'keygen', '--output', str(key)], env=env,
                       stdout=subprocess.DEVNULL, check=True, timeout=8)
        host_path = run_dir / 'host.log'
        host = subprocess.Popen(
            [args.release, 'host', '--display', source_display, '--capture-source', 'root',
             '--scaling', 'auto', '--once', '--listen', '127.0.0.1:0', '--key-file', str(key),
             '--stats-json', '--fps', '30', '--jpeg-quality', '85', '--fixed-jpeg-quality'],
            env=env, stdout=subprocess.DEVNULL, stderr=log('host.log'))
        cleanup.callback(stop, host)

        def find_address():
            match = re.search(r'listening on (127\.0\.0\.1:[0-9]+)', host_path.read_text())
            return match.group(1) if match else None

        address = wait_for(host, find_address)
        viewer_args = [args.release, 'connect', address, '--display', viewer_display,
                       '--window-size', size, '--window-position', '0,0', '--scaling', 'cpu',
                       '--view-only', '--jpeg', '--toggle', '--stats-json', '--key-file', str(key)]
        viewer = subprocess.Popen(viewer_args, env=env, stdout=subprocess.DEVNULL,
                                  stderr=log('viewer.log'))
        cleanup.callback(stop, viewer)
        viewer_window = wait_for_window(viewer, viewer_display, f'{address} - JWM Remote', env,
                                        run_dir / 'viewer-window-tree.log', 15, (width, height))
        viewer_pixels = Pixels(viewer_display)
        cleanup.callback(viewer_pixels.close)
        def initial_tile():
            x, text = sample(viewer_pixels, viewer_window, width, top)
            return x if x is not None and abs(x - origin_x) <= 4 and text else None
        try:
            wait_for(viewer, initial_tile)
        finally:
            write_capture(run_dir / 'viewer-static-window.ppm',
                          viewer_pixels.crop(viewer_window, 0, 0, width, height))
        initial_source = sample(source_pixels, source_pixels.root, width, top)
        initial_viewer = sample(viewer_pixels, viewer_window, width, top)
        subprocess.run(['xdotool', 'mousemove', '80', str(header_top + 30), 'click', '1', 'mousemove',
                        str(width - 5), str(height - 5)], env=dict(env, DISPLAY=source_display),
                       check=True, timeout=5)
        lanes = {'source': (source_pixels, source_pixels.root), 'viewer': (viewer_pixels, viewer_window)}
        samples = {name: [] for name in lanes}
        start = time.monotonic_ns()
        slot_ns = 1_000_000_000 // 90
        deadline = start + args.seconds * 1_000_000_000
        with (run_dir / 'pixels.jsonl').open('w') as observer:
            while time.monotonic_ns() < deadline:
                for name, (pixels, xid) in lanes.items():
                    tile, scroll = sample(pixels, xid, width, top)
                    row = {'side': name, 'monotonic_ns': time.monotonic_ns(),
                           'tile_x': tile, 'scroll_text': scroll}
                    samples[name].append(row)
                    print(json.dumps(row), file=observer)
                elapsed = time.monotonic_ns() - start
                time.sleep(max(0, (slot_ns - elapsed % slot_ns) / 1e9))
        end = time.monotonic_ns()
        subprocess.run(viewer_args, env=env, stdout=subprocess.DEVNULL,
                       stderr=log('disconnect.log'), timeout=8, check=True)
        if viewer.wait(timeout=10) or host.wait(timeout=10):
            raise RuntimeError('owned viewer or host failed to close')
        result = {name: summarize(rows, width - 64) for name, rows in samples.items()}
        result.update(scope='unscored single-machine software pixel calibration',
                      duration_s=(end - start) / 1e9, size=[width, height], tile_top=top,
                      initial_source=initial_source, initial_viewer=initial_viewer,
                      fixture_sha256=hashlib.sha256((HERE / 'browser.html').read_bytes()).hexdigest())
        (run_dir / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps(result), flush=True)
        if any(result[name]['observed_changes'] < 8 or result[name]['distinct_scroll_signatures'] < 3
               for name in lanes):
            raise RuntimeError('actual tile motion or scrolling was not independently visible at both ends')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--release', default=str(RELEASE))
    parser.add_argument('--firefox', default='/usr/bin/firefox')
    parser.add_argument('--seconds', type=int, default=8)
    args = parser.parse_args()
    if not 3 <= args.seconds <= 15:
        parser.error('duration must be within the unchanged page motion window (3–15 seconds)')
    run(args)
