#!/usr/bin/env python3
"""Deterministic xterm scroll with an in-band pixel sequence row."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time


FONT = '10x20'
CELL_WIDTH = 10
CELL_HEIGHT = 20
SIZE = (1920, 1080)
ROWS = SIZE[1] // CELL_HEIGHT
COLUMNS = SIZE[0] // CELL_WIDTH
SOURCE_FPS = 60
MOTION_SECONDS = 108
PREAMBLE = 0xb2
MARKER_WIDTH = 40 * CELL_WIDTH
GLYPH_WIDTH = 10 * CELL_WIDTH


def crc(data):
    result = 0
    for byte in data:
        result ^= byte
        for _ in range(8):
            result = ((result << 1) ^ (0x07 if result & 0x80 else 0)) & 0xff
    return result


def marker_bytes(case, sequence):
    payload = bytes((PREAMBLE, case)) + sequence.to_bytes(2, 'big')
    return payload + bytes((crc(payload),))


def marker_line(case, sequence):
    cells = ''.join(('\x1b[47m' if byte & bit else '\x1b[40m') + ' '
                    for byte in marker_bytes(case, sequence)
                    for bit in (128, 64, 32, 16, 8, 4, 2, 1))
    return '\x1b[1;1H' + cells + '\x1b[0m'


def glyph_line(sequence):
    palette = (
        'RGBC #ff1100  Il1| 0O Unicode 中文標點 αβγ fn render() { 123; }',
        'xyzw #00adee  IiÍl |1 O0 交易 清晰 中文 ドット θεδ { 789; }',
    )
    return f'{sequence:06d}  ' + palette[sequence % len(palette)] * 2


def decode_row(row, case):
    if len(row) != MARKER_WIDTH * 4:
        return None
    bits = []
    for cell in range(MARKER_WIDTH // CELL_WIDTH):
        # Use the middle three pixels of each glyph cell, well away from
        # block edges and JPEG color ringing.
        x = cell * CELL_WIDTH + CELL_WIDTH // 2
        columns = [row[i*4:i*4+3] for i in (x-1, x, x+1)]
        levels = [sum(pixel) / 3 for pixel in columns]
        if all(level >= 165 for level in levels):
            bits.append(1)
        elif all(level <= 70 for level in levels):
            bits.append(0)
        else:
            return None
    value = bytes(sum(bit << (7-offset) for offset, bit in enumerate(bits[start:start+8]))
                  for start in range(0, len(bits), 8))
    if value[:2] != bytes((PREAMBLE, case)) or value[-1] != crc(value[:-1]):
        return None
    return int.from_bytes(value[2:4], 'big')


def sample(pixels, xid, width, case):
    if width != SIZE[0]:
        raise ValueError('unexpected capture width')
    rows = pixels.crop(xid, 0, 8, MARKER_WIDTH, 3)
    markers = [decode_row(row, case) for row in rows]
    sequence = markers[1]
    if sequence is None or markers.count(sequence) < 2:
        sequence = None
    text = pixels.crop(xid, 0, CELL_HEIGHT, GLYPH_WIDTH, CELL_HEIGHT)
    mask = bytes(g > 137 for row in text for g in row[1::4])
    ink = sum(mask)
    digest = hashlib.blake2s(mask, digest_size=8).hexdigest() if 30 < ink < len(mask)//2 else None
    return sequence, digest


def write(text):
    sys.stdout.write(text)
    sys.stdout.flush()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('case', type=int, choices=range(256))
    parser.add_argument('motion_trigger', type=Path)
    parser.add_argument('observer', type=Path)
    args = parser.parse_args()
    if not sys.stdout.isatty():
        raise RuntimeError('the workload requires an actual terminal')
    size = os.get_terminal_size(sys.stdout.fileno())
    if (size.columns, size.lines) != (COLUMNS, ROWS):
        raise RuntimeError(f'expected {COLUMNS}x{ROWS} terminal cells, got {size}')
    with args.observer.open('w') as evidence:
        def event(**values):
            print(json.dumps({'time_ns': time.monotonic_ns(), **values}), file=evidence, flush=True)

        write('\x1b[?1049h\x1b[?25l\x1b[?7l\x1b[2J'
              + ''.join(f'\x1b[{row};1H'+glyph_line(row-1) for row in range(2, ROWS+1))
              + f'\x1b[2;{ROWS}r' + marker_line(args.case, 0))
        event(type='ready', cols=size.columns, rows=size.lines, marker=0)
        alarm = time.monotonic() + 150
        while not args.motion_trigger.is_file():
            if time.monotonic() >= alarm:
                raise RuntimeError('controller did not start the scroll workload')
            time.sleep(.01)
        begun = time.monotonic()
        for sequence in range(1, MOTION_SECONDS * SOURCE_FPS + 1):
            # Scroll into the existing text region and insert one new row.
            # The fixed marker row is sent in the same terminal write.
            write(f'\x1b[1S\x1b[{ROWS};1H\x1b[2K' + glyph_line(sequence + ROWS - 1)
                  + marker_line(args.case, sequence))
            if sequence == 1 or sequence % SOURCE_FPS == 0:
                event(type='scroll_progress', marker=sequence)
            time.sleep(max(0, begun + sequence / SOURCE_FPS - time.monotonic()))
        event(type='motion_complete', marker=MOTION_SECONDS * SOURCE_FPS)
        # The coordinator closes only its owned window after observations.
        time.sleep(20)
        write('\x1b[r\x1b[?7h\x1b[?25h\x1b[?1049l')


if __name__ == '__main__':
    main()
