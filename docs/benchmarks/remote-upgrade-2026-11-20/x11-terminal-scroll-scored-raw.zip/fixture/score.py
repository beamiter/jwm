"""Exact local monotonic phase scoring for observed browser raster content."""
import json
import math

SECOND = 1_000_000_000
WARM_SECONDS = 30
MEASURE_SECONDS = 60
TAIL_SECONDS = 8
REQUESTED_FPS = 30


def score_pixels(rows, start, end):
    bins = [0] * MEASURE_SECONDS
    text_bins = [0] * MEASURE_SECONDS
    newest_marker = last_text = None
    accepted = []
    text_changes = invalid_marker = invalid_text = reads = reordered = 0
    scroll_signatures = set()
    read_ns = []
    for row in rows:
        stamp = row['end_monotonic_ns']
        if stamp >= end:
            break
        measured = stamp >= start
        marker, scroll = row['marker'], row['scroll_signature']
        if measured:
            reads += 1
            read_ns.append(stamp - row['start_monotonic_ns'])
            invalid_marker += marker is None
            invalid_text += scroll is None
            if scroll is not None:
                scroll_signatures.add(scroll)
        # Keep warm-up references. Accept monotonically increasing markers.
        # Independently count glyph changes from the actual scroll region.
        marker_changed = marker is not None and newest_marker is not None and marker > newest_marker
        text_changed = scroll is not None and last_text is not None and scroll != last_text
        if measured:
            slot = (stamp - start) // SECOND
            if text_changed:
                text_changes += 1
                text_bins[slot] += 1
            if marker is not None and newest_marker is not None and marker < newest_marker:
                reordered += 1
            if marker_changed:
                bins[slot] += 1
                accepted.append(stamp)
        # Keep the newest valid marker and leave any holes unfilled.
        if marker_changed or newest_marker is None:
            newest_marker = marker
        if scroll is not None:
            last_text = scroll
    points = [start, *accepted, end]
    gaps = sorted((b - a) / 1e6 for a, b in zip(points, points[1:]))
    return {
        'unique_marker_changes': len(accepted),
        'unique_content_fps': len(accepted) / MEASURE_SECONDS,
        'one_second_unique_bins': bins,
        'zero_unique_bins': sum(value == 0 for value in bins),
        'scroll_changes_seen': text_changes,
        'one_second_scroll_bins': text_bins,
        'distinct_scroll_signatures': len(scroll_signatures),
        'valid_and_invalid_sample_reads': reads,
        'invalid_marker_reads': invalid_marker,
        'reordered_marker_reads': reordered,
        'invalid_scroll_reads': invalid_text,
        'observer_max_read_ms': max(read_ns, default=0) / 1e6,
        'gap_ms': {'p50': gaps[math.ceil(len(gaps) * .5) - 1],
                   'p95': gaps[math.ceil(len(gaps) * .95) - 1], 'max': gaps[-1]},
        'accepted_observations_monotonic_ns': accepted,
    }


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')
