"""Recompute the owned terminal benchmark from captured interval records."""

from collections import Counter
import hashlib
import json
from math import isclose
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile

from run_baseline import select_telemetry
from score import MEASURE_SECONDS, TAIL_SECONDS, WARM_SECONDS, score_pixels
from terminal_scroll import SIZE, sample


LAB = Path(__file__).resolve().parent
REPORT_NAME = 'x11-terminal-scroll-scored'
SECOND = 1_000_000_000
EXPECTED_HOST = '5e1951ed8bbc23f41db5b5918931d91a37baa1e9fa213c8ef9067a214a1511e5'
EXPECTED_VIEWER = 'aaa1ed44223181963b3463fb169d56c9a76b31a514f29915f7ad5d47002690a3'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(path.read_bytes())


def jsonl(path):
    return [json.loads(line) for line in path.read_bytes().splitlines()]


class Photo:
    """Use the original pixel classifier on an unmodified captured raster."""

    def __init__(self, path):
        header = f'P6\n{SIZE[0]} {SIZE[1]}\n255\n'.encode()
        payload = path.read_bytes()
        assert payload.startswith(header)
        self.rgb = payload[len(header):]
        assert len(self.rgb) == SIZE[0] * SIZE[1] * 3

    def crop(self, _xid, x, y, w, h):
        rows = []
        for scan in range(y, y+h):
            start = (scan * SIZE[0] + x) * 3
            row = self.rgb[start:start + w*3]
            raw = bytearray(w*4)
            raw[0::4], raw[1::4], raw[2::4] = row[2::3], row[1::3], row[0::3]
            rows.append(raw)
        return rows


def measure(phase, endpoint, actual, translated, run):
    raw = read_json(actual / f'{phase}-scope.json')
    begin, end = (raw[f'score_{part}_monotonic_ns'] for part in ('start', 'end'))
    assert begin - raw['phase_start_monotonic_ns'] == WARM_SECONDS * SECOND
    assert end - begin == MEASURE_SECONDS * SECOND
    assert raw['telemetry_phase_end_monotonic_ns'] - end == TAIL_SECONDS * SECOND
    assert raw['observer_end_monotonic_ns'] >= end
    samples = jsonl(actual / f'{phase}-pixels.jsonl')
    lane = 'source' if endpoint == 'host' else 'viewer'
    assert all(item['side'] == lane and item['start_monotonic_ns'] <= item['end_monotonic_ns']
               for item in samples)
    assert all(a['end_monotonic_ns'] <= b['start_monotonic_ns']
               for a, b in zip(samples, samples[1:]))
    observation = score_pixels(samples, begin, end)
    assert observation == raw['samples'][lane]
    telemetry = select_telemetry(translated, raw, endpoint, SIZE)
    exact = set(telemetry) - {'window_seconds'}
    assert all(telemetry[key] == raw['telemetry'][key] for key in exact)
    assert isclose(telemetry['window_seconds'], raw['telemetry']['window_seconds'])
    assert len(telemetry['session_ids']) == 1 and telemetry['frame_scopes_match_requested_jpeg']
    if phase == 'motion':
        assert telemetry['frame_scopes_observed'] > 0
    records = jsonl(translated / f'{phase}-{endpoint}.jsonl')
    observed_frame_field = 'last_sent_frame' if endpoint == 'host' else 'last_frame'
    for key in ('source_epoch', 'geometry_epoch'):
        values = sorted({row[observed_frame_field][key] for row in records if row.get(observed_frame_field)})
        run.add((key, tuple(values)))
    stages = ('capture_ms', 'jpeg_ms', 'socket_write_ms', 'send_to_ack_ms') if endpoint == 'host' else (
        'decode_ms', 'presentation_completion_ms'
    )
    for stage in stages:
        percentiles = [row['stages'][stage]['quantiles']['p95_ms'] for row in records
                       if row.get('stages', {}).get(stage, {}).get('quantiles', {}).get('samples')]
        telemetry.setdefault('max_recent_window_p95_ms', {})[stage] = max(percentiles) if percentiles else None
    if endpoint == 'host':
        telemetry['payload_mbit_per_second'] = sum(row['bytes'] for row in records)*8e-6/telemetry['window_seconds']
        telemetry['sampled_backpressure_skips'] = sum(row['backpressure_skipped'] for row in records)
    return observation, telemetry


def sanitized_identity(identity):
    keys = ('role', 'kernel', 'cpu', 'drawable_size', 'clock', 'release_sha256')
    result = {key: identity[key] for key in keys}
    result['boot_id_sha256'] = digest(identity['boot_id'].encode())
    if identity['role'] == 'host':
        result['xterm'] = {key: identity['xterm'][key] for key in ('sha256', 'version', 'font', 'grid')}
    return result


def archive_component(entries, run, name, paths):
    for path in paths:
        if (run / path).is_file():
            entries[name + '/' + path] = (run / path).read_bytes()


def verify_trial(batch, outcome, entries):
    name = f"trial-{outcome['trial']:02}"
    run = batch / name
    host_name, viewer_name = f'{name}/host', f'{name}/viewer'
    for endpoint, directory, member in (('host', run, host_name), ('viewer', run / 'viewer', viewer_name)):
        names = tuple(f'{phase}-{suffix}'
                      for phase in ('static', 'motion')
                      for suffix in ('scope.json', 'pixels.jsonl')) + (f'{endpoint}-clocked-telemetry.jsonl',)
        archive_component(entries, directory, member, names)
    archive_component(entries, run, host_name, ('terminal-progress.jsonl', 'source-static.ppm',
                                                  'source-static-end.ppm','source-motion-end.ppm'))
    archive_component(entries, run/'viewer', viewer_name, ('viewer-static.ppm','viewer-motion-end.ppm'))
    if outcome['status'] != 'completed':
        failures = {
            name: (run / name).read_text().splitlines()[-1][:256]
            for name in ('failure.log', 'artifact-fetch-failure.log') if (run / name).exists()
        }
        # Do not archive complete tracebacks or SSH logs from private paths.
        return {'trial': outcome['trial'], 'status': 'failed',
                'failure_types': [entry.partition(':')[0] for entry in failures.values()],
                'failure': outcome['error'].split(':', 1)[0]}

    ident = read_json(run / 'identity.json')
    endpoints = {role: sanitized_identity(ident[role]) for role in ('host', 'viewer')}
    assert endpoints['host']['boot_id_sha256'] != endpoints['viewer']['boot_id_sha256']
    assert endpoints['host']['release_sha256'] == EXPECTED_HOST
    assert endpoints['viewer']['release_sha256'] == EXPECTED_VIEWER
    assert all(info['drawable_size'] == list(SIZE) for info in endpoints.values())
    assert endpoints['host']['xterm']['grid'] == [192,54]
    entries[f'{name}/endpoints.json'] = (json.dumps(endpoints, indent=2)+'\n').encode()
    case = int(ident['run_id'][-2:], 16)
    phases = {}
    scopes = set()
    with TemporaryDirectory(prefix='jwm-terminal-replay.') as temp:
        isolated = Path(temp)
        for endpoint, seen in (('host',run), ('viewer',run/'viewer')):
            trace = f'{endpoint}-clocked-telemetry.jsonl'
            (isolated / trace).symlink_to((seen / trace).resolve())
            for phase in ('static','motion'):
                obs, stats = measure(phase, endpoint, seen, isolated, scopes)
                phases.setdefault(phase, {})[endpoint] = {'raster': obs, 'telemetry': stats}
    for field in ('source_epoch', 'geometry_epoch'):
        nonempty = {values for key, values in scopes if key == field and values}
        assert len(nonempty) == 1 and len(next(iter(nonempty))) == 1
    session_ids = {session for endpoints in phases.values() for phase in endpoints.values()
                   for session in phase['telemetry']['session_ids']}
    assert len(session_ids) == 1
    for directory, path in ((run,'source-static.ppm'),(run,'source-static-end.ppm'),
                            (run/'viewer','viewer-static.ppm')):
        sequence, glyphs = sample(Photo(directory/path),0,SIZE[0],case)
        assert sequence == 0 and glyphs
    photos = {}
    for endpoint, directory, path in (('host',run,'source-motion-end.ppm'),
                                     ('viewer',run/'viewer','viewer-motion-end.ppm')):
        sequence, glyphs = sample(Photo(directory/path),0,SIZE[0],case)
        photos[endpoint] = {'marker': sequence, 'glyph_signature': glyphs}
    raw = read_json(run/'result.json')
    events = jsonl(run/'peer-events.jsonl')
    assert [entry['event'] for entry in events] == [
        'viewer_ready','viewer_static_started','viewer_static_done',
        'viewer_motion_armed','viewer_motion_done','viewer_disconnected']
    assert all(event['run_id'] == ident['run_id'] for event in events)
    entries[f'{name}/control-events.json'] = (json.dumps(
        [{'event':entry['event'],'run_id':ident['run_id']} for entry in events],indent=2)+'\n').encode()
    for role in ('host','viewer'):
        stats = phases['motion'][role]['raster']
        assert stats['unique_content_fps'] == raw[f'{"source" if role=="host" else "viewer"}_motion_fps']
    return {'trial': outcome['trial'], 'status': 'completed', 'scope': outcome['result']['scope'],
            'endpoints': {role:sanitized_identity(ident[role]) for role in ('host','viewer')},
            'authenticated_session': session_ids.pop(), 'phases': phases,
            'motion_snapshot_evidence': photos,
            'static_unchanged': raw['static_unchanged'],
            'source_qualified': raw['source_qualified'],
            'telemetry_complete': raw['telemetry_complete'],
            'viewer_motion_gate_met': raw['viewer_motion_gate_met']}


def publish(batch, output):
    outcomes = read_json(batch/'outcomes.json')
    manifest = read_json(batch/'manifest.json')
    assert len(outcomes) == manifest['requested_trials'] == 3
    assert [outcome['trial'] for outcome in outcomes] == [1,2,3]
    entries = {}
    for filename, expected in manifest['workload']['files'].items():
        payload = (LAB / filename).read_bytes()
        assert digest(payload) == expected
        entries['fixture/'+filename] = payload
    entries['fixture/publish.py'] = Path(__file__).read_bytes()
    first = LAB/'dual.8g8xcy_n'
    setup = read_json(first/'outcomes.json')
    assert len(setup)==3 and all(row.get('error')=="name 'threading' is not defined" for row in setup)
    entries['failed-setup/outcomes.json'] = (first/'outcomes.json').read_bytes()
    entries['failed-setup/manifest.json'] = (first/'manifest.json').read_bytes()
    entries['trial-manifest.json'] = (batch/'manifest.json').read_bytes()
    trials = [verify_trial(batch,outcome,entries) for outcome in outcomes]
    valid = [trial for trial in trials if trial['status']=='completed']
    assert len({trial['authenticated_session'] for trial in valid}) == len(valid)
    archive = output/(REPORT_NAME+'-raw.zip')
    with ZipFile(archive,'w',compression=ZIP_DEFLATED,compresslevel=5) as bundle:
        for name,content in sorted(entries.items()):
            bundle.writestr(name,content)
    with ZipFile(archive) as bundle:
        assert bundle.testzip() is None
        assert set(bundle.namelist()) == set(entries)
        assert all(bundle.read(name)==item for name,item in entries.items())
    report = {'schema_version':1,
              'scope':'Real xterm scroll and glyph reads on owned X11 machines and an authenticated JPEG Q85 viewer.',
              'manifest':manifest,'trials':trials,'first_attempt_fixture_errors':setup,
              'summary':{'attempt_status_counts':dict(Counter(trial['status'] for trial in trials)),
                         'viewer_fps':[trial['phases']['motion']['viewer']['raster']['unique_content_fps']
                                       for trial in valid],
                         'gate_met_count':sum(trial['viewer_motion_gate_met'] is True for trial in valid)},
              'archive':{'path':archive.name,'sha256':digest(archive.read_bytes()),
                         'entries':{name:digest(data) for name,data in entries.items()}}}
    (output/(REPORT_NAME+'.json')).write_text(json.dumps(report,indent=2)+'\n')
    replay(report, archive)
    print(report['summary'])


def replay(report, archive):
    assert digest(archive.read_bytes()) == report['archive']['sha256']
    with ZipFile(archive) as raw:
        assert raw.testzip() is None
        assert set(raw.namelist()) == set(report['archive']['entries'])
        for member, expected in report['archive']['entries'].items():
            assert digest(raw.read(member)) == expected
        for trial in report['trials']:
            if trial['status'] != 'completed':
                continue
            name = f"trial-{trial['trial']:02}"
            identities = json.loads(raw.read(f'{name}/endpoints.json'))
            assert identities == trial['endpoints']
            with TemporaryDirectory(prefix='jwm-terminal-bundle-replay.') as work:
                root = Path(work)
                for role in ('host', 'viewer'):
                    observed = root / role
                    observed.mkdir()
                    trace = f'{role}-clocked-telemetry.jsonl'
                    for member in (trace, *(f'{phase}-{suffix}' for phase in ('static','motion')
                                            for suffix in ('scope.json','pixels.jsonl'))):
                        (observed/member).write_bytes(raw.read(f'{name}/{role}/{member}'))
                    (root/trace).symlink_to(observed/trace)
                    for phase in ('static','motion'):
                        raster, telemetry = measure(phase, role, observed, root, set())
                        expected = trial['phases'][phase][role]
                        assert raster == expected['raster'] and telemetry == expected['telemetry']


if __name__=='__main__':
    if sys.argv[1] == 'replay':
        replay(read_json(Path(sys.argv[2])), Path(sys.argv[3]))
        print('Replayed the archive with matching raster counts and telemetry')
    else:
        publish(Path(sys.argv[1]),Path(sys.argv[2]))
