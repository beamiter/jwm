"""Recompute the one-hour result while retaining the original capture validator."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_text())


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def verify(summary, archive):
    expected = read(summary)
    pins = expected.pop('archive')
    validation = expected.pop('offline_validation')
    require(archive.name == pins['path'] and digest(archive) == pins['sha256'],
            'archive name or checksum differs')
    with TemporaryDirectory(prefix='jwm-4k-hour-verified.') as temporary:
        root = Path(temporary)
        with ZipFile(archive) as package:
            members = package.namelist()
            require(len(members) == len(set(members))
                    and set(members) == set(pins['members']) | {'members.sha256.json'},
                    'archive member list differs')
            for member in members:
                path = PurePosixPath(member)
                require(not path.is_absolute() and '..' not in path.parts and not member.endswith('/'),
                        'archive member escaped its directory')
                package.extract(member, root)
        require(read(root/'members.sha256.json') == pins['members']
                and all(digest(root/name) == want for name,want in pins['members'].items()),
                'archive members differ from their checksums')
        require((root/'capture-controller.exit').read_text() == '1\n'
                and read(root/'capture-result.json') == validation['capture_validator_result']
                and read(root/'replay/validation.json') == validation,
                'original capture validator result changed')
        require(digest(root/'fixture/sampler.py') == validation['captured_sampler_sha256']
                and digest(root/'replay/sampler.py') == validation['corrected_sampler_sha256'],
                'resource validation code differs from the recorded versions')
        sys.path[:0] = [str(root/'replay'), str(root/'fixture')]
        import sampler
        from soak_evidence import analyze

        require(Path(sampler.__file__).resolve() == root/'replay/sampler.py',
                'corrected resource validator was not loaded')
        require(analyze(root) == read(root/'result.json') == expected,
                'the extracted evidence does not reproduce the one-hour result')
    print('Verified the archived capture and reproduced the corrected one-hour result.')


if __name__ == '__main__':
    verify(Path(sys.argv[1]), Path(sys.argv[2]))
