#!/usr/bin/env python3
"""Create a replayable publication from whitelisted long-soak evidence."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
from tempfile import TemporaryDirectory
import zipfile

from soak_evidence import analyze

NAME='x11-native-4k-prefetch-resource-hour-soak'
FILES=('protocol.json','terminal.json','controller.exit','observer-pin.json',
       'remote-pins-before.json','remote-pins-after.json','observed.jsonl',
       'display/result.json','remote/paint.jsonl','remote/terminal.json',
       'viewer-resources.jsonl','remote/host-resources.jsonl')
CLOCKS=('viewer-clock.jsonl','remote/host-clock.jsonl')
OPTIONAL_TCP=('viewer-ssh-tcp.jsonl','remote/source-loopback-tcp.jsonl')
DIAGNOSTIC_LINES={
    'viewer.log':('native H.264 VA-API/EGL/DRI3 video rendering active',
                  'native x11 video unavailable','native x11 video disabled','X11 RGB preallocation','connection closed without a goodbye'),
    'remote/host.log':('H.264 NVENC negotiated','hardware H.264 encoding active (NVENC)',
                       'parallel 4:2:0 conversion active','remote protocol I/O error'),
}
PRIVATE = re.compile(r'(/home/[^\s:\"\']+|/tmp/[^\s:\"\']+|127\.0\.0\.1:\d+)')


def require(condition,message):
    if not condition:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def write(path,obj):
    path.write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n')


def redact(message):
    return PRIVATE.sub('[owned runtime]',message)


def sanitize_resources(source, destination):
    with destination.open('x') as output:
        for line in source.read_text().splitlines():
            record=json.loads(line)
            if 'failure' in record:
                record['failure']=redact(record['failure'])
            output.write(json.dumps(record,allow_nan=False)+'\n')


def copy_clock(source,destination):
    with destination.open('x') as output:
        for line in source.read_text().splitlines():
            row=json.loads(line)
            session=row['record'].get('session_id')
            if session:
                row['record']['session_id']=hashlib.sha256(session.encode()).hexdigest()
            output.write(json.dumps(row,allow_nan=False)+'\n')


def publish(run,out):
    require(run.is_dir() and (run/'controller.exit').is_file(),'terminal controller output is required')
    code=int((run/'controller.exit').read_text())
    result=read(run/'result.json')
    require((code==0)==(result['status']=='complete'),'result does not match controller terminal')
    out.mkdir(mode=0o700)
    stage=out/'contents'
    stage.mkdir()
    for name in (*FILES, *OPTIONAL_TCP):
        source=run/name
        if not source.is_file():
            require(code!=0 or name in OPTIONAL_TCP,'completed run is missing '+name)
            continue
        destination=stage/name
        destination.parent.mkdir(parents=True,exist_ok=True)
        if name.endswith('resources.jsonl'):
            sanitize_resources(source,destination)
        else:
            shutil.copyfile(source,destination)
    for name in CLOCKS:
        source=run/name
        if not source.is_file():
            require(code!=0,'completed run is missing '+name)
            continue
        destination=stage/name
        destination.parent.mkdir(parents=True,exist_ok=True)
        copy_clock(source,destination)
    for name, keep in DIAGNOSTIC_LINES.items():
        source=run/name
        if not source.is_file():
            require(code!=0,'completed run is missing '+name)
            continue
        destination=stage/name
        destination.parent.mkdir(parents=True,exist_ok=True)
        destination.write_text(''.join(redact(line)+'\n' for line in source.read_text().splitlines()
                                       if any(token.lower() in line.lower() for token in keep)))
    if (run/'build-provenance.json').is_file():
        shutil.copyfile(run/'build-provenance.json',stage/'build-provenance.json')
    plan_path=stage/'protocol.json'
    if plan_path.is_file():
        plan=read(plan_path)
        (stage/'fixture').mkdir()
        for name,pin in plan['fixture_sha256'].items():
            # The published fixture was copied by the live controller before
            # actor launch. Verify its declared contents and directory scope.
            require(Path(name).name==name,'fixture path escaped its directory')
            source=run/'fixture'/name
            require(source.is_file() and digest(source)==pin,'captured fixture differs: '+name)
            shutil.copyfile(source,stage/'fixture'/name)
    elif code==0:
        raise ValueError('completed run has no protocol')
    if code==0:
        require(analyze(stage)==result,'sanitized evidence does not replay the exact final result')
    elif 'failure' in result:
        result['failure']=redact(result['failure'])
    write(stage/'result.json',result)
    manifest={path.relative_to(stage).as_posix():digest(path) for path in sorted(stage.rglob('*')) if path.is_file()}
    write(stage/'members.sha256.json',manifest)
    suffix='' if code==0 else '-incomplete'
    archive=out/(NAME+suffix+'-raw.zip')
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as target:
        for path in sorted(stage.rglob('*')):
            if path.is_file():
                target.write(path,path.relative_to(stage).as_posix())
    summary = out/(NAME+suffix+'.json')
    write(summary, result | {'archive':{'path':archive.name,'sha256':digest(archive),'members':manifest}})
    replay(summary, archive)


def replay(summary, archive):
    expected = read(summary)
    pins = expected.pop('archive')
    require(archive.name == pins['path'] and digest(archive) == pins['sha256'],
            'resource archive name or digest differs')
    with TemporaryDirectory(prefix='jwm-4k-soak-replay.') as temporary:
        root = Path(temporary)
        with zipfile.ZipFile(archive) as source:
            names = source.namelist()
            require(len(names) == len(set(names)) and set(names) == set(pins['members']) | {'members.sha256.json'}
                    and source.testzip() is None, 'resource archive member list differs')
            for name in names:
                member = Path(name)
                require(not member.is_absolute() and '..' not in member.parts and not name.endswith('/'),
                        'resource archive member escaped its scope')
                source.extract(name, root)
        require(read(root/'members.sha256.json') == pins['members'] and
                all(digest(root/name) == pin for name,pin in pins['members'].items()),
                'resource archive member digests differ')
        require(read(root/'result.json') == expected, 'archived terminal result differs')
        code = int((root/'controller.exit').read_text())
        require((code == 0) == (expected['status'] == 'complete'), 'terminal exit and result disagree')
        if code == 0:
            require(analyze(root) == expected, 'extracted archive changes the exact resource results')
    print('Verified resource archive and reproduced its result from retained evidence.')


def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('first', type=Path)
    cli.add_argument('second', type=Path)
    cli.add_argument('--replay', action='store_true',
                     help='verify an existing public summary and raw archive')
    args = cli.parse_args()
    operation = replay if args.replay else publish
    operation(args.first,args.second)


if __name__=='__main__':
    main()
