"""Bounded Linux TCP counters for one exact, harness-owned socket."""
from collections import Counter
from dataclasses import dataclass
import ipaddress
import json
from pathlib import Path
import re
import struct
import subprocess
import threading
import time

SECOND = 1_000_000_000
INTERVAL_SECONDS = 2
INTERVAL = INTERVAL_SECONDS * SECOND
MAX_SAMPLES = 1950
INTEGER_FIELDS = ("bytes_sent", "bytes_acked", "bytes_received", "bytes_retrans", "segs_out",
                  "segs_in", "data_segs_out", "data_segs_in", "unacked", "lost", "sacked",
                  "notsent", "cwnd", "rto")


def start_ticks(proc_pid):
    prefix, sep, suffix = (proc_pid / "stat").read_text().rpartition(") ")
    fields = suffix.split()
    if not sep or not prefix.startswith(f"{proc_pid.name} (") or len(fields) < 20 or fields[0] == "Z":
        raise RuntimeError("owned SSH process stat is unavailable")
    return int(fields[19])


def owned_inodes(proc_pid):
    owned = set()
    for fd in (proc_pid / "fd").iterdir():
        try:
            target = str(fd.readlink())
        except FileNotFoundError:
            continue
        match = re.fullmatch(r"socket:\[(\d+)\]", target)
        if match:
            owned.add(int(match[1]))
    return owned


def decode_endpoint(encoded):
    address, port = encoded.split(":")
    if len(address) not in (8, 32):
        raise ValueError("unrecognised /proc TCP endpoint")
    raw = b"".join(struct.pack("=I", int(address[index:index + 8], 16))
                   for index in range(0, len(address), 8))
    return str(ipaddress.ip_address(raw)), int(port, 16)


@dataclass(frozen=True)
class SocketIdentity:
    inode: int
    local: tuple
    remote: tuple


@dataclass(frozen=True)
class ProcSocket:
    identity: SocketIdentity
    tx_queue: int
    rx_queue: int


def parse_proc_tcp(text, inodes, remote_address, remote_port):
    found = []
    for line in text.splitlines()[1:]:
        fields = line.split()
        if len(fields) < 10 or fields[3] != "01" or int(fields[9]) not in inodes:
            continue
        remote = decode_endpoint(fields[2])
        if remote != (remote_address, remote_port):
            continue
        tx, rx = (int(number, 16) for number in fields[4].split(":"))
        identity = SocketIdentity(int(fields[9]), decode_endpoint(fields[1]), remote)
        found.append(ProcSocket(identity, tx, rx))
    return found


def find_owned_socket(proc_pid, remote_address, remote_port):
    sockets = owned_inodes(proc_pid)
    tcp = "tcp6" if ":" in remote_address else "tcp"
    candidates = parse_proc_tcp((proc_pid / "net" / tcp).read_text(), sockets, remote_address, remote_port)
    return candidates[0] if len(candidates) == 1 else None


def ss_command(identity):
    local, sport = identity.local
    remote, dport = identity.remote
    family = "-6" if ":" in remote else "-4"
    filters = f"( src {local} and sport = :{sport} and dst {remote} and dport = :{dport} )"
    return ["ss", family, "-tHnieO", "state", "established", filters]


def parse_ss(text, inode):
    lines = [line for line in text.splitlines() if re.search(rf"\bino:{inode}\b", line)]
    if len(lines) != 1:
        return None
    line = lines[0]
    data = {}
    for name in INTEGER_FIELDS:
        match = re.search(rf"(?<!\S){name}:(\d+)(?![\w./])", line)
        if match:
            data[name] = int(match[1])
    rtt = re.search(r"(?<!\S)rtt:([0-9.]+)/([0-9.]+)", line)
    if rtt:
        data["rtt_ms"], data["rttvar_ms"] = (float(value) for value in rtt.groups())
    retrans = re.search(r"(?<!\S)retrans:(\d+)(?:/(\d+))?", line)
    if retrans:
        data["retransmitting_now"] = int(retrans[1])
        if retrans[2] is not None:
            data["total_retransmissions"] = int(retrans[2])
    return data


def read_ss(identity):
    try:
        result = subprocess.run(ss_command(identity), capture_output=True, text=True, timeout=.65,
                                check=False)
    except (OSError, subprocess.TimeoutExpired):
        return None
    return parse_ss(result.stdout, identity.inode) if result.returncode == 0 else None


class OwnedTcpSampler:
    def __init__(self, process, output, remote_address, remote_port, role, *,
                 proc=Path("/proc"), clock=time.monotonic_ns, query=read_ss):
        if role not in {"source_loopback", "ssh_transport"}:
            raise ValueError("unexpected owned-socket role")
        self.role = role
        self.process = process
        self.proc_pid = proc / str(process.pid)
        self.output = output
        self.remote_address = str(ipaddress.ip_address(remote_address))
        self.port = remote_port
        self.clock = clock
        self.query = query
        self.cancel = threading.Event()
        self.worker = threading.Thread(target=self.run, daemon=True)
        self.worker.start()

    def write(self, data):
        self.output.write(json.dumps(data, separators=(",", ":")) + "\n")
        self.output.flush()

    def sample(self, ticks, pinned):
        sample_start = self.clock()
        if self.process.poll() is not None or start_ticks(self.proc_pid) != ticks:
            raise RuntimeError("owned process identity changed")
        observed = find_owned_socket(self.proc_pid, self.remote_address, self.port)
        if observed is None:
            return pinned, "owned_tcp_socket_unavailable"
        if pinned is not None and observed.identity != pinned:
            raise RuntimeError("owned TCP socket changed")
        query_start = self.clock()
        info = self.query(observed.identity)
        query_end = self.clock()
        if (self.process.poll() is not None or start_ticks(self.proc_pid) != ticks
                or observed.identity.inode not in owned_inodes(self.proc_pid)):
            raise RuntimeError("owned process identity changed during sampling")
        sample_end = self.clock()
        self.write({
            "type": "p09_owned_tcp_sample", "schema_version": 1, "role": self.role,
            "start_monotonic_ns": sample_start, "end_monotonic_ns": sample_end,
            "ss_duration_ns": query_end - query_start,
            "socket_inode": observed.identity.inode, "remote_port": self.port,
            "tx_queue_bytes": observed.tx_queue, "rx_queue_bytes": observed.rx_queue,
            "tcp_info": info,
        })
        return observed.identity, "tcp_info" if info else "queue_only"

    def run(self):
        began = self.clock()
        counts = Counter()
        pinned = None
        reason = "closed"
        ticks = None
        skipped = 0
        try:
            ticks = start_ticks(self.proc_pid)
            slot = 0
            while slot < MAX_SAMPLES and not self.cancel.is_set():
                current = (self.clock() - began) // INTERVAL
                if current > slot:
                    skipped += min(current, MAX_SAMPLES) - slot
                    if current >= MAX_SAMPLES:
                        break
                    slot = current
                if self.process.poll() is not None:
                    reason = "process_ended"
                    break
                pinned, status = self.sample(ticks, pinned)
                counts[status] += 1
                slot += 1
                due = began + slot * INTERVAL
                self.cancel.wait(max((due - self.clock()) / SECOND, 0))
            if slot >= MAX_SAMPLES:
                reason = "sample_bound"
        except (OSError, RuntimeError, ValueError):
            reason = "owned_socket_identity_or_proc_unavailable"
        finally:
            self.write({
                "type": "p09_owned_tcp_summary", "schema_version": 1, "clock": "monotonic",
                "role": self.role, "pid": self.process.pid, "proc_start_ticks": ticks,
                "socket_inode": pinned.inode if pinned else None, "remote_port": self.port,
                "start_monotonic_ns": began, "end_monotonic_ns": self.clock(),
                "interval_seconds": INTERVAL_SECONDS, "max_sample_slots": MAX_SAMPLES, "missed_slots": skipped,
                "counts": dict(counts), "end_reason": reason,
            })

    def stop(self):
        self.cancel.set()
        self.worker.join(timeout=2)
        if self.worker.is_alive():
            raise RuntimeError("owned SSH TCP sampler did not finish")
