#!/usr/bin/env python3
"""Run and preserve one owned two-machine native X11 prefetch 4K soak."""
import argparse
from contextlib import ExitStack
import fcntl
import json
from pathlib import Path
import re
import shlex
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import traceback

from evidence import NATIVE_LOG, require, write_json
import native_fixture as native
from owned_tcp_sampler import OwnedTcpSampler
from prior_resources import TelemetryRelay, track
from processes import sha256, stop, wait_for
from sampler import BURN, INTERVAL, MEASURE, capture
from soak_evidence import EXPECTED_WATCHDOG, analyze

HERE=Path(__file__).resolve().parent
KEY_FILES=('source.py','p09-workload.c','prior_resources.py','sampler.py','remote_processes.py','owned_tcp_sampler.py')
OBSERVER_SECONDS=BURN+MEASURE+15
REPLAY_FILES=(*KEY_FILES,'run_soak.py','native_fixture.py','evidence.py','processes.py','soak_evidence.py',
              'launch.py','previous_probe.py','dri3-node.py','extend-owned-compositor.patch','publish_soak.py','test_offline.py','test_marker.c')


def json_lines(path):
    return [json.loads(line) for line in path.read_bytes().splitlines(keepends=True)
            if line.startswith(b'{') and line.endswith(b'\n')]


def one_event(path, name):
    return next((row for row in json_lines(path) if row.get('type')==name),None)


def shell_peer(argv, *, timeout=30, check=True):
    return subprocess.run(['ssh',*native.SSH_OPTIONS,'-n',native.PEER,shlex.join(argv)],
                          stdin=subprocess.DEVNULL,capture_output=True,text=True,timeout=timeout,check=check)


def verify_peer(directory, expected_assets, require_painter):
    paths={name: f'{directory}/{name}' for name in expected_assets}
    paths['host']=native.HOST
    if require_painter:
        paths['p09-workload']=f'{directory}/p09-workload'
    answer=shell_peer(['sha256sum','--',*paths.values()],timeout=15).stdout
    received={path:digest for digest,path in (line.split(maxsplit=1) for line in answer.splitlines())}
    actual={name:received.get(path) for name,path in paths.items()}
    require(actual['host']==native.REMOTE_PINS['host'],'existing Ubuntu NVENC codec binary changed')
    require({name:actual[name] for name in expected_assets}==expected_assets, 'remote fixture assets differ')
    if require_painter:
        require(re.fullmatch(r'[0-9a-f]{64}',actual.get('p09-workload') or ''),'missing actual remote painter pin')
    return actual


def stage_source(path):
    output = shell_peer(['mktemp','-d','/tmp/jwm-native-prefetch-soak.XXXXXXXX'],timeout=15).stdout.strip()
    require(re.fullmatch(r'/tmp/jwm-native-prefetch-soak\.[A-Za-z0-9]+',output),'unexpected own source scratch location')
    (path/'remote-directory.txt').write_text(output+'\n')
    assets={name:sha256(HERE/name) for name in KEY_FILES}
    subprocess.run(['scp',*native.SSH_OPTIONS,'-q',*[HERE/name for name in KEY_FILES],f'{native.PEER}:{output}/'],
                   stdin=subprocess.DEVNULL,stderr=subprocess.PIPE,timeout=25,check=True)
    verify_peer(output,assets,False)
    # Both capture executables are built from the already tested extended P09
    # source. No source modifications are made to the ongoing ABBA staging.
    build = shell_peer(['cc','-std=c11','-O2','-Wall','-Wextra','-o',f'{output}/p09-workload',
                        f'{output}/p09-workload.c','-lX11','-lXext','-lXdamage','-lm'],check=False)
    (path/'remote-painter-build.log').write_text(build.stdout+build.stderr)
    build.check_returncode()
    pinned=verify_peer(output,assets,True)
    write_json(path/'remote-pins-before.json',pinned)
    return output,pinned,assets


def open_session(opts, root, display, launcher, term, key, env, stack, log, source, observer_bin):
    ready=wait_for(source,lambda:one_event(root/'remote-ready.jsonl','soak_ready'),25)
    port=ready['upstream_port']
    require(type(port) is int and 1<=port<=65535,'invalid pinned source port')
    with socket.socket(socket.AF_INET,socket.SOCK_STREAM) as choice:
        choice.bind(('127.0.0.1',0))
        forward=choice.getsockname()[1]
    tunnel_log=root/'tunnel.log'
    tunnel=subprocess.Popen(['ssh',*native.SSH_OPTIONS,'-Nv','-o','ExitOnForwardFailure=yes',
                              '-L',f'127.0.0.1:{forward}:127.0.0.1:{port}',native.PEER],env=env,
                            stdin=subprocess.DEVNULL,stdout=log(tunnel_log.name),stderr=subprocess.STDOUT)
    stack.callback(stop,tunnel)
    wait_for(tunnel,lambda:re.search(r'Local forwarding listening on 127\.0\.0\.1 port',tunnel_log.read_text()),12)
    tcp = OwnedTcpSampler(tunnel, log('viewer-ssh-tcp.jsonl', mode='x'),
                          native.PEER.split('@', 1)[1], 22, 'ssh_transport')
    stack.callback(tcp.stop)
    args=[opts.viewer_bin,'connect',f'127.0.0.1:{forward}','--view-only','--toggle','--stats-json','--key-file',key,
          '--display',display,'--window-size','3840x2160','--window-position','0,0','--scaling','gpu']
    viewer_env=env | {'JWM_REMOTE_GPU_PRESENT':str(opts.render_node),'JWM_REMOTE_X11_PREFETCH_TARGET':'1'}
    viewer=subprocess.Popen(args,env=viewer_env,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
    relay=TelemetryRelay(viewer,'viewer',log('viewer.log'),log('viewer-clock.jsonl',mode='x'))
    stack.callback(relay.finish)
    stack.callback(stop,viewer)
    identity=track(viewer.pid,opts.viewer_bin)

    def drawable_ready():
        text = (root/'viewer.log').read_text(errors='replace')
        if re.search(r'^jwm-remote: native x11 video (?:unavailable|disabled)',text,re.M | re.I):
            raise RuntimeError('viewer left the declared same-device native 4K route')
        if NATIVE_LOG not in text:
            return None
        return native.find_viewer(display,forward,env)

    drawable=wait_for(viewer,drawable_ready,20)
    observer=subprocess.Popen([observer_bin,'observe','--display',display,'--window',drawable,'--width','3840',
                               '--height','2160','--seconds',str(OBSERVER_SECONDS),'--run-id',str(opts.run_id)],
                              env=env,stdin=subprocess.DEVNULL,stdout=log('observed.jsonl'),stderr=log('observer.log'))
    stack.callback(stop,observer)
    began=wait_for(observer,lambda:one_event(root/'observed.jsonl','p09_start'),10)
    require((began['width'],began['height'],began['seconds'],began['run_id']) ==
            (3840,2160,OBSERVER_SECONDS,opts.run_id),'wrong witness geometry, duration or marker')

    def health():
        relay.check()
        if any(child.poll() is not None for child in (launcher,tunnel,source,observer)):
            raise RuntimeError('an owned native soak participant ended before the resource interval')

    print(f'Authenticated exact 4K observer active. Burn-in {BURN}s, retained {MEASURE}s.',flush=True)
    capture(log('viewer-resources.jsonl',mode='x'),'viewer',identity,began['monotonic_ns'],health)
    term['observer']=observer.wait(timeout=25)
    require(term['observer']==0,'independent visible marker observer did not close successfully')
    require(drawable==native.find_viewer(display,forward,env),'exact 4K drawable disappeared or changed')
    wait_for(source,lambda:one_event(root/'remote-ready.jsonl','host_measured'),25)
    relay.check()
    subprocess.run(args,env=viewer_env,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,
                   stderr=log('disconnect.log'),timeout=12,check=True)
    term['viewer']=viewer.wait(timeout=14)
    relay.finish()
    relay.check(alive=False)
    require(term['viewer']==0 and not relay.worker.is_alive(),'viewer failed to shut down and drain telemetry')
    term['source']=source.wait(timeout=20)
    require(term['source']==0 and one_event(root/'remote-ready.jsonl','host_closed'),'Ubuntu host failed to close')


def run(opts):
    root = opts.out.resolve()
    root.mkdir(mode=0o700)
    opts.out=root
    opts.render_node=opts.render_node.resolve(strict=True)
    opts.study='single-native-soak'
    opts.display_launcher=HERE/'launch.py'
    opts.launcher_sha256=sha256(opts.display_launcher)
    require(sha256(opts.harness)==opts.harness_sha256,'declared compositor harness pin differs')
    opts.launcher_arg=['--harness',str(opts.harness.resolve()),'--harness-sha256',opts.harness_sha256,
                       '--doctor','{viewer}','--doctor-sha256','{viewer_sha256}','--out','{out}',
                       '--node','{node}','--max-seconds',str(EXPECTED_WATCHDOG)]
    protocol={'schema':1,'trial':{'run_id':opts.run_id,'mode':'on','formal':False,'warmup_seconds':BURN,
                                  'score_seconds':MEASURE,'observer_seconds':OBSERVER_SECONDS},
              'burn_in_seconds':BURN,'retained_seconds':MEASURE,'resource_interval_seconds':INTERVAL,
              'source_video_size':[3840,2160],'renderer':native.render_pin(opts),'viewer_sha256':opts.viewer_sha256,
              'harness_sha256':opts.harness_sha256,'fixture_sha256':{name:sha256(HERE/name) for name in REPLAY_FILES},
              'transport':'Same uncapped authenticated IPv4 SSH forward as the formal 4K comparison',
              'passive_tcp_observation':'Owned SSH and host-loopback sockets at two-second intervals',
              'viewer_env':{'JWM_REMOTE_X11_PREFETCH_TARGET':'1','JWM_REMOTE_X11_LAZY_PICTURE':None},
              'host_env':{'JWM_REMOTE_PARALLEL_YUV420':'1'},'host_telemetry_clock_anchor':'First complete active H.264/ACK window',
              'viewer_telemetry_clock_anchor':'Independent X11 marker observer startup'}
    write_json(root/'protocol.json',protocol)
    fixture = root/'fixture'
    fixture.mkdir(mode=0o700)
    for name in REPLAY_FILES:
        shutil.copyfile(HERE/name, fixture/name)
    require(all(sha256(fixture/name)==pin for name,pin in protocol['fixture_sha256'].items()),
            'fixture copy does not match declared source pins')
    remote=None
    source_started=False
    error=None
    term={}
    try:
        opts.viewer_bin=native.private_copy(opts.viewer_bin,root/'viewer',opts.viewer_sha256)
        observer=root/'observer'
        result=subprocess.run(['cc','-std=c11','-O2','-Wall','-Wextra','-o',observer,HERE/'p09-workload.c',
                               '-lX11','-lXext','-lXdamage','-lm'],stdin=subprocess.DEVNULL,capture_output=True,text=True,timeout=20)
        (root/'observer-build.log').write_text(result.stdout+result.stderr)
        result.check_returncode()
        write_json(root/'observer-pin.json',{'sha256':sha256(observer)})
        with ExitStack() as stack:
            def log(name,mode='xb'):
                return stack.enter_context((root/name).open(mode))
            env=native.viewer_env(opts)
            env['XDG_RUNTIME_DIR']=stack.enter_context(tempfile.TemporaryDirectory(prefix='jwm-prefetch-soak-client.'))
            key=root/'key'
            stack.callback(key.unlink,missing_ok=True)
            subprocess.run([opts.viewer_bin,'keygen','--output',key],env=env,stdin=subprocess.DEVNULL,
                           stdout=subprocess.DEVNULL,stderr=log('keygen.log'),timeout=8,check=True)
            display,launcher=native.start_x11(opts,root,stack,log,env,'on')
            native.prove_gpu(opts,root,key,log,env,display)
            remote,pins,remote_assets=stage_source(root)
            remote_args=['python3','-u','-B',f'{remote}/source.py',opts.label,'--run-id',str(opts.run_id),
                         '--painter-sha256',pins['p09-workload']]
            source=subprocess.Popen(['ssh',*native.SSH_OPTIONS,native.PEER,shlex.join(remote_args)],
                                    env=env,stdin=subprocess.PIPE,stdout=log('remote-ready.jsonl'),stderr=log('remote-stderr.log'))
            source_started=True
            stack.callback(stop,source,natural=True)
            source.stdin.write(key.read_bytes())
            source.stdin.flush()
            open_session(opts,root,display,launcher,term,key,env,stack,log,source,observer)
            native.close_display(launcher,root)
            term['launcher']=launcher.returncode
    except BaseException:
        error=sys.exc_info()[1]
        raise
    finally:
        write_json(root/'terminal.json',term)
        if source_started:
            try:
                subprocess.run(['scp',*native.SSH_OPTIONS,'-qr',f'{native.PEER}:{remote}/{opts.label}',root/'remote'],
                               stdin=subprocess.DEVNULL,stderr=subprocess.PIPE,timeout=45,check=True)
                pinned=verify_peer(remote,remote_assets,True)
                require(pinned==pins,'active host or isolated source pin changed during the trial')
                write_json(root/'remote-pins-after.json',pinned)
            except (OSError,RuntimeError,subprocess.SubprocessError):
                if error is None:
                    raise
                (root/'remote-harvest-error.log').write_text(traceback.format_exc())
    return analyze(root)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--label',required=True)
    parser.add_argument('--viewer-bin',type=Path,required=True)
    parser.add_argument('--viewer-sha256',required=True)
    parser.add_argument('--harness',type=Path,required=True)
    parser.add_argument('--harness-sha256',required=True)
    parser.add_argument('--run-id',type=int,default=41)
    parser.add_argument('--render-node',type=Path,default=Path('/dev/dri/renderD128'))
    parser.add_argument('--ffmpeg-lib',type=Path,default=Path('/tmp/jwm-remote-ffmpeg/usr/lib/x86_64-linux-gnu'))
    opts=parser.parse_args()
    if not (1<=opts.run_id<=63 and re.fullmatch(r'[a-z0-9-]{1,54}',opts.label)
            and all(re.fullmatch(r'[0-9a-f]{64}',pin) for pin in (opts.viewer_sha256,opts.harness_sha256))
            and not opts.out.exists() and opts.out.parent.is_dir()):
        parser.error('need a fresh destination, one bounded marker identity and both exact SHA-256 pins')
    code=1
    summary=None
    with native.LOCK.open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        try:
            summary=run(opts)
            code=0
        except (KeyboardInterrupt,OSError,KeyError,RuntimeError,ValueError,subprocess.SubprocessError) as problem:
            traceback.print_exc()
            summary={'status':'invalid','failure_type':type(problem).__name__,'failure':str(problem)}
        if opts.out.is_dir():
            write_json(opts.out/'result.json',summary)
            (opts.out/'controller.exit').write_text(f'{code}\n')
    print(json.dumps(summary,indent=2,allow_nan=False),flush=True)
    return code


if __name__=='__main__':
    raise SystemExit(main())
