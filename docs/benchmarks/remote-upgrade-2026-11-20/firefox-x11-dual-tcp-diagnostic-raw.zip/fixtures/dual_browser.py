#!/usr/bin/env python3
"""Scratch Firefox/JPEG baseline with one owned X11 endpoint per machine."""

import argparse
from contextlib import ExitStack, suppress
import fcntl
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import platform
from queue import Empty, Queue
import re
import shlex
import socket
import subprocess
import sys
import tarfile
import tempfile
from threading import Thread
import time
import traceback
import uuid

from processes import clean_env, get_display, start_display, stop, wait_for
from run_baseline import (Pixels, collect_phase, find_static_page, monitor_stderr,
                          sample, select_telemetry, stop_group, wait_for_window, write_capture)
from score import MEASURE_SECONDS, REQUESTED_FPS, TAIL_SECONDS, WARM_SECONDS, write_json


HERE = Path(__file__).resolve().parent
SIZE = (1920, 1080)
GEOMETRY = '1920x1080'
LOCK = '/tmp/jwm-p08-p09-release/benchmark.lock'
SSH = ['ssh', '-T', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
       '-o', 'ExitOnForwardFailure=yes', '-o', 'ForwardX11=no', '-o', 'ForwardAgent=no',
       '-o', 'ServerAliveInterval=8', '-o', 'ServerAliveCountMax=3',
       '-o', 'StrictHostKeyChecking=yes']
PIPE_TIMEOUT = WARM_SECONDS + MEASURE_SECONDS + TAIL_SECONDS + 15
CLEAN_PINS = {
    'host_release_sha256': '5e1951ed8bbc23f41db5b5918931d91a37baa1e9fa213c8ef9067a214a1511e5',
    'viewer_release_sha256': 'aaa1ed44223181963b3463fb169d56c9a76b31a514f29915f7ad5d47002690a3',
    'firefox_sha256': 'ddf58d7cb36bd35e8e9dab7bc70ce31e17340ce87fc7c0fe81e495ccbd863965',
    'firefox_profile_sha256': '5b6d7fa4a2fae76978dddd3835bf9ed330e53e125a5d20ad5d67e2817c7bd771',
}


class Messages:
    """Bound waits and flag controller EOF without touching the measured lane."""

    def __init__(self, stream, trace, terminal_event):
        self.args = ['control channel']
        self.queue = Queue()
        self.closed = False

        def receive():
            try:
                # An error path can exit while the control pipe is silent.
                # Avoid holding a BufferedReader lock across that wait.
                with os.fdopen(os.dup(stream.fileno()), 'rb', buffering=0) as receive_pipe, \
                     trace.open('wb') as log:
                    for line in iter(lambda: receive_pipe.readline(8192), b''):
                        log.write(line)
                        log.flush()
                        if not line.endswith(b'\n'):
                            raise ValueError('unterminated or oversized control event')
                        message = json.loads(line)
                        self.queue.put(message)
                        if message.get('event') == terminal_event:
                            break
            except (OSError, ValueError) as error:
                self.queue.put(error)
            finally:
                self.closed = True
                self.queue.put(EOFError('control channel reached EOF'))

        Thread(target=receive, daemon=True).start()

    def poll(self):
        return 1 if self.closed else None

    def expect(self, event, run_id, timeout=15):
        try:
            message = self.queue.get(timeout=timeout)
        except Empty as error:
            raise RuntimeError(f'waiting for {event} timed out') from error
        if isinstance(message, Exception):
            raise RuntimeError(f'waiting for {event}: {message}') from message
        if message.get('event') != event or message.get('run_id') != run_id:
            raise RuntimeError(f'unexpected control event while waiting for {event}: {message}')
        return message


def send(stream, event, run_id, **values):
    stream.write((json.dumps({'event': event, 'run_id': run_id, **values}) + '\n').encode())
    stream.flush()


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as data:
        for chunk in iter(lambda: data.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def process_identity(process):
    pid = process if isinstance(process, int) else process.pid
    fields = Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()
    executable = Path(f'/proc/{pid}/exe')
    stat = executable.stat()
    return {'pid': pid, 'start_ticks': int(fields[19]), 'exe': os.readlink(executable),
            'exe_device': stat.st_dev, 'exe_inode': stat.st_ino}


def firefox_identity(launcher, profile):
    task = Path(f'/proc/{launcher.pid}/task/{launcher.pid}/children')
    expected = [b'--profile', os.fsencode(profile)]
    matches = []
    for pid in map(int, task.read_text().split()):
        with suppress(FileNotFoundError):
            args = Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0')
            if any(args[index:index + 2] == expected for index in range(len(args) - 1)):
                matches.append(pid)
    if len(matches) != 1:
        raise RuntimeError('could not identify the exact Firefox process for the owned profile')
    pid, = matches
    return process_identity(pid) | {'sha256': sha256(f'/proc/{pid}/exe')}


def endpoint(role, release, display, xvfb, process):
    cpu = next((line.split(':', 1)[1].strip() for line in Path('/proc/cpuinfo').read_text().splitlines()
                if line.startswith('model name')), platform.processor())
    return {'role': role, 'hostname': socket.gethostname(), 'kernel': platform.release(),
            'boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
            'cpu': cpu, 'display': display, 'drawable_size': SIZE, 'clock': 'CLOCK_MONOTONIC',
            'release_sha256': sha256(release), 'xvfb': process_identity(xvfb),
            'endpoint_process': process_identity(process)}


def runtime(stack, run_dir):
    env = clean_env()
    env.pop('LD_PRELOAD', None)
    runtime_dir = Path(stack.enter_context(
        tempfile.TemporaryDirectory(prefix='jwbfrt.', ignore_cleanup_errors=True)))
    stack.callback(detach_document_portal, runtime_dir, run_dir)
    env.update(XDG_RUNTIME_DIR=str(runtime_dir), XDG_SESSION_TYPE='x11')
    xvfb = start_display(*SIZE, stack.enter_context((run_dir / 'xvfb.log').open('wb')))
    stack.callback(stop, xvfb)
    return env, xvfb, get_display(xvfb)


def detach_document_portal(runtime_dir, run_dir):
    mountpoint = runtime_dir / 'doc'
    log_path = run_dir / 'document-portal-cleanup.log'
    try:
        mounted = subprocess.run(['findmnt', '--noheadings', '--mountpoint', str(mountpoint),
                                  '--types', 'fuse.portal', '--output', 'TARGET'],
                                 stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, timeout=3)
        if mounted.returncode == 0 and mounted.stdout.strip() == str(mountpoint):
            with log_path.open('wb') as log:
                subprocess.run(['fusermount3', '-u', str(mountpoint)],
                               stdout=log, stderr=log, timeout=5, check=True)
    except (OSError, subprocess.SubprocessError):
        with log_path.open('a') as log:
            traceback.print_exc(file=log)


def verify_geometry(pixels, xid):
    info = pixels.crop(xid, 0, 0, *SIZE)
    if len(info) != SIZE[1] or len(info[0]) != SIZE[0] * 4:
        raise RuntimeError('owned X11 drawable is smaller than 1920x1080')
    return info


def verify_reverse_listener(port):
    result = subprocess.run(['ss', '-H', '-ltn', f'sport = :{port}'], capture_output=True,
                            check=True, text=True, timeout=5)
    listeners = [line.split()[3] for line in result.stdout.splitlines() if line.strip()]
    if listeners != [f'127.0.0.1:{port}']:
        raise RuntimeError(f'reverse-forward listener is not an exact loopback socket: {listeners}')


def wait_motion(process, pixels, xid, test_tile, initial_scroll, allowed_offset):
    x_origin, tile_top = test_tile
    def moved():
        x, text = sample(pixels, xid, SIZE[0], tile_top)
        return x if (x is not None and abs(x - x_origin) >= allowed_offset
                     and text and text != initial_scroll) else None
    wait_for(process, moved, 5)


def save_phase(run, phase, role):
    phase['telemetry'] = select_telemetry(run, phase, role, SIZE)
    write_json(run / f"{phase['phase']}-scope.json", phase)
    return phase


def viewer_worker(args):
    run = Path(args.run_dir)
    run.mkdir(mode=0o700)
    with ExitStack() as stack:
        key_line = sys.stdin.buffer.readline(4096)
        if not key_line.endswith(b'\n'):
            raise RuntimeError('no bounded one-use key received on the SSH control pipe')
        private_key_dir = Path(stack.enter_context(tempfile.TemporaryDirectory(prefix='jwbfkey.')))
        key = private_key_dir / 'key'
        with os.fdopen(os.open(key, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600), 'wb') as key_file:
            key_file.write(key_line)
        stack.callback(key.unlink)
        control = Messages(sys.stdin.buffer, run / 'control-in.jsonl', 'disconnect')
        verify_reverse_listener(args.port)
        release = Path(args.release).resolve(strict=True)
        env, xvfb, display = runtime(stack, run)
        address = f'127.0.0.1:{args.port}'
        viewer_args = [str(release), 'connect', address, '--display', display, '--view-only',
                       '--jpeg', '--stats-json', '--toggle', '--scaling', 'cpu',
                       '--window-size', GEOMETRY, '--window-position', '0,0', '--key-file', str(key)]
        viewer = subprocess.Popen(viewer_args, env=env, stdin=subprocess.DEVNULL,
                                  stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        stack.callback(stop, viewer)
        monitor, errors = monitor_stderr(viewer, 'viewer', run)
        xid = wait_for_window(viewer, display, f'{address} - JWM Remote', env,
                              run / 'viewer-tree.log', 15, SIZE)
        pixels = Pixels(display)
        stack.callback(pixels.close)

        def ready():
            x, text = sample(pixels, xid, SIZE[0], args.tile_top)
            return (x, text) if x is not None and abs(x - args.origin_x) <= 4 and text else None

        x_origin, _ = wait_for(viewer, ready)
        write_capture(run / 'viewer-static.ppm', verify_geometry(pixels, xid))
        identity = endpoint('viewer', release, display, xvfb, viewer) | {'drawable_xid': xid}
        write_json(run / 'identity.json', identity)
        send(sys.stdout.buffer, 'viewer_ready', args.run_id, identity=identity)
        control.expect('static', args.run_id)
        send(sys.stdout.buffer, 'viewer_static_started', args.run_id)
        lanes = {'viewer': (pixels, xid)}
        processes = (viewer, xvfb, control)
        static = collect_phase('static', run, lanes, processes, SIZE[0], args.tile_top)
        send(sys.stdout.buffer, 'viewer_static_done', args.run_id)
        control.expect('motion', args.run_id)
        if viewer.poll() is not None:
            raise RuntimeError(f'owned viewer exited during the phase transition: {viewer.returncode}')
        initial = sample(pixels, xid, SIZE[0], args.tile_top)[1]
        send(sys.stdout.buffer, 'viewer_motion_armed', args.run_id)
        wait_motion(viewer, pixels, xid, (x_origin, args.tile_top), initial, 8)
        motion = collect_phase('motion', run, lanes, processes, SIZE[0], args.tile_top)
        write_capture(run / 'viewer-motion-end.ppm', verify_geometry(pixels, xid))
        send(sys.stdout.buffer, 'viewer_motion_done', args.run_id)
        control.expect('disconnect', args.run_id)
        with (run / 'disconnect.log').open('wb') as diagnostic:
            subprocess.run(viewer_args, env=env, stdin=subprocess.DEVNULL,
                           stdout=subprocess.DEVNULL, stderr=diagnostic, timeout=10, check=True)
        if viewer.wait(timeout=12):
            raise RuntimeError('viewer failed its owned toggle disconnect')
        monitor.join(timeout=4)
        if monitor.is_alive() or errors:
            raise RuntimeError(f'viewer stats did not close cleanly: {errors}')
        for phase in (static, motion):
            save_phase(run, phase, 'viewer')
        send(sys.stdout.buffer, 'viewer_disconnected', args.run_id)


def source_setup(stack, args, run, env, display):
    profile = run / 'firefox-profile'
    profile.mkdir(mode=0o700)
    (profile / 'user.js').write_bytes((HERE / 'firefox-profile-user.js').read_bytes())
    firefox_env = dict(env, DISPLAY=display, GDK_BACKEND='x11', MOZ_NO_REMOTE='1',
                       MOZ_ENABLE_WAYLAND='0', LIBGL_ALWAYS_SOFTWARE='1',
                       XDG_CACHE_HOME=str(profile / 'cache'), XDG_CONFIG_HOME=str(profile / 'config'))
    firefox_env.pop('MOZ_HEADLESS', None)
    browser = subprocess.Popen(['dbus-run-session', '--', args.firefox, '--new-instance',
                                '--profile', str(profile), '--kiosk', (HERE / 'browser-trial.html').as_uri()],
                               env=firefox_env, stdout=subprocess.DEVNULL,
                               stderr=stack.enter_context((run / 'firefox.log').open('wb')),
                               start_new_session=True)
    stack.callback(stop_group, browser)
    title = 'JWM remote browser workload (offline)'
    xid = wait_for_window(browser, display, title, env, run / 'source-tree.log', 25)
    subprocess.run(['xdotool', 'windowmove', str(xid), '0', '0', 'windowsize', str(xid),
                    str(SIZE[0]), str(SIZE[1])], env=dict(env, DISPLAY=display), timeout=5, check=True)
    if xid != wait_for_window(browser, display, title, env, run / 'source-positioned-tree.log', 10, SIZE):
        raise RuntimeError('Firefox changed identity during resize')
    pixels = Pixels(display)
    stack.callback(pixels.close)
    placement = wait_for(browser, lambda: find_static_page(verify_geometry(pixels, pixels.root)), 10)
    write_capture(run / 'source-static.ppm', verify_geometry(pixels, pixels.root))
    _, tile_top, _ = placement
    if not 50 <= tile_top < SIZE[1] - 108:
        raise RuntimeError(f'Firefox raster location is ineligible: {placement}')
    return browser, pixels, placement


def ssh_command(control, *options):
    return SSH + ['-S', str(control), *options]


def forward_remote(master, control, peer, host_port):
    wait_for(master, lambda: True if subprocess.run(
        ssh_command(control, '-O', 'check', '--', peer), capture_output=True, timeout=3
    ).returncode == 0 else None, 12)
    spec = f'127.0.0.1:0:127.0.0.1:{host_port}'
    reply = subprocess.check_output(ssh_command(control, '-O', 'forward', '-R', spec, '--', peer),
                                    text=True, timeout=10).strip()
    if not re.fullmatch(r'[0-9]{1,5}', reply) or not 1 <= int(reply) <= 65535:
        raise RuntimeError(f'OpenSSH returned an unexpected dynamic remote port: {reply!r}')
    return int(reply)


def fetch_viewer_artifacts(control, peer, remote_trial, run):
    packed = run / 'viewer-trace.tar.gz'
    command = shlex.join(['tar', '-C', remote_trial, '-czf', '-', '--', '.'])
    with packed.open('wb') as output, (run / 'viewer-artifact-transfer.log').open('wb') as log:
        subprocess.run(ssh_command(control, '--', peer, command), stdin=subprocess.DEVNULL,
                       stdout=output, stderr=log, timeout=45, check=True)
    destination = run / 'viewer'
    destination.mkdir(mode=0o700)
    with tarfile.open(packed, 'r:gz') as archive:
        for member in archive:
            path = Path(member.name)
            if member.isdir() and path == Path('.'):
                continue
            if not member.isfile() or path.parent != Path('.') or path.name in ('', '.', '..'):
                raise RuntimeError('unexpected peer artifact type or layout')
            with archive.extractfile(member) as source, (destination / path.name).open('xb') as data:
                while chunk := source.read(65536):
                    data.write(chunk)


def stop_tcp_sampler(sampler, run):
    if sampler is None:
        return
    try:
        sampler.stop()
    except RuntimeError:
        (run / 'ssh-tcp-sampler-failure.log').write_text(traceback.format_exc())


def run_source_trial(args, run):
    run.mkdir(mode=0o700)
    run_id = uuid.uuid4().hex
    remote_trial = f'{args.remote_dir}/{run_id}'
    with ExitStack() as stack:
        env, xvfb, display = runtime(stack, run)
        browser, pixels, placement = source_setup(stack, args, run, env, display)
        origin_x, tile_top, header_top = placement
        key = run / 'key'
        stack.callback(key.unlink, missing_ok=True)
        subprocess.run([args.release, 'keygen', '--output', str(key)], env=env,
                       stdout=subprocess.DEVNULL, timeout=8, check=True)
        host = subprocess.Popen([args.release, 'host', '--display', display, '--capture-source', 'root',
                                 '--scaling', 'auto', '--once', '--listen', '127.0.0.1:0',
                                 '--key-file', str(key), '--stats-json', '--fps', str(REQUESTED_FPS),
                                 '--jpeg-quality', '85', '--fixed-jpeg-quality'], env=env,
                                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        stack.callback(stop, host)
        monitor, errors = monitor_stderr(host, 'host', run)

        def listen_port():
            log = run / 'host.log'
            match = re.search(r'listening on 127\.0\.0\.1:(\d+)', log.read_text()) if log.exists() else None
            return int(match[1]) if match else None

        port = wait_for(host, listen_port)
        socket_dir = Path(stack.enter_context(tempfile.TemporaryDirectory(prefix='jwbfssh.')))
        control = socket_dir / 'c'
        master = subprocess.Popen(ssh_command(control, '-M', '-N', '-o', 'ControlPersist=no',
                                               '-o', 'ClearAllForwardings=yes',
                                               '--', args.peer), stdin=subprocess.DEVNULL,
                                  stdout=subprocess.DEVNULL,
                                  stderr=stack.enter_context((run / 'tunnel.log').open('wb')))
        stack.callback(stop, master)
        remote_port = forward_remote(master, control, args.peer, port)
        remote_cmd = ['python3', '-B', '-u', f'{args.remote_dir}/dual_browser.py', 'viewer',
                      '--run-dir', remote_trial, '--run-id', run_id, '--port', str(remote_port),
                      '--origin-x', str(origin_x), '--tile-top', str(tile_top), '--release', args.remote_release]
        peer = subprocess.Popen(ssh_command(control, '--', args.peer, shlex.join(remote_cmd)),
                                stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                stderr=stack.enter_context((run / 'peer.log').open('wb')))
        tcp_sampler = None
        try:
            peer.stdin.write(key.read_bytes())
            peer.stdin.flush()
            events = Messages(peer.stdout, run / 'peer-events.jsonl', 'viewer_disconnected')
            ready = events.expect('viewer_ready', run_id, timeout=30)
            source = endpoint('host', args.release, display, xvfb, host)
            source['firefox_launcher'] = process_identity(browser)
            source['firefox'] = firefox_identity(browser, run / 'firefox-profile')
            application_ini = Path(source['firefox']['exe']).with_name('application.ini')
            source['installed_firefox_application'] = dict(re.findall(
                r'^(Version|BuildID)=(.+)$', application_ini.read_text(), re.M))
            viewer = ready['identity']
            if viewer['boot_id'] == source['boot_id']:
                raise RuntimeError('the two endpoint records identify one machine')
            master_identity = process_identity(master)
            write_json(run / 'identity.json', {'run_id': run_id, 'host': source, 'viewer': viewer,
                       'ssh_master': master_identity, 'local_port': port, 'remote_port': remote_port})
            if args.tcp_peer_address:
                from ssh_tcp_sampler import TunnelSampler
                actual_pins = {'host_release_sha256': source['release_sha256'],
                               'viewer_release_sha256': viewer['release_sha256'],
                               'firefox_sha256': source['firefox']['sha256'],
                               'firefox_profile_sha256': sha256(run / 'firefox-profile' / 'user.js')}
                if actual_pins != CLEAN_PINS:
                    write_json(run / 'pin-mismatch.json', {'actual': actual_pins, 'expected': CLEAN_PINS})
                    raise RuntimeError('running endpoints differ from the clean Firefox diagnostic pins')
                tcp_trace = stack.enter_context((run / 'ssh-tcp.jsonl').open('w'))
                tcp_sampler = TunnelSampler(master, tcp_trace, args.tcp_peer_address, run_id, master_identity)

            lanes = {'source': (pixels, pixels.root)}
            processes = (browser, xvfb, host, master, peer, events)
            send(peer.stdin, 'static', run_id)
            events.expect('viewer_static_started', run_id)
            static = collect_phase('static', run, lanes, processes, SIZE[0], tile_top)
            events.expect('viewer_static_done', run_id, timeout=PIPE_TIMEOUT)
            raster = verify_geometry(pixels, pixels.root)
            write_capture(run / 'source-static-end.ppm', raster)
            if find_static_page(raster) != placement:
                raise RuntimeError('source browser layout changed before the motion click')

            initial = sample(pixels, pixels.root, SIZE[0], tile_top)[1]
            send(peer.stdin, 'motion', run_id)
            events.expect('viewer_motion_armed', run_id)
            subprocess.run(['xdotool', 'mousemove', '80', str(header_top + 30), 'click', '1', 'mousemove',
                            str(SIZE[0] - 5), str(SIZE[1] - 5)], env=dict(env, DISPLAY=display),
                           timeout=5, check=True)
            wait_motion(browser, pixels, pixels.root, (origin_x, tile_top), initial, 8)
            motion = collect_phase('motion', run, lanes, processes, SIZE[0], tile_top)
            write_capture(run / 'source-motion-end.ppm', verify_geometry(pixels, pixels.root))
            events.expect('viewer_motion_done', run_id, timeout=PIPE_TIMEOUT)
            stop_tcp_sampler(tcp_sampler, run)
            tcp_sampler = None
            send(peer.stdin, 'disconnect', run_id)
            events.expect('viewer_disconnected', run_id, timeout=25)
            peer.stdin.close()
            peer_status, host_status = peer.wait(timeout=8), host.wait(timeout=12)
            if peer_status or host_status:
                raise RuntimeError(f'endpoint did not close cleanly: peer={peer_status}, host={host_status}')
            monitor.join(timeout=4)
            if monitor.is_alive() or errors:
                raise RuntimeError(f'host stats did not close cleanly: {errors}')
            for phase in (static, motion):
                save_phase(run, phase, 'host')
        finally:
            original_error = sys.exc_info()[0]
            stop_tcp_sampler(tcp_sampler, run)
            stop(peer, natural=True)
            # Preserve the peer's private logs before closing the owned SSH master.
            try:
                fetch_viewer_artifacts(control, args.peer, remote_trial, run)
            except (OSError, subprocess.SubprocessError):
                (run / 'artifact-fetch-failure.log').write_text(traceback.format_exc())
                if original_error is None:
                    raise

    return summarize(run)


def summarize(run):
    scopes = {}
    for name in ('static', 'motion'):
        host = json.loads((run / f'{name}-scope.json').read_text())
        viewer = json.loads((run / 'viewer' / f'{name}-scope.json').read_text())
        scopes[name] = {'host': host, 'viewer': viewer}
    entries = [(name, endpoint_name, phase['telemetry']) for name, pair in scopes.items()
               for endpoint_name, phase in pair.items()]
    sessions = {session for _, _, stats in entries for session in stats['session_ids']}
    complete = len(sessions) == 1 and all(
        len(stats['session_ids']) == 1 and stats['window_seconds'] >= MEASURE_SECONDS
        and stats['frame_scopes_match_requested_jpeg']
        and (name == 'static' or stats['frame_scopes_observed'] > 0)
        for name, _, stats in entries)
    path = scopes['motion']
    host_routes = path['host']['telemetry']['routes']
    viewer_route = path['viewer']['telemetry']
    complete = (complete and bool(host_routes) and all(route.startswith('root/') for route in host_routes)
                and viewer_route['viewer_backends'] == ['x11'] and viewer_route['routes'] == ['rgb'])
    host = scopes['motion']['host']['samples']['source']
    viewer = scopes['motion']['viewer']['samples']['viewer']
    capable = host['unique_content_fps'] >= REQUESTED_FPS and host['scroll_changes_seen'] >= MEASURE_SECONDS
    result = {'scope': 'independent X11 software raster observations on separate machines over OpenSSH',
              'source_and_requested_viewer_dimensions': SIZE, 'codec': 'JPEG', 'jpeg_quality': 85,
              'authenticated_session_ids': sorted(sessions), 'telemetry_complete': complete,
              'source_motion_fps': host['unique_content_fps'], 'viewer_motion_fps': viewer['unique_content_fps'],
              'source_qualified': capable,
              'viewer_motion_gate_met': (viewer['unique_content_fps'] >= 0.9 * REQUESTED_FPS
                                         and viewer['scroll_changes_seen'] >= MEASURE_SECONDS)
                                        if capable and complete else None, 'phases': scopes}
    write_json(run / 'result.json', result)
    return {key: value for key, value in result.items() if key != 'phases'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_subparsers(dest='role', required=True)
    host = modes.add_parser('source')
    host.add_argument('--peer', required=True)
    host.add_argument('--remote-dir', required=True)
    host.add_argument('--release', default='/tmp/jwm-p08-p09-release/jwm-remote')
    host.add_argument('--remote-release', default='/tmp/jwm-p08-p09-release/jwm-remote')
    host.add_argument('--firefox', default='/usr/bin/firefox')
    host.add_argument('--trials', type=int, default=3)
    host.add_argument('--tcp-peer-address', type=ipaddress.ip_address,
                      help='observe the fresh master’s exact transport to this pinned address on port 22')
    viewer = modes.add_parser('viewer')
    for flag in ('run-dir', 'run-id', 'release'):
        viewer.add_argument(f'--{flag}', required=True)
    for flag in ('port', 'origin-x', 'tile-top'):
        viewer.add_argument(f'--{flag}', required=True, type=int)
    args = parser.parse_args()
    if args.role == 'viewer':
        try:
            viewer_worker(args)
        except Exception:
            with suppress(OSError):
                (Path(args.run_dir) / 'failure.log').write_text(traceback.format_exc())
            raise
        return
    if not re.fullmatch(r'/tmp/[A-Za-z0-9_.-]+', args.remote_dir):
        parser.error('remote-dir must be one private staged directory directly under /tmp')
    if not re.fullmatch(r'(?:[A-Za-z0-9_.-]+@)?[A-Za-z0-9.][A-Za-z0-9_.-]*', args.peer):
        parser.error('peer must be a pinned SSH hostname or user@hostname')
    if args.trials < 1:
        parser.error('trials must be positive')
    if args.tcp_peer_address and args.peer.rsplit('@', 1)[-1] != str(args.tcp_peer_address):
        parser.error('the diagnostic requires the SSH peer itself to be the pinned numeric address')
    args.release = str(Path(args.release).resolve(strict=True))
    fixture = json.loads((HERE / 'fixture-manifest.json').read_text())
    if sha256(HERE / 'browser-trial.html') != fixture['trial_sha256']:
        parser.error('the carried-over browser fixture digest differs')
    if args.tcp_peer_address and (sha256(HERE / 'firefox-profile-user.js') != CLEAN_PINS['firefox_profile_sha256']
                                  or sha256(args.release) != CLEAN_PINS['host_release_sha256']):
        parser.error('local release or browser profile differs from the clean Firefox pins')
    with open(LOCK, 'a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        batch = Path(tempfile.mkdtemp(prefix='dual.', dir=HERE))
        print(batch, flush=True)
        write_json(batch / 'manifest.json', {'workload': fixture, 'requested_trials': args.trials,
                   'diagnostic_batch': bool(args.tcp_peer_address) or args.trials < 3,
                   'passive_owned_ssh_tcp': bool(args.tcp_peer_address), 'requested_fps': REQUESTED_FPS,
                   'baseline_pins': CLEAN_PINS if args.tcp_peer_address else None,
                   'fixture_digests': {name: sha256(HERE / name) for name in (
                       'dual_browser.py', 'peer/dual_browser.py', 'run_baseline.py', 'processes.py',
                       'score.py', 'browser-trial.html', 'firefox-profile-user.js', 'ssh_tcp_sampler.py')
                       } if args.tcp_peer_address else None,
                   'dimensions': SIZE, 'warm_seconds': WARM_SECONDS, 'score_seconds': MEASURE_SECONDS,
                   'telemetry_tail_seconds': TAIL_SECONDS, 'transport': 'loopback-only OpenSSH -R',
                   'source': 'Mint Firefox source and original X11 capture policy',
                   'target': 'owned Ubuntu X11 viewer, JPEG at 1:1'})
        outcomes = []
        for index in range(1, args.trials + 1):
            run = batch / f'trial-{index:02}'
            try:
                outcomes.append({'trial': index, 'status': 'completed', 'result': run_source_trial(args, run)})
            except Exception as error:
                (run / 'failure.log').write_text(traceback.format_exc())
                outcomes.append({'trial': index, 'status': 'failed', 'error': str(error)})
            write_json(batch / 'outcomes.json', outcomes)
        if any(trial['status'] == 'failed' for trial in outcomes):
            raise SystemExit(1)


if __name__ == '__main__':
    main()
