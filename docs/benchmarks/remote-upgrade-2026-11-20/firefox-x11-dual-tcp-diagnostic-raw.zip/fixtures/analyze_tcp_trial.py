#!/usr/bin/env python3
"""Replay ROI and telemetry and attach passive SSH diagnostics by local clocks and frame sequence."""
import argparse
import json
from pathlib import Path

CLEAN_PINS = {'host_release_sha256': '5e1951ed8bbc23f41db5b5918931d91a37baa1e9fa213c8ef9067a214a1511e5', 'viewer_release_sha256': 'aaa1ed44223181963b3463fb169d56c9a76b31a514f29915f7ad5d47002690a3', 'firefox_sha256': 'ddf58d7cb36bd35e8e9dab7bc70ce31e17340ce87fc7c0fe81e495ccbd863965', 'firefox_profile_sha256': '5b6d7fa4a2fae76978dddd3835bf9ed330e53e125a5d20ad5d67e2817c7bd771'}
from score import MEASURE_SECONDS, SECOND, score_pixels

HOST_COUNTS = ('captured', 'sent', 'bytes', 'drawn_acks', 'viewer_superseded',
               'backpressure_skipped', 'outstanding', 'max_outstanding')
VIEW_COUNTS = ('received', 'decoded', 'drawn', 'acked', 'replaced')
TCP_COUNTS = ('bytes_sent', 'bytes_acked', 'bytes_received', 'bytes_retrans',
              'total_retransmissions', 'data_segs_out', 'data_segs_in')


def read(path):
    return json.loads(path.read_text())


def lines(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def single_session(result, identity):
    sessions = result.get('authenticated_session_ids', [])
    require(result.get('telemetry_complete') and result.get('source_qualified')
            and result.get('source_and_requested_viewer_dimensions') == [1920, 1080]
            and result.get('codec') == 'JPEG' and result.get('jpeg_quality') == 85 and len(sessions) == 1,
            'ineligible motion raster, telemetry or authenticated session')
    for role in ('host', 'viewer'):
        endpoint = identity[role]
        require(endpoint.get('clock') == 'CLOCK_MONOTONIC'
                and endpoint.get('drawable_size') == [1920, 1080], 'ineligible endpoint clock or drawable')
    require(identity['host']['boot_id_sha256'] != identity['viewer']['boot_id_sha256'], 'one-machine run')
    require(identity['host']['release_sha256'] == CLEAN_PINS['host_release_sha256']
            and identity['viewer']['release_sha256'] == CLEAN_PINS['viewer_release_sha256']
            and identity['host']['firefox']['binary_sha256'] == CLEAN_PINS['firefox_sha256'],
            'release or Firefox mismatch')
    return sessions[0]


def load_lane(directory, role, session):
    side = 'source' if role == 'host' else 'viewer'
    scope = read(directory / 'motion-scope.json')
    start, end = scope['score_start_monotonic_ns'], scope['score_end_monotonic_ns']
    require(scope['telemetry']['session_ids'] == [session] and end - start == MEASURE_SECONDS * SECOND,
            f'ineligible {role} phase')
    roi = lines(directory / 'motion-pixels.jsonl')
    require(all(row['side'] == side and row['start_monotonic_ns'] <= row['end_monotonic_ns'] for row in roi)
            and all(a['end_monotonic_ns'] < b['end_monotonic_ns'] for a, b in zip(roi, roi[1:])),
            f'{role} ROI crossed lane or clock')
    score = score_pixels(roi, start, end)
    require(score == scope['samples'][side], f'{role} raster score does not replay')
    windows = []
    for row in lines(directory / f'{role}-clocked-telemetry.jsonl'):
        data = row['record']
        finish = row['end_monotonic_ns']
        begin = finish - round(data['window_seconds'] * SECOND)
        if begin >= scope['telemetry_phase_end_monotonic_ns'] or finish <= scope['phase_start_monotonic_ns']:
            continue
        require(data['session_id'] == session and begin < finish, f'{role} telemetry changed session or time')
        frame = data.get('last_sent_frame' if role == 'host' else 'last_frame')
        if frame:
            require(frame['codec'] == 'JPEG' and frame['source_dimensions'] == [1920, 1080]
                    and frame['encoded_dimensions'] == [1920, 1080], f'{role} frame scope changed')
        stage_quantiles = {key: value['quantiles'] for key, value in data.get('stages', {}).items()
                           if isinstance(value, dict) and value.get('quantiles', {}).get('samples', 0) > 0}
        windows.append({'start_monotonic_ns': begin, 'end_monotonic_ns': finish, 'last_frame': frame,
                        'counts': {key: data.get(key) for key in (HOST_COUNTS if role == 'host' else VIEW_COUNTS)},
                        'stage_p95_ms': {key: value['p95_ms'] for key, value in stage_quantiles.items()},
                        'stage_quantile_samples': {key: value['samples'] for key, value in stage_quantiles.items()}})
    require(all(a['end_monotonic_ns'] < b['end_monotonic_ns'] for a, b in zip(windows, windows[1:])),
            f'{role} telemetry receipt clock did not increase')
    return start, end, roi, score, windows


def load_tcp(trial, identity):
    path = trial / 'ssh-tcp.jsonl'
    if not path.exists():
        return [], {'status': 'unrecorded'}
    manifest = read(trial.parent / 'manifest.json')
    require(manifest['diagnostic_batch'] and manifest['passive_owned_ssh_tcp']
            and manifest['baseline_pins'] == CLEAN_PINS, 'recorded TCP diagnostic pins are unavailable')
    all_rows = lines(path)
    require(all(row.get('schema_version') == 1 and row['run_id'] == identity['run_id'] for row in all_rows),
            'TCP records belong to another run or schema')
    samples = [row for row in all_rows if row['type'] == 'firefox_ssh_tcp_sample']
    routes = [row for row in all_rows if row['type'] == 'firefox_ssh_route']
    summaries = [row for row in all_rows if row['type'] == 'firefox_ssh_tcp_summary']
    if len(summaries) != 1:
        return [], {'status': 'missing_terminal_sampler_summary', 'partial_samples': len(samples)}
    summary, = summaries
    owned = identity['ssh_master']
    require((summary['ssh_pid'], summary['ssh_start_ticks'], summary['ssh_exe_device'], summary['ssh_exe_inode'])
            == (owned['pid'], owned['start_ticks'], owned['exe_device'], owned['exe_inode'])
            and summary['remote_port'] == 22 and summary['clock'] == 'monotonic',
            'TCP sampler identity differed from the owned master')
    require(all(row['socket_inode'] == summary['socket_inode'] for row in [*samples, *routes])
            and all(row['remote_port'] == summary['remote_port'] for row in samples)
            and all(summary['start_monotonic_ns'] <= row['start_monotonic_ns']
                    <= row['end_monotonic_ns'] <= summary['end_monotonic_ns'] for row in [*samples, *routes])
            and all(a['end_monotonic_ns'] < b['start_monotonic_ns'] for a, b in zip(samples, samples[1:])),
            'socket, port or local TCP clock scope changed')
    return samples, {'status': 'recorded' if samples else 'no_owned_samples', 'sample_count': len(samples),
                     'terminal_summary': summary, 'routes': routes,
                     'fixture_digests': manifest['fixture_digests']}


def counter_delta(rows, key):
    values = [(row.get('tcp_info') or {}).get(key) for row in rows]
    if len(values) < 2 or any(value is None for value in values) or any(a > b for a, b in zip(values, values[1:])):
        return None
    return values[-1] - values[0]


def sampled_ack_plateaus(points):
    """Locate consecutive unchanged-ACK snapshots with a nonempty sampled transmit queue."""
    plateaus = []
    first = previous = None
    for point in points:
        ack = (point.get('tcp_info') or {}).get('bytes_acked')
        queued = point['tx_queue_bytes'] > 0
        follows = (previous is not None
                   and point['start_monotonic_ns'] - previous['start_monotonic_ns'] < 2 * SECOND
                   and (previous.get('tcp_info') or {}).get('bytes_acked') == ack)
        if first is None or not queued or ack is None or not follows:
            if first is not None and first is not previous:
                plateaus.append((first, previous))
            first = point if queued and ack is not None else None
        previous = point
    if first is not None and first is not previous:
        plateaus.append((first, previous))
    plateaus.sort(key=lambda span: span[1]['end_monotonic_ns'] - span[0]['end_monotonic_ns'], reverse=True)
    return [{'first_monotonic_ns': first['end_monotonic_ns'],
             'last_monotonic_ns': last['end_monotonic_ns'],
             'unchanged_bytes_acked': first['tcp_info']['bytes_acked'],
             'observed_span_ms': (last['end_monotonic_ns'] - first['end_monotonic_ns']) / 1e6}
            for first, last in plateaus[:3]]


def tcp_progress(rows, start, end):
    points = [row for row in rows if start <= row['start_monotonic_ns'] <= row['end_monotonic_ns'] <= end]
    if not points:
        return {'samples': 0, 'span_ms': None, 'same_ack_with_pending_tx_observations': []}
    queues = lambda key: [row[key] for row in points]
    return {'samples': len(points), 'first_monotonic_ns': points[0]['start_monotonic_ns'],
            'last_monotonic_ns': points[-1]['end_monotonic_ns'],
            'span_ms': (points[-1]['end_monotonic_ns'] - points[0]['start_monotonic_ns']) / 1e6,
            'max_transmit_queue_bytes': max(queues('tx_queue_bytes')),
            'max_receive_queue_bytes': max(queues('rx_queue_bytes')),
            'tcp_deltas': {key: counter_delta(points, key) for key in TCP_COUNTS},
            'same_ack_with_pending_tx_observations': sampled_ack_plateaus(points)}


def epoch_sequence(window):
    frame = window['last_frame']
    if frame:
        return (frame['source_epoch'], frame['geometry_epoch']), frame['sequence']
    return None, None


def sequence_neighbors(host, view_window):
    epoch, sequence = epoch_sequence(view_window)
    if epoch is None:
        return {}
    matching = [(other_sequence, row) for row in host
                for other_epoch, other_sequence in (epoch_sequence(row),) if other_epoch == epoch]
    lower = next((row for seq, row in reversed(matching) if seq <= sequence), None)
    upper = next((row for seq, row in matching if seq >= sequence), None)
    return {'epoch': list(epoch), 'viewer_last_frame_sequence': sequence,
            'host_last_sent_at_or_below': lower, 'host_last_sent_at_or_above': upper}


def summarize_gap(a, b, roi, score, view, host):
    selected = [row for row in roi if a <= row['end_monotonic_ns'] <= b]
    timepoints = sorted({a, b, *(row['end_monotonic_ns'] for row in selected)})
    overlapping = [row for row in view if row['start_monotonic_ns'] < b and a < row['end_monotonic_ns']]
    return {'viewer_start_monotonic_ns': a, 'viewer_end_monotonic_ns': b, 'duration_ms': (b - a) / 1e6,
            'includes_score_boundary': a not in score['accepted_observations_monotonic_ns']
                                      or b not in score['accepted_observations_monotonic_ns'],
            'roi_reads': len(selected),
            'valid_tile_reads': sum(row['tile_x'] is not None for row in selected),
            'valid_scroll_reads': sum(row['scroll_text'] is not None for row in selected),
            'max_roi_sample_interval_ms': max((y - x for x, y in zip(timepoints, timepoints[1:])), default=0) / 1e6,
            'viewer_local_windows': overlapping,
            'host_links_by_application_sequence_only': [sequence_neighbors(host, row) for row in overlapping]}


def inspect(trial):
    identity = read(trial / 'identity.json')
    result = read(trial / 'result.json')
    session = single_session(result, identity)
    host_start, host_end, _, host_score, host = load_lane(trial, 'host', session)
    view_start, view_end, roi, score, view = load_lane(trial / 'viewer', 'viewer', session)
    samples, diagnostic = load_tcp(trial, identity)
    for row in host:
        row['owned_ssh_tcp_progress'] = tcp_progress(samples, row['start_monotonic_ns'], row['end_monotonic_ns'])
    points = [view_start, *score['accepted_observations_monotonic_ns'], view_end]
    gaps = sorted(zip(points, points[1:]), key=lambda gap: gap[1] - gap[0], reverse=True)[:3]
    clocks = {'host': [host_start, host_end], 'viewer': [view_start, view_end]}
    return {'run_id': identity['run_id'], 'session_id': session, 'seconds': MEASURE_SECONDS,
            'independent_local_score_intervals_monotonic_ns': clocks,
            'source_motion_fps': host_score['unique_content_fps'],
            'viewer_motion_fps': score['unique_content_fps'], 'viewer_empty_bins': score['zero_unique_bins'],
            'diagnostic': diagnostic, 'source_local_transport_progress': tcp_progress(samples, host_start, host_end),
            'source_local_application_telemetry': host,
            'longest_viewer_roi_gaps': [summarize_gap(a, b, roi, score, view, host) for a, b in gaps],
            'interpretation': [
                'TCP sample deltas stay on the host clock; viewer gaps and windows stay on the viewer clock.',
                'Host and viewer snapshots are associated only by same authenticated session and frame epochs/sequence.',
                'Window ends are local log receipts. Window overlaps and sequence bounds are coarse and are not per-frame events.',
                'TCP bytes_acked counts the encrypted SSH stream, including control channels. Host drawn_acks and viewer acked count JWM records.',
                'Missing or changing sampled counters and absent windows do not identify a cause. The sampler cannot locate a network hop.',
            ]}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('trial', type=Path)
    print(json.dumps(inspect(parser.parse_args().trial), indent=2))
