"""Replay interrupted diagnostic evidence from extracted files."""

import json

from pathlib import Path

import sys

import analyze_tcp_trial as analysis

from analyze_tcp_trial import read as from_json, require

REALTIME = 10**9

def json_lines(data):
    return [json.loads(line) for line in data.splitlines()]

def partial_motion(trial, samples, analysis):
    details = {}
    for role, prefix in (('host', trial), ('viewer', trial / 'viewer')):
        scope_file = prefix / 'motion-scope.json'
        roi = prefix / 'motion-pixels.jsonl'
        if not scope_file.is_file() or not roi.is_file():
            continue
        scope = from_json(scope_file)
        start, score, end, tail = [scope[f'{key}_monotonic_ns'] for key in
                                  ('phase_start', 'score_start', 'score_end', 'telemetry_phase_end')]
        require((score - start, end - score, tail - end) == (30 * REALTIME, 60 * REALTIME, 8 * REALTIME),
                'interrupted attempt requested the wrong phase scopes')
        rows = json_lines(roi.read_bytes())
        side = 'source' if role == 'host' else 'viewer'
        require(all(row['side'] == side and row['end_monotonic_ns'] >= start for row in rows),
                'interrupted observer rows crossed a local lane')
        selected = [row for row in rows if row['end_monotonic_ns'] < end]
        last = selected[-1]['end_monotonic_ns'] if selected else start
        details[role] = {'local_motion_start_monotonic_ns': start,
                         'last_observed_motion_monotonic_ns': last, 'raster_reads': len(rows),
                         'local_elapsed_from_phase_start_ms': (last - start) / 1e6,
                         'requested_measurement_end_monotonic_ns': end,
                         'completed_full_requested_motion_scope': 'observer_end_monotonic_ns' in scope}
        if role == 'viewer':
            telemetry = prefix / 'viewer-clocked-telemetry.jsonl'
            if telemetry.is_file():
                for row in json_lines(telemetry.read_bytes())[-3:]:
                    record = row['record']
                    finish = row['end_monotonic_ns']
                    if finish < start:
                        continue
                    details[role].setdefault('last_viewer_local_application_windows', []).append({
                        'local_window_end_from_motion_ms': (finish - start) / 1e6,
                        'session_id': record['session_id'],
                        'last_frame_sequence': (record.get('last_frame') or {}).get('sequence'),
                        'counts': {key: record.get(key) for key in ('received', 'decoded', 'drawn', 'acked')}
                    })
    if 'host' not in details or not samples:
        return details, None
    motion = details['host']
    start = motion['local_motion_start_monotonic_ns']
    points = [sample for sample in samples if start <= sample['start_monotonic_ns']]
    plateaus = analysis.sampled_ack_plateaus(points)
    if not plateaus:
        return details, None
    stop = plateaus[0]
    first, last = stop['first_monotonic_ns'], stop['last_monotonic_ns']
    records = [row for row in points if first <= row['end_monotonic_ns'] <= last]
    stop['sample_count'] = len(records)
    stop['motion_local_offsets_ms'] = [(stamp - start) / 1e6 for stamp in (first, last)]
    stop['observed_tx_queue_bytes_range'] = [
        min(entry['tx_queue_bytes'] for entry in records), max(entry['tx_queue_bytes'] for entry in records)]
    stop['tcp_retransmitted_bytes_delta'] = analysis.counter_delta(records, 'bytes_retrans')
    stop['total_retransmissions_delta'] = analysis.counter_delta(records, 'total_retransmissions')
    stop['peer_to_host_bytes_received_delta'] = analysis.counter_delta(records, 'bytes_received')
    for metric in ('cwnd', 'rto', 'snd_wnd', 'rtt_ms'):
        stop[f'{metric}_first_last'] = [records[0]['tcp_info'].get(metric), records[-1]['tcp_info'].get(metric)]
    # A source-local raster measurement inside the same TCP observation range.
    raster = [row for row in json_lines((trial / 'motion-pixels.jsonl').read_bytes())
              if first <= row['end_monotonic_ns'] <= last]
    tile_changes, previous = 0, None
    for row in raster:
        tile = row['tile_x']
        changed = tile is not None and previous is not None and abs(tile - previous) >= 2
        tile_changes += changed
        if changed or previous is None:
            previous = tile
    stop['source_raster_during_host_clock_interval'] = {
        'observations': len(raster), 'valid_tile_samples': sum(row['tile_x'] is not None for row in raster),
        'observed_distinct_tile_transitions': tile_changes}
    host_windows = []
    for row in json_lines((trial / 'host-clocked-telemetry.jsonl').read_bytes()):
        finish, app = row['end_monotonic_ns'], row['record']
        begin = finish - round(app['window_seconds'] * REALTIME)
        if begin < last and first <= finish:
            host_windows.append({'local_window_end_from_motion_ms': (finish - start) / 1e6,
                                 'window_seconds': app['window_seconds'],
                                 'session_id': app['session_id'], 'counts': {key: app.get(key) for key in
                                 ('sent', 'drawn_acks', 'backpressure_skipped', 'outstanding', 'max_outstanding')},
                                 'last_sent_sequence': (app.get('last_sent_frame') or {}).get('sequence')})
    stop['overlapping_host_local_application_windows'] = host_windows
    return details, stop

if __name__ == '__main__':
    path = Path(sys.argv[1])
    if (path / 'identity.json').is_file():
        samples, _ = analysis.load_tcp(path, from_json(path / 'identity.json'))
    else:
        samples = []
    motion, plateau = partial_motion(path, samples, analysis)
    print(json.dumps({'motion': motion, 'plateau': plateau}, indent=2))
