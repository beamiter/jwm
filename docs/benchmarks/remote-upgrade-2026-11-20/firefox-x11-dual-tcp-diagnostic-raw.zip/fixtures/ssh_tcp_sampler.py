"""Bounded, content-free Linux TCP observation for an owned OpenSSH tunnel."""
from collections import Counter
from dataclasses import dataclass
import ipaddress
import json
from pathlib import Path
import re
import struct
import subprocess
import threading
import time

SECOND = 1_000_000_000
MAX_SAMPLES = 300
INTEGER_FIELDS = ("bytes_sent", "bytes_acked", "bytes_received", "bytes_retrans", "segs_out",
                  "segs_in", "data_segs_out", "data_segs_in", "unacked", "lost", "sacked",
                  "notsent", "cwnd", "rto", "lastsnd", "lastrcv", "lastack",
                  "snd_wnd", "rcv_space")


def start_ticks(proc_pid):
    prefix, sep, suffix = (proc_pid / "stat").read_text().rpartition(") ")
    fields = suffix.split()
    if not sep or not prefix.startswith(f"{proc_pid.name} (") or len(fields) < 20 or fields[0] == "Z":
        raise RuntimeError("owned SSH process stat is unavailable")
    return int(fields[19])


def owned_inodes(proc_pid):
    owned = set()
    for fd in (proc_pid / "fd").iterdir():
        try:
            target = str(fd.readlink())
        except FileNotFoundError:
            continue
        match = re.fullmatch(r"socket:\[(\d+)\]", target)
        if match:
            owned.add(int(match[1]))
    return owned


def decode_endpoint(encoded):
    address, port = encoded.split(":")
    if len(address) not in (8, 32):
        raise ValueError("unrecognised /proc TCP endpoint")
    raw = b"".join(struct.pack("=I", int(address[index:index + 8], 16))
                   for index in range(0, len(address), 8))
    return str(ipaddress.ip_address(raw)), int(port, 16)


@dataclass(frozen=True)
class SocketIdentity:
    inode: int
    local: tuple
    remote: tuple


@dataclass(frozen=True)
class ProcSocket:
    identity: SocketIdentity
    tx_queue: int
    rx_queue: int


def parse_proc_tcp(text, inodes, remote_address, remote_port):
    found = []
    for line in text.splitlines()[1:]:
        fields = line.split()
        if len(fields) < 10 or fields[3] != "01" or int(fields[9]) not in inodes:
            continue
        remote = decode_endpoint(fields[2])
        if remote != (remote_address, remote_port):
            continue
        tx, rx = (int(number, 16) for number in fields[4].split(":"))
        identity = SocketIdentity(int(fields[9]), decode_endpoint(fields[1]), remote)
        found.append(ProcSocket(identity, tx, rx))
    return found


def find_owned_socket(proc_pid, remote_address, remote_port):
    sockets = owned_inodes(proc_pid)
    tcp = "tcp6" if ":" in remote_address else "tcp"
    candidates = parse_proc_tcp((proc_pid / "net" / tcp).read_text(), sockets, remote_address, remote_port)
    return candidates[0] if len(candidates) == 1 else None


def ss_command(identity):
    local, sport = identity.local
    remote, dport = identity.remote
    family = "-6" if ":" in remote else "-4"
    filters = f"( src {local} and sport = :{sport} and dst {remote} and dport = :{dport} )"
    return ["ss", family, "-tHnieO", "state", "established", filters]


def parse_ss(text, inode):
    lines = [line for line in text.splitlines() if re.search(rf"\bino:{inode}\b", line)]
    if len(lines) != 1:
        return None
    line = lines[0]
    data = {}
    for name in INTEGER_FIELDS:
        match = re.search(rf"(?<!\S){name}:(\d+)(?![\w./])", line)
        if match:
            data[name] = int(match[1])
    rtt = re.search(r"(?<!\S)rtt:([0-9.]+)/([0-9.]+)", line)
    if rtt:
        data["rtt_ms"], data["rttvar_ms"] = (float(value) for value in rtt.groups())
    retrans = re.search(r"(?<!\S)retrans:(\d+)(?:/(\d+))?", line)
    if retrans:
        data["retransmitting_now"] = int(retrans[1])
        if retrans[2] is not None:
            data["total_retransmissions"] = int(retrans[2])
    return data


def read_ss(identity):
    try:
        result = subprocess.run(ss_command(identity), capture_output=True, text=True, timeout=.65,
                                check=False)
    except (OSError, subprocess.TimeoutExpired):
        return None
    return parse_ss(result.stdout, identity.inode) if result.returncode == 0 else None


def classify_interface(device, root=Path("/sys/class/net")):
    if not device or Path(device).name != device or device in (".", ".."):
        return "unavailable"
    link = root / device
    try:
        hardware_type = (link / "type").read_text().strip()
        if hardware_type == "772":
            return "loopback"
        devtype = (link / "uevent").read_text()
        if (link / "wireless").is_dir() or "DEVTYPE=wlan" in devtype.splitlines():
            return "wireless"
        if "/devices/virtual/" in str(link.resolve()):
            return "virtual"
        return "ethernet_driver" if hardware_type == "1" else "other"
    except OSError:
        return "unavailable"


def parse_route(text, expected_source, root=Path("/sys/class/net")):
    routes = json.loads(text)
    if not isinstance(routes, list) or len(routes) != 1 or not isinstance(routes[0], dict):
        return {"status": "unavailable"}
    route = routes[0]
    declared_source = route.get("prefsrc") or route.get("from")
    source_matches = declared_source == expected_source if declared_source is not None else None
    return {"status": "observed", "source_matches_socket": source_matches,
            "interface_class": classify_interface(route.get("dev"), root),
            "gateway_present": bool(route.get("gateway") or route.get("via")),
            "route_type": route.get("type") if route.get("type") in ("local", "unicast") else None}


def read_route(identity):
    local, sport = identity.local
    remote, dport = identity.remote
    family = "-6" if ":" in remote else "-4"
    try:
        query = ["ip", "-j", family, "route", "get", remote, "from", local,
                 "ipproto", "tcp", "sport", str(sport), "dport", str(dport)]
        result = subprocess.run(query, capture_output=True, text=True, timeout=.65, check=False)
        if result.returncode == 0:
            return parse_route(result.stdout, local)
    except (OSError, ValueError, subprocess.TimeoutExpired):
        pass
    return {"status": "unavailable"}


class TunnelSampler:
    def __init__(self, process, output, remote_address, run_id, master_identity, remote_port=22, *,
                 proc=Path("/proc"), clock=time.monotonic_ns, query=read_ss, route=read_route):
        self.process = process
        self.proc_root = proc
        self.run_id = run_id
        self.master_identity = master_identity
        self.route = route
        self.proc_pid = proc / str(process.pid)
        self.output = output
        self.remote_address = str(ipaddress.ip_address(remote_address))
        self.port = remote_port
        self.clock = clock
        self.query = query
        self.cancel = threading.Event()
        self.worker = threading.Thread(target=self.run, daemon=True)
        self.worker.start()

    def write(self, data):
        self.output.write(json.dumps({"run_id": self.run_id, **data}, separators=(",", ":")) + "\n")
        self.output.flush()

    def check_process(self):
        if self.process.poll() is not None or start_ticks(self.proc_pid) != self.master_identity["start_ticks"]:
            return False
        executable = (self.proc_pid / "exe").stat()
        return (executable.st_dev, executable.st_ino) == (self.master_identity["exe_device"],
                                                          self.master_identity["exe_inode"])

    def sample(self, pinned):
        if not self.check_process():
            raise RuntimeError("owned SSH identity changed")
        sample_start = self.clock()
        observed = find_owned_socket(self.proc_pid, self.remote_address, self.port)
        if observed is None:
            return pinned, "owned_tcp_socket_unavailable"
        if pinned is not None and observed.identity != pinned:
            raise RuntimeError("owned SSH socket changed")
        info = self.query(observed.identity)
        sample_end = self.clock()
        if not self.check_process() or observed.identity.inode not in owned_inodes(self.proc_pid):
            raise RuntimeError("owned SSH identity changed during sampling")
        self.write({
            "type": "firefox_ssh_tcp_sample", "schema_version": 1,
            "start_monotonic_ns": sample_start, "end_monotonic_ns": sample_end,
            "socket_inode": observed.identity.inode, "remote_port": self.port,
            "tx_queue_bytes": observed.tx_queue, "rx_queue_bytes": observed.rx_queue,
            "tcp_info": info,
        })
        return observed.identity, "tcp_info" if info else "queue_only"

    def record_route(self, identity, purpose):
        began = self.clock()
        if not self.check_process() or identity.inode not in owned_inodes(self.proc_pid):
            raise RuntimeError("owned SSH identity changed before route lookup")
        own_net = (self.proc_root / "self" / "ns" / "net").stat()
        master_net = (self.proc_pid / "ns" / "net").stat()
        same_net = (own_net.st_dev, own_net.st_ino) == (master_net.st_dev, master_net.st_ino)
        selected = self.route(identity) if same_net else {"status": "different_network_namespace"}
        if not self.check_process() or identity.inode not in owned_inodes(self.proc_pid):
            raise RuntimeError("owned SSH identity changed during route lookup")
        self.write({"type": "firefox_ssh_route", "schema_version": 1, "stage": purpose,
                    "start_monotonic_ns": began, "end_monotonic_ns": self.clock(),
                    "socket_inode": identity.inode, "netns_matches_master": same_net,
                    "address_family": "ipv6" if ":" in identity.remote[0] else "ipv4",
                    "selected": selected})

    def run(self):
        began = self.clock()
        counts = Counter()
        pinned = None
        reason = "closed"
        skipped = 0
        try:
            if self.master_identity["pid"] != self.process.pid or not self.check_process():
                raise RuntimeError("original SSH identity did not match")
            slot = 0
            while slot < MAX_SAMPLES and not self.cancel.is_set():
                current = (self.clock() - began) // SECOND
                if current > slot:
                    skipped += min(current, MAX_SAMPLES) - slot
                    if current >= MAX_SAMPLES:
                        break
                    slot = current
                if self.process.poll() is not None:
                    reason = "process_ended"
                    break
                previous = pinned
                pinned, status = self.sample(pinned)
                counts[status] += 1
                if previous is None and pinned is not None:
                    self.record_route(pinned, "first_socket")
                slot += 1
                due = began + slot * SECOND
                self.cancel.wait(max((due - self.clock()) / SECOND, 0))
            if slot >= MAX_SAMPLES:
                reason = "sample_bound"
            if pinned is not None and self.process.poll() is None:
                self.record_route(pinned, "sampling_end")
        except (OSError, RuntimeError, ValueError):
            reason = "owned_socket_identity_or_proc_unavailable"
        finally:
            self.write({
                "type": "firefox_ssh_tcp_summary", "schema_version": 1, "clock": "monotonic",
                "ssh_pid": self.process.pid, "ssh_start_ticks": self.master_identity["start_ticks"],
                "ssh_exe_device": self.master_identity["exe_device"],
                "ssh_exe_inode": self.master_identity["exe_inode"],
                "socket_inode": pinned.inode if pinned else None, "remote_port": self.port,
                "start_monotonic_ns": began, "end_monotonic_ns": self.clock(),
                "interval_seconds": 1, "max_sample_slots": MAX_SAMPLES, "missed_slots": skipped,
                "counts": dict(counts), "end_reason": reason,
            })

    def stop(self):
        self.cancel.set()
        self.worker.join(timeout=4)
        if self.worker.is_alive():
            raise RuntimeError("owned SSH TCP sampler did not finish")
