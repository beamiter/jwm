#!/usr/bin/env python3
"""Independently replay and archive a terminal local Workbench raster batch."""
import argparse
from collections import Counter
from itertools import groupby
import hashlib
import json
import math
from pathlib import Path
import re
import zipfile

SECOND = 1_000_000_000
PHASES = ('static', 'motion')
ROLES = ('host', 'viewer')
SIDES = ('source', 'viewer')
SIZE = (960, 640)
ARCHIVE_FILES = {
    'result.json', 'failure.log', 'workbench-view.json', 'workbench-static-state.json',
    'workbench-initial-oracle.json', 'blender-window.log', 'blender-positioned.log',
    'viewer-window.log', 'blender-stdout.log', 'blender-stderr.log', 'source-xvfb.log',
    'viewer-xvfb.log', 'disconnect.log', 'source-static.ppm', 'viewer-static.ppm',
    'source-motion-end.ppm', 'viewer-motion-end.ppm',
    *(f'{role}-clocked-telemetry.jsonl' for role in ROLES),
    *(f'{name}-{key}' for name in PHASES for key in ('scope.json', 'pixels.jsonl', 'host.jsonl', 'viewer.jsonl')),
}


class InvalidEvidence(Exception):
    pass


def require(condition, detail):
    if not condition:
        raise InvalidEvidence(detail)


def one(path):
    return json.loads(path.read_bytes())


def lines(path):
    with path.open() as handle:
        return [json.loads(line) for line in handle if line.strip()]


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def replay_samples(observations, start, end):
    # The independent evaluator never imports the live producer or its scorer.
    start_previous = None
    observed = []
    rejected = 0
    measured = 0
    slowest_read_ns = 0
    for row in observations:
        stamp = row['end_monotonic_ns']
        if stamp >= end:
            break
        in_interval = stamp >= start
        center = row['cube_span']['center_x'] if row['cube_span'] is not None else None
        if in_interval:
            measured += 1
            slowest_read_ns = max(slowest_read_ns, stamp - row['start_monotonic_ns'])
            rejected += center is None
        if center is None:
            continue
        if start_previous is None:
            start_previous = center
        elif abs(center - start_previous) >= 2:
            start_previous = center
            if in_interval:
                observed.append(stamp)
    counts = Counter((stamp - start) // SECOND for stamp in observed)
    bins = [counts[second] for second in range(60)]
    samples = [start] + observed + [end]
    intervals = sorted(follow - previous for previous, follow in zip(samples, samples[1:]))
    return {'distinct_mesh_positions': len(observed), 'unique_content_fps': len(observed) / 60,
            'one_second_unique_bins': bins, 'zero_unique_bins': bins.count(0), 'reads': measured,
            'invalid_mesh_reads': rejected, 'observer_max_read_ms': slowest_read_ns / 1e6,
            'gap_ms': {'p95': intervals[math.ceil(len(intervals) * .95) - 1] / 1e6,
                       'max': intervals[-1] / 1e6}, 'accepted_monotonic_ns': observed}


def raster_span(path, viewport, scan_row):
    data = path.read_bytes()
    header = b'P6\n960 640\n255\n'
    require(data.startswith(header) and len(data) == len(header) + 960 * 640 * 3,
            f'{path.name}: unexpected snapshot size or format')
    x, _, width, _ = viewport
    spans = []
    for row in range(scan_row - 1, scan_row + 2):
        begin = len(header) + (row * 960 + x) * 3
        region = data[begin:begin + 3 * width]
        red = [r >= 75 and r >= g + 34 and r >= b + 42 for r, g, b in zip(region[::3], region[1::3], region[2::3])]
        groups = ([idx for idx, _ in run] for colored, run in groupby(enumerate(red), lambda pair: pair[1]) if colored)
        longest = max(groups, key=len, default=[])
        if len(longest) >= 14:
            spans.append((x + longest[0], x + longest[-1]))
    require(len(spans) >= 2, f'{path.name}: no qualifying red mesh span on at least two scanlines')
    spans.sort(key=sum)
    first, last = spans[len(spans) // 2]
    return {'left': first, 'right': last, 'center_x': (first + last) // 2}


def inspect_route(trial):
    state = one(trial / 'workbench-static-state.json')
    current = one(trial / 'workbench-view.json')
    oracle = one(trial / 'workbench-initial-oracle.json')
    viewport = state['viewport']
    x, y, width, height = viewport
    scan_row = oracle['scan_row']
    expected = {'scene': 'jwm-workbench-cube-v1', 'application_version': '4.5.16 LTS',
                'build_hash': '3f6797307da5', 'render_engine': 'BLENDER_WORKBENCH',
                'shading': 'SOLID', 'camera': 'CAMERA', 'window_size': list(SIZE), 'timeline_fps': 60}
    require(all(state[k] == v and current[k] == v for k, v in expected.items()), 'application, scene or camera route mismatch')
    require(any(item in state['renderer'].lower() for item in ('llvmpipe', 'softpipe'))
            and current['renderer'] == state['renderer'], 'software GL route changed or was unavailable')
    require(state['playing'] is False and state['frame'] == 1 and current['playing'] is True
            and current['playback_requested'] is True and current['frame'] > 1,
            'app report does not prove static initialization and subsequent playback')
    require(current['viewport'] == viewport and 0 <= x and 0 <= y and width >= 200 and height >= 200
            and x + width <= SIZE[0] and y + height <= SIZE[1] and y + 1 <= scan_row < y + height - 1,
            'Blender viewport moved or raster crop is out of bounds')
    for name, title in [('blender-positioned.log', 'Blender'), ('viewer-window.log', 'JWM Remote')]:
        require(any(title in line and re.search(r'\b960x640\+0\+0(?: |$)', line)
                    for line in (trial / name).read_text().splitlines()), f'owned 1:1 X11 geometry missing in {name}')
    still = {side: raster_span(trial / f'{side}-static.ppm', viewport, scan_row) for side in SIDES}
    motion = {side: raster_span(trial / f'{side}-motion-end.ppm', viewport, scan_row) for side in SIDES}
    require(all(abs(still[side]['center_x'] - oracle[f'{side}_span']['center_x']) <= 4 for side in SIDES)
            and abs(still['source']['center_x'] - still['viewer']['center_x']) <= 4,
            'static visible mesh position disagrees between the archived raster and observer')
    return {'application_start': state, 'application_last': current, 'scan_row': scan_row,
            'static_mesh_spans': still, 'motion_end_mesh_spans': motion}


def select_windows(trial, phase, role, start, tail):
    retained = []
    last_end = 0
    for item in lines(trial / f'{role}-clocked-telemetry.jsonl'):
        end = item['end_monotonic_ns']
        record = item['record']
        require(type(end) is int and end > last_end, f'{role} telemetry is out of order')
        require(record['type'] == f'jwm_remote_{role}_stats' and not record.get('final'),
                f'{role} clocked stream contains an unrelated or final record')
        last_end = end
        duration = record['window_seconds']
        require(type(duration) in (int, float) and duration > 0 and math.isfinite(duration),
                f'{role} telemetry window has invalid duration')
        if end - round(duration * SECOND) >= start and end <= tail:
            retained.append(record)
    selected_path = trial / f'{phase}-{role}.jsonl'
    exact_selection = selected_path.is_file() and retained == lines(selected_path)
    frame_key = 'last_sent_frame' if role == 'host' else 'last_frame'
    route_key = 'mode' if role == 'host' else 'last_presentation_path'
    frames = [r[frame_key] for r in retained if r.get(frame_key)]
    routes = sorted({r[route_key] for r in retained if r.get(route_key)})
    session_ids = sorted({r['session_id'] for r in retained if r.get('session_id')})
    dims_match = all(f['source_dimensions'] == list(SIZE) and f['encoded_dimensions'] == list(SIZE)
                     and f['codec'] == 'JPEG' for f in frames)
    route_ok = (bool(routes) and all(route.startswith('root/') for route in routes)) if role == 'host' else (
        routes == ['rgb'] and all(r['negotiated_codec'] == 'JPEG' for r in retained))
    valid_sessions = all(re.fullmatch(r'[0-9a-f]{32}', r.get('session_id') or '') for r in retained)
    seconds = sum(r['window_seconds'] for r in retained)
    progress = {key: sum(r.get(key, 0) for r in retained)
                for key in (('captured', 'sent', 'drawn_acks', 'bytes') if role == 'host' else ('received', 'decoded', 'drawn', 'acked'))}
    observed_epochs = sorted({(r['source_epoch'], r['geometry_epoch']) for r in frames})
    return {'window_seconds': seconds, 'whole_windows': len(retained), 'session_ids': session_ids, 'actual_routes': routes,
            'frames_with_scope': len(frames), 'frame_scopes_match_960x640_jpeg': dims_match, 'source_geometry_epochs': observed_epochs,
            'retained_windows_exact_match': exact_selection, 'progress': progress,
            'valid': exact_selection and seconds >= 60 and len(session_ids) == 1 and valid_sessions and dims_match and route_ok}


def inspect_phase(trial, phase, viewport, reported):
    scope = one(trial / f'{phase}-scope.json')
    tick, start, end, tail = (scope[key] for key in ('phase_start_monotonic_ns', 'score_start_monotonic_ns',
                                                    'score_end_monotonic_ns', 'telemetry_phase_end_monotonic_ns'))
    require(all(type(stamp) is int for stamp in (tick, start, end, tail)) and start - tick == 30 * SECOND
            and end - start == 60 * SECOND and tail - end == 8 * SECOND and scope['phase'] == phase,
            f'{phase}: wrong clock interval')
    by_side = {side: [] for side in SIDES}
    last_end = tick
    for row in lines(trial / f'{phase}-pixels.jsonl'):
        before, after, side = row['start_monotonic_ns'], row['end_monotonic_ns'], row['side']
        require(type(before) is int and type(after) is int and last_end <= before <= after and side in by_side,
                f'{phase}: invalid raw sample order or role')
        last_end = after
        span = row['cube_span']
        if span is not None:
            l, m, r = (span[k] for k in ('left', 'center_x', 'right'))
            require(all(type(p) is int for p in (l, m, r)) and viewport[0] <= l <= r < viewport[0] + viewport[2]
                    and r - l + 1 >= 14 and m == (l + r) // 2, f'{phase}: invalid observed raster span')
        by_side[side].append(row)
    values = {}
    qualified_observation = True
    scope_replayed = reported is not None and all(reported.get(key) == scope[key] for key in (
        'phase_start_monotonic_ns', 'score_start_monotonic_ns', 'score_end_monotonic_ns',
        'telemetry_phase_end_monotonic_ns'))
    for side, rows in by_side.items():
        covers = bool(rows and rows[0]['end_monotonic_ns'] < start <= end <= rows[-1]['end_monotonic_ns'])
        score = replay_samples(rows, start, end)
        scope_match = scope.get('samples', {}).get(side) == score
        result_match = reported is not None and reported['samples'][side] == score
        qualified_observation &= covers and score['reads'] > 0
        scope_replayed &= scope_match and result_match
        values[side] = {key: val for key, val in score.items() if key != 'accepted_monotonic_ns'}
        values[side].update(covers_score_interval=covers, scope_samples_match=scope_match, result_samples_match=result_match)
    telemetry = {role: select_windows(trial, phase, role, start, tail) for role in ROLES}
    return {'phase': phase, 'warmup_seconds': 30, 'measurement_seconds': 60,
            'start_monotonic_ns': start, 'end_monotonic_ns': end, 'tail_end_monotonic_ns': tail,
            'observer_covers_both_intervals': qualified_observation, 'exact_score_replay': scope_replayed,
            'samples': values, 'telemetry': telemetry}


def inspect_trial(trial, number, outcome):
    report = {'trial': number, 'controller_outcome': outcome, 'validation_errors': [], 'phases': []}
    errors = report['validation_errors']
    if (trial / 'key').exists():
        errors.append('private key file was not cleaned up; contents excluded from archive')
    try:
        result = one(trial / 'result.json')
        report['route'] = inspect_route(trial)
        if not (result['resolution'] == list(SIZE) and result['requested_fps'] == 30 and result['codec'] == 'fixed JPEG 85'):
            errors.append('unexpected local result configuration')
    except (InvalidEvidence, OSError, ValueError, KeyError, TypeError) as error:
        result = None
        errors.append(str(error))
    try:
        viewport = one(trial / 'workbench-static-state.json')['viewport']
    except (OSError, ValueError, KeyError):
        viewport = None
    for phase in PHASES:
        if viewport is None or not (trial / f'{phase}-scope.json').is_file():
            errors.append(f'{phase}: no recorded viewport or scope')
            continue
        recorded = next((r for r in result['phases'] if r['phase'] == phase), None) if result else None
        try:
            replay = inspect_phase(trial, phase, viewport, recorded)
        except (InvalidEvidence, OSError, ValueError, KeyError, TypeError) as error:
            errors.append(str(error))
            continue
        report['phases'].append(replay)
        if not replay['observer_covers_both_intervals'] or not replay['exact_score_replay']:
            errors.append(f'{phase}: incomplete or different observer replay')
    report['motion_gate'] = None
    if len(report['phases']) == 2:
        static, motion = report['phases']
        if static['tail_end_monotonic_ns'] > motion['start_monotonic_ns'] - 30 * SECOND:
            errors.append('static and motion intervals overlap')
        telemetry = [item for phase in report['phases'] for item in phase['telemetry'].values()]
        sessions = {item for lane in telemetry for item in lane['session_ids']}
        epochs = {pair for lane in telemetry for pair in lane['source_geometry_epochs']}
        active = motion['telemetry']
        report['telemetry_verified'] = (all(lane['valid'] for lane in telemetry) and len(sessions) == 1 and len(epochs) == 1
                                        and all(role['frames_with_scope'] > 0 for role in active.values())
                                        and active['host']['progress']['drawn_acks'] > 0 and active['viewer']['progress']['drawn'] > 0)
        report['session_id'] = next(iter(sessions)) if len(sessions) == 1 else None
        report['static_idle_verified'] = all(lane['distinct_mesh_positions'] == 0 and lane['reads'] > lane['invalid_mesh_reads']
                                             for lane in static['samples'].values())
        source, viewer = (motion['samples'][side] for side in SIDES)
        source_qualified = source['distinct_mesh_positions'] >= 1800
        viewer_gate = viewer['distinct_mesh_positions'] >= 1620 if source_qualified else None
        report['source_qualified'] = source_qualified
        report['motion_gate'] = viewer_gate
        if not report['telemetry_verified']:
            errors.append('incomplete, mismatched or wrong-route typed telemetry')
        if result is not None and (result['source_qualified_for_viewer_gate'] != source_qualified
                                   or result['viewer_motion_gate_met'] != viewer_gate
                                   or result['telemetry_complete'] != report['telemetry_verified']):
            errors.append('controller gate or telemetry result differs from independent replay')
    if outcome is None or outcome.get('status') != 'completed':
        report['status'] = 'recorded_failure' if outcome and outcome.get('status') == 'failed' else 'missing_controller_outcome'
    elif errors:
        report['status'] = 'invalid_evidence'
    elif report['motion_gate'] is None:
        report['status'] = 'source_unqualified'
    elif report['motion_gate'] is False:
        report['status'] = 'qualified_gate_miss'
    else:
        report['status'] = 'qualified_gate_pass'
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--batch', type=Path, required=True)
    parser.add_argument('--runner-pid', type=int, required=True)
    parser.add_argument('--out-dir', type=Path, required=True)
    args = parser.parse_args()
    with_runner = Path(f'/proc/{args.runner_pid}/cmdline')
    try:
        if b'run_workbench.py' in with_runner.read_bytes():
            parser.error('the Workbench runner is still live; do not archive an active batch')
    except FileNotFoundError:
        pass
    batch = args.batch.resolve(strict=True)
    manifest = one(batch / 'manifest.json')
    outcomes_path = batch / 'outcomes.json'
    outcome_rows = one(outcomes_path) if outcomes_path.is_file() else []
    outcomes = {item['trial']: item for item in outcome_rows}
    scene = batch.parent / 'workbench_scene.py'
    scene_matches = scene.is_file() and sha(scene) == manifest['scene_sha256']
    release = Path(manifest['release'])
    release_matches = release.is_file() and sha(release) == manifest['release_sha256']
    reports = [inspect_trial(batch / f'trial-{i:02}', i, outcomes.get(i))
               for i in range(1, manifest['attempted_trials'] + 1)]
    session_counts = Counter(trial.get('session_id') for trial in reports if trial.get('session_id'))
    for trial in reports:
        if session_counts[trial.get('session_id')] > 1:
            trial['validation_errors'].append('authenticated session was reused by another trial')
            trial['status'] = 'invalid_evidence'
    output = args.out_dir
    output.mkdir(mode=0o700)
    report_path = output / 'x11-blender-workbench-baseline.json'
    report = {'schema_version': 1, 'scope': 'single-machine isolated X11 software Workbench pixel baseline',
              'manifest': manifest, 'scene_hash_verified': scene_matches, 'release_hash_verified': release_matches,
              'trial_status_counts': dict(Counter(row['status'] for row in reports)), 'trials': reports}
    report_path.write_text(json.dumps(report, indent=2) + '\n')
    archive_path = output / 'x11-blender-workbench-raw.zip'
    with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=4) as archive:
        for path in (batch / 'manifest.json', outcomes_path):
            if path.is_file():
                archive.write(path, path.name)
        if scene_matches:
            archive.write(scene, 'fixture/workbench_scene.py')
        for name in ('run_workbench.py', 'x11_session.py', 'processes.py'):
            path = batch.parent / name
            if path.is_file() and not path.is_symlink():
                archive.write(path, f'fixture/{name}')
        archive.write(Path(__file__), 'fixture/validate_archive.py')
        for number in range(1, manifest['attempted_trials'] + 1):
            trial = batch / f'trial-{number:02}'
            for name in sorted(ARCHIVE_FILES):
                candidate = trial / name
                if candidate.is_file() and not candidate.is_symlink():
                    archive.write(candidate, f'{trial.name}/{name}')
        archive.write(report_path, report_path.name)
    with zipfile.ZipFile(archive_path) as archive:
        require(archive.testzip() is None, 'raw archive integrity check failed')
    print(json.dumps({'report': str(report_path), 'archive': str(archive_path), 'archive_sha256': sha(archive_path),
                      'scene_hash_verified': scene_matches, 'release_hash_verified': release_matches,
                      'trial_status_counts': report['trial_status_counts']}))
    if not scene_matches or not release_matches or any(
            row['status'] in {'invalid_evidence', 'missing_controller_outcome'} for row in reports):
        raise SystemExit(1)


if __name__ == '__main__':
    main()
