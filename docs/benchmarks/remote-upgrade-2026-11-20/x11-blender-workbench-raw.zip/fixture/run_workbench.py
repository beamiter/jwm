#!/usr/bin/env python3
"""Observe an actual Blender Workbench viewport on two owned Xvfb displays."""
import argparse
from contextlib import ExitStack
import fcntl
import hashlib
import json
import math
from pathlib import Path
import re
import subprocess
import tempfile
import time
import traceback

from processes import clean_env, get_display, start_display, stop, wait_for
from x11_session import (Pixels, monitor_stderr, select_telemetry, stop_group,
                         wait_for_window, write_capture)

HERE = Path(__file__).resolve().parent
BLENDER = '/tmp/jwm-blender-acceptance.VR4FQlr0/blender-4.5.16-linux-x64/blender'
RELEASE = '/tmp/jwm-p08-p09-release/jwm-remote'
SCENE = HERE / 'workbench_scene.py'
WIDTH, HEIGHT = 960, 640
SECOND = 1_000_000_000
REQUESTED_FPS = 30
POLL_HZ = 90


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def red_span(row):
    """Longest connected saturated-red mesh run in this row."""
    start = None
    best = None
    for x, (b, g, r) in enumerate(zip(row[0::4], row[1::4], row[2::4])):
        if r >= 75 and r - g >= 34 and r - b >= 42:
            if start is None:
                start = x
            if best is None or x - start > best[1] - best[0]:
                best = start, x
        else:
            start = None
    return best if best and best[1] - best[0] + 1 >= 14 else None


def locate_cube_row(rows, viewport):
    x, y, width, height = viewport
    # The startup scene keeps the cube centered vertically. The center of its
    # actual painted red components, not a hard-coded screen y, defines the ROI.
    run = []
    best = []
    for row in range(y + height // 4, y + 3 * height // 4, 3):
        if red_span(rows[row][x * 4:(x + width) * 4]) is not None:
            run.append(row)
            if len(run) > len(best):
                best = run.copy()
        else:
            run = []
    return best[len(best) // 2] if len(best) >= 8 else None


def read_cube(pixels, xid, viewport, scan_row):
    x, _, width, _ = viewport
    rows = pixels.crop(xid, x, scan_row - 1, width, 3)
    spans = sorted((span for row in rows if (span := red_span(row)) is not None),
                   key=lambda edges: sum(edges))
    if len(spans) < 2:
        return None
    left, right = spans[len(spans) // 2]
    return {'center_x': x + (left + right) // 2, 'left': x + left, 'right': x + right}


def score_pixels(rows, start, end):
    bins = [0] * ((end - start) // SECOND)
    previous = None
    invalid = samples = max_read = 0
    stamps = []
    for row in rows:
        stamp = row['end_monotonic_ns']
        if stamp >= end:
            break
        active = stamp >= start
        span = row['cube_span']
        if active:
            samples += 1
            max_read = max(max_read, stamp - row['start_monotonic_ns'])
            invalid += span is None
        if span is None:
            continue
        current = span['center_x']
        if previous is None:
            previous = current
        elif abs(current - previous) >= 2:
            previous = current
            if active:
                bins[(stamp - start) // SECOND] += 1
                stamps.append(stamp)
    points = [start, *stamps, end]
    gaps = sorted((b - a) / 1e6 for a, b in zip(points, points[1:]))
    return {'distinct_mesh_positions': len(stamps), 'unique_content_fps': len(stamps) / len(bins),
            'one_second_unique_bins': bins, 'zero_unique_bins': bins.count(0),
            'reads': samples, 'invalid_mesh_reads': invalid, 'observer_max_read_ms': max_read / 1e6,
            'gap_ms': {'p95': gaps[math.ceil(.95 * len(gaps)) - 1], 'max': gaps[-1]},
            'accepted_monotonic_ns': stamps}


def collect_phase(run_dir, name, lanes, state_path, viewport, scan_row, processes, warm, seconds, tail):
    phase_start = time.monotonic_ns()
    start = phase_start + warm * SECOND
    end = start + seconds * SECOND
    deadline = end + tail * SECOND
    phase = {'phase': name, 'phase_start_monotonic_ns': phase_start, 'score_start_monotonic_ns': start,
             'score_end_monotonic_ns': end, 'telemetry_phase_end_monotonic_ns': deadline}
    path = run_dir / f'{name}-scope.json'
    write_json(path, phase)
    rows = {side: [] for side in lanes}
    slot = last_health_check = 0
    with (run_dir / f'{name}-pixels.jsonl').open('w') as log:
        while (now := time.monotonic_ns()) < deadline:
            if now - last_health_check >= SECOND:
                state = json.loads(state_path.read_text())
                if (any(proc.poll() is not None for proc in processes) or state['viewport'] != list(viewport)
                        or state['playing'] != (name == 'motion')):
                    raise RuntimeError(f'{name} lost its owned process, viewport or playback state: {state}')
                last_health_check = now
            for side, (pixels, xid) in lanes.items():
                before = time.monotonic_ns()
                span = read_cube(pixels, xid, viewport, scan_row)
                sample = {'side': side, 'start_monotonic_ns': before, 'end_monotonic_ns': time.monotonic_ns(),
                          'cube_span': span}
                rows[side].append(sample)
                print(json.dumps(sample, separators=(',', ':')), file=log)
            slot = max(slot + 1, (time.monotonic_ns() - phase_start) * POLL_HZ // SECOND + 1)
            due = min(deadline, phase_start + slot * SECOND // POLL_HZ)
            time.sleep(max(0, (due - time.monotonic_ns()) / SECOND))
    phase['samples'] = {side: score_pixels(samples, start, end) for side, samples in rows.items()}
    write_json(path, phase)
    return phase


def run(args, directory):
    directory.mkdir(mode=0o700)
    print(f'Workbench trial: {directory}', flush=True)
    runtime, config = directory / 'runtime', directory / 'blender-config'
    runtime.mkdir(mode=0o700)
    config.mkdir(mode=0o700)
    report, start_playback = directory / 'workbench-view.json', directory / 'start-playback'
    env = clean_env()
    env.update(XDG_RUNTIME_DIR=str(runtime), XDG_SESSION_TYPE='x11')
    size = f'{WIDTH}x{HEIGHT}'
    with ExitStack() as stack:
        def log(name):
            return stack.enter_context((directory / name).open('wb'))

        displays = []
        for side in ('source', 'viewer'):
            server = start_display(WIDTH, HEIGHT, log(f'{side}-xvfb.log'))
            stack.callback(stop, server)
            displays.append(get_display(server))
        source_display, viewer_display = displays
        blender_env = dict(env, DISPLAY=source_display, GDK_BACKEND='x11', LIBGL_ALWAYS_SOFTWARE='1',
                           BLENDER_USER_RESOURCES=str(config), BLENDER_USER_CONFIG=str(config),
                           JWM_WORKBENCH_REPORT=str(report), JWM_WORKBENCH_START=str(start_playback))
        blender_env.pop('EGL_PLATFORM', None)
        app = subprocess.Popen(['dbus-run-session', '--', args.blender, '--factory-startup',
                                '--disable-autoexec', '--window-geometry', '0', '0', str(WIDTH), str(HEIGHT),
                                '--python', str(SCENE)], env=blender_env, stdout=log('blender-stdout.log'),
                               stderr=log('blender-stderr.log'), start_new_session=True)
        stack.callback(stop_group, app)
        source = wait_for_window(app, source_display, 'Blender', env, directory / 'blender-window.log', 30)
        subprocess.run(['xdotool', 'windowmove', str(source), '0', '0', 'windowsize', str(source),
                        str(WIDTH), str(HEIGHT)], env=dict(env, DISPLAY=source_display), check=True, timeout=5)
        native = wait_for_window(app, source_display, 'Blender', env, directory / 'blender-positioned.log', 10,
                                 (WIDTH, HEIGHT))
        if native != source:
            raise RuntimeError('Blender recreated its X11 window during setup')

        def ready_state():
            if not report.is_file():
                return None
            state = json.loads(report.read_text())
            if state.get('window_size') != [WIDTH, HEIGHT]:
                return None
            if (not state['application_version'].startswith('4.5.16') or state['build_hash'] != '3f6797307da5'
                    or state['scene'] != 'jwm-workbench-cube-v1' or state['render_engine'] != 'BLENDER_WORKBENCH'
                    or state['shading'] != 'SOLID' or state['camera'] != 'CAMERA' or state['playing']
                    or state['timeline_fps'] != 60
                    or not any(driver in state['renderer'].lower() for driver in ('llvmpipe', 'softpipe'))):
                raise RuntimeError(f'wrong Blender, scene or camera state: {state}')
            return state

        state = wait_for(app, ready_state, 15)
        viewport = tuple(state['viewport'])
        x, y, width, height = viewport
        if min(x, y) < 0 or width < 200 or height < 200 or x + width > WIDTH or y + height > HEIGHT:
            raise RuntimeError(f'unusable measured Blender viewport: {viewport}')
        write_json(directory / 'workbench-static-state.json', state)
        source_pixels = Pixels(source_display)
        stack.callback(source_pixels.close)
        last_pixels = ()

        def find_scan_row():
            nonlocal last_pixels
            last_pixels = source_pixels.crop(source_pixels.root, 0, 0, WIDTH, HEIGHT)
            return locate_cube_row(last_pixels, viewport)

        try:
            scan_row = wait_for(app, find_scan_row, 10)
        finally:
            if last_pixels:
                write_capture(directory / 'source-static.ppm', last_pixels)
        initial = read_cube(source_pixels, source_pixels.root, viewport, scan_row)
        if initial is None:
            raise RuntimeError('could not read the center of the actual startup cube')
        write_json(directory / 'workbench-initial-oracle.json', {'scan_row': scan_row, 'source_span': initial})
        key = directory / 'key'
        stack.callback(key.unlink, missing_ok=True)
        subprocess.run([args.release, 'keygen', '--output', str(key)], env=env, stdout=subprocess.DEVNULL,
                       check=True, timeout=8)
        host = subprocess.Popen([args.release, 'host', '--display', source_display, '--capture-source', 'root',
                                 '--scaling', 'auto', '--once', '--listen', '127.0.0.1:0', '--key-file', str(key),
                                 '--stats-json', '--fps', str(REQUESTED_FPS), '--jpeg-quality', '85', '--fixed-jpeg-quality'],
                                env=env, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        stack.callback(stop, host)
        host_monitor, host_errors = monitor_stderr(host, 'host', directory)
        host_log = directory / 'host.log'

        def address():
            if not host_log.exists():
                return None
            match = re.search(r'listening on (127\.0\.0\.1:[0-9]+)', host_log.read_text())
            return match.group(1) if match else None

        remote = wait_for(host, address)
        viewer_args = [args.release, 'connect', remote, '--display', viewer_display, '--window-size', size,
                       '--window-position', '0,0', '--scaling', 'cpu', '--view-only', '--jpeg', '--toggle',
                       '--stats-json', '--key-file', str(key)]
        viewer = subprocess.Popen(viewer_args, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        stack.callback(stop, viewer)
        viewer_monitor, viewer_errors = monitor_stderr(viewer, 'viewer', directory)
        viewer_id = wait_for_window(viewer, viewer_display, f'{remote} - JWM Remote', env,
                                    directory / 'viewer-window.log', 15, (WIDTH, HEIGHT))
        viewer_pixels = Pixels(viewer_display)
        stack.callback(viewer_pixels.close)

        def initial_viewer():
            seen = read_cube(viewer_pixels, viewer_id, viewport, scan_row)
            return seen if seen and abs(seen['center_x'] - initial['center_x']) <= 4 else None

        try:
            visible = wait_for(viewer, initial_viewer, 10)
        finally:
            write_capture(directory / 'viewer-static.ppm', viewer_pixels.crop(viewer_id, 0, 0, WIDTH, HEIGHT))
        write_json(directory / 'workbench-initial-oracle.json',
                   {'scan_row': scan_row, 'source_span': initial, 'viewer_span': visible})
        lanes = {'source': (source_pixels, source_pixels.root), 'viewer': (viewer_pixels, viewer_id)}
        processes = app, host, viewer
        phases = []
        if not args.calibrate:
            phases.append(collect_phase(directory, 'static', lanes, report, viewport, scan_row, processes, 30, 60, 8))
        start_playback.touch(exist_ok=False)

        def first_motion():
            active = json.loads(report.read_text()).get('playing')
            seen = read_cube(source_pixels, source_pixels.root, viewport, scan_row)
            return seen if active and seen and abs(seen['center_x'] - initial['center_x']) >= 8 else None

        wait_for(app, first_motion, 6)
        warm, seconds, tail = (0, 8, 0) if args.calibrate else (30, 60, 8)
        phases.append(collect_phase(directory, 'motion', lanes, report, viewport, scan_row, processes, warm, seconds, tail))
        for role, (pixels, xid) in lanes.items():
            write_capture(directory / f'{role}-motion-end.ppm', pixels.crop(xid, 0, 0, WIDTH, HEIGHT))
        subprocess.run(viewer_args, env=env, stdout=subprocess.DEVNULL, stderr=log('disconnect.log'),
                       check=True, timeout=8)
        statuses = viewer.wait(timeout=10), host.wait(timeout=10)
        for monitor in (viewer_monitor, host_monitor):
            monitor.join(timeout=3)
        if any(statuses) or viewer_errors or host_errors or viewer_monitor.is_alive() or host_monitor.is_alive():
            raise RuntimeError(f'host or viewer failed closure/telemetry: {statuses}, {host_errors}, {viewer_errors}')
        telemetry_complete = None
        if not args.calibrate:
            for phase in phases:
                phase['telemetry'] = {side: select_telemetry(directory, phase, side) for side in ('host', 'viewer')}
            windows = [windows for phase in phases for windows in phase['telemetry'].values()]
            sessions = {session for side in windows for session in side['session_ids']}
            telemetry_complete = (len(sessions) == 1 and all(
                side['window_seconds'] >= 60 and len(side['session_ids']) == 1
                and side['frame_scopes_match_960x640_jpeg'] for side in windows)
                and all(side['frame_scopes_observed'] > 0 for side in phases[-1]['telemetry'].values()))
        motion = phases[-1]['samples']
        source_qualifies = motion['source']['unique_content_fps'] >= REQUESTED_FPS
        gate = motion['viewer']['unique_content_fps'] >= .9 * REQUESTED_FPS if source_qualifies else None
        result = {'scope': 'unscored isolated calibration' if args.calibrate else 'scored local X11 software Workbench',
                  'resolution': [WIDTH, HEIGHT], 'requested_fps': REQUESTED_FPS, 'codec': 'fixed JPEG 85',
                  'static_state': state, 'scan_row': scan_row, 'phases': phases,
                  'telemetry_complete': telemetry_complete,
                  'source_qualified_for_viewer_gate': None if args.calibrate else source_qualifies,
                  'viewer_motion_gate_met': None if args.calibrate else gate}
        write_json(directory / 'result.json', result)
        print(json.dumps({'run': str(directory), 'source_fps': motion['source']['unique_content_fps'],
                          'viewer_fps': motion['viewer']['unique_content_fps'], 'scope': result['scope']}), flush=True)
        if args.calibrate and any(motion[side]['distinct_mesh_positions'] < 8 for side in lanes):
            raise RuntimeError('the raster observer did not follow Blender mesh motion on both ends')
        return result


if __name__ == '__main__':
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--blender', default=BLENDER)
    cli.add_argument('--release', default=RELEASE)
    cli.add_argument('--calibrate', action='store_true')
    cli.add_argument('--trials', type=int, default=3)
    args = cli.parse_args()
    if not args.calibrate and args.trials < 3:
        cli.error('a scored baseline requires at least three repetitions')
    args.blender = str(Path(args.blender).resolve(strict=True))
    args.release = str(Path(args.release).resolve(strict=True))
    with open('/tmp/jwm-p08-p09-release/benchmark.lock', 'a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        directory = Path(tempfile.mkdtemp(prefix='calibration.' if args.calibrate else 'scored.', dir=HERE))
        with open(args.release, 'rb') as binary:
            release_sha256 = hashlib.file_digest(binary, 'sha256').hexdigest()
        count = 1 if args.calibrate else args.trials
        write_json(directory / 'manifest.json', {'scene': SCENE.name, 'scene_sha256': hashlib.sha256(SCENE.read_bytes()).hexdigest(),
                                                'blender': args.blender, 'release': args.release,
                                                'release_sha256': release_sha256, 'attempted_trials': count,
                                                'scope': 'one machine, private Xvfb displays, software OpenGL and loopback',
                                                'capture': 'owned X11 root Auto scaling', 'viewer': 'X11 1:1 decoder',
                                                'phases': ['static', 'motion'], 'poll_hz_ceiling': POLL_HZ})
        outcomes = []
        for i in range(1, count + 1):
            trial = directory / f'trial-{i:02}'
            try:
                result = run(args, trial)
                outcomes.append({'trial': i, 'status': 'completed',
                                 'source_qualified': result['source_qualified_for_viewer_gate'],
                                 'telemetry_complete': result['telemetry_complete'],
                                 'viewer_motion_gate_met': result['viewer_motion_gate_met']})
            except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as error:
                trial.mkdir(mode=0o700, exist_ok=True)
                (trial / 'failure.log').write_text(traceback.format_exc())
                outcomes.append({'trial': i, 'status': 'failed', 'reason': str(error)})
                print(f'Workbench trial {i} failed: {error}', flush=True)
            write_json(directory / 'outcomes.json', outcomes)
        if any(row['status'] != 'completed' for row in outcomes):
            raise SystemExit(f'Incomplete Workbench trial; see {directory}')
