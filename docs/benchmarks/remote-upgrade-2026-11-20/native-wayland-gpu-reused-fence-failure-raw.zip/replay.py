"""Verify native Wayland fence diagnostic artifacts from archived text."""
import hashlib
import json
import os
from pathlib import Path
import re
import sys

TIMEOUT = 'native_wayland_fence_timeout_retires_real_surface_without_ack'
REUSE = 'native_wayland_fence_wait_failure_retires_reused_target_without_ack'
REUSE_MARKER = 'JWM_NATIVE_WAYLAND_REUSED_FENCE '
ACTIVE = 'jwm-remote: native Wayland XRGB DMA-BUF backing reuse active'
HEAD = 'JWM_NATIVE_WAYLAND_RENDERER='
FIXTURE = 'src/remote/host_wayland_gpu_fence_integration.rs'


def require(condition, explanation):
    if not condition:
        raise AssertionError(explanation)


def one(iterable):
    result, = iterable
    return result


def sha(content):
    return hashlib.sha256(content).hexdigest()


def case(log, name, reused):
    lines = log.strip().splitlines()
    require(lines[0] == 'running 1 test', 'missing harness start')
    named = one(line for line in lines if line.startswith('test remote::'))
    require(f'::{name} ... {HEAD}' in named, 'wrong harness case or missing actual renderer')
    renderer = named.split(HEAD, 1)[1]
    require('Intel' in renderer and 'ok' in lines, 'missing real renderer or successful test status')
    done = re.fullmatch(r'test result: ok\. 1 passed; 0 failed; 0 ignored; 0 measured; (\d+) filtered out; finished in ([\d.]+)s', lines[-1])
    require(done, 'hardware test did not finish')
    decoder = 'jwm-remote: H.264 hardware decoder active (VAAPI)'
    render = 'jwm-remote: native H.264 VA-API/EGL/Wayland DMA-BUF video rendering active'
    require(decoder in lines and render in lines and 'jwm-remote: connected; view-only; clipboard off' in lines,
            'actual authenticated native video path unavailable')
    report = one(line for line in lines if line.startswith('jwm-remote: viewer final received '))
    counts = re.fullmatch(r'jwm-remote: viewer final received [\d.]+ fps \((\d+)\), decoded (\d+), replaced (\d+), drawn (\d+), acked (\d+),.*', report)
    require(counts, 'unexpected terminal viewer counters')
    received, decoded, replaced, drawn, acked = map(int, counts.groups())
    healthy = 3 if reused else 1
    require(received == decoded == healthy + 1 and replaced == 0 and drawn == acked == healthy,
            'an unresolved frame was drawn or acknowledged')
    error = 'GLES frame fence wait failed' if reused else 'GLES frame fence did not complete'
    require(f'jwm-remote: native wayland video disabled; using RGB ({error})' in lines,
            'missing underlying fence failure diagnostic')
    outcome = {
        'test_case': name, 'test_passed': True, 'test_wall_seconds': float(done[2]),
        'renderer': renderer, 'received_frames': received, 'decoded_frames': decoded,
        'replaced_frames': replaced, 'drawn_frames': drawn, 'acked_frames': acked,
        'underlying_error': error, 'rgb_fallback_commit_observed': False,
        'successful_cleanup': True, 'reconnect_certified': False,
        'injection': 'Test-only override after the real successful GLES wait and glDeleteSync.',
        'healthy_frame_oracle': {
            'four_distinct_color_samples_per_commit': True,
            'rgba_framebuffer_locations': [[16,16],[233,16],[16,231],[233,231]],
            'maximum_absolute_rgb_error_threshold': 4,
            'reference': 'Independent VA-API decode and CPU conversion of the synthetic H.264 input.',
            'feedback_order': 'Read committed DMA-BUF, compare pixels, then send controlled private presentation feedback.',
        },
        'failure_edge': {
            'faulted_frame_reached_wayland_commit': False,
            'faulted_frame_returned_wire_ack': False,
            'same_exact_va_frame_held_at_renderer_teardown': True,
            'same_egl_context_destroy_succeeded': True,
            'both_workers_terminated': True,
        },
    }
    if reused:
        require(lines.count(ACTIVE) == 1, 'actual backing reuse was not activated once')
        marker = json.loads(one(line[len(REUSE_MARKER):] for line in lines if line.startswith(REUSE_MARKER)))
        require(marker['injected_status'] == 'GL_WAIT_FAILED'
                and marker['healthy_acks'] == [[1,71],[1,72],[1,73]]
                and marker['healthy_presentations'] == 3 and marker['faulted_sequence'] == 74
                and marker['signaled_reused_draws_including_fault'] == 2
                and marker['error'] == error, 'the fault did not target the second actual reused draw')
        require(marker['faulted_target_not_pooled'] and marker['same_va_frame_held_at_egl_teardown']
                and marker['same_egl_context_destroyed'] and not marker['reconnect_certified'],
                'fault resource or terminal-state proof failed')
        require((os.major(marker['render_node_device']), os.minor(marker['render_node_device'])) == (226,128),
                'unexpected physical render device')
        outcome.update(reuse_enabled=True, successful_reuse_marker_observed=True,
                       healthy_wire_acks=marker['healthy_acks'], faulted_sequence=74,
                       signaled_reused_draws_including_fault=2, render_node_linux_major_minor=[226,128],
                       healthy_reused_frames=1, faulted_reused_target_not_pooled=True,
                       nested_io_error_kind='Other', overridden_status='GL_WAIT_FAILED')
    else:
        require(ACTIVE not in lines and not any(line.startswith(REUSE_MARKER) for line in lines),
                'control unexpectedly enabled RGB allocation reuse')
        outcome.update(reuse_enabled=False, successful_reuse_marker_observed=False,
                       healthy_wire_acks=[[1,71]], faulted_sequence=72,
                       nested_io_error_kind='TimedOut', overridden_status='GL_TIMEOUT_EXPIRED')
    return outcome


def replay(root):
    manifest = json.loads((root / 'evidence/pins.json').read_text())
    build = json.loads((root / 'evidence/cargo-artifact.json').read_text())
    require(build['build_finished_success'] and build['target_name'] == 'jwm'
            and build['test_profile'] and not build['fresh']
            and {'remote-wayland','backend-wayland-udev','remote-h264'} <= set(build['effective_features'])
            and build['executable_name'] == manifest['test_binary']['name']
            and re.fullmatch(r'[0-9a-f]{64}',manifest['test_binary']['sha256']),
            'compiler selection and pinned test executable are inconsistent')
    selected = manifest['build_selected_source_sha256']
    for source, archived in manifest['archived_source'].items():
        content = (root / archived['archive_path']).read_bytes()
        digest = sha(content)
        require(archived['archive_sha256'] == digest, 'archived source bytes changed')
        if source in selected:
            require(archived['original_sha256'] == selected[source], 'source build digest changed')
            if not archived['redacted']:
                require(digest == selected[source], 'archived exact source differs from test-time digest')
    fixture = (root / manifest['archived_source'][FIXTURE]['archive_path']).read_text()
    require(all(token in fixture for token in (
        'proof.real_signaled_draws, healthy_frames + 1', 'proof.real_signaled_reused_draws, 2',
        'proof.faulted_reused_target_not_pooled', 'proof.exact_frame_held_at_teardown',
        'proof.same_egl_context_destroyed', 'later_commits.load(Ordering::Relaxed)',
        'hardware_decode_failure_clean(failure.as_ref())', 'wait_failure.kind(), error_kind',
    )), 'source snapshot is missing an asserted behavior')
    runner = (root / 'fixture/native-test.sh').read_text()
    require('unset LIBGL_ALWAYS_SOFTWARE JWM_REMOTE_WAYLAND_REUSE_RGB' in runner
            and f'JWM_REMOTE_WAYLAND_REUSE_RGB=1 "$1" {REUSE}' in runner
            and '/dev/dri/renderD128' in runner, 'runtime scope differs')
    a,b = re.split(r'\n(?=running 1 test\n)', (root / 'evidence/native-fault-tests.log').read_text().strip())
    return {'timeout_control': case(a, TIMEOUT, False), 'reused_wait_failure': case(b, REUSE, True)}


if __name__ == '__main__':
    print(json.dumps(replay(Path(sys.argv[1])), indent=2))
