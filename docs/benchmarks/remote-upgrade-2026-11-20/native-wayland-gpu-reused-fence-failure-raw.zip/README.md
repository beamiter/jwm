# Native Wayland fence failure after real RGB backing reuse

Extract this ZIP and run the offline validator with `python3 -B replay.py .`.

Two owned Intel hardware tests ran against the newly built Cargo test
executable. Both use the physical Intel render node and a private Wayland
compositor. The unpooled control substitutes a timeout after the second
successful real GLES draw. The reuse case checks actual pixels and wire ACKs
for frames 71 through 73, including one previously released RGB backing,
then substitutes GL_WAIT_FAILED on the next actual reused backing draw.
The genuine driver wait signaled. The injected failure tests the native
error path and retirement, and no physical loss or fault was induced.

The redacted spool includes both test outcomes. Loopback ports and the
fixture's synthetic test credential were replaced. The build artifact excerpt
joins the selected source hashes and captured executable identity. The full
build, GPU and viewer binaries are outside this archive.

The historical line saying "using RGB" came from disabling native decode.
The viewer terminated with no RGB fallback commit and no ACK for the
unresolved frame. The recorded durations are whole-test durations.
