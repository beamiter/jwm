#!/usr/bin/env bash
set -euo pipefail
[[ $# -eq 1 && -x $1 ]]
runtime=$(mktemp -d -t jwm-native-reused-fence.XXXXXXXX)
trap 'rmdir -- "$runtime" 2>/dev/null || true' EXIT
export TMPDIR="$runtime" XDG_RUNTIME_DIR="$runtime"
export JWM_REMOTE_GPU_PRESENT=/dev/dri/renderD128 JWM_REQUIRE_HEADLESS_GL=1 EGL_PLATFORM=surfaceless
unset LIBGL_ALWAYS_SOFTWARE JWM_REMOTE_WAYLAND_REUSE_RGB
status=0
"$1" native_wayland_fence_timeout_retires_real_surface_without_ack \
    --ignored --test-threads=1 --nocapture || status=$?
JWM_REMOTE_WAYLAND_REUSE_RGB=1 "$1" native_wayland_fence_wait_failure_retires_reused_target_without_ack \
    --ignored --test-threads=1 --nocapture || status=$?
exit "$status"
