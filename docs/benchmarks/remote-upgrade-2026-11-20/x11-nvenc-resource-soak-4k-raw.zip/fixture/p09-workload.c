#define _POSIX_C_SOURCE 200809L

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/extensions/XShm.h>
#include <X11/extensions/Xdamage.h>
#include <errno.h>
#include <inttypes.h>
#include <poll.h>
#include <signal.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <time.h>

enum { MARKER_ORIGIN = 16, MARKER_CELL = 12, MARKER_SIZE = 8 * MARKER_CELL, TILE = 8 };
static const uint64_t SECOND = UINT64_C(1000000000);
static volatile sig_atomic_t interrupted;

struct options {
    const char *display;
    unsigned width, height, fps, seconds, run_id, poll_hz;
    uint32_t seed;
    Window window;
};

struct shared_image {
    XImage *image;
    XShmSegmentInfo shm;
};

static void die(const char *message)
{
    fprintf(stderr, "p09-workload: %s\n", message);
    exit(EXIT_FAILURE);
}

static void interrupt(int signum)
{
    (void)signum;
    interrupted = 1;
}

static uint64_t now_ns(void)
{
    struct timespec now;
    if (clock_gettime(CLOCK_MONOTONIC, &now) < 0)
        die("could not read CLOCK_MONOTONIC");
    return (uint64_t)now.tv_sec * SECOND + (uint64_t)now.tv_nsec;
}

static void wait_until(uint64_t ns)
{
    const struct timespec deadline = {
        .tv_sec = (time_t)(ns / SECOND), .tv_nsec = (long)(ns % SECOND)
    };
    int err;
    do {
        err = clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &deadline, NULL);
    } while (err == EINTR && !interrupted);
    if (err && err != EINTR)
        die("absolute sleep failed");
}

static void usage(FILE *out)
{
    fputs("p09-workload paint --display :N --run-id 1 [--width 1920 --height 1080 --fps 60 --seconds 110 --seed 1]\n"
          "p09-workload observe --display :N --window 0xID --run-id 1 [--width 1920 --height 1080 --seconds 100 --poll-hz 0]\n",
          out);
}

static unsigned long number(const char *value, unsigned long min, unsigned long max)
{
    char *end;
    errno = 0;
    unsigned long parsed = strtoul(value, &end, 0);
    if (!*value || *end || value[0] == '-' || errno || parsed < min || parsed > max)
        die("invalid numeric argument");
    return parsed;
}

static struct options arguments(int argc, char **argv, bool painter)
{
    struct options result = {
        .width = 1920, .height = 1080, .fps = 60, .seconds = painter ? 110 : 100, .seed = 1
    };
    for (int i = 2; i < argc; i += 2) {
        const char *flag = argv[i];
        if (i + 1 == argc)
            die("missing option value");
        const char *value = argv[i + 1];
        if (strcmp(flag, "--display") == 0)
            result.display = value;
        else if (strcmp(flag, "--width") == 0)
            result.width = number(value, MARKER_ORIGIN + MARKER_SIZE, 4096);
        else if (strcmp(flag, "--height") == 0)
            result.height = number(value, MARKER_ORIGIN + MARKER_SIZE, 2160);
        else if (strcmp(flag, "--seconds") == 0)
            result.seconds = number(value, 1, 1200);
        else if (strcmp(flag, "--run-id") == 0)
            result.run_id = number(value, 1, 255);
        else if (painter && strcmp(flag, "--fps") == 0)
            result.fps = number(value, 1, 120);
        else if (painter && strcmp(flag, "--seed") == 0)
            result.seed = number(value, 0, UINT32_MAX);
        else if (!painter && strcmp(flag, "--window") == 0)
            result.window = number(value, 1, UINT32_MAX);
        else if (!painter && strcmp(flag, "--poll-hz") == 0)
            result.poll_hz = number(value, 0, 240);
        else
            die("unknown option for mode");
    }
    if (!result.display || (result.display[0] != ':' && strncmp(result.display, "unix:", 5) != 0))
        die("an explicit local X11 display is required");
    if (!result.run_id || (!painter && !result.window))
        die("--run-id and, for observe, --window are required");
    if (painter && result.seconds * result.fps > UINT16_MAX)
        die("duration and FPS exceed the marker frame number range");
    return result;
}

static void shared_image_create(struct shared_image *result, Display *display, Visual *visual,
                                int depth, unsigned width, unsigned height)
{
    result->image = XShmCreateImage(display, visual, (unsigned)depth, ZPixmap,
                                  NULL, &result->shm, width, height);
    if (!result->image)
        die("could not create MIT-SHM image");
    if (result->image->bits_per_pixel != 32 ||
        result->image->red_mask != 0xff0000 || result->image->green_mask != 0xff00 ||
        result->image->blue_mask != 0xff || result->image->byte_order != LSBFirst)
        die("requires a little-endian XRGB8888-compatible visual");
    result->shm.shmid = shmget(IPC_PRIVATE,
                              (size_t)result->image->bytes_per_line * height, IPC_CREAT | 0600);
    if (result->shm.shmid < 0)
        die("could not allocate MIT-SHM image");
    result->shm.shmaddr = shmat(result->shm.shmid, NULL, 0);
    if (result->shm.shmaddr == (char *)-1) {
        shmctl(result->shm.shmid, IPC_RMID, NULL);
        die("could not map MIT-SHM image");
    }
    result->image->data = result->shm.shmaddr;
    result->shm.readOnly = False;
    if (shmctl(result->shm.shmid, IPC_RMID, NULL) < 0)
        die("could not mark MIT-SHM image for automatic cleanup");
    if (!XShmAttach(display, &result->shm))
        die("could not attach MIT-SHM image to X11");
    XSync(display, False);
}

static void shared_image_destroy(Display *display, struct shared_image *shared)
{
    XShmDetach(display, &shared->shm);
    XSync(display, False);
    shared->image->data = NULL;
    XDestroyImage(shared->image);
    shmdt(shared->shm.shmaddr);
}

static uint32_t mix(uint32_t value)
{
    value ^= value >> 16;
    value *= UINT32_C(0x7feb352d);
    value ^= value >> 15;
    value *= UINT32_C(0x846ca68b);
    return value ^ (value >> 16);
}

static uint32_t marker(unsigned run, unsigned frame)
{
    const uint32_t identity = (run << 16) | frame;
    return (identity << 8) | (mix(identity ^ UINT32_C(0xc94959a7)) & 255);
}

static void repaint(XImage *image, const struct options *opts, unsigned frame)
{
    const unsigned stride = (unsigned)image->bytes_per_line / sizeof(uint32_t);
    uint32_t *pixels = (uint32_t *)image->data;
    const uint32_t dynamic_seed = mix(opts->seed ^ frame * UINT32_C(0x9e3779b9));
    const unsigned motion_width = opts->width - opts->width / 5;
    const unsigned object_x = opts->width / 5 + (frame * 11) % motion_width;
    const unsigned object_y = (frame * 7) % opts->height;
    for (unsigned y = 0; y < opts->height; y += TILE) {
        uint32_t *line = pixels + (size_t)y * stride;
        for (unsigned x = 0; x < opts->width; x += TILE) {
            const uint32_t spatial = x * UINT32_C(0x5851f42d) ^ y * UINT32_C(0x4c957f2d);
            const bool moving_region = x >= opts->width / 5;
            const uint32_t noise = mix(spatial ^ (moving_region ? dynamic_seed : opts->seed));
            uint32_t color = noise & UINT32_C(0x00ffffff);
            // Move a coarse colored object across the broad changing texture.
            if (moving_region && (x + motion_width - object_x) % motion_width < motion_width / 3 &&
                (y + opts->height - object_y) % opts->height < opts->height / 3)
                color = (color & UINT32_C(0x007f7f7f)) | UINT32_C(0x00808000);
            unsigned right = x + TILE < opts->width ? x + TILE : opts->width;
            for (unsigned i = x; i < right; ++i)
                line[i] = color;
        }
        const unsigned bottom = y + TILE < opts->height ? y + TILE : opts->height;
        for (unsigned row = y + 1; row < bottom; ++row)
            memcpy(pixels + (size_t)row * stride, line, opts->width * sizeof(*line));
    }

    const uint32_t word = marker(opts->run_id, frame);
    const uint64_t bits = ((uint64_t)(~word) << 32) | word;
    for (unsigned cell = 0; cell < 64; ++cell) {
        const unsigned x = MARKER_ORIGIN + (cell % 8) * MARKER_CELL;
        const unsigned y = MARKER_ORIGIN + (cell / 8) * MARKER_CELL;
        const uint32_t color = (bits >> cell) & 1 ? 0x00f8f8f8 : 0x00080808;
        for (unsigned row = y; row < y + MARKER_CELL; ++row) {
            uint32_t *line = pixels + (size_t)row * stride;
            for (unsigned column = x; column < x + MARKER_CELL; ++column)
                line[column] = color;
        }
    }
}

static int paint(Display *display, const struct options *opts)
{
    const int screen = DefaultScreen(display);
    if (opts->width > (unsigned)DisplayWidth(display, screen) ||
        opts->height > (unsigned)DisplayHeight(display, screen))
        die("source scene does not fit the selected screen");
    Window root = RootWindow(display, screen);
    XSetWindowAttributes attrs = {.override_redirect = True};
    Window window = XCreateWindow(display, root, 0, 0, opts->width, opts->height,
                                  0, CopyFromParent, InputOutput, CopyFromParent,
                                  CWOverrideRedirect, &attrs);
    XStoreName(display, window, "JWM P09 motion fixture");
    struct shared_image shared = {0};
    shared_image_create(&shared, display, DefaultVisual(display, screen),
                        DefaultDepth(display, screen), opts->width, opts->height);
    GC gc = XCreateGC(display, window, 0, NULL);
    XMapRaised(display, window);
    XSync(display, False);
    const uint64_t start = now_ns();
    const uint64_t end = start + opts->seconds * SECOND;
    const unsigned total_slots = opts->fps * opts->seconds;
    unsigned submitted = 0, next = 1;
    uint64_t first_ns = 0, last_ns = 0, maximum_render_ns = 0;

    while (!interrupted && next <= total_slots) {
        wait_until(start + (uint64_t)(next - 1) * SECOND / opts->fps);
        const uint64_t begun = now_ns();
        if (begun >= end || interrupted)
            break;
        const unsigned frame = (unsigned)((begun - start) * opts->fps / SECOND) + 1;
        if (frame > next)
            next = frame;
        repaint(shared.image, opts, next);
        if (!XShmPutImage(display, window, gc, shared.image, 0, 0, 0, 0,
                          opts->width, opts->height, False))
            die("shared repaint was rejected");
        XSync(display, False);
        last_ns = now_ns();
        if (!first_ns) {
            first_ns = last_ns;
            printf("{\"type\":\"p09_start\",\"role\":\"source\",\"clock\":\"monotonic\","
                   "\"monotonic_ns\":%" PRIu64 ",\"run_id\":%u,\"width\":%u,\"height\":%u,"
                   "\"fps\":%u,\"seconds\":%u,\"seed\":%" PRIu32 ",\"window\":\"0x%lx\"}\n",
                   start, opts->run_id, opts->width, opts->height, opts->fps, opts->seconds,
                   opts->seed, window);
        }
        if (last_ns - begun > maximum_render_ns)
            maximum_render_ns = last_ns - begun;
        ++submitted;
        ++next;
    }
    if (!interrupted && now_ns() < end)
        wait_until(end);
    const uint64_t stopped = now_ns();
    const unsigned due = stopped >= end ? total_slots :
        (unsigned)((stopped - start) * opts->fps / SECOND) + 1;
    printf("{\"type\":\"p09_end\",\"role\":\"source\",\"monotonic_ns\":%" PRIu64
           ",\"run_id\":%u,\"submitted\":%u,\"deadline_skips\":%u,\"first_submit_ns\":%" PRIu64
           ",\"last_submit_ns\":%" PRIu64 ",\"max_render_sync_ns\":%" PRIu64
           ",\"interrupted\":%s}\n",
           stopped, opts->run_id, submitted, due > submitted ? due - submitted : 0, first_ns,
           last_ns, maximum_render_ns, interrupted ? "true" : "false");
    XFreeGC(display, gc);
    shared_image_destroy(display, &shared);
    XDestroyWindow(display, window);
    return submitted ? EXIT_SUCCESS : EXIT_FAILURE;
}

// Median-like majority of a central 5x5 region avoids edge ringing.
static int bit_value(XImage *image, unsigned x, unsigned y)
{
    unsigned white = 0, black = 0;
    for (unsigned row = y - 2; row <= y + 2; ++row) {
        const uint32_t *line = (const uint32_t *)(image->data + (size_t)row * image->bytes_per_line);
        for (unsigned column = x - 2; column <= x + 2; ++column) {
            const uint32_t pixel = line[column];
            unsigned red = (pixel >> 16) & 255, green = (pixel >> 8) & 255, blue = pixel & 255;
            white += red >= 180 && green >= 180 && blue >= 180;
            black += red <= 75 && green <= 75 && blue <= 75;
        }
    }
    if (white >= 19)
        return 1;
    if (black >= 19)
        return 0;
    return -1;
}

static uint32_t read_marker(XImage *image)
{
    uint64_t bits = 0;
    for (unsigned cell = 0; cell < 64; ++cell) {
        unsigned x = (cell % 8) * MARKER_CELL + MARKER_CELL / 2;
        unsigned y = (cell / 8) * MARKER_CELL + MARKER_CELL / 2;
        int bit = bit_value(image, x, y);
        if (bit < 0)
            return 0;
        bits |= (uint64_t)bit << cell;
    }
    const uint32_t word = (uint32_t)bits;
    const unsigned run = word >> 24, frame = (word >> 8) & 65535;
    if ((bits >> 32) != (uint32_t)~word || !run || !frame || marker(run, frame) != word)
        return 0;
    return word;
}

static int observe(Display *display, const struct options *opts)
{
    XWindowAttributes attrs;
    if (!XGetWindowAttributes(display, opts->window, &attrs) || attrs.map_state != IsViewable)
        die("target window is not viewable");
    if (attrs.width != (int)opts->width || attrs.height != (int)opts->height)
        die("target drawable dimensions differ from the required 1:1 dimensions");
    struct shared_image shared = {0};
    shared_image_create(&shared, display, attrs.visual, attrs.depth, MARKER_SIZE, MARKER_SIZE);
    XSelectInput(display, opts->window, StructureNotifyMask);
    int event_base = 0, error_base;
    Damage damage = None;
    if (!opts->poll_hz) {
        if (!XDamageQueryExtension(display, &event_base, &error_base))
            die("XDamage is unavailable; use --poll-hz for an explicit polling trial");
        int major, minor;
        if (!XDamageQueryVersion(display, &major, &minor) || major < 1)
            die("XDamage is unavailable; use --poll-hz for an explicit polling trial");
        damage = XDamageCreate(display, opts->window, XDamageReportNonEmpty);
    }
    XSync(display, False);
    const uint64_t start = now_ns();
    const uint64_t end = start + opts->seconds * SECOND;
    uint64_t poll_at = start, max_read_ns = 0;
    unsigned reads = 0, unique = 0, duplicates = 0, invalid = 0, wrong_run = 0, reordered = 0;
    unsigned last = 0, damage_events = 0;
    bool sample_due = true, target_lost = false;
    struct pollfd xfd = {.fd = ConnectionNumber(display), .events = POLLIN};
    printf("{\"type\":\"p09_start\",\"role\":\"observer\",\"clock\":\"monotonic\","
           "\"monotonic_ns\":%" PRIu64 ",\"run_id\":%u,\"width\":%u,\"height\":%u,"
           "\"seconds\":%u,\"poll_hz\":%u,\"window\":\"0x%lx\"}\n",
           start, opts->run_id, opts->width, opts->height, opts->seconds,
           opts->poll_hz, opts->window);
    while (!interrupted && now_ns() < end) {
        while (XPending(display)) {
            XEvent event;
            XNextEvent(display, &event);
            if (damage && event.type == event_base + XDamageNotify) {
                ++damage_events;
                sample_due = true;
            }
            if (event.type == UnmapNotify || event.type == DestroyNotify ||
                (event.type == ConfigureNotify &&
                 (event.xconfigure.width != (int)opts->width ||
                  event.xconfigure.height != (int)opts->height))) {
                target_lost = true;
                break;
            }
        }
        if (target_lost)
            break;
        const uint64_t now = now_ns();
        if (now >= end)
            break;
        if (opts->poll_hz && now >= poll_at) {
            const uint64_t next = ((now - start) * opts->poll_hz) / SECOND + 1;
            poll_at = start + (next * SECOND + opts->poll_hz - 1) / opts->poll_hz;
            sample_due = true;
        }
        if (sample_due) {
            sample_due = false;
            if (damage)
                XDamageSubtract(display, damage, None, None);
            const uint64_t read_started = now_ns();
            if (!XShmGetImage(display, opts->window, shared.image,
                             MARKER_ORIGIN, MARKER_ORIGIN, AllPlanes))
                die("could not read target marker crop");
            const uint64_t received = now_ns();
            if (received - read_started > max_read_ns)
                max_read_ns = received - read_started;
            ++reads;
            if (received >= end)
                break;
            uint32_t word = read_marker(shared.image);
            if (!word) {
                ++invalid;
                continue;
            }
            unsigned run = word >> 24, frame = (word >> 8) & 65535;
            if (run != opts->run_id) {
                ++wrong_run;
                continue;
            }
            if (frame <= last) {
                if (frame == last)
                    ++duplicates;
                else
                    ++reordered;
                continue;
            }
            last = frame;
            ++unique;
            printf("{\"type\":\"p09_frame\",\"monotonic_ns\":%" PRIu64
                   ",\"run_id\":%u,\"source_frame\":%u}\n", received, run, frame);
            continue;
        }
        const uint64_t deadline = opts->poll_hz && poll_at < end ? poll_at : end;
        const int timeout = (int)((deadline - now + 999999) / 1000000);
        if (poll(&xfd, 1, timeout) < 0 && errno != EINTR)
            die("X11 event wait failed");
        if (xfd.revents & (POLLERR | POLLHUP | POLLNVAL))
            die("X11 display disconnected during observation");
    }
    printf("{\"type\":\"p09_end\",\"role\":\"observer\",\"monotonic_ns\":%" PRIu64
           ",\"run_id\":%u,\"reads\":%u,\"unique\":%u,\"duplicates\":%u,\"invalid\":%u,"
           "\"wrong_run\":%u,\"reordered\":%u,\"damage_events\":%u,\"max_read_ns\":%" PRIu64
           ",\"interrupted\":%s,\"target_lost\":%s}\n",
           now_ns(), opts->run_id, reads, unique, duplicates, invalid, wrong_run, reordered,
           damage_events, max_read_ns, interrupted ? "true" : "false",
           target_lost ? "true" : "false");
    if (damage)
        XDamageDestroy(display, damage);
    shared_image_destroy(display, &shared);
    return unique && !target_lost ? EXIT_SUCCESS : EXIT_FAILURE;
}

int main(int argc, char **argv)
{
    if (argc == 2 && strcmp(argv[1], "--help") == 0) {
        usage(stdout);
        return EXIT_SUCCESS;
    }
    if (argc < 2 || (strcmp(argv[1], "paint") && strcmp(argv[1], "observe"))) {
        usage(stderr);
        return EXIT_FAILURE;
    }
    const bool painter = strcmp(argv[1], "paint") == 0;
    const struct options opts = arguments(argc, argv, painter);
    struct sigaction action = {.sa_handler = interrupt};
    sigemptyset(&action.sa_mask);
    sigaction(SIGINT, &action, NULL);
    sigaction(SIGTERM, &action, NULL);
    setvbuf(stdout, NULL, _IOLBF, 0);
    Display *display = XOpenDisplay(opts.display);
    if (!display || !XShmQueryExtension(display))
        die("X11 display or MIT-SHM unavailable");
    const int status = painter ? paint(display, &opts) : observe(display, &opts);
    XCloseDisplay(display);
    return status;
}
