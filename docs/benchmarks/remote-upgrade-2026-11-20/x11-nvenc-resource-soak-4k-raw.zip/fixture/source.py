"""Owned source-side harness for the isolated two-machine H.264 soak."""
import argparse
from contextlib import ExitStack
import json
from pathlib import Path
import re
import select
import subprocess
import sys
import time

from processes import clean_env, get_display, start_display, stop, wait_for
from resources import BURN_SECONDS, Plan, TelemetryRelay, collect, track

LAB = Path(__file__).resolve().parent
RELEASE = Path("/tmp/jwm-p08-p09-release/jwm-remote")


def parser():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("trial")
    cli.add_argument("--arm", choices=("fixed", "adaptive"), required=True)
    for flag in ("width", "height", "fps", "measure-seconds", "sample-seconds",
                 "cap", "send-buffer", "recv-buffer"):
        cli.add_argument("--" + flag, type=int, required=True)
    return cli


def readiness(path):
    for line in path.read_text().splitlines():
        if line.startswith("{") and line.endswith("}"):
            return json.loads(line)["listening"][1]
    return None


def assert_controller():
    if select.select([sys.stdin], [], [], 0)[0]:
        raise RuntimeError("controller closed or sent unexpected data")


def main(args):
    plan = Plan(args.measure_seconds, args.sample_seconds)
    if not re.fullmatch(r"[a-z0-9-]{1,60}", args.trial):
        raise ValueError("invalid private trial label")
    run = LAB / args.trial
    run.mkdir(mode=0o700)
    key = sys.stdin.buffer.readline(4096)
    if not key or not key.endswith(b"\n"):
        raise RuntimeError("missing one-line private session key")
    with ExitStack() as stack:
        def log(name, binary=False):
            return stack.enter_context((run / name).open("wb" if binary else "w"))

        xvfb = start_display(args.width, args.height, log("xvfb.log", True))
        stack.callback(stop, xvfb)
        display = get_display(xvfb)

        host_diag = log("host.log", True)
        host_telemetry = log("host-telemetry.jsonl")
        host_env = clean_env()
        if args.arm == "adaptive":
            host_env["JWM_REMOTE_ADAPT_VIDEO"] = "desktop"
        if args.send_buffer:
            host_env["LD_PRELOAD"] = str(LAB / "accept-buffers.so")
            host_env["P09_SEND_BUFFER"] = str(args.send_buffer)
        host = subprocess.Popen(
            [RELEASE, "host", "--display", display, "--capture-source", "root", "--scaling", "cpu",
             "--listen", "127.0.0.1:0", "--key-stdin", "--once", "--stats-json", "--allow-h264",
             "--fps", str(args.fps)], env=host_env, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE)
        relay = TelemetryRelay(host, "host", host_diag, host_telemetry)
        stack.callback(relay.finish)
        stack.callback(stop, host, natural=True)
        host_identity = track(host.pid, RELEASE)
        host.stdin.write(key)
        host.stdin.flush()
        port = int(wait_for(host, lambda: re.search(r"listening on 127\.0\.0\.1:(\d+)",
                                                   (run / "host.log").read_text()), 15).group(1))

        proxy = None
        if args.cap:
            proxy_env = clean_env()
            proxy_env.pop("P09_PROXY_RCVBUF", None)
            if args.recv_buffer:
                proxy_env["P09_PROXY_RCVBUF"] = str(args.recv_buffer)
            proxy_log = log("proxy.log", True)
            proxy = subprocess.Popen(
                [sys.executable, str(LAB / "proxy-compat.py"),
                 "--upstream-host", "127.0.0.1", "--upstream-port", str(port),
                 "--max-connections", "1", "--session-seconds", str(BURN_SECONDS + plan.measured_seconds + 35),
                 "--s2c-bytes-per-second", str(args.cap),
                 "--chunk-bytes", "4096" if args.recv_buffer else "16384"],
                env=proxy_env, stdin=subprocess.DEVNULL, stdout=proxy_log, stderr=proxy_log)
            stack.callback(stop, proxy)
            port = wait_for(proxy, lambda: readiness(run / "proxy.log"), 15)

        painter = subprocess.Popen(
            [LAB / "p09-workload", "paint", "--display", display,
             "--width", str(args.width), "--height", str(args.height), "--fps", "60",
             "--seconds", str(BURN_SECONDS + plan.measured_seconds + 65), "--run-id", "1", "--seed", "7"],
            env=clean_env(), stdin=subprocess.DEVNULL, stdout=log("paint.jsonl", True),
            stderr=log("paint-stderr.log", True))
        stack.callback(stop, painter)
        wait_for(painter, lambda: re.search(r'"type":"p09_start"', (run / "paint.jsonl").read_text()), 10)
        print(json.dumps({"type": "p09_soak_ready", "upstream_port": port}), flush=True)

        def health():
            relay.check()
            assert_controller()
            if xvfb.poll() is not None or painter.poll() is not None or (proxy and proxy.poll() is not None):
                raise RuntimeError("an owned source fixture ended early")

        deadline = time.monotonic() + 40
        while relay.anchor is None:
            health()
            if time.monotonic() >= deadline:
                raise RuntimeError("host has no active hardware-video telemetry window")
            time.sleep(.1)
        collect(log("host-resources.jsonl"), "host", host_identity, plan, relay.anchor, health)
        print(json.dumps({"type": "p09_soak_host_measured"}), flush=True)
        deadline = time.monotonic() + 35
        while host.poll() is None:
            health()
            if time.monotonic() >= deadline:
                raise RuntimeError("host did not close after the measured soak")
            time.sleep(.1)
        if host.returncode:
            raise RuntimeError(f"jwm-remote host exited with {host.returncode}")
        relay.finish()
        relay.check(alive=False)
        if relay.worker.is_alive():
            raise RuntimeError("host telemetry did not drain on clean close")
        print(json.dumps({"type": "p09_soak_host_closed", "status": host.returncode}), flush=True)


if __name__ == "__main__":
    main(parser().parse_args())
