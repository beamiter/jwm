#!/usr/bin/env python3
"""Single isolated NVENC soak; preserve raw resource samples and typed telemetry."""
import argparse
from contextlib import ExitStack
import fcntl
import json
from pathlib import Path
import re
import shlex
import socket
import subprocess
import sys
import tempfile
import time
import traceback

from processes import clean_env, get_display, start_display, stop, wait_for
from resources import BURN_SECONDS, Plan, TelemetryRelay, collect, read_rows, summarize_resources, summarize_video, track

LAB = Path(__file__).resolve().parent
RELEASE = Path("/tmp/jwm-p08-p09-release/jwm-remote")
SSH = ["ssh", "-o", "BatchMode=yes", "-o", "ConnectTimeout=5",
       "-o", "ServerAliveInterval=8", "-o", "ServerAliveCountMax=3"]


def bridge(path, kind, field=None):
    for line in path.read_text().splitlines():
        if line.startswith("{") and line.endswith("}"):
            row = json.loads(line)
            if row.get("type") == kind:
                return row.get(field) if field else row
    return None


def verify_proxy(run, args):
    details = {}
    host_text = (run / "remote" / "host.log").read_text()
    viewer_text = (run / "viewer.log").read_text()
    if "H.264 NVENC negotiated" not in host_text or "hardware H.264 decoding active" not in viewer_text:
        raise ValueError("expected NVENC encode and hardware decode diagnostics")
    if "hardware encoding failed" in host_text:
        raise ValueError("hardware encoding failed during soak")
    if args.cap:
        text = (run / "remote" / "proxy.log").read_text()
        rows = [json.loads(line) for line in text.splitlines() if line.startswith("{")]
        config, = rows
        if config["config"]["s2c_bytes_per_second"] != args.cap                 or config["config"]["c2s_bytes_per_second"] != 0:
            raise ValueError("proxy configuration does not match requested fixture")
        details["proxy_config"] = config["config"]
    else:
        text = ""
    for name, log, key, request in (
        ("host_send_buffer", host_text, "P09_SOCKET_BUFFER", args.send_buffer),
        ("proxy_recv_buffer", text, "P09_PROXY_RCVBUF", args.recv_buffer),
    ):
        if request:
            match = re.findall(rf"{key} requested=(\d+) effective=(\d+)", log)
            if len(match) != 1 or int(match[0][0]) != request or int(match[0][1]) < request:
                raise ValueError(f"{name} does not match the requested private socket buffer")
            details[name] = {"requested_bytes": request, "effective_bytes": int(match[0][1])}
    return details


def report(run, args):
    remote = run / "remote"
    sides = {}
    for role, folder in (("host", remote), ("viewer", run)):
        resource = summarize_resources(read_rows(folder / f"{role}-resources.jsonl"), role)
        video, kept = summarize_video(read_rows(folder / f"{role}-telemetry.jsonl"), role,
                                      resource, args.width, args.height)
        sides[role] = resource | {"video": video}
        path = run / f"retained-{role}-telemetry.jsonl"
        path.write_text("".join(json.dumps(row, separators=(",", ":")) + "\n" for row in kept))
    if sides["host"]["video"]["session_id"] != sides["viewer"]["video"]["session_id"]:
        raise ValueError("host and viewer do not share one authenticated session")
    source_start, source_end = read_rows(remote / "paint.jsonl")
    if source_start["type"] != "p09_start" or source_end["type"] != "p09_end"             or source_start["run_id"] != source_end["run_id"] or source_end["submitted"] < 2:
        raise ValueError("source painter lacks complete continuity diagnostics")
    painter_seconds = (source_end["last_submit_ns"] - source_end["first_submit_ns"]) / 1e9
    if painter_seconds < BURN_SECONDS + args.measure_seconds:
        raise ValueError("source painter did not cover burn-in and measurement")
    manifest = {
        "schema_version": 1, "label": args.label, "role_results": sides,
        "clean_shutdown": True, "codec": "H.264 NVENC", "workload": "isolated X11 motion fixture",
        "dimensions": [args.width, args.height], "arm": args.arm, "requested_encoder_fps": args.fps,
        "burn_in_seconds": BURN_SECONDS, "measure_seconds": args.measure_seconds,
        "sample_interval_seconds": args.sample_seconds, "configured_proxy_bytes_per_second": args.cap,
        "socket_configuration": verify_proxy(run, args),
        "source": {"start": source_start, "end": source_end, "painter_span_seconds": painter_seconds,
                   "submitted_per_second": (source_end["submitted"] - 1) / painter_seconds},
        "scope": "RSS, threads and FDs of the JWM endpoint processes. Xvfb, proxy, SSH and painter excluded. "
                 "Process RSS omits GPU allocations; head/tail trend is descriptive and coverage is finite.",
    }
    rendered = json.dumps(manifest, indent=2) + "\n"
    (run / "result.json").write_text(rendered)
    print(rendered, end="", flush=True)


def run_trial(args):
    plan = Plan(args.measure_seconds, args.sample_seconds)
    run = LAB / args.label
    run.mkdir(mode=0o700)
    size = f"{args.width}x{args.height}"
    try:
        with ExitStack() as stack:
            def log(name, binary=True):
                return stack.enter_context((run / name).open("wb" if binary else "w"))

            key = run / "key"
            subprocess.run([RELEASE, "keygen", "--output", key], stdout=subprocess.DEVNULL, check=True)
            stack.callback(key.unlink, missing_ok=True)
            env = clean_env()
            env["XDG_RUNTIME_DIR"] = stack.enter_context(tempfile.TemporaryDirectory(prefix="jwm-p09-soak-runtime."))
            xvfb = start_display(args.width, args.height, log("xvfb.log"))
            stack.callback(stop, xvfb)
            display = get_display(xvfb)

            host_cmd = ["python3", "-u", f"{args.remote_dir}/source.py", args.label, "--arm", args.arm]
            for name in ("width", "height", "fps", "measure-seconds", "sample-seconds",
                         "cap", "send-buffer", "recv-buffer"):
                host_cmd.extend(["--"+name, str(getattr(args, name.replace("-", "_")))])
            readiness = run / "remote-ready.jsonl"
            source = subprocess.Popen(SSH + [args.peer, shlex.join(host_cmd)], stdin=subprocess.PIPE,
                                      stdout=log(readiness.name), stderr=log("remote-stderr.log"))
            stack.callback(stop, source, natural=True)
            source.stdin.write(key.read_bytes())
            source.stdin.flush()
            port = wait_for(source, lambda: bridge(readiness, "p09_soak_ready", "upstream_port"), 30)
            with socket.socket() as chooser:
                chooser.bind(("127.0.0.1", 0))
                local_port = chooser.getsockname()[1]
            tunnel_path = run / "tunnel.log"
            tunnel = subprocess.Popen(
                SSH + ["-vN", "-o", "ExitOnForwardFailure=yes",
                       "-L", f"127.0.0.1:{local_port}:127.0.0.1:{port}", args.peer],
                stdin=subprocess.DEVNULL, stdout=log(tunnel_path.name), stderr=subprocess.STDOUT)
            stack.callback(stop, tunnel)
            wait_for(tunnel, lambda: re.search(r"Local forwarding listening on 127\.0\.0\.1 port",
                                               tunnel_path.read_text()), 15)

            viewer_args = [RELEASE, "connect", f"127.0.0.1:{local_port}", "--view-only", "--toggle",
                           "--stats-json", "--key-file", key, "--display", display,
                           "--window-size", size, "--window-position", "0,0", "--scaling", "cpu"]
            viewer_log = log("viewer.log")
            viewer_telemetry = log("viewer-telemetry.jsonl", binary=False)
            viewer = subprocess.Popen(viewer_args, env=env, stdin=subprocess.DEVNULL,
                                      stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
            relay = TelemetryRelay(viewer, "viewer", viewer_log, viewer_telemetry)
            stack.callback(relay.finish)
            stack.callback(stop, viewer)
            viewer_identity = track(viewer.pid, RELEASE)

            def health():
                relay.check()
                if any(proc.poll() is not None for proc in (xvfb, tunnel, source)):
                    raise RuntimeError("an owned viewer fixture ended early")

            end_of_startup = time.monotonic() + 30
            while relay.anchor is None:
                health()
                if time.monotonic() >= end_of_startup:
                    raise RuntimeError("viewer has no active hardware-video telemetry window")
                time.sleep(.1)
            print(f"Started {args.label}. Burn-in {BURN_SECONDS}s, measured {args.measure_seconds}s.",
                  flush=True)
            collect(log("viewer-resources.jsonl", binary=False), "viewer", viewer_identity, plan,
                    relay.anchor, health)
            wait_for(source, lambda: bridge(readiness, "p09_soak_host_measured"), 30)
            health()

            subprocess.run(viewer_args, env=env, stdout=subprocess.DEVNULL,
                           stderr=log("disconnect.log"), timeout=10, check=True)
            if viewer.wait(timeout=16):
                raise RuntimeError(f"viewer exited with {viewer.returncode}")
            relay.finish()
            relay.check(alive=False)
            if relay.worker.is_alive():
                raise RuntimeError("viewer telemetry did not drain on clean close")
            if source.wait(timeout=20) or not bridge(readiness, "p09_soak_host_closed"):
                raise RuntimeError("remote host did not report a clean close")
    finally:
        original_failure = sys.exc_info()[0]
        try:
            subprocess.run(["scp", "-Bqr", f"{args.peer}:{args.remote_dir}/{args.label}",
                            str(run / "remote")], timeout=30, check=True, stderr=subprocess.PIPE)
        except (OSError, subprocess.SubprocessError):
            if original_failure is None:
                raise
            (run / "remote-copy-error.log").write_text(traceback.format_exc())
    report(run, args)


def parser():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--remote-dir", required=True)
    cli.add_argument("--label", required=True)
    cli.add_argument("--peer", default="ubuntu@192.168.0.78")
    cli.add_argument("--arm", choices=("fixed", "adaptive"), default="adaptive")
    cli.add_argument("--width", type=int, default=1920)
    cli.add_argument("--height", type=int, default=1080)
    cli.add_argument("--fps", type=int, default=30)
    cli.add_argument("--measure-seconds", type=int, default=900)
    cli.add_argument("--sample-seconds", type=int, default=5)
    cli.add_argument("--cap", type=int, default=0)
    cli.add_argument("--send-buffer", type=int, default=0)
    cli.add_argument("--recv-buffer", type=int, default=0)
    return cli


if __name__ == "__main__":
    cli = parser()
    args = cli.parse_args()
    try:
        Plan(args.measure_seconds, args.sample_seconds)
    except ValueError as exc:
        cli.error(str(exc))
    if not re.fullmatch(r"[a-z0-9-]{1,60}", args.label) or not re.fullmatch(
        r"/tmp/jwm-p09-soak\.[A-Za-z0-9]+", args.remote_dir
    ) or not re.fullmatch(r"[a-zA-Z0-9_]+@[a-zA-Z0-9][a-zA-Z0-9.-]*", args.peer):
        cli.error("invalid private trial label, peer, or source scratch directory")
    if not (112 <= args.width <= 4096 and 112 <= args.height <= 2160 and 1 <= args.fps <= 120):
        cli.error("size or FPS is outside the fixture limits")
    if args.cap < 0 or any(b != 0 and b < 4096 for b in (args.send_buffer, args.recv_buffer))             or (not args.cap and (args.send_buffer or args.recv_buffer)):
        cli.error("private socket buffers require a positive cap and must be at least 4096 bytes")
    with open("/tmp/jwm-p08-p09-release/benchmark.lock", "a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        run_trial(args)
