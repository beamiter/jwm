#!/usr/bin/env python3
"""Publish and replay a terminal private 4K X11 resource trial without launching it."""

import argparse
import hashlib
import json
import re
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

from resources import BURN_SECONDS, SECOND, summarize_resources, summarize_video


LAB = Path("/tmp/jwm-p09-soak")
DIMENSIONS = [3840, 2160]
STEM = "x11-nvenc-resource-soak-4k"
LABEL = "soak-fixed-4k-20261121"
MEASURE_SECONDS = 900
INTERVAL_SECONDS = 5
PIN_FILES = ("4k-mint-pins.sha256", "4k-ubuntu-pins.sha256", "4k-source-pins.sha256")
SOURCE_FILES = ("source.py", "resources.py", "processes.py", "p09-workload.c")
FIXTURE_FILES = ("soak.py", *SOURCE_FILES)
RUN_FILES = {
    "host-resources.jsonl": "remote/host-resources.jsonl",
    "viewer-resources.jsonl": "viewer-resources.jsonl",
    "host-telemetry.jsonl": "remote/host-telemetry.jsonl",
    "viewer-telemetry.jsonl": "viewer-telemetry.jsonl",
    "retained-host-telemetry.jsonl": "retained-host-telemetry.jsonl",
    "retained-viewer-telemetry.jsonl": "retained-viewer-telemetry.jsonl",
    "paint.jsonl": "remote/paint.jsonl",
    "result.json": "result.json",
}
ROLE = ("host", "viewer")
EXPECTED_MODE = {
    "arm": "fixed",
    "burn_in_seconds": BURN_SECONDS,
    "measure_seconds": MEASURE_SECONDS,
    "sample_interval_seconds": INTERVAL_SECONDS,
    "requested_encoder_fps": 30,
    "configured_proxy_bytes_per_second": 0,
    "socket_configuration": {},
    "codec": "H.264 NVENC",
}
HOST_DIAGNOSTICS = {
    "nvenc_negotiated": "H.264 NVENC negotiated",
    "hardware_encode_failed": "hardware encoding failed",
}
VIEWER_DIAGNOSTICS = {
    "hardware_h264_active": "hardware H.264 decoding active",
    "vaapi_active": "H.264 hardware decoder active (VAAPI)",
    "session_ended": "jwm-remote: session ended",
}
REMOTE_STATUSES = {"p09_soak_ready", "p09_soak_host_measured", "p09_soak_host_closed"}
INPUT_ERRORS = (KeyError, TypeError, ValueError, IndexError, AttributeError)
SHA_LINE = re.compile(r"([0-9a-f]{64})  ([A-Za-z0-9_./-]+)")
TYPE_NAMES = {"host": "jwm_remote_host_stats", "viewer": "jwm_remote_viewer_stats"}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def normalized(value):
    return json.loads(json.dumps(value, allow_nan=False))


def as_bytes(value):
    return (json.dumps(value, indent=2, allow_nan=False) + "\n").encode()


def json_rows(data):
    return [json.loads(line) for line in data.splitlines()]


def require(condition, description):
    if not condition:
        raise ValueError(description)


def parse_pins(data):
    entries = {}
    for line in data.decode("ascii").splitlines():
        match = SHA_LINE.fullmatch(line)
        require(match is not None, "malformed pinned SHA-256 manifest")
        checksum, path = match.groups()
        require(path not in entries, "duplicate pinned path")
        entries[path] = checksum
    return entries


def verify_pins(entries):
    mint, ubuntu, source = [parse_pins(entries["pins/" + name]) for name in PIN_FILES]
    binary = "/tmp/jwm-p08-p09-release/jwm-remote"
    require(set(mint) == {binary}, "Mint pin must name the tested viewer binary")
    painter, = set(ubuntu) - {binary}
    require(binary in ubuntu and re.fullmatch(r"/tmp/jwm-p09-soak\.[A-Za-z0-9]+/p09-workload", painter),
            "Ubuntu pins must name the tested host and painter binaries")
    require(set(source) == set(SOURCE_FILES), "source pin set changed")
    for name, checksum in source.items():
        require(digest(entries["fixture/" + name]) == checksum, "pinned fixture digest mismatch: " + name)
    return {
        "mint_viewer_sha256": mint[binary],
        "ubuntu_host_sha256": ubuntu[binary],
        "ubuntu_painter_sha256": ubuntu[painter],
        "fixture_source_sha256": source,
        "scope": "Pretrial SHA-256 manifests and the fixture source bytes; resource sampling checks the live process executable device and inode.",
    }


def diagnostics(run, controller_log):
    host_log = run / "remote" / "host.log"
    viewer_log = run / "viewer.log"
    remote_log = run / "remote-ready.jsonl"
    report = {"host": None, "viewer": None, "remote_bridge": [], "invalid_bridge_rows": 0}
    for role, path, phrases in (("host", host_log, HOST_DIAGNOSTICS), ("viewer", viewer_log, VIEWER_DIAGNOSTICS)):
        if path.is_file():
            contents = path.read_text(errors="replace")
            report[role] = {"sha256_before_omission": digest(path.read_bytes()),
                            "matches": {key: contents.count(phrase) for key, phrase in phrases.items()}}
    if remote_log.is_file():
        for raw in remote_log.read_bytes().splitlines():
            try:
                row = json.loads(raw)
                if row.get("type") not in REMOTE_STATUSES:
                    continue
                safe = {"type": row["type"]}
                if type(row.get("status")) is int:
                    safe["status"] = row["status"]
                report["remote_bridge"].append(safe)
            except INPUT_ERRORS:
                report["invalid_bridge_rows"] += 1
    if controller_log is not None:
        data = controller_log.read_bytes()
        known_messages = (
            "viewer has no active hardware-video telemetry window",
            "host has no active hardware-video telemetry window",
            "viewer telemetry did not drain on clean close",
            "host telemetry did not drain on clean close",
            "remote host did not report a clean close",
            "an owned viewer fixture ended early",
            "an owned source fixture ended early",
            "incomplete host resource trace",
            "incomplete viewer resource trace",
            "host changed capture geometry",
            "viewer changed codec or geometry",
            "expected NVENC encode and hardware decode diagnostics",
            "hardware encoding failed during soak",
        )
        text = data.decode(errors="replace")
        report["controller"] = {
            "sha256_before_omission": digest(data),
            "known_errors": [message for message in known_messages if message in text],
            "terminal_error_types": [
                match.group(1) for line in text.splitlines()
                if (match := re.match(r"^(?:[A-Za-z0-9_]+\.)*([A-Za-z0-9_]*(?:Error|Timeout|Exception)):", line))
            ],
        }
    report["remote_copy_error_recorded"] = (run / "remote-copy-error.log").is_file()
    return report


def resource_result(rows, role):
    require(rows and rows[0]["sample_interval_seconds"] == INTERVAL_SECONDS,
            "resource sampling interval differs from the declared trial")
    summary = summarize_resources(rows, role)
    require(summary["measurement_seconds"] == MEASURE_SECONDS and
            summary["measurement_start_ns"] - summary["anchor_ns"] == BURN_SECONDS * SECOND,
            "resource burn-in or measurement duration differs from the declared trial")
    return summary


def video_result(rows, role, resource, size):
    require(all(row["record"]["type"] == TYPE_NAMES[role] for row in rows), "unexpected typed telemetry")
    require(all(b["arrived_monotonic_ns"] >= a["arrived_monotonic_ns"] for a, b in zip(rows, rows[1:])),
            "telemetry arrival timestamps regressed")
    video, retained = summarize_video(rows, role, resource, *size)
    for row in retained:
        record = row["record"]
        if role == "host":
            require(record["mode"] == "root/cpu-resize/core-getimage/no-damage/cursor-events",
                    "host presentation scope is not root core XGetImage")
            count, frame = record["h264_frames"], record["last_sent_frame"]
        else:
            require(record["viewer_backend"] == "x11" and
                    (not record["drawn"] or record["last_presentation_path"] == "rgb"),
                    "viewer presentation scope is not X11 RGB")
            count, frame = record["drawn"], record["last_frame"]
        if count:
            require(frame and frame["codec"] == "H.264" and
                    frame["source_dimensions"] == size and frame["encoded_dimensions"] == size,
                    "active frame metadata does not prove exact native-size H.264")
    return video, retained


def painter_result(rows, size):
    start, end = rows
    require(start["type"] == "p09_start" and end["type"] == "p09_end" and
            start["role"] == end["role"] == "source" and
            start["run_id"] == end["run_id"] == 1 and start["seed"] == 7 and
            [start["width"], start["height"]] == size and start["fps"] == 60 and
            end["submitted"] >= 2 and
            start["monotonic_ns"] <= end["first_submit_ns"] <
            end["last_submit_ns"] <= end["monotonic_ns"], "source painter scope or continuity differs")
    span = (end["last_submit_ns"] - end["first_submit_ns"]) / SECOND
    require(span >= BURN_SECONDS + MEASURE_SECONDS, "source does not span burn-in plus measurement")
    return {"start": start, "end": end, "painter_span_seconds": span,
            "submitted_per_second": (end["submitted"] - 1) / span}


def assessment(entries, terminal, size=DIMENSIONS):
    notes = []
    measured = {}
    available = {name: entries["trace/" + name] for name in RUN_FILES if "trace/" + name in entries}
    absent = sorted(set(RUN_FILES) - set(available))
    for name in absent:
        notes.append("missing trace: " + name)

    for role in ROLE:
        try:
            resource = resource_result(json_rows(available[role + "-resources.jsonl"]), role)
            measured[role] = {"resource": resource}
            video, retained = video_result(json_rows(available[role + "-telemetry.jsonl"]), role, resource, size)
            measured[role] |= {"video": video}
            if "retained-" + role + "-telemetry.jsonl" in available:
                require(json_rows(available["retained-" + role + "-telemetry.jsonl"]) == retained,
                        "controller retained windows differ from the recomputed windows")
        except INPUT_ERRORS as exc:
            notes.append(role + " replay: " + validation_reason(exc))
    same_session = all("video" in measured.get(role, {}) for role in ROLE) and (
        measured["host"]["video"]["session_id"] == measured["viewer"]["video"]["session_id"])
    if not same_session:
        notes.append("one matching authenticated host/viewer session was not established")

    painter = None
    try:
        painter = painter_result(json_rows(available["paint.jsonl"]), size)
    except INPUT_ERRORS as exc:
        notes.append("source replay: " + validation_reason(exc))

    diag = json.loads(entries["trace/terminal-diagnostics.json"])
    host = (diag["host"] or {}).get("matches", {})
    viewer = (diag["viewer"] or {}).get("matches", {})
    remote_closed = {"type": "p09_soak_host_closed", "status": 0} in diag["remote_bridge"]
    host_measured = {"type": "p09_soak_host_measured"} in diag["remote_bridge"]
    if not (host.get("nvenc_negotiated") and not host.get("hardware_encode_failed") and
            viewer.get("hardware_h264_active") and viewer.get("vaapi_active")):
        notes.append("expected NVENC and VA-API route diagnostics were not established")
    clean_close_observed = bool(host_measured and remote_closed and viewer.get("session_ended"))
    if not clean_close_observed:
        notes.append("clean close was not observed on both endpoints")

    result = None
    try:
        result = json.loads(available["result.json"])
        require(result["label"] == terminal["label"] and result["dimensions"] == size and
                result["clean_shutdown"] is True and
                all(result[key] == value for key, value in EXPECTED_MODE.items()),
                "controller result scope differs from the declared trial")
        actual_sides = {role: measured[role]["resource"] | {"video": measured[role]["video"]} for role in ROLE}
        require(result["role_results"] == normalized(actual_sides) and result["source"] == painter,
                "controller result differs from raw resource, telemetry, or painter replay")
    except INPUT_ERRORS as exc:
        notes.append("controller result replay: " + validation_reason(exc))
    if terminal["exit_status"] != 0:
        status = "failed"
        notes.append("controller returned nonzero")
    elif notes:
        status = "unqualified"
    else:
        status = "complete"
    return normalized({
        "status": status,
        "qualification": status == "complete",
        "endpoint_close_diagnostics_observed": clean_close_observed,
        "controller_confirmed_clean_shutdown": terminal["exit_status"] == 0 and clean_close_observed,
        "matching_authenticated_session": same_session,
        "replayed_roles": measured,
        "replayed_source": painter,
        "controller_result": result,
        "missing_traces": absent,
        "findings": notes,
    })


def validation_reason(exc):
    if type(exc) is ValueError:
        # Fixed sampler/summary diagnostics do not embed free-form input, except geometry.
        reason = str(exc)
        if reason.startswith("host changed capture geometry:"):
            return "host changed capture geometry"
        if reason.startswith("not enough values to unpack") or reason.startswith("too many values to unpack"):
            return "unexpected row count"
        return reason
    return type(exc).__name__


def build_payload(lab, run, exit_status, controller_log):
    entries = {"pins/" + name: (lab / name).read_bytes() for name in PIN_FILES}
    entries |= {"fixture/" + name: (lab / name).read_bytes() for name in FIXTURE_FILES}
    entries["fixture/archive_4k.py"] = Path(__file__).read_bytes()
    for name, relative in RUN_FILES.items():
        path = run / relative
        if path.is_file():
            entries["trace/" + name] = path.read_bytes()
    # Keep typed fixed diagnostics, without the runtime address, key path, or full command.
    entries["trace/terminal-diagnostics.json"] = as_bytes(diagnostics(run, controller_log))
    entries["trace/terminal.json"] = as_bytes({"label": run.name, "exit_status": exit_status})
    return entries


def build_report(entries):
    terminal = json.loads(entries["trace/terminal.json"])
    require(terminal["label"] == LABEL and type(terminal["exit_status"]) is int, "unexpected trial identity")
    return {
        "schema_version": 1,
        "experiment": {
            "dimensions": DIMENSIONS,
            "route": "Ubuntu private Xvfb host, SSH forwarding over the tested Wi-Fi link, Mint private Xvfb viewer.",
            "requested_mode": EXPECTED_MODE,
            "measurement_scope": (
                "Linux endpoint process RSS, FDs and threads, excluding private display, painter, SSH and GPU allocations. "
                "Drawn and ACK counts include repeated content. The two monotonic clocks summarize their own windows."
            ),
            "scope_of_qualification": (
                "Completion, identity, size, route, measurements and shutdown. "
                "Frame uniqueness and long-term leak behavior are outside this trial."
            ),
        },
        "terminal": terminal,
        "pins": verify_pins(entries),
        "assessment": assessment(entries, terminal),
    }


def verify_archive(report_path, archive_path):
    expected = json.loads(report_path.read_bytes())
    index = expected.pop("archive")
    require(index["path"] == archive_path.name and index["sha256"] == digest(archive_path.read_bytes()),
            "raw ZIP identity differs from its report")
    with ZipFile(archive_path) as reader:
        names = reader.namelist()
        require(len(names) == len(set(names)) and set(names) == set(index["entries"]),
                "raw ZIP inventory differs from its report")
        entries = {name: reader.read(name) for name in names}
    require({name: digest(data) for name, data in entries.items()} == index["entries"],
            "raw ZIP entry digest differs from its report")
    require(build_report(entries) == expected, "offline replay differs from published assessment")
    return expected


def publish(args):
    require(args.run.name == LABEL, "use the exact declared terminal 4K trial label")
    entries = build_payload(args.lab, args.run, args.controller_exit, args.controller_log)
    report = build_report(entries)
    args.out.mkdir(parents=True, exist_ok=True)
    raw = args.out / (STEM + "-raw.zip")
    summary = args.out / (STEM + ".json")
    require(not raw.exists() and not summary.exists(), "output artifacts already exist; use a fresh scratch output")
    with ZipFile(raw, "x", compression=ZIP_DEFLATED, compresslevel=7) as writer:
        for name, data in sorted(entries.items()):
            writer.writestr(name, data)
    report["archive"] = {
        "path": raw.name,
        "sha256": digest(raw.read_bytes()),
        "entries": {name: digest(data) for name, data in entries.items()},
    }
    with summary.open("xb") as output:
        output.write(as_bytes(report))
    verify_archive(summary, raw)
    print(report["assessment"]["status"], summary, raw)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    pack = commands.add_parser("publish")
    pack.add_argument("--run", required=True, type=Path)
    pack.add_argument("--controller-exit", required=True, type=int, help="Observed terminal status from the trial controller")
    pack.add_argument("--controller-log", type=Path)
    pack.add_argument("--lab", type=Path, default=LAB)
    pack.add_argument("--out", required=True, type=Path)
    replay = commands.add_parser("replay")
    replay.add_argument("summary", type=Path)
    replay.add_argument("archive", type=Path)
    args = parser.parse_args()
    if args.command == "publish":
        publish(args)
    else:
        report = verify_archive(args.summary, args.archive)
        print(report["assessment"]["status"], "reproduced from", args.archive)


if __name__ == "__main__":
    main()
