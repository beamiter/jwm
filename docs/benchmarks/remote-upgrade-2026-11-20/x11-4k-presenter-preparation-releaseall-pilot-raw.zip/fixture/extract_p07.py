from pathlib import Path
from hashlib import sha256
import ast

base = Path('/tmp/jwm-p07-normal-dual-terminal.gMagY8oC/normal-release.py')
raw = base.read_bytes()
assert sha256(raw).hexdigest() == 'b7bf2bc50f132f1336b8b30c6dbf5ebcdcc0f0a4ea0275e4e29ff16e8125dbec'
source = raw.decode()
items = ['require', 'key_codes', 'held', 'grab_probe', 'send', 'Lines', 'expected_edges',
         'Watch', 'timed_out', 'measure_sample', 'normal_close', 'terminate_signal',
         'phase_samples', 'distribution']
found = {node.name: ast.get_source_segment(source, node) for node in ast.parse(source).body
         if isinstance(node, (ast.FunctionDef, ast.ClassDef))}
head = '''"""Unmodified local input probe helpers copied from the P07 observer fixture."""
from collections import deque
import json
import math
import os
import select
import signal
import subprocess
import time

from Xlib import X, XK
from Xlib.ext import xtest
from Xlib.protocol import event

KEY_NAMES = ('F8', 'F9', 'Control_L', 'Super_L', 'F12')
'''
Path(__file__).with_name('p07_core.py').write_text(head + '\n\n' + '\n\n\n'.join(found[name] for name in items) + '\n')
