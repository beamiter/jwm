"""Unmodified local input probe helpers copied from the P07 observer fixture."""
from collections import deque
import json
import math
import os
import select
import signal
import subprocess
import time

from Xlib import X, XK
from Xlib.ext import xtest
from Xlib.protocol import event

KEY_NAMES = ('F8', 'F9', 'Control_L', 'Super_L', 'F12')


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def key_codes(conn):
    codes = {name: conn.keysym_to_keycode(XK.string_to_keysym(name)) for name in KEY_NAMES}
    require(0 not in codes.values() and len(set(codes.values())) == len(KEY_NAMES), 'probe keymap unavailable')
    return codes


def held(conn, codes):
    state = conn.query_keymap()
    return [code for code in codes if state[code // 8] & (1 << (code % 8))]


def grab_probe(conn):
    root = conn.screen().root
    keyboard = root.grab_keyboard(False, X.GrabModeAsync, X.GrabModeAsync, X.CurrentTime)
    try:
        pointer = root.grab_pointer(False, X.ButtonPressMask, X.GrabModeAsync, X.GrabModeAsync,
                                    X.NONE, X.NONE, X.CurrentTime)
        if pointer == X.GrabSuccess:
            conn.ungrab_pointer(X.CurrentTime)
        return [keyboard, pointer]
    finally:
        if keyboard == X.GrabSuccess:
            conn.ungrab_keyboard(X.CurrentTime)
        conn.sync()


def send(stream, value):
    stream.write(json.dumps(value, separators=(',', ':')).encode() + b'\n')
    stream.flush()


class Lines:
    """Timestamp complete decoded lines using the reader's monotonic clock."""
    def __init__(self, stream):
        self.stream = stream
        self.data = b''
        self.pending = deque()
        self.eof = False

    def read_ready(self):
        block = os.read(self.stream.fileno(), 65536)
        arrived = time.monotonic_ns()
        if not block:
            self.eof = True
            require(not self.data, 'partial observer line at EOF')
            return
        self.data += block
        require(len(self.data) <= 1 << 20, 'observer line exceeds limit')
        while b'\n' in self.data:
            line, self.data = self.data.split(b'\n', 1)
            if line:
                self.pending.append((json.loads(line), arrived))

    def next(self, deadline):
        while not self.pending:
            if self.eof:
                raise RuntimeError('observer channel closed')
            remaining = deadline - time.monotonic()
            if remaining <= 0 or not select.select([self.stream], [], [], remaining)[0]:
                raise TimeoutError('observer message deadline expired')
            self.read_ready()
        return self.pending.popleft()


def expected_edges(row, codes):
    actual = [(edge['type'], edge['detail']) for edge in row['source_edges']]
    old = row['held_keycode']
    modifier_keys = [codes['Control_L'], codes['Super_L']]
    modifiers = [detail for kind, detail in actual[3:] if kind == X.KeyPress]
    require(modifiers == [code for code in modifier_keys if code in modifiers], 'unexpected forwarded chord press')
    expected = ([(X.ButtonPress, 1), (X.ButtonRelease, 1), (X.KeyPress, old)]
                + [(X.KeyPress, code) for code in modifiers]
                + [(X.KeyRelease, code) for code in reversed(modifiers)] + [(X.KeyRelease, old)])
    require(actual == expected, f'wrong actual order {actual}; expected {expected}')
    require([edge['index'] for edge in row['source_edges']] == list(range(1, len(expected) + 1)),
            'missing or duplicate source observer record')


class Watch:
    def __init__(self, worker):
        self.worker = worker
        self.lines = Lines(worker.stdout)
        self.edges = {0: []}
        self.seq = 0
        self.request_id = 0
        self.pending_control = None

    def control_identity(self, op, seq, **fields):
        self.request_id += 1
        return {'op': op, 'seq': seq, 'request_id': self.request_id, **fields}

    def request(self, op, seq, **fields):
        require(self.pending_control is None, 'source control already has an outstanding request')
        command = self.control_identity(op, seq, **fields)
        self.pending_control = {**command, 'viewer_request_ns': time.monotonic_ns()}
        send(self.worker.stdin, command)

    def next_reply(self, deadline):
        reply, received = self.lines.next(deadline)
        reply['viewer_receipt_ns'] = received
        if reply['event'] == 'error':
            raise RuntimeError(f"owned source observer {reply['error']}: {reply['detail']}")
        return reply

    @staticmethod
    def matches_control(reply, command, name, *, actual_seq=None, **matches):
        return (reply.get('event') == name and reply.get('seq') == (command['seq'] if actual_seq is None else actual_seq)
                and reply.get('request_id') == command['request_id'] and reply.get('request_seq') == command['seq']
                and all(reply.get(key) == value for key, value in matches.items()))

    def until(self, deadline, predicate):
        while True:
            reply = self.next_reply(deadline)
            if reply['event'] == 'edge':
                seq = reply['seq']
                require(seq in self.edges and seq == self.seq, 'source edge tagged outside the active sample')
                self.edges[seq].append(reply)
            if predicate(reply):
                return reply
            require(reply['event'] == 'edge', 'unexpected source reply type')

    def control(self, deadline, name, seq, **matches):
        command = self.pending_control
        require(command is not None and command['seq'] == seq, 'no matching source control request')
        reply = self.until(deadline, lambda item: self.matches_control(item, command, name, **matches))
        self.pending_control = None
        return reply

    def finish_after_failure(self, deadline, diagnostic):
        # Scoring has already stopped. Preserve an actual late echo and any
        # terminal edges separately. Never append them to measured rows.
        pending = self.pending_control
        terminal_fields = {}
        valid_seqs = {self.seq}
        if pending and pending['op'] == 'arm':
            require(pending['seq'] == self.seq + 1, 'abandoned source arm identity mismatch')
            terminal_fields['abandoned_arm_seq'] = pending['seq']
            valid_seqs.add(pending['seq'])
        terminal = self.control_identity('finish', self.seq, **terminal_fields)
        diagnostic.update(pending_control=pending, finish_command=terminal, late_replies=[])
        send(self.worker.stdin, terminal)
        may_consume_pending = pending is not None
        while len(diagnostic['late_replies']) < 32:
            reply = self.next_reply(deadline)
            actual_seq = reply.get('seq')
            if (actual_seq in valid_seqs
                    and self.matches_control(reply, terminal, 'finished', actual_seq=actual_seq)):
                diagnostic['finished_receipt_ns'] = reply['viewer_receipt_ns']
                self.pending_control = None
                return reply
            diagnostic['late_replies'].append(reply)
            if reply['event'] == 'edge' and actual_seq in valid_seqs:
                continue
            if may_consume_pending and pending['op'] == 'snapshot' and self.matches_control(
                    reply, pending, 'snapshot', token=pending['token']):
                may_consume_pending = False
                continue
            if may_consume_pending and pending['op'] == 'arm' and self.matches_control(reply, pending, 'armed'):
                may_consume_pending = False
                continue
            raise RuntimeError('unexpected source reply identity during failed-measurement teardown')
        raise RuntimeError('too many replies during failed-measurement teardown')

    def edge(self, deadline, seq, kind, detail):
        return self.until(deadline, lambda reply: reply['event'] == 'edge' and reply['seq'] == seq
                          and (reply['type'], reply['detail']) == (kind, detail))


def timed_out(_signum, _frame):
    raise TimeoutError('per-sample deadline expired')


def measure_sample(row, watch, conn, grab_conn, win, codes, duration, profile, inline_release_proof):
    seq = row['seq']
    deadline = time.monotonic() + duration
    old = row['held_keycode']
    chord = [codes['Control_L'], codes['Super_L'], codes['F12']]
    key_set = list(codes.values())

    def stage(value):
        row['stage'] = value

    def issue(label, kind, detail=0, *, x=0, y=0):
        started = time.monotonic_ns()
        xtest.fake_input(conn, kind, detail, x=x, y=y)
        conn.flush()
        row['viewer_actions'].append({'event': label, 'type': kind, 'detail': detail, 'at_ns': started})
        return started

    signal.setitimer(signal.ITIMER_REAL, duration)
    try:
        stage('arm')
        watch.edges[seq] = row['source_edges']
        watch.request('arm', seq, held_keycode=old)
        watch.control(deadline, 'armed', seq)
        watch.seq = seq
        stage('reacquire')
        win.set_input_focus(X.RevertToParent, X.CurrentTime)
        geo = win.get_geometry()
        issue('focus_pointer', X.MotionNotify, x=geo.x + geo.width // 2, y=geo.y + geo.height // 2)
        issue('reacquire_button_down', X.ButtonPress, 1)
        watch.edge(deadline, seq, X.ButtonPress, 1)
        issue('reacquire_button_up', X.ButtonRelease, 1)
        watch.edge(deadline, seq, X.ButtonRelease, 1)
        row['grab_before'] = grab_probe(grab_conn)
        require(row['grab_before'] == [X.AlreadyGrabbed] * 2, 'viewer did not reacquire both local grabs')
        stage('host_held_key')
        issue('held_key_down', X.KeyPress, old)
        watch.edge(deadline, seq, X.KeyPress, old)
        watch.request('snapshot', seq, token='held')
        row['host_held_before'] = watch.control(deadline, 'snapshot', seq, token='held')['host_held']
        row['viewer_held_before'] = held(conn, key_set)
        require(row['host_held_before'] == row['viewer_held_before'] == [old], 'original key not held on both systems')
        stage('host_release')
        for code in chord[:2]:
            issue('shortcut_modifier_down', X.KeyPress, code)
        row['viewer_issue_ns'] = issue('shortcut_trigger_down', X.KeyPress, chord[-1])
        released = watch.edge(deadline, seq, X.KeyRelease, old)
        row['host_edge_ns'], row['viewer_receipt_ns'] = released['host_ns'], released['viewer_receipt_ns']
        end = row['host_edge_ns'] if profile == 'loopback' else row['viewer_receipt_ns']
        row['latency_ns'] = end - row['viewer_issue_ns']
        require(row['latency_ns'] >= 0, 'noncausal release observation')
        stage('prove_release_before_local_key_up')
        if inline_release_proof:
            row['host_held_after'] = released['host_held_at_release']
            row['host_keymap_checked_ns'] = released['host_keymap_checked_ns']
            require(row['host_keymap_checked_ns'] >= row['host_edge_ns'], 'source keymap proof preceded the release edge')
        else:
            watch.request('snapshot', seq, token='released')
            row['host_held_after'] = watch.control(deadline, 'snapshot', seq, token='released')['host_held']
        row['viewer_held_before_cleanup'] = held(conn, key_set)
        require(row['host_held_after'] == [] and set(row['viewer_held_before_cleanup']) == {old, *chord},
                'source did not clear keys before local held-key release')
        row['grab_after'] = grab_probe(grab_conn)
        require(row['grab_after'] == [X.GrabSuccess] * 2, 'viewer did not relinquish both local grabs')
        stage('cleanup')
        for code in reversed(chord):
            issue('shortcut_cleanup_up', X.KeyRelease, code)
        row['viewer_local_key_up_ns'] = issue('held_key_local_up', X.KeyRelease, old)
        conn.sync()
        row['viewer_held_after_cleanup'] = held(conn, key_set)
        require(not row['viewer_held_after_cleanup'], 'probe left a locally held key')
        expected_edges(row, codes)
        row['status'] = 'passed'
        row['stage'] = 'complete'
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)


def normal_close(conn, win, viewer):
    close = event.ClientMessage(window=win, client_type=conn.intern_atom('WM_PROTOCOLS'),
                                data=(32, [conn.intern_atom('WM_DELETE_WINDOW'), 0, 0, 0, 0]))
    win.send_event(close)
    conn.flush()
    return viewer.wait(timeout=8)


def terminate_signal(signum, _frame):
    raise KeyboardInterrupt(f'owned probe stopped by signal {signum}')


def phase_samples(kind, total, start_ns, duration_ns, session, ledger, watch, conn, probe, win, codes, args):
    rows = session['warmup_samples'] if kind == 'warmup' else session['samples']
    end_ns = start_ns + duration_ns
    for slot in range(total):
        slot_at = start_ns + (duration_ns * slot // total)
        next_slot = start_ns + (duration_ns * (slot + 1) // total)
        delay = (slot_at - time.monotonic_ns()) / 1_000_000_000
        if delay > 0:
            time.sleep(delay)
        row = {'phase': kind, 'slot': slot + 1, 'planned_slot_ns': slot_at, 'viewer_actions': [], 'source_edges': []}
        try:
            now_ns = time.monotonic_ns()
            if now_ns >= next_slot:
                row['status'] = 'not_issued'
                row['stage'] = 'slot_elapsed_while_prior_sample_in_flight'
                continue
            row['seq'] = watch.seq + 1
            row['held_keycode'] = codes[KEY_NAMES[(row['seq'] - 1) % 2]]
            row['started_ns'] = now_ns
            deadline = min(args.deadline_ms / 1000, (end_ns - now_ns) / 1_000_000_000)
            if deadline <= 0:
                row['status'] = 'not_issued'
                row['stage'] = 'window_ended'
                continue
            measure_sample(row, watch, conn, probe, win, codes, deadline, args.profile,
                           args.inline_release_proof)
            if not start_ns <= row['viewer_issue_ns'] <= row['viewer_receipt_ns'] < end_ns:
                raise TimeoutError('shortcut or observer receipt fell outside the exact phase')
        except (TimeoutError, subprocess.TimeoutExpired) as error:
            row['status'] = 'timeout'
            row['error'] = type(error).__name__
            row['detail'] = str(error)
            raise
        except BaseException as error:
            row['status'] = 'failed'
            row['error'] = type(error).__name__
            row['detail'] = str(error)
            raise
        finally:
            row['observations_finished_locally_ns'] = time.monotonic_ns()
            rows.append(row)
            ledger.write(json.dumps(row, separators=(',', ':')) + '\n')
            ledger.flush()
    remaining = (end_ns - time.monotonic_ns()) / 1_000_000_000
    if remaining > 0:
        time.sleep(remaining)


def distribution(rows):
    values = sorted(row['latency_ns'] for row in rows if row['status'] == 'passed')
    if not values:
        return None
    def percentile(p):
        return values[math.ceil(len(values) * p) - 1] / 1_000_000
    return {'observations': len(values), 'p50_ms': percentile(.5), 'p95_ms': percentile(.95), 'max_ms': values[-1] / 1_000_000}
