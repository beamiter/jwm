#!/usr/bin/env python3
"""Viewer CPU preparation A/B with active 4K H.264 and actual ReleaseAll."""
import argparse
from contextlib import ExitStack
import json
import math
from pathlib import Path
import re
import select
import signal
import subprocess
import sys
from threading import Thread
import time
from types import SimpleNamespace

from Xlib import X, display

import p07_core as p07
from processes import clean_env, get_display, sha256, start_display, stop

SIZE = (3840, 2160)
FPS = 30
WARMUP, SCORED = 30, 60
SAMPLES = 100
SECOND = 1_000_000_000
TOGGLE = 'JWM_REMOTE_X11_PREPARE'
RELEASE = Path('/tmp/jwm-x11-prepare-release.ntmgdBNj/jwm-remote')
RELEASE_SHA = '5945a9d94a65699ea0514be3bff6328f976d776ea8e94410d48b451ed034d371'
MARKER = Path('/tmp/jwm-p09-workload/p09-workload')
MARKER_SHA = 'b79b433f17f1e061d30dc9fc4d5bb7cf867535c8ed4ca002987cc30640a21706'
EDGES = (X.KeyPress, X.KeyRelease, X.ButtonPress, X.ButtonRelease)
require = p07.require


def jsonl(path):
    return [json.loads(line) for line in path.read_text(errors='replace').splitlines()
            if line.startswith('{') and line.endswith('}')]


def await_owned(children, detail, check, timeout=17):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        for process in children:
            require(process.poll() is None, f'{detail}: owned child exited {process.returncode}')
        if result := check():
            return result
        time.sleep(.015)
    raise TimeoutError(detail)


def dimensions(window):
    g = window.get_geometry()
    return (g.width, g.height)


def watcher(display_name, xid):
    # The previously pinned P09 painter opened its own window, without an
    # exclusive button selector. Observe its actual target, never a proxy
    # window or a synthetic protocol event sample.
    conn = display.Display(display_name)
    command_wire = p07.Lines(sys.stdin.buffer)
    out = sys.stdout.buffer
    try:
        source = conn.create_resource_object('window', xid)
        require(source.get_wm_name() == 'JWM P09 motion fixture' and dimensions(source) == SIZE
                and source.get_attributes().map_state == X.IsViewable, 'wrong owned painter input recipient')
        require(conn.has_extension('XTEST'), 'source XTEST unavailable')
        conn.change_keyboard_control(auto_repeat_mode=X.AutoRepeatModeOff)
        source.change_attributes(event_mask=X.KeyPressMask | X.KeyReleaseMask | X.ButtonPressMask | X.ButtonReleaseMask)
        source.set_input_focus(X.RevertToParent, X.CurrentTime)
        conn.sync()
        seq, index = 0, 0
        codes = p07.key_codes(conn)
        key_set = list(codes.values())
        p07.send(out, {'event': 'ready', 'keys': codes, 'target': xid, 'clock': 'CLOCK_MONOTONIC'})

        def drain():
            nonlocal index
            while conn.pending_events():
                received = conn.next_event()
                observed = time.monotonic_ns()
                if received.type in EDGES:
                    require(seq and received.window.id == xid and not received.send_event,
                            'source edge is not real input in the owned painter window')
                    index += 1
                    p07.send(out, {'event': 'edge', 'seq': seq, 'index': index,
                                   'type': received.type, 'detail': received.detail, 'host_ns': observed})

        def reply(request, kind, **fields):
            p07.send(out, {'event': kind, 'seq': seq, 'request_id': request['request_id'],
                           'request_seq': request['seq'], **fields})

        while True:
            drain()
            if not command_wire.pending:
                ready, _, _ = select.select([command_wire.stream, conn.fileno()], [], [], 2)
                if command_wire.stream in ready:
                    command_wire.read_ready()
                if command_wire.eof:
                    return 0
                drain()
            if not command_wire.pending:
                continue
            command, _ = command_wire.pending.popleft()
            op, target_seq = command['op'], command['seq']
            if op == 'arm':
                require(target_seq == seq + 1 and command['held_keycode'] == codes[p07.KEY_NAMES[(target_seq - 1) % 2]],
                        'source arm identity mismatch')
                keys = p07.held(conn, key_set)
                drain()
                require(not keys, 'source keys survived the previous release')
                seq, index = target_seq, 0
                reply(command, 'armed', host_held=keys)
            elif op == 'snapshot':
                require(target_seq == seq, 'snapshot identity mismatch')
                keys = p07.held(conn, key_set)
                drain()
                reply(command, 'snapshot', token=command['token'], host_held=keys)
            elif op == 'finish':
                require(target_seq == seq or command.get('abandoned_arm_seq') == target_seq + 1 == seq,
                        'terminal watcher identity mismatch')
                keys = p07.held(conn, key_set)
                drain()
                reply(command, 'finished', host_held_when_finished=keys)
                return 0
            else:
                raise RuntimeError('unknown source observer command')
    except Exception as error:
        p07.send(out, {'event': 'error', 'error': type(error).__name__, 'detail': str(error)})
        return 1
    finally:
        conn.close()


def scope_window(conn):
    label = conn.intern_atom('_NET_WM_NAME')
    matches = []
    for win in conn.screen().root.query_tree().children:
        prop = win.get_full_property(label, X.AnyPropertyType)
        title = prop.value.decode(errors='replace') if prop and isinstance(prop.value, bytes) else win.get_wm_name()
        if isinstance(title, str) and ' - JWM Remote' in title:
            matches.append(win)
    require(len(matches) <= 1, 'multiple viewers in isolated display')
    return matches[0] if matches else None


def paint_score(records, run_id, start, end):
    opened = next(row for row in records if row['type'] == 'p09_start')
    closed = next(row for row in records if row['type'] == 'p09_end')
    require((opened['width'], opened['height']) == SIZE and opened['run_id'] == closed['run_id'] == run_id
            and opened['monotonic_ns'] <= start < end <= closed['monotonic_ns']
            and not any(closed[name] for name in ('target_lost', 'interrupted', 'wrong_run', 'reordered')),
            'marker observer lost its scope, identity or complete scored interval')
    marks = [row for row in records if row['type'] == 'p09_frame' and start <= row['monotonic_ns'] < end]
    require(marks and all(row['run_id'] == run_id for row in marks)
            and all(b['source_frame'] > a['source_frame'] and b['monotonic_ns'] > a['monotonic_ns']
                    for a, b in zip(marks, marks[1:])), 'visible marker sequence empty, duplicated or regressed')
    points = [start, *[row['monotonic_ns'] for row in marks], end]
    gaps = sorted((b - a) / 1_000_000 for a, b in zip(points, points[1:]))
    bins = [0] * math.ceil((end - start) / SECOND)
    for row in marks:
        bins[(row['monotonic_ns'] - start) // SECOND] += 1
    return {'unique_frames': len(marks), 'unique_fps': len(marks) * SECOND / (end - start),
            'gap_p95_ms': gaps[math.ceil(.95 * len(gaps)) - 1], 'longest_gap_ms': gaps[-1],
            'one_second_bins': bins, 'invalid_reads_total': closed['invalid'], 'duplicate_reads_total': closed['duplicates']}


def endpoint_stats(path, endpoint):
    return [row for row in jsonl(path) if row.get('type') == f'jwm_remote_{endpoint}_stats']


def stage_telemetry(source, clocks, score_start, score_end):
    # Pair complete same-process stderr records to local observations. A
    # receipt window is diagnostic and is not an exact presenter time bin.
    require(len(source) == len(clocks), 'viewer telemetry did not align to receipt timestamps')
    out = []
    for index, (row, clock) in enumerate(zip(source, clocks), 1):
        require(clock['telemetry_record'] == index, 'viewer telemetry receipt order changed')
        arrived = clock['received_ns']
        out.append({name: row['stages'].get(name) for name in ('x11_presenter_submit_ms', 'x11_cpu_prepare_ms',
                    'presentation_completion_ms', 'sender_input_queue_ms', 'sender_control_write_ms')}
                   | {'window_seconds': row['window_seconds'], 'final': row['final'], 'received_ns': arrived,
                      'receipt_in_scored_interior': (not row['final']
                          and score_start + int(row['window_seconds'] * SECOND) <= arrived < score_end),
                      'worker': row.get('x11_cpu_preparation')})
    return out


def route_witness(host, view, host_log, view_log, arm, windows):
    require(host and view and view[-1]['final'], 'endpoint telemetry incomplete')
    a, b = {row.get('session_id') for row in host}, {row.get('session_id') for row in view}
    require(a == b and len(a) == 1 and None not in a, 'auth endpoint scopes did not agree')
    require(host_log.count('authenticated session started (screen + pointer + keyboard)') == 1
            and view_log.count('connected; keyboard + pointer; clipboard off') == 1, 'authenticated input grant missing')
    require('hardware H.264 encoding active (NVENC)' in host_log
            and 'H.264 hardware decoder active (VAAPI)' in view_log and 'host switched to JPEG' not in view_log,
            'required NVENC / VA-API hardware codec not established')
    frames = [row['last_sent_frame'] for row in host if row.get('last_sent_frame')]
    frames += [row['last_frame'] for row in view if row.get('last_frame')]
    require(frames and all(frame['codec'] == 'H.264' and frame['source_dimensions'] == frame['encoded_dimensions'] == list(SIZE)
                           for frame in frames)
            and all(row.get('last_presentation_path') in ('rgb', None) for row in view)
            and all(row.get('negotiated_codec') == 'H.264' for row in view)
            and any(row.get('last_presentation_path') == 'rgb' for row in view)
            and sum(row.get('h264_frames', 0) for row in host) > 0, 'fixed native 4K CPU RGB route changed')
    epochs = {(frame['source_epoch'], frame['geometry_epoch']) for frame in frames}
    require(len(epochs) == 1, 'scope geometry or source changed during measurement')
    toggled = {key: sum(int((row.get('x11_cpu_preparation') or {}).get(key) or 0) for row in view)
              for key in ('scheduled', 'prepared', 'submitted', 'stale', 'fallbacks')}
    samples = sum(int((row.get('stages', {}).get('x11_cpu_prepare_ms') or {}).get('observations', 0)) for row in view)
    require(all(bool(toggled[k]) == (arm == 'on') for k in ('scheduled', 'prepared', 'submitted'))
            and bool(samples) == (arm == 'on'), 'worker preparation/submission route inactive or contaminated')
    require(sum((row.get('stages', {}).get('hardware_download_ms') or {}).get('observations', 0) for row in view) > 0,
            'missing actual VA-API downloads for CPU RGB')
    interior = [row for row in windows if row['receipt_in_scored_interior']]
    require(bool(interior), 'no active viewer telemetry receipt in the scored interior')
    interior_submissions = sum(int((row['worker'] or {}).get('submitted') or 0) for row in interior)
    interior_ui_samples = sum(int((row['x11_presenter_submit_ms'] or {}).get('observations') or 0) for row in interior)
    require(bool(interior_submissions) == (arm == 'on') and interior_ui_samples > 0,
            'worker activation or real X11 presenter submission missing in scored interior windows')
    return {'host_and_viewer_same_authenticated_session': True, 'scopes': [list(item) for item in sorted(epochs)],
            'interior_telemetry_receipt_windows': len(interior), 'interior_worker_submitted': interior_submissions,
            'interior_presenter_submit_samples': interior_ui_samples,
            'host_frames_h264': sum(row['h264_frames'] for row in host), 'worker': toggled | {'stage_samples': samples},
            'viewer_acked': sum(row['acked'] for row in view), 'host_drawn_acks': sum(row['drawn_acks'] for row in host)}


def input_counts(rows):
    return {'scheduled': SAMPLES, 'attempted': sum('seq' in row for row in rows),
            'qualified_samples': sum(row['status'] == 'passed' for row in rows),
            'timeouts': sum(row['status'] == 'timeout' for row in rows),
            'explicit_unissued': sum(row['status'] == 'not_issued' for row in rows),
            'slots_not_reached': SAMPLES - len(rows)}


def note_latency(rows, start, end):
    passed = [row for row in rows if row['status'] == 'passed']
    for row in passed:
        require(start <= row['viewer_issue_ns'] <= row['host_edge_ns'] <= row['viewer_receipt_ns']
                < row['viewer_local_key_up_ns'] < end
                and row['latency_ns'] == row['host_edge_ns'] - row['viewer_issue_ns'],
                'input witness outside same monotonic interval or wrong order')
    return {'actual_issue_to_source_x11_observer': p07.distribution(passed),
            'conservative_issue_to_local_observer_reply': p07.distribution([
                {'status': 'passed', 'latency_ns': row['viewer_receipt_ns'] - row['viewer_issue_ns']} for row in passed]),
            **input_counts(rows)}


def run_arm(args, arm, run_id, directory, report):
    with ExitStack() as owned:
        def log(name):
            return owned.enter_context((directory / name).open('wb'))

        def launch(command, name, env):
            process = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=log(name),
                                       stderr=log(name + '.stderr'), env=env)
            owned.callback(stop, process)
            return process

        def endpoint(command, name, env):
            output = log(name + '.log')
            clocks = log(name + '-stats-clock.jsonl')
            process = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                       stderr=subprocess.STDOUT, env=env)

            def drain():
                index = 0
                for line in process.stdout:
                    now = time.monotonic_ns()
                    output.write(line)
                    output.flush()
                    if line.startswith(b'{'):
                        index += 1
                        clocks.write(json.dumps({'telemetry_record': index, 'received_ns': now}).encode() + b'\n')
                        clocks.flush()

            reader = Thread(target=drain, daemon=True)
            reader.start()
            owned.callback(reader.join, 3)
            owned.callback(stop, process)
            return process, reader

        env = clean_env()
        env.pop('XAUTHORITY', None)
        env['XDG_CACHE_HOME'] = str(directory / 'cache')
        if args.lib:
            env['LD_LIBRARY_PATH'] = args.lib
        source_x = start_display(*SIZE, log('source-xvfb.log'))
        owned.callback(stop, source_x)
        local_x = start_display(*SIZE, log('viewer-xvfb.log'))
        owned.callback(stop, local_x)
        host_display, viewer_display = get_display(source_x), get_display(local_x)
        local, grab = display.Display(viewer_display), display.Display(viewer_display)
        owned.callback(local.close)
        owned.callback(grab.close)
        require(local.has_extension('XTEST'), 'owned viewer XTEST unavailable')
        local.change_keyboard_control(auto_repeat_mode=X.AutoRepeatModeOff)
        local.sync()
        codes = p07.key_codes(local)
        report['probe_keycodes'] = codes
        key = directory / 'private.key'
        owned.callback(key.unlink, missing_ok=True)
        subprocess.run([args.binary, 'keygen', '--output', key], env=env, check=True, timeout=8,
                       stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL)
        marker_flags = ['--width', str(SIZE[0]), '--height', str(SIZE[1]), '--run-id', str(run_id)]
        painter = launch([args.marker, 'paint', '--display', host_display, '--fps', str(FPS), '--seed', '1',
                          '--seconds', str(WARMUP + SCORED + 65), *marker_flags], 'painter.jsonl', env)
        painter_log = directory / 'painter.jsonl'
        opened = await_owned((painter,), 'actual source painter', lambda: next((r for r in jsonl(painter_log)
                              if r['type'] == 'p09_start'), None))
        require(opened['run_id'] == run_id and (opened['width'], opened['height']) == SIZE, 'painter route mismatch')
        input_observer = subprocess.Popen([sys.executable, '-B', str(Path(__file__).resolve()), '_watch',
                                           host_display, opened['window']], env=env,
                                          stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                          stderr=log('source-input-observer.stderr'))
        owned.callback(stop, input_observer)
        watch = p07.Watch(input_observer)
        ready = watch.until(time.monotonic() + 12, lambda r: r['event'] == 'ready')
        require(ready['keys'] == codes and ready['target'] == int(opened['window'], 16)
                and ready['clock'] == 'CLOCK_MONOTONIC', 'source and viewer input scope/keymap disagree')
        host, host_reader = endpoint([args.binary, 'host', '--display', host_display, '--capture-source', 'root',
                  '--scaling', 'auto', '--key-file', key, '--once', '--stats-json', '--allow-h264', '--allow-input',
                  '--max-width', '0', '--fps', str(FPS), '--listen', '127.0.0.1:0'], 'host', env)
        hlog, vlog = directory / 'host.log', directory / 'viewer.log'
        port = await_owned((host,), 'authenticated host listener', lambda: re.search(r'listening on 127\.0\.0\.1:(\d+)',
                          hlog.read_text(errors='replace')))[1]
        viewer_env = env | ({TOGGLE: '1'} if arm == 'on' else {})
        viewer, viewer_reader = endpoint([args.binary, 'connect', f'127.0.0.1:{port}', '--display', viewer_display,
                     '--key-file', key, '--grab-input', '--escape-key', 'F12', '--stats-json', '--scaling', 'cpu',
                     '--window-size', '3840x2160', '--window-position', '0,0'], 'viewer', viewer_env)
        app = (host, viewer, painter, input_observer)
        win = await_owned(app, 'actual X11 viewer window', lambda: scope_window(local))
        require(dimensions(win) == SIZE, 'viewer is not 3840x2160')
        await_owned(app, 'actual authenticated input grant', lambda:
                    'connected; keyboard + pointer; clipboard off' in vlog.read_text(errors='replace'))

        marker_observers = {}
        marker_logs = {}
        for endpoint_name, display_name, window in (('source', host_display, opened['window']),
                                                      ('viewer', viewer_display, hex(win.id))):
            logname = endpoint_name + '-visible-marker.jsonl'
            marker_logs[endpoint_name] = directory / logname
            marker_observers[endpoint_name] = launch([args.marker, 'observe', '--display', display_name, '--window', window,
                '--poll-hz', '90', '--seconds', str(WARMUP + SCORED + 14), *marker_flags], logname, env)
        worker_set = (*app, *marker_observers.values())
        for endpoint_name, logfile in marker_logs.items():
            await_owned(worker_set, f'first validated visible {endpoint_name} marker', lambda: next((r for r in jsonl(logfile)
                        if r['type'] == 'p09_frame' and r['run_id'] == run_id), None))
        warm_start = time.monotonic_ns() + 50_000_000
        score_start = warm_start + WARMUP * SECOND
        score_end = score_start + SCORED * SECOND
        report['phase_clock_ns'] = {'warmup_begin': warm_start, 'score_begin': score_start, 'score_end': score_end}
        probe_options = SimpleNamespace(deadline_ms=args.deadline_ms, profile='loopback', inline_release_proof=False)
        input_error = None
        with (directory / 'input-samples.jsonl').open('w') as ledger:
            try:
                p07.phase_samples('warmup', WARMUP, warm_start, WARMUP * SECOND, report,
                                  ledger, watch, local, grab, win, codes, probe_options)
                p07.phase_samples('scored', SAMPLES, score_start, SCORED * SECOND, report,
                                  ledger, watch, local, grab, win, codes, probe_options)
            except Exception as error:
                input_error = error
                report['input_error'] = {'kind': type(error).__name__, 'detail': str(error)}
        report['input_counts'] = input_counts(report['samples'])

        # Independent marker readers continue and keep boundary gaps even if
        # the input loop fails. Do not manufacture local cleanup to salvage a
        # timed-out sample. The fixture is wholly isolated until viewer close.
        report['marker_exits'] = {name: proc.wait(timeout=max(12, (score_end - time.monotonic_ns()) / SECOND + 19))
                                  for name, proc in marker_observers.items()}
        require(set(report['marker_exits'].values()) == {0} and dimensions(win) == SIZE,
                'marker observer or actual fixed viewer geometry failed')
        observed_motion = {ep: paint_score(jsonl(path), run_id, score_start, score_end) for ep, path in marker_logs.items()}
        source_bins = observed_motion['source']['one_second_bins']
        require(all(any(source_bins[i:i + 10]) for i in range(0, SCORED, 10)),
                'source motion witness does not span all six scored blocks')
        report['viewer_exit'] = p07.normal_close(local, win, viewer)
        report['host_exit'] = host.wait(timeout=10)
        host_reader.join(3)
        viewer_reader.join(3)
        require(not host_reader.is_alive() and not viewer_reader.is_alive(), 'endpoint output reader did not drain')
        try:
            if input_error is None:
                watch.request('finish', watch.seq)
                finished = watch.control(time.monotonic() + 8, 'finished', watch.seq)
            else:
                report['late_observer_replies'] = {}
                finished = watch.finish_after_failure(time.monotonic() + 8, report['late_observer_replies'])
            report['source_post_close_held'] = finished['host_held_when_finished']
            report['source_input_observer_exit'] = input_observer.wait(timeout=5)
        except Exception as error:
            report['input_teardown_error'] = {'kind': type(error).__name__, 'detail': str(error)}
            require(input_error is not None, 'input watcher failed healthy teardown')
        painter.terminate()
        report['painter_exit'] = painter.wait(timeout=6)
        report['painter_terminal'] = next(row for row in jsonl(painter_log) if row['type'] == 'p09_end')
        require(report['viewer_exit'] == report['host_exit'] == report['painter_exit'] == 0,
                'owned codec endpoint or painter did not exit cleanly')
        vst, hst = endpoint_stats(vlog, 'viewer'), endpoint_stats(hlog, 'host')
        windows = stage_telemetry(vst, jsonl(directory / 'viewer-stats-clock.jsonl'), score_start, score_end)
        report['hardware_and_worker_route'] = route_witness(hst, vst, hlog.read_text(), vlog.read_text(), arm, windows)
        report['viewer_telemetry_predictor_windows'] = windows
        report['input_diagnostic'] = note_latency(report['samples'], score_start, score_end)
        report['independent_visible_motion'] = observed_motion
        if (input_error is None and report.get('source_input_observer_exit') == 0
                and report.get('source_post_close_held') == [] and len(report['samples']) == SAMPLES
                and all(row['status'] == 'passed' for row in report['samples'])):
            for row in (*report['samples'], *report['warmup_samples']):
                if row['status'] == 'passed':
                    p07.expected_edges(row, codes)
            report['status'] = 'passed'
        else:
            report['status'] = 'incomplete_input_population'
    report['owned_xvfb_exits'] = [source_x.returncode, local_x.returncode]
    require(None not in report['owned_xvfb_exits'], 'private Xvfb did not terminate')


def self_test():
    opened = {'type': 'p09_start', 'monotonic_ns': 0, 'run_id': 1, 'width': 3840, 'height': 2160}
    closed = {'type': 'p09_end', 'monotonic_ns': 93 * SECOND, 'run_id': 1, 'target_lost': False, 'interrupted': False,
              'wrong_run': 0, 'reordered': 0, 'invalid': 5, 'duplicates': 2}
    marks = [{'type': 'p09_frame', 'monotonic_ns': pos * SECOND, 'source_frame': pos * 30, 'run_id': 1}
             for pos in (29, 30, 31, 89, 90)]
    scored = paint_score([opened, *marks, closed], 1, 30 * SECOND, 90 * SECOND)
    assert scored['unique_frames'] == 3 and scored['longest_gap_ms'] == 58000 and sum(scored['one_second_bins']) == 3
    sample = {'status': 'passed', 'seq': 1, 'viewer_issue_ns': SECOND, 'host_edge_ns': SECOND + 2_000_000,
              'viewer_receipt_ns': SECOND + 4_000_000, 'viewer_local_key_up_ns': SECOND + 10_000_000,
              'latency_ns': 2_000_000}
    latency = note_latency([sample, {'status': 'timeout', 'seq': 2}], 0, 2 * SECOND)
    assert latency['timeouts'] == 1 and latency['attempted'] == 2 and latency['slots_not_reached'] == 98
    assert latency['actual_issue_to_source_x11_observer']['p95_ms'] == 2
    assert latency['conservative_issue_to_local_observer_reply']['p95_ms'] == 4
    try:
        note_latency([sample | {'viewer_receipt_ns': SECOND - 1}], 0, 2 * SECOND)
    except RuntimeError:
        pass
    else:
        raise AssertionError('accepted inverted clocks')
    print('offline exact motion bins, boundary gaps, independent input metric, receipt bound and timeout retention passed')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path)
    parser.add_argument('--binary', type=Path, default=RELEASE)
    parser.add_argument('--marker', type=Path, default=MARKER)
    parser.add_argument('--lib', default='/tmp/jwm-remote-ffmpeg/usr/lib/x86_64-linux-gnu')
    parser.add_argument('--order', default='off,on', choices=('off,on', 'on,off'))
    parser.add_argument('--deadline-ms', type=int, default=2500)
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return 0
    if args.out is None or not 1 <= args.deadline_ms <= 5000:
        parser.error('owned output directory and bounded 1–5000 ms input deadline required')
    require(sha256(args.binary) == RELEASE_SHA and sha256(args.marker) == MARKER_SHA, 'required frozen binary digest mismatch')
    signal.signal(signal.SIGTERM, p07.terminate_signal)
    signal.signal(signal.SIGALRM, p07.timed_out)
    out = args.out
    out.mkdir(mode=0o700)
    data = {'kind': 'paired_responsiveness_pilot', 'binary_sha256': RELEASE_SHA, 'marker_sha256': MARKER_SHA,
            'script_sha256': sha256(Path(__file__)), 'independent_p07_probe_sha256': sha256(Path(p07.__file__)),
            'scope': 'one machine, two private Xvfb displays, unshaped authenticated IPv4 loopback; active 4K H.264 NVENC to VA-API CPU X11, no clipboard',
            'warmup_seconds': WARMUP, 'scored_seconds': SCORED, 'input_samples_per_arm': SAMPLES,
            'per_sample_deadline_ms': args.deadline_ms,
            'metrics': {'primary_input': 'same CLOCK_MONOTONIC, XTEST F12 down issue to observer of actual F8/F9 key-up at source painter window',
                        'conservative_bound': 'same CLOCK_MONOTONIC, F12 issue to source edge receipt via local observer pipe',
                        'ui_predictor': 'x11_presenter_submit_ms reports CPU/UI-side submission-call duration per telemetry window, independent of real ReleaseAll measurement',
                        'motion': 'unique visible marker samples and boundary-inclusive gaps, from both independent X11 observers in the exact scored input interval'},
            'arms': [], 'paired_population_qualified': False}
    for run_id, arm in enumerate(args.order.split(','), 1):
        directory = out / f'{run_id:02d}-{arm}'
        directory.mkdir(mode=0o700)
        report = {'arm': arm, 'run_id': run_id, 'status': 'failed', 'samples': [], 'warmup_samples': []}
        try:
            run_arm(args, arm, run_id, directory, report)
        except (Exception, KeyboardInterrupt) as error:
            report['status'] = 'failed'
            report['error'] = {'kind': type(error).__name__, 'detail': str(error)}
            if isinstance(error, KeyboardInterrupt):
                raise
        finally:
            data['arms'].append(report)
            (directory / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
            (out / 'result.json').write_text(json.dumps(data, indent=2) + '\n')
        print(json.dumps({name: report.get(name) for name in ('arm', 'status', 'error', 'input_counts', 'input_diagnostic',
                                                             'hardware_and_worker_route', 'independent_visible_motion')}), flush=True)
    data['paired_population_qualified'] = all(report['status'] == 'passed' for report in data['arms'])
    (out / 'result.json').write_text(json.dumps(data, indent=2) + '\n')
    return 0 if data['paired_population_qualified'] else 1


if __name__ == '__main__':
    if len(sys.argv) == 4 and sys.argv[1] == '_watch':
        raise SystemExit(watcher(sys.argv[2], int(sys.argv[3], 16)))
    raise SystemExit(main())
