#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/bin:/bin
lab=$(cd "$(dirname "$0")" && pwd -P)
(
    cd "$lab"
    sha256sum -c source.sha256
)
if [[ $# -eq 1 && "$1" = --check ]]; then
    printf '%s  %s\n' \
        5945a9d94a65699ea0514be3bff6328f976d776ea8e94410d48b451ed034d371 \
        /tmp/jwm-x11-prepare-release.ntmgdBNj/jwm-remote \
        b79b433f17f1e061d30dc9fc4d5bb7cf867535c8ed4ca002987cc30640a21706 \
        /tmp/jwm-p09-workload/p09-workload | sha256sum -c -
    /usr/bin/python3 -B "$lab/combined.py" --self-test
    exit 0
fi
if [[ $# -ne 0 ]]; then
    printf 'Usage: %s [--check]\n' "$0" >&2
    exit 2
fi
exec 9>/tmp/jwm-p08-p09-release/benchmark.lock
flock -w 7200 9
unset DISPLAY XAUTHORITY WAYLAND_DISPLAY WAYLAND_SOCKET PYTHONPATH PYTHONHOME
attempt=$(mktemp -d "$lab/pair.XXXXXXXX")
printf 'P06 simultaneous release and marker pair %s\n' "$attempt/raw"
status=0
/usr/bin/python3 -B -u "$lab/combined.py" --out "$attempt/raw" || status=$?
printf '%s\n' "$status" > "$attempt/controller.exit"
exit "$status"
