#!/usr/bin/env python3
"""Publish/replay the separately scoped 4K motion and ReleaseAll loopback pilot."""

import argparse
from hashlib import sha256
import json
import math
from pathlib import Path
import re
from statistics import median
from zipfile import ZIP_DEFLATED, ZipFile

from release_metrics import distribution, observation, reconcile_ledger, require, verify_phase_slots


STEM = "x11-4k-presenter-preparation-releaseall-pilot"
SIZE = [3840, 2160]
NANO = 1_000_000_000
SHA = re.compile(r"[0-9a-f]{64}")
VIEWER_PIN = "5945a9d94a65699ea0514be3bff6328f976d776ea8e94410d48b451ed034d371"
MARKER_PIN = "b79b433f17f1e061d30dc9fc4d5bb7cf867535c8ed4ca002987cc30640a21706"
FILES = ("combined.py", "p07_core.py", "processes.py", "extract_p07.py", "run.sh", "README.md")
JSONL = (
    "painter.jsonl", "viewer-visible-marker.jsonl", "source-visible-marker.jsonl",
    "input-samples.jsonl", "viewer-stats-clock.jsonl", "host-stats-clock.jsonl",
)
TIMINGS = ("x11_presenter_submit_ms", "x11_cpu_prepare_ms", "presentation_completion_ms",
           "sender_input_queue_ms", "sender_control_write_ms")
COUNTERS = ("scheduled", "prepared", "submitted", "stale", "fallbacks")
DIAGNOSTICS = {
    "host": {"input_grant": "authenticated session started (screen + pointer + keyboard)",
             "nvenc_active": "hardware H.264 encoding active (NVENC)"},
    "viewer": {"input_grant": "connected; keyboard + pointer; clipboard off",
               "vaapi_active": "H.264 hardware decoder active (VAAPI)", "jpeg_fallback": "host switched to JPEG",
               "direct_shm": "direct RGB-to-MIT-SHM upload active",
               "read_ahead": "authenticated reader and ordered decoder running independently"},
}
ERROR_REASONS = {
    "per-sample deadline expired": "sample_deadline",
    "unexpected source reply identity during failed-measurement teardown": "unexpected_terminal_reply_identity",
    "too many replies during failed-measurement teardown": "too_many_terminal_replies",
    "shortcut or observer receipt fell outside the exact phase": "timestamp_outside_phase",
}
OMIT_KEYS = {"window", "target", "port", "address", "auth_key", "private_key", "auth_cookie"}


def digest(data):
    return sha256(data).hexdigest()


def encode(data):
    return (json.dumps(data, indent=2, allow_nan=False) + "\n").encode()


def rows_bytes(rows):
    return b"".join(json.dumps(row, separators=(",", ":"), allow_nan=False).encode() + b"\n" for row in rows)


def scrub(value):
    if type(value) is list:
        return [scrub(item) for item in value]
    if type(value) is not dict:
        return value
    out = {}
    for key, item in value.items():
        if key in OMIT_KEYS:
            continue
        if key == "detail" and type(item) is str:
            out["diagnostic_code"] = ERROR_REASONS.get(item, "free_form_text_omitted")
            continue
        if key == "session_id" and type(item) is str:
            out[key] = digest(b"combined pilot session alias " + item.encode())
            continue
        out[key] = scrub(item)
    return out


def read(path):
    with path.open("rb") as handle:
        data = handle.read(16_000_001)
    require(len(data) <= 16_000_000, "fixture file exceeds bounded capture size")
    return data


def optional_json(path):
    if not path.is_file():
        return None, {"status": "missing"}
    raw = read(path)
    provenance = {"original_sha256": digest(raw), "bytes": len(raw)}
    try:
        decoded = json.loads(raw)
    except (ValueError, UnicodeError):
        return None, provenance | {"status": "malformed"}
    return scrub(decoded), provenance | {"status": "captured"}


def read_jsonl(path, kind=None):
    if not path.is_file():
        return None, {"status": "missing"}
    raw = read(path)
    malformed = 0
    rows = []
    for line in raw.splitlines():
        if kind is not None and not line.startswith(b"{"):
            continue
        try:
            record = json.loads(line)
            require(type(record) is dict, "expected one typed JSON object")
        except (ValueError, UnicodeError):
            malformed += 1
            continue
        if kind is None or record.get("type") == kind:
            rows.append(scrub(record))
    return rows, {"status": "captured" if not malformed and (not raw or raw.endswith(b"\n")) else "malformed",
                  "bytes": len(raw), "rows": len(rows), "original_sha256": digest(raw), "malformed": malformed}


def collect(fixture, raw, controller_log=None):
    exit_status = int(read(raw.parent / "controller.exit").strip())
    entries = {"run/terminal.json": encode({"controller_exit": exit_status})}
    fixture_pins = {}
    for line in read(fixture / "source.sha256").decode().splitlines():
        match = re.fullmatch(r"([0-9a-f]{64})  ([A-Za-z0-9_.-]+)", line)
        require(match is not None and match[2] not in fixture_pins, "invalid frozen fixture SHA manifest")
        fixture_pins[match[2]] = match[1]
    require(fixture_pins.keys() == set(FILES), "fixture source set changed")
    for name, pin in fixture_pins.items():
        content = read(fixture / name)
        require(digest(content) == pin, "fixture SHA differs from frozen run")
        entries[f"fixture/{name}"] = content
    entries["fixture/source.sha256"] = read(fixture / "source.sha256")
    for name in ("combined_report.py", "release_metrics.py"):
        entries[f"replay/{name}"] = read(Path(__file__).with_name(name))
    if controller_log is not None and controller_log.is_file():
        log = read(controller_log)
        entries["run/controller-diagnostic.json"] = encode({"original_sha256": digest(log), "bytes": len(log)})

    claimed, provenance = optional_json(raw / "result.json")
    entries["run/result-capture.json"] = encode(provenance)
    if claimed is not None:
        entries["run/result.json"] = encode(claimed)
    for index in (1, 2):
        for mode in ("off", "on"):
            folder = raw / f"{index:02d}-{mode}"
            if not folder.is_dir():
                continue
            base = f"run/{folder.name}"
            info = {}
            checkpoint, info["result.json"] = optional_json(folder / "result.json")
            if checkpoint is not None:
                entries[f"{base}/result.json"] = encode(checkpoint)
            for name in JSONL:
                rows, info[name] = read_jsonl(folder / name)
                if rows is not None:
                    entries[f"{base}/{name}"] = rows_bytes(rows)
            for role, labels in DIAGNOSTICS.items():
                name = role + ".log"
                log_path = folder / name
                rows, info[name] = read_jsonl(log_path, f"jwm_remote_{role}_stats")
                if rows is not None:
                    log = read(log_path)
                    entries[f"{base}/{role}-stats.jsonl"] = rows_bytes(rows)
                    info[name]["diagnostics"] = {key: log.count(text.encode()) for key, text in labels.items()}
            entries[f"{base}/capture.json"] = encode(info)
    return entries


def read_records(entries, case, filename, info, source_name=None):
    require(info[source_name or filename]["status"] == "captured", f"{filename} missing or malformed")
    return [json.loads(line) for line in entries[f"{case}/{filename}"].splitlines()]


def score_motion(rows, run_id, start, end):
    starts = [row for row in rows if row["type"] == "p09_start"]
    finishes = [row for row in rows if row["type"] == "p09_end"]
    require(len(starts) == len(finishes) == 1, "marker lifecycle incomplete")
    opened, closed = starts[0], finishes[0]
    require([opened["width"], opened["height"]] == SIZE and
            opened["run_id"] == closed["run_id"] == run_id and
            opened["monotonic_ns"] <= start < end <= closed["monotonic_ns"] and
            not any(closed[key] for key in ("target_lost", "interrupted", "wrong_run", "reordered")),
            "wrong marker identity, geometry or terminal interval")
    marks = [row for row in rows if row["type"] == "p09_frame" and start <= row["monotonic_ns"] < end]
    require(marks and all(row["run_id"] == run_id for row in marks) and
            all(a["source_frame"] < b["source_frame"] and a["monotonic_ns"] < b["monotonic_ns"]
                for a, b in zip(marks, marks[1:])), "visible frame monotonicity or uniqueness failed")
    stamps = [start, *(row["monotonic_ns"] for row in marks), end]
    gaps = sorted((b - a) / 1e6 for a, b in zip(stamps, stamps[1:]))
    bins = [0] * math.ceil((end - start) / NANO)
    for row in marks:
        bins[(row["monotonic_ns"] - start) // NANO] += 1
    return {"unique_frames": len(marks), "unique_fps": len(marks) * NANO / (end - start),
            "gap_p95_ms": gaps[(95 * len(gaps) + 99) // 100 - 1], "longest_gap_ms": gaps[-1],
            "one_second_bins": bins, "invalid_reads_total": closed["invalid"], "duplicate_reads_total": closed["duplicates"]}


def motion_report(entries, case, info, claimed, start, end):
    motions = {role: score_motion(read_records(entries, case, f"{role}-visible-marker.jsonl", info),
                                  claimed["run_id"], start, end) for role in ("source", "viewer")}
    require(claimed["marker_exits"] == {"source": 0, "viewer": 0} and
            all(any(motions["source"]["one_second_bins"][i:i+10]) for i in range(0, 60, 10)),
            "source or viewer observer lacked complete span")
    require(motions == claimed["independent_visible_motion"], "marker scores differ from raw observations")
    painter = read_records(entries, case, "painter.jsonl", info)
    run, finish = painter[0], painter[-1]
    require(run["type"] == "p09_start" and finish["type"] == "p09_end" and run["fps"] == 30 and run["seed"] == 1 and
            run["run_id"] == finish["run_id"] == claimed["run_id"] and [run["width"], run["height"]] == SIZE and
            run["monotonic_ns"] <= start < end <= finish["monotonic_ns"] and
            finish == claimed["painter_terminal"] and claimed["painter_exit"] == 0,
            "actual painter lifecycle, fixed scope or clean close missing")
    return motions | {"painter_submitted": finish["submitted"], "painter_deadline_skips": finish["deadline_skips"]}


def observe_input(entries, case, info, claimed, warm, start, end, deadline):
    ledger = read_records(entries, case, "input-samples.jsonl", info)
    warmup, scored = claimed["warmup_samples"], claimed["samples"]
    require(not reconcile_ledger(ledger, warmup + scored), "terminal replies entered measured input ledger")
    seq = [row["seq"] for row in ledger if "seq" in row]
    require(seq == list(range(1, len(seq) + 1)), "input sequence missing or duplicated")
    verify_phase_slots(warmup, "warmup", warm, start, 30)
    verify_phase_slots(scored, "scored", start, end, 100)
    action = []
    pipe = []
    for row in ledger:
        proven = observation(row, "loopback", deadline * 1_000_000, claimed["probe_keycodes"])
        if row["status"] == "passed":
            phase_end = start if row["phase"] == "warmup" else end
            require(row["viewer_local_key_up_ns"] < phase_end, "passed key cleanup is outside phase")
        if row["phase"] == "scored":
            action.append(proven)
            pipe.append(proven | {"latency_ns": row["viewer_receipt_ns"] - row["viewer_issue_ns"]
                                 if row["status"] == "passed" else None})
    typed = claimed["input_counts"]
    exact, bounds = distribution(action), distribution(pipe)
    require(typed == {"scheduled": 100, "attempted": sum("seq" in row for row in scored),
                      "qualified_samples": exact["verified_responses"], "timeouts": exact["timeouts"],
                      "explicit_unissued": exact["not_issued_slots"], "slots_not_reached": exact["absent_slot_records"]},
            "input counts differ from the frozen raw sample ledger")
    def fixture_distribution(dist):
        field = dist["observed_only_ms"]
        return ({"observations": dist["verified_responses"], "p50_ms": field["p50"],
                 "p95_ms": field["p95"], "max_ms": field["maximum"]} if dist["verified_responses"] else None)
    original = claimed["input_diagnostic"]
    require(original == {"actual_issue_to_source_x11_observer": fixture_distribution(exact),
                         "conservative_issue_to_local_observer_reply": fixture_distribution(bounds)} | typed,
            "software latency differs from raw event timings")
    closure = claimed.get("source_input_observer_exit") == 0 and claimed.get("source_post_close_held") == []
    return {
        "counts": typed, "same_clock_issue_to_host_X11_edge": exact,
        "same_clock_issue_to_local_observer_reply_bound": bounds,
        "input_error": claimed.get("input_error"), "watcher_clean_close": closure,
        "input_teardown_error": claimed.get("input_teardown_error"),
        "terminal_only_replies": claimed.get("late_observer_replies"),
        "input_population_complete": exact["verified_responses"] == 100 and closure and claimed["status"] == "passed",
        "scored_outcomes": action,
    }


def weighted_stage(rows, name):
    stages = [row[name] for row in rows if row[name] and row[name]["observations"]]
    n = sum(stage["observations"] for stage in stages)
    if not n:
        return {"windows": 0, "observations": 0}
    return {"windows": len(stages), "observations": n,
            "observation_weighted_mean_ms": sum(stage["mean"] * stage["observations"] for stage in stages) / n,
            "median_window_p95_ms": median(stage["quantiles"]["p95_ms"] for stage in stages),
            "maximum_window_p95_ms": max(stage["quantiles"]["p95_ms"] for stage in stages)}


def route_report(entries, case, info, claimed, start, end):
    host, viewer = (read_records(entries, case, f"{role}-stats.jsonl", info, f"{role}.log")
                    for role in ("host", "viewer"))
    clocks = read_records(entries, case, "viewer-stats-clock.jsonl", info)
    require(host and viewer and viewer[-1]["final"] and len(clocks) == len(viewer),
            "typed viewer/host windows or viewer receipt clocks incomplete")
    require(all(clock["telemetry_record"] == i for i, clock in enumerate(clocks, 1)) and
            all(a["received_ns"] <= b["received_ns"] for a, b in zip(clocks, clocks[1:])),
            "viewer telemetry receipt alignment changed")
    grant_h, grant_v = (info[f"{role}.log"]["diagnostics"] for role in ("host", "viewer"))
    auth = {row["session_id"] for row in host + viewer}
    require(len(auth) == 1 and all(SHA.fullmatch(pin) for pin in auth) and
            grant_h["input_grant"] == grant_v["input_grant"] == 1 and grant_h["nvenc_active"] > 0 and
            grant_v["vaapi_active"] > 0 and grant_v["jpeg_fallback"] == grant_v["direct_shm"] == grant_v["read_ahead"] == 0,
            "authenticated fixed NVENC/VA-API input and viewer routes were not established")
    frames = [row[key] for records, key in ((host, "last_sent_frame"), (viewer, "last_frame"))
              for row in records if row.get(key)]
    require(frames and all(frame["codec"] == "H.264" and frame["source_dimensions"] == frame["encoded_dimensions"] == SIZE
                           for frame in frames) and all(row["viewer_backend"] == "x11" and
                           row["negotiated_codec"] == "H.264" and row.get("last_presentation_path") in ("rgb", None)
                           and row.get("native_presented", 0) == 0 for row in viewer) and
            any(row.get("last_presentation_path") == "rgb" for row in viewer), "scope escaped native 4K X11 CPU")
    require(not any(row["hevc444_frames"] or row["jpeg_atlases"] or row["png_atlases"] for row in host),
            "host fallback codec observed")
    scopes = sorted({(frame["source_epoch"], frame["geometry_epoch"]) for frame in frames})
    require(len(scopes) == 1, "geometry/source changed during the pilot")
    windows = []
    for row, clock in zip(viewer, clocks):
        arrived = clock["received_ns"]
        windows.append({name: row["stages"].get(name) for name in TIMINGS} |
                       {"window_seconds": row["window_seconds"], "final": row["final"], "received_ns": arrived,
                        "receipt_in_scored_interior": not row["final"] and start + int(row["window_seconds"] * NANO) <= arrived < end,
                        "worker": row.get("x11_cpu_preparation")})
    require(windows == claimed["viewer_telemetry_predictor_windows"], "scored interior telemetry differs from receipt replay")
    interior = [row for row in windows if row["receipt_in_scored_interior"]]
    totals = {key: sum((row["worker"] or {}).get(key) or 0 for row in windows) for key in COUNTERS}
    submitted = sum((row["worker"] or {}).get("submitted") or 0 for row in interior)
    presented = sum((row["x11_presenter_submit_ms"] or {}).get("observations") or 0 for row in interior)
    worker = sum((row["x11_cpu_prepare_ms"] or {}).get("observations") or 0 for row in windows)
    mode = claimed["arm"]
    require(interior and presented and bool(worker) == bool(submitted) == (mode == "on") and
            all(bool(totals[key]) == (mode == "on") for key in ("scheduled", "prepared", "submitted")),
            "worker route inactive or contaminated in measured interval")
    base = {"host_and_viewer_same_authenticated_session": True, "scopes": [list(scope) for scope in scopes],
            "interior_telemetry_receipt_windows": len(interior), "interior_worker_submitted": submitted,
            "interior_presenter_submit_samples": presented, "host_frames_h264": sum(row["h264_frames"] for row in host),
            "worker": totals | {"stage_samples": worker}, "viewer_acked": sum(row["acked"] for row in viewer),
            "host_drawn_acks": sum(row["drawn_acks"] for row in host)}
    require(base == claimed["hardware_and_worker_route"], "typed codec/worker route differs from saved fixture result")
    downloads = sum((row["stages"].get("hardware_download_ms") or {}).get("observations", 0) for row in viewer)
    require(downloads > 0 and claimed["host_exit"] == claimed["viewer_exit"] == 0,
            "ordinary VA-API download or endpoint clean closure missing")
    return base | {
        "hardware_downloads": downloads,
        "whole_session_host_readback_observations": {
            name: sum(row.get("x11_capture", {}).get("stages", {}).get(name, {}).get("observations", 0) for row in host)
            for name in ("shm_readback_ms", "core_readback_ms", "cpu_resize_ms")
        },
        "interior_stage_summaries": {name: weighted_stage(interior, name) for name in TIMINGS},
    }


def arm_report(entries, raw_arm, form, deadline):
    case = f"run/{raw_arm['run_id']:02d}-{raw_arm['arm']}"
    captured = json.loads(entries[f"{case}/capture.json"])
    arm = {"arm": raw_arm["arm"], "run_id": raw_arm["run_id"], "fixture_status": raw_arm.get("status"),
           "fixture_error": raw_arm.get("error"), "capture_dir": case,
           "errors": {}, "phase_clock_ns": raw_arm.get("phase_clock_ns")}
    require(json.loads(entries[f"{case}/result.json"]) == raw_arm, "frozen arm result and totals disagree")
    phase = raw_arm.get("phase_clock_ns")
    if phase is None:
        arm["errors"]["phase"] = "phase timestamps unavailable"
        return arm
    warm, start, end = (phase[key] for key in ("warmup_begin", "score_begin", "score_end"))
    require(start - warm == form["warmup_seconds"] * NANO and end - start == form["scored_seconds"] * NANO,
            "nonmatching fixed warmup or scored duration")
    for key, inspect in (
        ("motion", lambda: motion_report(entries, case, captured, raw_arm, start, end)),
        ("input", lambda: observe_input(entries, case, captured, raw_arm, warm, start, end, deadline)),
        ("route_and_worker", lambda: route_report(entries, case, captured, raw_arm, start, end)),
    ):
        try:
            arm[key] = inspect()
        except (AttributeError, IndexError, KeyError, TypeError, ValueError) as error:
            arm["errors"][key] = str(error) if type(error) is ValueError else type(error).__name__
    arm["hardware_motion_verified"] = "motion" in arm and "route_and_worker" in arm
    arm["input_population_complete"] = arm.get("input", {}).get("input_population_complete", False)
    arm["endpoint_exits"] = {name: raw_arm[name] for name in (
        "host_exit", "viewer_exit", "painter_exit", "source_input_observer_exit", "owned_xvfb_exits", "marker_exits",
    ) if name in raw_arm}
    return arm


def paired_summary(arms):
    by_name = {arm["arm"]: arm for arm in arms}
    if set(by_name) != {"off", "on"}:
        return None
    off, on = by_name["off"], by_name["on"]
    result = {}
    if off.get("hardware_motion_verified") and on.get("hardware_motion_verified"):
        for role in ("source", "viewer"):
            a, b = off["motion"][role], on["motion"][role]
            result[f"on_minus_off_{role}_motion"] = {name: b[name] - a[name]
                                                       for name in ("unique_fps", "gap_p95_ms", "longest_gap_ms")}
        a = off["route_and_worker"]["interior_stage_summaries"]["x11_presenter_submit_ms"]
        b = on["route_and_worker"]["interior_stage_summaries"]["x11_presenter_submit_ms"]
        result["on_minus_off_median_window_presenter_p95_ms"] = b["median_window_p95_ms"] - a["median_window_p95_ms"]
    if off.get("input_population_complete") and on.get("input_population_complete"):
        for name in ("same_clock_issue_to_host_X11_edge", "same_clock_issue_to_local_observer_reply_bound"):
            a, b = off["input"][name], on["input"][name]
            result[f"on_minus_off_{name}_p95_ms"] = b["p95_ms_over_planned_rank"] - a["p95_ms_over_planned_rank"]
    return result


def reconstruct(entries):
    pins = {}
    for line in entries["fixture/source.sha256"].decode().splitlines():
        pin, name = line.split("  ", 1)
        require(SHA.fullmatch(pin) and name in FILES and name not in pins and digest(entries[f"fixture/{name}"]) == pin,
                "archived fixture snapshot differs from frozen SHA")
        pins[name] = pin
    require(pins.keys() == set(FILES), "fixture pin inventory incomplete")
    terminal = json.loads(entries["run/terminal.json"])["controller_exit"]
    require(type(terminal) is int, "invalid terminal controller exit")
    capture = json.loads(entries["run/result-capture.json"])
    raw = json.loads(entries["run/result.json"]) if "run/result.json" in entries else None
    arms = []
    if raw is not None:
        require(raw["kind"] == "paired_responsiveness_pilot" and
                raw["binary_sha256"] == VIEWER_PIN and raw["marker_sha256"] == MARKER_PIN and
                raw["script_sha256"] == pins["combined.py"] and raw["independent_p07_probe_sha256"] == pins["p07_core.py"] and
                raw["warmup_seconds"] == 30 and raw["scored_seconds"] == 60 and raw["input_samples_per_arm"] == 100 and
                type(raw["per_sample_deadline_ms"]) is int and 1 <= raw["per_sample_deadline_ms"] <= 5000,
                "fixture scope, source, endpoint, or observer pins changed")
        observed_arms = raw["arms"]
        require(len(observed_arms) <= 2 and len({a["arm"] for a in observed_arms}) == len(observed_arms),
                "unexpected pilot arm list")
        for ordinal, arm in enumerate(observed_arms, 1):
            require(arm["run_id"] == ordinal and arm["arm"] in {"off", "on"}, "pilot arm identity changed")
            try:
                arms.append(arm_report(entries, arm, raw, raw["per_sample_deadline_ms"]))
            except (AttributeError, IndexError, KeyError, TypeError, ValueError) as error:
                arms.append({"arm": arm["arm"], "run_id": ordinal, "fixture_status": arm.get("status"),
                             "status": "invalid_evidence",
                             "error": str(error) if type(error) is ValueError else type(error).__name__})
    hardware_pair = len(arms) == 2 and all(arm.get("hardware_motion_verified") for arm in arms)
    input_pair = len(arms) == 2 and all(arm.get("input_population_complete") for arm in arms)
    complete = terminal == 0 and hardware_pair and input_pair and raw["paired_population_qualified"] is True
    return {
        "schema_version": 1,
        "status": "complete" if complete else "partial",
        "controller_exit": terminal,
        "result_capture": capture,
        "pilot_kind": "one paired 4K motion and ReleaseAll software loopback diagnostic",
        "scope": {
            "dimensions": SIZE, "host_capture_fps": 30, "source_requested_fps": 30, "warmup_seconds": 30,
            "score_seconds": 60, "planned_input_per_arm": 100, "same_monotonic_clock": True,
            "topology": "One Mint machine, two owned private Xvfb desktops, authenticated local IPv4 TCP",
            "route": "Fixed H.264 NVENC encode, VA-API downloads, CPU X11 RGB presentation; clipboard off.",
        },
        "pins": {"both_endpoints_binary_sha256": VIEWER_PIN, "marker_observer_binary_sha256": MARKER_PIN,
                 "fixture_sha256": pins},
        "hardware_motion_pair_verified": hardware_pair,
        "all_200_input_samples_qualified": complete,
        "arms": arms,
        "on_minus_off": paired_summary(arms),
        "method": (
            "Primary ReleaseAll time is real viewer XTEST F12 issue through observation of the matched host X11 key-up "
            "in the owned painter window on one monotonic clock. The same-issuer interval to receipt of that edge on its "
            "local observer pipe is a separate conservative software bound. Only samples with all held-state, "
            "ordering and cleanup witnesses enter ranks. Unverified slots have an unbounded latency when ranking the planned samples. "
            "The presenter stage measures whole UI draw-call time, while the marker observers measure visible "
            "source/viewer motion over the common fixed 60 seconds. Receipt-associated telemetry windows are diagnostic. "
            "These scopes provide no input-to-photon or external-network measurement."
        ),
    }


def publish(entries, output):
    report = reconstruct(entries)
    output.mkdir(parents=True, exist_ok=True)
    summary = output / f"{STEM}.json"
    archive = output / f"{STEM}-raw.zip"
    require(not archive.exists() and not summary.exists(), "use fresh publication directory")
    with ZipFile(archive, "x", compression=ZIP_DEFLATED, compresslevel=7) as writer:
        for name, content in sorted(entries.items()):
            writer.writestr(name, content)
    report["archive"] = {"name": archive.name, "sha256": digest(archive.read_bytes()),
                         "members_sha256": {name: digest(content) for name, content in entries.items()}}
    with summary.open("xb") as writer:
        writer.write(encode(report))
    replay(summary, archive)
    print(report["status"], summary, archive)


def replay(summary, archive):
    expected = json.loads(read(summary))
    metadata = expected.pop("archive")
    require(archive.name == metadata["name"] and digest(archive.read_bytes()) == metadata["sha256"],
            "whole archive pin differs")
    with ZipFile(archive) as bundle:
        names = bundle.namelist()
        require(len(names) == len(set(names)) and set(names) == set(metadata["members_sha256"]),
                "archive member inventory differs")
        entries = {name: bundle.read(name) for name in names}
    require({name: digest(content) for name, content in entries.items()} == metadata["members_sha256"],
            "archive member SHA changed")
    require(reconstruct(entries) == expected, "portable replay differs from publication")
    return expected


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    pack = commands.add_parser("publish")
    pack.add_argument("--fixture", required=True, type=Path)
    pack.add_argument("--raw", required=True, type=Path)
    pack.add_argument("--controller-log", type=Path)
    pack.add_argument("--out", required=True, type=Path)
    verify = commands.add_parser("replay")
    verify.add_argument("summary", type=Path)
    verify.add_argument("archive", type=Path)
    args = parser.parse_args()
    if args.command == "publish":
        require((args.raw.parent / "controller.exit").is_file(), "terminal controller status unavailable")
        publish(collect(args.fixture, args.raw, args.controller_log), args.out)
    else:
        print(replay(args.summary, args.archive)["status"], "reproduced from", args.archive)


if __name__ == "__main__":
    main()
