//! Configure and retire opt-in native H.264 presentation.

use super::ClientOptions;
#[cfg(feature = "remote-wayland")]
use crate::remote::telemetry::NativeWaylandStageTimes;
use crate::remote::{
    RemoteResult,
    frame::{FrameInfo, RecyclableDecodedFrame, SharedDecodeBufferPool, prepare_decode_buffer},
    gpu_present, h264,
    messages::FrameCodec,
    viewer_backend::{Viewer, ViewerBackend},
    x11_viewer,
};
use ffmpeg_next::frame::Video;
#[cfg(feature = "remote-wayland")]
use std::os::unix::fs::{FileTypeExt, MetadataExt};
use std::{
    ffi::CString,
    os::unix::ffi::OsStrExt,
    path::Path,
    sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
    },
    time::{Duration, Instant},
};

#[derive(Clone)]
pub(super) struct Decode {
    node: CString,
    backend: ViewerBackend,
    enabled: Arc<AtomicBool>,
}

impl Decode {
    pub(super) fn open(&self, size: (u32, u32)) -> Option<h264::Decoder> {
        if !self.active() {
            return None;
        }
        match h264::Decoder::native_vaapi(size.0, size.1, &self.node) {
            Ok(decoder) => Some(decoder),
            Err(error) => {
                self.disable(&format!("opening the selected VA-API decoder: {error}"));
                None
            }
        }
    }

    pub(super) fn active(&self) -> bool {
        self.enabled.load(Ordering::Acquire)
    }

    fn disable(&self, reason: &str) {
        if self.enabled.swap(false, Ordering::AcqRel) {
            eprintln!(
                "jwm-remote: native {} video disabled; using RGB ({reason})",
                self.backend
            );
        }
    }
}

pub(super) struct Presenter {
    decode: Decode,
    renderer: gpu_present::Renderer,
    transfer: h264::RgbTransfer,
    reported_active: bool,
    #[cfg(feature = "remote-wayland")]
    device: u64,
    #[cfg(feature = "remote-wayland")]
    measure_wayland_stages: bool,
}

pub(super) struct Submission {
    pub(super) drawn: bool,
    pub(super) native: Option<(&'static str, Duration)>,
    pub(super) fallback: Option<h264::DecodeTimings>,
    #[cfg(feature = "remote-wayland")]
    pub(super) native_wayland_stages: Option<NativeWaylandStageTimes>,
}

impl Presenter {
    pub(super) fn configure(options: &ClientOptions, codec: FrameCodec) -> Option<Self> {
        let node = std::env::var_os("JWM_REMOTE_GPU_PRESENT")?;
        let backend = options.viewer_backend;
        let result = if codec == FrameCodec::H264
            && options.scaling != crate::remote::ScalingPolicy::Cpu
        {
            match backend {
                ViewerBackend::X11 => Self::open_x11(Path::new(&node), options.display.as_deref()),
                #[cfg(feature = "remote-wayland")]
                ViewerBackend::Wayland if options.view_only => {
                    Self::open_wayland(Path::new(&node), options.stats_json)
                }
                _ => Err("native Wayland video requires view-only mode".into()),
            }
        } else {
            Err("native video requires negotiated H.264 and GPU-compatible scaling".into())
        };
        match result {
            Ok(presenter) => Some(presenter),
            Err(error) => {
                eprintln!("jwm-remote: native {backend} video unavailable; using RGB ({error})");
                None
            }
        }
    }

    fn open_x11(path: &Path, display: Option<&str>) -> RemoteResult<Self> {
        let (conn, root) = x11_viewer::open_root(display)?;
        let path = gpu_present::select_device(&conn, root, path)?;
        Self::open(&path, ViewerBackend::X11)
    }

    #[cfg(feature = "remote-wayland")]
    fn open_wayland(path: &Path, stats_json: bool) -> RemoteResult<Self> {
        let path = path.canonicalize()?;
        if !path.metadata()?.file_type().is_char_device()
            || !path
                .file_name()
                .is_some_and(|name| name.as_encoded_bytes().starts_with(b"renderD"))
        {
            return Err("Wayland GPU presentation requires a DRM render node".into());
        }
        let mut presenter = Self::open(&path, ViewerBackend::Wayland)?;
        presenter.measure_wayland_stages = stats_json;
        Ok(presenter)
    }

    fn open(path: &Path, backend: ViewerBackend) -> RemoteResult<Self> {
        let renderer = gpu_present::Renderer::new(path)?;
        let decode = Decode {
            node: CString::new(path.as_os_str().as_bytes())?,
            backend,
            enabled: Arc::new(AtomicBool::new(true)),
        };
        Ok(Self {
            decode,
            renderer,
            transfer: h264::RgbTransfer::default(),
            reported_active: false,
            #[cfg(feature = "remote-wayland")]
            device: path.metadata()?.rdev(),
            #[cfg(feature = "remote-wayland")]
            measure_wayland_stages: false,
        })
    }

    pub(super) fn decoder_config(&self) -> Decode {
        self.decode.clone()
    }

    pub(super) fn draw(
        &mut self,
        viewer: &mut Viewer,
        pixels: Video,
        info: FrameInfo,
        pool: &SharedDecodeBufferPool,
        measure: bool,
    ) -> RemoteResult<Submission> {
        self.draw_frame(viewer, pixels, info, pool, measure, None)
    }

    #[cfg(feature = "remote-wayland")]
    pub(super) fn refresh_wayland(
        &mut self,
        viewer: &mut Viewer,
        pool: &SharedDecodeBufferPool,
        measure: bool,
    ) -> RemoteResult<Option<(u64, Submission)>> {
        let Viewer::Wayland(wayland) = viewer else {
            return Ok(None);
        };
        let Some((pixels, info, acknowledge)) = wayland.take_native_redraw()? else {
            return Ok(None);
        };
        self.draw_frame(viewer, pixels, info, pool, measure, Some(acknowledge))
            .map(|submitted| Some((info.sequence, submitted)))
    }

    fn draw_frame(
        &mut self,
        viewer: &mut Viewer,
        pixels: Video,
        info: FrameInfo,
        pool: &SharedDecodeBufferPool,
        measure: bool,
        redraw: Option<bool>,
    ) -> RemoteResult<Submission> {
        if self.decode.active() {
            let started = Instant::now();
            #[cfg(feature = "remote-wayland")]
            let mut native_wayland_stages = None;
            let (path, result) = match viewer {
                Viewer::X11(x11) => {
                    let visible = (
                        u16::try_from(info.encoded_size.0)?,
                        u16::try_from(info.encoded_size.1)?,
                    );
                    let result = match self.renderer.render(&pixels, visible) {
                        Ok(buffer) => x11
                            .draw_native(
                                buffer,
                                info.sequence,
                                info.geometry_epoch,
                                info.source_size,
                            )?
                            .ok_or_else(|| "X11 rejected the native pixmap".into()),
                        Err(error) => Err(error),
                    };
                    ("x11-vaapi-dmabuf-dri3", result)
                }
                #[cfg(feature = "remote-wayland")]
                Viewer::Wayland(wayland) => {
                    // Match the aggregate submission series, which excludes
                    // standalone viewport redraws and the RGB fallback path.
                    native_wayland_stages = (self.measure_wayland_stages && redraw.is_none())
                        .then(NativeWaylandStageTimes::default);
                    (
                        "wayland-vaapi-dmabuf",
                        wayland.draw_native(
                            &mut self.renderer,
                            self.device,
                            &pixels,
                            info,
                            redraw.unwrap_or(true),
                            native_wayland_stages.as_mut(),
                        ),
                    )
                }
            };
            match result {
                Ok(drawn) => {
                    #[cfg(feature = "remote-wayland")]
                    if let Viewer::Wayland(wayland) = viewer
                        && (drawn || redraw.is_some())
                    {
                        wayland.remember_native(pixels, info);
                    }
                    if drawn && !self.reported_active {
                        let renderer = match self.decode.backend {
                            ViewerBackend::X11 => "VA-API/EGL/DRI3",
                            ViewerBackend::Wayland => "VA-API/EGL/Wayland DMA-BUF",
                        };
                        eprintln!("jwm-remote: native H.264 {renderer} video rendering active");
                        self.reported_active = true;
                    }
                    return Ok(Submission {
                        drawn,
                        native: Some((path, started.elapsed())),
                        fallback: None,
                        #[cfg(feature = "remote-wayland")]
                        native_wayland_stages,
                    });
                }
                Err(error) => {
                    return self.render_failure(viewer, pixels, info, pool, measure, redraw, error);
                }
            }
        }
        self.draw_fallback(viewer, pixels, info, pool, measure, redraw)
    }

    fn render_failure(
        &mut self,
        viewer: &mut Viewer,
        pixels: Video,
        info: FrameInfo,
        pool: &SharedDecodeBufferPool,
        measure: bool,
        redraw: Option<bool>,
        error: Box<dyn std::error::Error + Send + Sync>,
    ) -> RemoteResult<Submission> {
        self.decode.disable(&error.to_string());
        if error.is::<gpu_present::DecodeFenceFailure>() || self.renderer.has_unresolved_draw() {
            self.renderer.retire_if_pending(pixels);
            return Err(super::hardware_decoder_error(std::io::Error::other(error)));
        }
        self.draw_fallback(viewer, pixels, info, pool, measure, redraw)
    }

    fn draw_fallback(
        &mut self,
        viewer: &mut Viewer,
        pixels: Video,
        info: FrameInfo,
        pool: &SharedDecodeBufferPool,
        measure: bool,
        _redraw: Option<bool>,
    ) -> RemoteResult<Submission> {
        // An import or format rejection leaves the decoded picture available
        // for the existing CPU presentation path, without replaying packets.
        let (frame, timings) = self
            .resolve_rgb(&pixels, info, pool, measure)
            .map_err(|error| super::hardware_decoder_error(std::io::Error::other(error)))?;
        #[cfg(feature = "remote-wayland")]
        if let Viewer::Wayland(wayland) = viewer
            && let Some(acknowledge) = _redraw
        {
            let drawn = wayland.draw_rgb(frame, acknowledge)?;
            if !drawn {
                wayland.remember_native(pixels, info);
            }
            return Ok(Submission {
                drawn,
                native: None,
                fallback: Some(timings),
                native_wayland_stages: None,
            });
        }
        Ok(Submission {
            drawn: viewer.draw_recyclable(frame)?,
            native: None,
            fallback: Some(timings),
            #[cfg(feature = "remote-wayland")]
            native_wayland_stages: None,
        })
    }

    fn resolve_rgb(
        &mut self,
        pixels: &Video,
        info: FrameInfo,
        pool: &SharedDecodeBufferPool,
        measure: bool,
    ) -> RemoteResult<(RecyclableDecodedFrame, h264::DecodeTimings)> {
        let size = info.encoded_size;
        let (mut bytes, checkout) =
            prepare_decode_buffer(pool, size.0 as usize * size.1 as usize * 3, measure)?;
        let timings = self
            .transfer
            .vaapi_fallback(pixels, size, &mut bytes, measure)?
            .with_checkout(checkout);
        let rgb = image::RgbImage::from_raw(size.0, size.1, bytes)
            .ok_or("invalid decoded RGB fallback dimensions")?;
        let frame = RecyclableDecodedFrame::new(
            info.sequence,
            info.source_size.0,
            info.source_size.1,
            rgb,
            Arc::clone(pool),
        )
        .with_session_epoch(info.session_epoch)
        .with_source_epoch(info.source_epoch)
        .with_geometry_epoch(info.geometry_epoch);
        Ok((frame, timings))
    }
}
