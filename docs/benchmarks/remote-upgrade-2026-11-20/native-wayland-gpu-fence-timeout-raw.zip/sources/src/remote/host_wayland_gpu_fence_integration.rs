//! Real native frames with one test-only GLES completion result overridden.
use super::*;
use crate::backend::wayland::state::JwmWaylandState;
use crate::remote::{
    client::{classify_failure, hardware_decode_failure_clean, run_client_with_video_codec},
    gpu_present::fence_test::timeout_second_signaled_draw,
    h264, h264_wire,
    host::{AuthenticatedPeer, authenticate_peer},
    messages::{FrameCodec, ServerHello, StreamCapabilities, decode_source_frame_ack},
    protocol::{MessageKind, ProtocolError},
    source_session::{SourceId, SourceVersion},
    source_wire::{FramePurpose, SourceCatalog, SourceEntry, encode_frame_payload},
};
use std::{ffi::CString, io, net::TcpListener, os::unix::fs::MetadataExt};

const BITSTREAM: &[u8] = include_bytes!("native-video-probe.h264");
const SIZE: (u32, u32) = (256, 256);

fn drive_until<T>(
    server: &mut Server,
    phase: &str,
    mut observe: impl FnMut(&mut Server) -> Option<T>,
) -> T {
    let deadline = Instant::now() + Duration::from_secs(10);
    loop {
        server.roundtrip();
        if let Some(result) = observe(server) {
            return result;
        }
        assert!(Instant::now() < deadline, "timed out waiting for {phase}");
        thread::sleep(Duration::from_millis(1));
    }
}

fn serve_two_frames(listener: TcpListener, key: [u8; 32]) -> Vec<(u64, u64)> {
    let deadline = Instant::now() + Duration::from_secs(10);
    let stream = loop {
        match listener.accept() {
            Ok((stream, _)) => break stream,
            Err(error)
                if error.kind() == io::ErrorKind::WouldBlock && Instant::now() < deadline =>
            {
                thread::sleep(Duration::from_millis(1));
            }
            Err(error) => panic!("accept authenticated viewer: {error}"),
        }
    };
    let mut peer = authenticate_peer(stream, &key).unwrap();
    assert_eq!(peer.hello.stream.codec, FrameCodec::H264);
    assert!(!peer.hello.request_input && !peer.hello.request_clipboard);
    peer.reader
        .get_ref()
        .set_read_timeout(Some(Duration::from_secs(8)))
        .unwrap();
    let limits = peer.hello.stream.frame_limits;
    peer.writer
        .write_message(
            MessageKind::HelloAck,
            &ServerHello {
                stream: StreamCapabilities {
                    frame_limits: limits,
                    codec: FrameCodec::H264,
                    ..Default::default()
                },
                pointer_enabled: false,
                keyboard_enabled: false,
                clipboard_enabled: false,
                clipboard_files_enabled: false,
            }
            .encode(),
        )
        .unwrap();
    let source = SourceId(1);
    peer.writer
        .write_message(
            MessageKind::SourceCatalog,
            &SourceCatalog {
                current: SourceVersion { source, epoch: 1 },
                entries: vec![SourceEntry {
                    id: source,
                    label: "owned native fence source".into(),
                }],
            }
            .encode()
            .unwrap(),
        )
        .unwrap();

    let send_frame = |peer: &mut AuthenticatedPeer, sequence| {
        let mut bytes = Vec::new();
        h264_wire::encode_hardware_frame(
            &mut bytes,
            FrameCodec::H264,
            h264_wire::HardwareFrameHeader {
                sequence,
                source_width: SIZE.0 as u16,
                source_height: SIZE.1 as u16,
                encoded_width: SIZE.0 as u16,
                encoded_height: SIZE.1 as u16,
                geometry_epoch: 1,
            },
            BITSTREAM,
            limits,
        )
        .unwrap();
        let payload = encode_frame_payload(1, FramePurpose::Video, &bytes).unwrap();
        peer.writer
            .write_message(MessageKind::Frame, &payload)
            .unwrap();
        peer.writer.flush().unwrap();
    };
    send_frame(&mut peer, 71);
    let mut acks = Vec::new();
    let mut second_sent = false;
    let deadline = Instant::now() + Duration::from_secs(10);
    loop {
        assert!(
            Instant::now() < deadline,
            "viewer did not close the authenticated connection"
        );
        match peer.reader.read_message() {
            Ok((MessageKind::FrameAck, payload)) => {
                let ack = decode_source_frame_ack(&payload).unwrap();
                acks.push(ack);
                assert_eq!(
                    acks.as_slice(),
                    &[(1, 71)],
                    "only the healthy frame may return credit"
                );
                assert!(!second_sent);
                send_frame(&mut peer, 72);
                second_sent = true;
            }
            Ok((MessageKind::Viewport | MessageKind::Heartbeat | MessageKind::Close, _)) => {}
            Ok((kind, _)) => panic!("unexpected authenticated record: {kind:?}"),
            Err(ProtocolError::Io(error))
                if matches!(
                    error.kind(),
                    io::ErrorKind::UnexpectedEof
                        | io::ErrorKind::ConnectionReset
                        | io::ErrorKind::ConnectionAborted
                ) =>
            {
                break;
            }
            Err(error) => panic!("viewer stream did not close normally: {error:?}"),
        }
    }
    assert!(second_sent);
    acks
}

#[test]
#[ignore = "requires a real Intel render node via JWM_REMOTE_GPU_PRESENT and working VA-API"]
fn native_wayland_fence_timeout_retires_real_surface_without_ack() {
    let node = std::path::PathBuf::from(
        std::env::var_os("JWM_REMOTE_GPU_PRESENT").expect("select an owned Intel render node"),
    );
    let mut gl = HeadlessSmithayGles::on_render_node(&node).expect("explicit Intel hardware GLES");
    let device = node.metadata().unwrap().rdev();
    let mut server = Server::new();
    register_test_presentation(&mut server);
    server.state.image_capture_pending = Some(init_image_copy_capture(&server.display.handle()));
    server.state.ensure_dmabuf_global_with_feedback(
        &server.display.handle(),
        gl.renderer
            .egl_context()
            .dmabuf_render_formats()
            .iter()
            .copied(),
        [],
        device,
    );
    let (native, stream) = UnixStream::pair().unwrap();
    server
        .display
        .handle()
        .insert_client(native, Arc::new(JwmClientState::default()))
        .unwrap();
    let listener = TcpListener::bind("127.0.0.1:0").unwrap();
    listener.set_nonblocking(true).unwrap();
    let address = listener.local_addr().unwrap().to_string();
    let key = [0x00; 32]; // Archived placeholder for the fixture key.
    let host = thread::spawn(move || serve_two_frames(listener, key));
    let viewer = thread::spawn(move || {
        timeout_second_signaled_draw(|| {
            with_wayland_test_stream(stream, || {
                run_client_with_video_codec(
                    ClientOptions {
                        stats_json: false,
                        control_duration: Default::default(),
                        viewer_backend: ViewerBackend::Wayland,
                        viewer_wayland_display: None,
                        wayland_keyboard: false,
                        wayland_pointer: false,
                        wayland_control: false,
                        wayland_gestures: false,
                        resumable_control: false,
                        wayland_seamless_input: false,
                        wayland_popup_pointer: false,
                        static_lossless: false,
                        wayland_text: None,
                        wayland_scroll: false,
                        wayland_horizontal_scroll: false,
                        resize_source: None,
                        follow_source_size: false,
                        window_size: Some(WindowSize {
                            width: SIZE.0 as u16,
                            height: SIZE.1 as u16,
                        }),
                        window_position: None,
                        x11_parent_window: None,
                        frame_limits: Default::default(),
                        address: address.clone(),
                        peer_label: address,
                        key: crate::remote::key::KeySource::Bytes(key.to_vec()),
                        display: None,
                        view_only: true,
                        grab_input: false,
                        seamless_input: None,
                        clipboard: false,
                        clipboard_mode: Default::default(),
                        clipboard_direction: Default::default(),
                        clipboard_file_limit: 0,
                        escape_key: "Escape".into(),
                        scaling: crate::remote::ScalingPolicy::Gpu,
                    },
                    FrameCodec::H264,
                )
            })
        })
    });

    let (surface, feedback) = drive_until(&mut server, "healthy native Wayland frame", |server| {
        let (&window, top) = server.state.toplevels.iter().next()?;
        if !top.is_initial_configure_sent() {
            let geometry = server.state.window_geometry.get_mut(&window).unwrap();
            (geometry.w, geometry.h) = SIZE;
            top.with_pending_state(|pending| {
                pending.size = Some((SIZE.0 as i32, SIZE.1 as i32).into());
                pending.states.set(TopState::Activated);
            });
            top.send_configure();
        }
        let surface = top.wl_surface().clone();
        let feedback = take_feedback(&surface);
        (!feedback.is_empty()).then_some((surface, feedback))
    });
    assert_eq!(feedback.len(), 1);
    assert!(smithay::wayland::dmabuf::get_dmabuf(&committed_buffer(&surface)).is_ok());

    // Positive control uses the same four CPU-reference comparisons as the
    // X11 GPU probe, from the actual committed Wayland buffer before feedback.
    let cpu = h264::vaapi_probe_rgb(
        &CString::new(node.as_os_str().as_encoded_bytes()).unwrap(),
        BITSTREAM,
    )
    .unwrap();
    let pixels = Readback::new(&mut server, SIZE).pixels(&mut server, &mut gl);
    let mut references = Vec::new();
    for (x, y) in [(16, 16), (233, 16), (16, 231), (233, 231)] {
        let offset = y * SIZE.0 as usize + x;
        let actual = [
            pixels[offset * 4 + 2],
            pixels[offset * 4 + 1],
            pixels[offset * 4],
        ];
        let expected: [u8; 3] = cpu[offset * 3..offset * 3 + 3].try_into().unwrap();
        assert!(!references.contains(&expected));
        assert!(
            actual
                .iter()
                .zip(expected)
                .all(|(gpu, cpu)| gpu.abs_diff(cpu) <= 4),
            "healthy frame color at ({x},{y}): {actual:?}, reference {expected:?}"
        );
        references.push(expected);
    }
    // A per-surface commit hook also catches any attach+destroy that arrive
    // together before a polling observer sees that attachment.
    let later_commits = Arc::new(AtomicU64::new(0));
    let later = later_commits.clone();
    smithay::wayland::compositor::add_post_commit_hook::<JwmWaylandState, _>(
        &surface,
        move |_, _, _| {
            later.fetch_add(1, Ordering::Relaxed);
        },
    );
    present(&mut server, feedback);
    drive_until(
        &mut server,
        "both native fence workers to terminate",
        |_| (host.is_finished() && viewer.is_finished()).then_some(()),
    );
    assert_eq!(host.join().unwrap(), [(1, 71)]);
    let (result, proof) = viewer.join().unwrap();
    server.roundtrip();
    assert_eq!(
        later_commits.load(Ordering::Relaxed),
        0,
        "unresolved GPU draw reached the Wayland surface"
    );
    assert_eq!(proof.real_signaled_draws, 2);
    assert!(
        proof.injected_timeout
            && proof.exact_frame_held_at_teardown
            && proof.same_egl_context_destroyed
    );

    let failure = result.unwrap_err();
    let diagnostic = classify_failure(failure.as_ref());
    assert_eq!(diagnostic.stage, Some("session"));
    assert_ne!(diagnostic.cleanup, "incomplete");
    assert!(!diagnostic.reconnect_certified);
    // Wayland's terminal retry check removes the HardwareDecodeFailure
    // certificate and preserves the original typed I/O cause.
    assert!(!hardware_decode_failure_clean(failure.as_ref()));
    let wrapper = failure
        .source()
        .unwrap()
        .downcast_ref::<io::Error>()
        .unwrap();
    let timeout = wrapper
        .get_ref()
        .unwrap()
        .downcast_ref::<io::Error>()
        .unwrap();
    assert_eq!(timeout.kind(), io::ErrorKind::TimedOut);
    assert_eq!(timeout.to_string(), "GLES frame fence did not complete");
}
