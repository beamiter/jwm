#!/usr/bin/env python3
"""Finalize the fixed 1440p readback ABBA without editing or archiving trial data."""
import argparse
import json
import math
from pathlib import Path

from stages import STAGES, bounded_read, bounds, lines, load, markers, stage_rollup

LAB = Path(__file__).resolve().parent
ORDER = ("cpu", "auto", "auto", "cpu") * 2
EXPECTED_SIZE = [2560, 1440]
PIN_FIELDS = ("host_binary_sha256", "viewer_binary_sha256", "observer_sha256", "painter_sha256")


def still_running(pid, ticks):
    try:
        fields = Path(f"/proc/{pid}/stat").read_text().rsplit(") ", 1)[1].split()
        return fields[0] != "Z" and int(fields[19]) == ticks
    except FileNotFoundError:
        return False


def analyze_trial(folder, policy):
    result = load(bounded_read(folder / "result.json"))
    host = lines(bounded_read(folder / "retained-host.jsonl"))
    viewer = lines(bounded_read(folder / "retained-viewer.jsonl"))
    observed = lines(bounded_read(folder / "retained-markers.jsonl"))
    if (result["pilot"] or result["arm"] != "fixed" or result["host_scaling_policy"] != policy
            or result["viewer_scaling_policy"] != "cpu" or result["requested_fps"] != 30
            or result["configured_cap_bytes_per_second"] != 0):
        raise ValueError("unexpected experimental configuration")
    if result["source_and_encoded_dimensions"] != EXPECTED_SIZE or result["codec"] != "H.264"             or result["ffmpeg_encoder"] != "h264_nvenc":
        raise ValueError("expected a true 1440p fixed H.264 NVENC trial")
    if result["observer_window_seconds"] != 60 or (
        result["viewer_observer_end_ns"] - result["viewer_observer_start_ns"] != 60_000_000_000
    ):
        raise ValueError("observer scoring interval is not exactly 60 seconds")
    unique_fps = len(observed) / 60
    if not math.isclose(unique_fps, result["observer_unique_frames_per_second"], abs_tol=1e-9):
        raise ValueError("unique FPS differs from the observer marks")
    if not result["session_id"] or {row["session_id"] for row in host + viewer} != {result["session_id"]}:
        raise ValueError("retained windows do not describe the same authenticated session")
    durations = {role: sum(row["window_seconds"] for row in rows)
                 for role, rows in (("host", host), ("viewer", viewer))}
    if len(host) < 12 or len(viewer) < 12 or min(durations.values()) < 60:
        raise ValueError("insufficient whole telemetry windows")
    if not math.isclose(durations["host"], result["host_window_seconds"], abs_tol=1e-7):
        raise ValueError("host telemetry seconds differ from the retained result")
    route = {}
    for name in ("core_readback_ms", "shm_readback_ms", "cpu_resize_ms"):
        route[name] = sum(row.get("x11_capture", {}).get("stages", {}).get(name, {}).get("observations", 0)
                          for row in host)
    expected, other = ("core_readback_ms", "shm_readback_ms") if policy == "cpu" else (
                      "shm_readback_ms", "core_readback_ms")
    if not route[expected] or route[other] or route["cpu_resize_ms"]:
        raise ValueError("actual host counters do not establish the expected native-size readback path")
    for row in host:
        stages = row.get("x11_capture", {}).get("stages", {})
        if row["captured"] and (not stages.get(expected, {}).get("observations")
                               or row["encoded_dimensions"] != EXPECTED_SIZE
                               or row["source_dimensions"] != EXPECTED_SIZE):
            raise ValueError("active host window changed route or geometry")
        if row["hevc444_frames"] or row["jpeg_atlases"] or row["png_atlases"]:
            raise ValueError("host switched codec")
    presentations = set()
    for row in viewer:
        scope = row.get("last_frame")
        if row["viewer_backend"] != "x11" or row["negotiated_codec"] != "H.264":
            raise ValueError("viewer changed negotiated codec or backend")
        if scope and (scope["codec"] != "H.264" or scope["encoded_dimensions"] != EXPECTED_SIZE
                      or scope["source_dimensions"] != EXPECTED_SIZE):
            raise ValueError("a viewer frame changed codec or geometry")
        if row.get("last_presentation_path"):
            presentations.add(row["last_presentation_path"])
    if presentations != {"rgb"}:
        raise ValueError(f"viewer route changed: {sorted(presentations)}")

    case = {"name": folder.name, "host": host, "viewer": viewer}
    pins = {field: result["binary_pins"][field] for field in PIN_FIELDS}
    capture = stage_rollup([case], "host", STAGES["host"]["capture"])
    readback = stage_rollup([case], "host", f"x11_capture.stages.{expected}")
    stats = {
        "case": folder.name, "host_scaling_policy": policy, "binary_pins": pins,
        "observation_seconds": 60, "telemetry_seconds": durations, "unique_fps": unique_fps,
        "p95_gap_ms": result["observer_gap_ms"]["p95"], "max_gap_ms": result["observer_gap_ms"]["max"],
        "longest_observer_gaps": markers(result, observed), "capture": capture, "readback": readback,
        "actual_route_observations": route, "capture_mode_labels": sorted({row["mode"] for row in host}),
        "host_zero_frame_windows": result["host_zero_frame_windows"],
        "viewer_zero_drawn_windows": result["viewer_zero_drawn_windows"],
        "payload_mbps": result["host_payload_mbps"],
        "source_submit_fps": result["source_observed_submit_fps"],
        "source_deadline_skips": result["source_summary"]["deadline_skips"],
        "existing_27_fps_gate_met": unique_fps >= 27,
    }
    return case, stats


def rollup(tested):
    stats = [stat for _, stat in tested]
    return {
        "trial_count": len(stats),
        "trial_unique_fps": bounds([row["unique_fps"] for row in stats]),
        "trial_observer_gap_p95_ms": bounds([row["p95_gap_ms"] for row in stats]),
        "trial_observer_longest_gap_ms": bounds([row["max_gap_ms"] for row in stats]),
        "trial_capture_window_p50_medians_ms": bounds([row["capture"]["window_p50_ms"]["median"]
                                                       for row in stats]),
        "trial_readback_window_p50_medians_ms": bounds([row["readback"]["window_p50_ms"]["median"]
                                                        for row in stats]),
        "trials_meeting_existing_27_unique_fps_target": sum(row["existing_27_fps_gate_met"] for row in stats),
        "stages": {
            role: {name: stage_rollup([case for case, _ in tested], role, path)
                   for name, path in list_definitions.items()}
            for role, list_definitions in STAGES.items()
        },
    }


def finalize(fixture, label):
    by_arm = {"cpu": [], "auto": []}
    trials = []
    build_pins = None
    for index, arm in enumerate(ORDER, 1):
        name = f"{label}-{index:02}-{arm}-fixed"
        attempts = []
        accepted = None
        for candidate in (name, f"{name}-retry"):
            directory = fixture / candidate
            log = fixture / f"{candidate}-error.log"
            if not directory.exists() and not log.exists() and candidate != name:
                continue
            attempt = {"case": candidate, "raw_directory": candidate if directory.exists() else None,
                       "failure_log": log.name if log.exists() else None}
            if (directory / "result.json").is_file():
                try:
                    case, stat = analyze_trial(directory, arm)
                    pins = stat["binary_pins"]
                    if build_pins is not None and pins != build_pins:
                        raise ValueError("binary pins differ from the other ABBA trials")
                    build_pins = pins
                except (OSError, ValueError, KeyError, TypeError) as error:
                    attempt.update(status="invalid_evidence", error=str(error))
                else:
                    attempt.update(status="valid", result=stat)
                    if accepted is None:
                        accepted = attempt
                        by_arm[arm].append((case, stat))
            else:
                attempt["status"] = "failed" if log.exists() else "missing_result"
            attempts.append(attempt)
        trials.append({"block": (index - 1) // 4 + 1, "order": index, "arm": arm,
                       "accepted_case": accepted["case"] if accepted else None, "attempts": attempts})
    done = all(trial["accepted_case"] for trial in trials)
    return {
        "schema_version": 1, "label": label, "status": "completed" if done else "incomplete",
        "role": "single host-side core GetImage versus direct MIT-SHM",
        "dimensions": EXPECTED_SIZE, "requested_fps": 30, "order": ORDER,
        "binary_pins": build_pins, "trials": trials,
        "arm_summaries": {arm: rollup(entries) for arm, entries in by_arm.items()},
        "method": "Unique content is counted in an exact 60-second observer interval after warmup. "
                  "Capture statistics describe window p50 and p95 values, not pooled frame quantiles. "
                  "Invalid, failed and retried attempts are retained with raw artifact paths. "
                  "Per-arm statistics use the first valid result for each planned position.",
        "link_notes": [path.name for path in (fixture / f"{label}-link-before.txt",
                                              fixture / f"{label}-link-after.txt") if path.is_file()],
    }


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--fixture", type=Path, default=LAB / "fixture")
    cli.add_argument("--label", default="readback-1440p")
    cli.add_argument("--controller-pid", type=int, default=791984)
    cli.add_argument("--controller-start-ticks", type=int, default=4858220)
    args = cli.parse_args()
    if still_running(args.controller_pid, args.controller_start_ticks):
        cli.error("formal ABBA controller is still running; leave the raw trials untouched")
    result = finalize(args.fixture, args.label)
    print(json.dumps(result, indent=2))
    return 0 if result["status"] == "completed" else 2


if __name__ == "__main__":
    raise SystemExit(main())
