#!/usr/bin/env bash
set -euo pipefail
fixture=$(cd "$(dirname "$0")" && pwd)
peer=ubuntu@192.168.0.78
python3 - <<'PY'
import os
from pathlib import Path
import select
import time

pid=791257
expected=b'/tmp/jwm-p09-candidate.CJJg2I/pilots-after-build.sh'
try:
    args=(Path('/proc')/str(pid)/'cmdline').read_bytes().split(b'\0')
    if expected not in args:
        raise RuntimeError('candidate pilot PID identity changed')
    fd=os.pidfd_open(pid)
except (FileNotFoundError, ProcessLookupError):
    print('Candidate pilot controller ended',flush=True)
else:
    print('Waiting for the candidate pilot controller',flush=True)
    waiter=select.poll()
    waiter.register(fd,select.POLLIN)
    deadline=time.monotonic()+7200
    while time.monotonic()<deadline:
        if waiter.poll(10000):
            print('Candidate pilot controller ended',flush=True)
            break
    else:
        raise SystemExit('Candidate pilot controller remains live at the scheduling deadline')
    os.close(fd)
PY
{
    flock 9
    old_remote=$(cat /tmp/jwm-p09-lab.0ZINwN/remote-dir)
    [[ "$old_remote" =~ ^/tmp/jwm-p09-lab\.[A-Za-z0-9]+$ ]]
    remote=$(ssh -o BatchMode=yes -o ConnectTimeout=5 "$peer" 'mktemp -d /tmp/jwm-p09-stage-ab.XXXXXXXX')
    [[ "$remote" =~ ^/tmp/jwm-p09-stage-ab\.[A-Za-z0-9]+$ ]]
    scp -q "$fixture"/{source.py,processes.py} "$peer:$remote/"
    painter_sha=$(ssh -o BatchMode=yes -o ConnectTimeout=5 "$peer" \
        "cp '$old_remote/p09-workload' '$remote/p09-workload' && sha256sum '$remote/p09-workload'" | cut -d' ' -f1)
    printf '%s\n' "$remote" >"$fixture/remote-dir"
    printf '%s\n' "$painter_sha" >"$fixture/painter-sha256"
} 9>/tmp/jwm-p08-p09-release/benchmark.lock
export LD_LIBRARY_PATH=/tmp/jwm-remote-ffmpeg/usr/lib/x86_64-linux-gnu
exec python3 -u "$fixture/benchmark.py" --remote-dir "$remote" --label readback-1440p \
    --painter-sha256 "$painter_sha" --width 2560 --height 1440 --retry-failed-trial
